import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 4);
        java.lang.String str6 = rectangleConstraint2.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]" + "'", str6.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-1.6777208E7d));
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        labelBlock1.setPaint((java.awt.Paint) color2);
        java.awt.Font font4 = labelBlock1.getFont();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment6);
        java.awt.geom.Rectangle2D rectangle2D8 = legendTitle1.getBounds();
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray14, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray18);
        java.lang.Comparable comparable20 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.data.general.Dataset) categoryDataset19, comparable20);
        java.lang.String str22 = legendItemBlockContainer21.getURLText();
        java.lang.String str23 = legendItemBlockContainer21.getURLText();
        legendTitle1.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer21);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        java.awt.Stroke stroke14 = legendItem13.getLineStroke();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem13.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer15);
        java.awt.Paint paint17 = legendItem13.getLinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(2);
        java.awt.Paint paint4 = paintList0.getPaint(2);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis0.setLabelFont(font5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean10 = legendItemCollection8.equals((java.lang.Object) layer9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle11.getVerticalAlignment();
        double double18 = textTitle11.getWidth();
        boolean boolean19 = layer9.equals((java.lang.Object) double18);
        java.util.Collection collection20 = categoryPlot7.getRangeMarkers(layer9);
        java.awt.Stroke stroke21 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis22.getLabelInsets();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, (java.awt.Paint) color24);
        int int26 = color24.getGreen();
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color24);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        numberAxis0.setLowerBound((double) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis12.setLeftArrow(shape14);
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape19 = defaultDrawingSupplier18.getNextShape();
        numberAxis12.setLeftArrow(shape19);
        statisticalBarRenderer11.setBaseShape(shape19);
        numberAxis0.setDownArrow(shape19);
        boolean boolean23 = numberAxis0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        jFreeChart6.fireChartChanged();
        float float8 = jFreeChart6.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart6.getTitle();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(textTitle9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle1.setPosition(rectangleEdge8);
        java.lang.String str10 = rectangleEdge8.toString();
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.RIGHT" + "'", str10.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100.0f);
        double double3 = rectangleConstraint2.getHeight();
        double double4 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator42 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator42);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        categoryPlot3.clearAnnotations();
        java.lang.String str8 = categoryPlot3.getNoDataMessage();
        categoryPlot3.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ItemLabelAnchor.OUTSIDE2", "AxisLocation.BOTTOM_OR_LEFT", "-4,-4,4,4", "");
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot2.setDomainAxisLocation((int) '#', axisLocation6, true);
        categoryPlot2.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot2.zoomDomainAxes((double) 100, (double) 128, plotRenderingInfo16, point2D17);
        org.jfree.chart.plot.Plot plot19 = categoryPlot2.getParent();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Color color5 = java.awt.Color.YELLOW;
        int int6 = color5.getRed();
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj10 = categoryAxis9.clone();
        boolean boolean11 = categoryAxis9.isVisible();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape14, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape14, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity23 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis9, shape14, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj25 = categoryAxis24.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis24.getLabelInsets();
        double double28 = rectangleInsets26.trimHeight(1.0d);
        double double30 = rectangleInsets26.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        java.awt.Paint paint33 = null;
        legendTitle32.setBackgroundPaint(paint33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle32.setLegendItemGraphicAnchor(rectangleAnchor35);
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle32.setVerticalAlignment(verticalAlignment37);
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle32.getBounds();
        rectangleInsets26.trim(rectangle2D39);
        axisLabelEntity23.setArea((java.awt.Shape) rectangle2D39);
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color5.createContext(colorModel7, rectangle8, rectangle2D39, affineTransform42, renderingHints43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        double double46 = size2D45.getHeight();
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle(legendItemSource51);
        java.awt.Paint paint53 = null;
        legendTitle52.setBackgroundPaint(paint53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = legendTitle52.getLegendItemGraphicLocation();
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape50, rectangleAnchor55, (double) (short) 1, (double) 2);
        java.awt.geom.Rectangle2D rectangle2D59 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 0.0d, (double) (byte) 1, rectangleAnchor55);
        org.jfree.chart.axis.AxisCollection axisCollection60 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj62 = categoryAxis61.clone();
        boolean boolean63 = categoryAxis61.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisCollection60.add((org.jfree.chart.axis.Axis) categoryAxis61, rectangleEdge64);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj68 = categoryAxis67.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean70 = categoryPlot69.isRangeGridlinesVisible();
        categoryAxis67.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot69);
        org.jfree.chart.JFreeChart jFreeChart72 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot69);
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color74 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke75 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = categoryAxis76.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder78 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color74, stroke75, rectangleInsets77);
        java.awt.Paint paint79 = lineBorder78.getPaint();
        boolean boolean80 = layer73.equals((java.lang.Object) lineBorder78);
        java.util.Collection collection81 = categoryPlot69.getDomainMarkers(layer73);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo84 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo84);
        org.jfree.chart.text.TextAnchor textAnchor88 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor89 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick91 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor88, textAnchor89, (double) (-1L));
        boolean boolean92 = plotRenderingInfo85.equals((java.lang.Object) numberTick91);
        java.awt.geom.Point2D point2D93 = null;
        categoryPlot69.zoomRangeAxes(10.0d, (double) 1L, plotRenderingInfo85, point2D93);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState95 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo85);
        try {
            org.jfree.chart.axis.AxisState axisState96 = numberAxis0.draw(graphics2D3, 0.0d, (java.awt.geom.Rectangle2D) rectangle8, rectangle2D59, rectangleEdge64, plotRenderingInfo85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-5.0d) + "'", double28 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(collection81);
        org.junit.Assert.assertNotNull(textAnchor88);
        org.junit.Assert.assertNotNull(textAnchor89);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "RectangleEdge.TOP");
        keyedObjects2D0.removeObject((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=97.0, height=0.05]", (java.lang.Comparable) (-15));
        int int7 = keyedObjects2D0.getRowCount();
        int int9 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toFixedHeight(0.2d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((-6.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape18 = statisticalBarRenderer0.lookupSeriesShape((int) (short) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = statisticalBarRenderer0.getURLGenerator((int) (short) 10, (int) 'a');
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.isRangeGridlinesVisible();
        java.awt.Image image25 = null;
        categoryPlot23.setBackgroundImage(image25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot27.setRowRenderingOrder(sortOrder28);
        categoryPlot23.setParent((org.jfree.chart.plot.Plot) categoryPlot27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick38 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor35, textAnchor36, (double) (-1L));
        boolean boolean39 = plotRenderingInfo32.equals((java.lang.Object) numberTick38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel41 = null;
        java.awt.Rectangle rectangle42 = null;
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        java.awt.Paint paint45 = null;
        legendTitle44.setBackgroundPaint(paint45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle44.setLegendItemGraphicAnchor(rectangleAnchor47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle44.setVerticalAlignment(verticalAlignment49);
        java.awt.geom.Rectangle2D rectangle2D51 = legendTitle44.getBounds();
        java.awt.geom.AffineTransform affineTransform52 = null;
        java.awt.RenderingHints renderingHints53 = null;
        java.awt.PaintContext paintContext54 = color40.createContext(colorModel41, rectangle42, rectangle2D51, affineTransform52, renderingHints53);
        plotRenderingInfo32.setDataArea(rectangle2D51);
        try {
            statisticalBarRenderer0.drawBackground(graphics2D22, categoryPlot27, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(paintContext54);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        java.lang.String str4 = lengthConstraintType3.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraintType.RANGE" + "'", str4.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge(15);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font1, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.lang.Object obj12 = jFreeChart11.clone();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart11.getLegend();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis15.setLeftArrow(shape17);
        numberAxis15.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        numberAxis15.setLeftArrow(shape22);
        statisticalBarRenderer14.setBaseShape(shape22);
        java.awt.Font font26 = statisticalBarRenderer14.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer14.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape32 = statisticalBarRenderer14.lookupSeriesShape((int) (short) 100);
        boolean boolean33 = statisticalBarRenderer14.getIncludeBaseInRange();
        java.awt.Paint paint35 = statisticalBarRenderer14.lookupSeriesPaint((int) (short) 1);
        jFreeChart11.setBackgroundPaint(paint35);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(font26);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("TextAnchor.CENTER");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        java.awt.Stroke stroke14 = legendItem13.getLineStroke();
        boolean boolean15 = legendItem13.isLineVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        double double5 = rectangleInsets1.calculateRightInset((double) 0L);
        double double7 = rectangleInsets1.extendHeight((double) (short) 10);
        double double9 = rectangleInsets1.calculateTopInset((double) ' ');
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets1.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.0d + "'", double7 == 16.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNotNull(unitType10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint5);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition((int) '4');
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesPaint(4);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer13.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean19 = plotRenderingInfo17.equals((java.lang.Object) color18);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis22.getLabelInsets();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, (java.awt.Paint) color24);
        legendTitle21.setItemPaint((java.awt.Paint) color24);
        java.awt.color.ColorSpace colorSpace27 = color24.getColorSpace();
        float[] floatArray33 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray34 = color18.getComponents(colorSpace27, floatArray33);
        statisticalBarRenderer13.setBaseItemLabelPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke38 = statisticalBarRenderer13.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj41 = categoryAxis40.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryAxis40.getLabelInsets();
        double double44 = rectangleInsets42.trimHeight(1.0d);
        double double46 = rectangleInsets42.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        java.awt.Paint paint49 = null;
        legendTitle48.setBackgroundPaint(paint49);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle48.setLegendItemGraphicAnchor(rectangleAnchor51);
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle48.setVerticalAlignment(verticalAlignment53);
        java.awt.geom.Rectangle2D rectangle2D55 = legendTitle48.getBounds();
        rectangleInsets42.trim(rectangle2D55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj58 = categoryAxis57.clone();
        categoryAxis57.setLabelToolTip("hi!");
        boolean boolean61 = categoryAxis57.isTickMarksVisible();
        java.awt.Font font62 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis57.setLabelFont(font62);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj65 = categoryAxis64.clone();
        categoryAxis64.setLabelToolTip("hi!");
        boolean boolean68 = categoryAxis64.isTickMarksVisible();
        java.awt.Font font69 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis64.setLabelFont(font69);
        categoryAxis57.setLabelFont(font69);
        categoryAxis57.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis();
        numberAxis74.setAutoRangeStickyZero(false);
        boolean boolean77 = numberAxis74.isInverted();
        org.jfree.chart.util.Layer layer78 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color79 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke80 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = categoryAxis81.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder83 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color79, stroke80, rectangleInsets82);
        java.awt.Paint paint84 = lineBorder83.getPaint();
        boolean boolean85 = layer78.equals((java.lang.Object) lineBorder83);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo86 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo86);
        statisticalBarRenderer13.drawAnnotations(graphics2D39, rectangle2D55, categoryAxis57, (org.jfree.chart.axis.ValueAxis) numberAxis74, layer78, plotRenderingInfo87);
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation12, layer78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-5.0d) + "'", double44 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(layer78);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(rectangleInsets82);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "HorizontalAlignment.RIGHT");
        java.lang.String str3 = chartEntity2.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-4,-4,4,4" + "'", str3.equals("-4,-4,4,4"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toFixedWidth((double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        categoryPlot3.setBackgroundImageAlpha((float) (short) 1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle0.setTextAlignment(horizontalAlignment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj10 = categoryAxis9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis9.getLabelInsets();
        double double13 = rectangleInsets11.trimHeight(1.0d);
        double double15 = rectangleInsets11.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        java.awt.Paint paint18 = null;
        legendTitle17.setBackgroundPaint(paint18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle17.setLegendItemGraphicAnchor(rectangleAnchor20);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle17.setVerticalAlignment(verticalAlignment22);
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle17.getBounds();
        rectangleInsets11.trim(rectangle2D24);
        java.awt.Color color26 = java.awt.Color.darkGray;
        java.lang.Object obj27 = textTitle0.draw(graphics2D8, rectangle2D24, (java.lang.Object) color26);
        java.awt.Paint paint28 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-5.0d) + "'", double13 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getDomainAxisEdge(15);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot2.getColumnRenderingOrder();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray12, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset17, false);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot2.getRendererForDataset(categoryDataset17);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 10.0d + "'", number20.equals(10.0d));
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        java.text.NumberFormat numberFormat6 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        categoryPlot3.clearAnnotations();
        int int8 = categoryPlot3.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot10.setRowRenderingOrder(sortOrder11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot10.setRangeAxisLocation(axisLocation13, true);
        categoryPlot3.setRangeAxisLocation(64, axisLocation13, false);
        categoryPlot3.setNoDataMessage("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape2, "hi!", "hi!");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity5.setArea(shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        legendItemEntity8.setSeriesKey((java.lang.Comparable) 0.2d);
        java.lang.String str11 = legendItemEntity8.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis0.setNumberFormatOverride(numberFormat4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range7 = numberAxis6.getRange();
        numberAxis0.setRangeWithMargins(range7);
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range7, (double) 0.0f);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("RectangleEdge.TOP");
        java.awt.Image image3 = null;
        projectInfo0.setLogo(image3);
        java.lang.String str5 = projectInfo0.toString();
        java.lang.String str6 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        projectInfo7.setLicenceName("RectangleEdge.TOP");
        java.awt.Image image10 = null;
        projectInfo7.setLogo(image10);
        java.util.List list12 = projectInfo7.getContributors();
        projectInfo0.setContributors(list12);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextAnchor.CENTER" + "'", str5.equals("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.CENTER" + "'", str6.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        legendTitle1.setNotify(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj12 = categoryAxis11.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isRangeGridlinesVisible();
        categoryAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getDomainAxisEdge(15);
        int int18 = categoryPlot13.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font10, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        java.awt.Paint paint22 = jFreeChart20.getBorderPaint();
        jFreeChart20.removeLegend();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat3 = numberAxis0.getNumberFormatOverride();
        numberAxis0.setAutoRangeIncludesZero(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj8 = categoryAxis7.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean10 = categoryPlot9.isRangeGridlinesVisible();
        categoryAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot9.getDomainAxisEdge(15);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot9.getColumnRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setFixedDimension((double) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj20 = categoryAxis19.clone();
        boolean boolean21 = categoryAxis19.isVisible();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis19.setAxisLinePaint((java.awt.Paint) color22);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape24, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape24, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis19, shape24, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj35 = categoryAxis34.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryAxis34.getLabelInsets();
        double double38 = rectangleInsets36.trimHeight(1.0d);
        double double40 = rectangleInsets36.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource41 = null;
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle(legendItemSource41);
        java.awt.Paint paint43 = null;
        legendTitle42.setBackgroundPaint(paint43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle42.setLegendItemGraphicAnchor(rectangleAnchor45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle42.setVerticalAlignment(verticalAlignment47);
        java.awt.geom.Rectangle2D rectangle2D49 = legendTitle42.getBounds();
        rectangleInsets36.trim(rectangle2D49);
        axisLabelEntity33.setArea((java.awt.Shape) rectangle2D49);
        org.jfree.chart.axis.AxisCollection axisCollection52 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj54 = categoryAxis53.clone();
        boolean boolean55 = categoryAxis53.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisCollection52.add((org.jfree.chart.axis.Axis) categoryAxis53, rectangleEdge56);
        double double58 = numberAxis15.valueToJava2D(20.0d, rectangle2D49, rectangleEdge56);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj60 = categoryAxis59.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean62 = categoryPlot61.isRangeGridlinesVisible();
        categoryAxis59.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot61);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot61.getDomainAxisEdge(15);
        org.jfree.chart.axis.AxisSpace axisSpace66 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace67 = numberAxis0.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot9, rectangle2D49, rectangleEdge65, axisSpace66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-5.0d) + "'", double38 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-117.0d) + "'", double58 == (-117.0d));
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        double double4 = numberAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("AxisLabelEntity: label = null");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name AxisLabelEntity: label = null, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot6);
        jFreeChart9.fireChartChanged();
        float float11 = jFreeChart9.getBackgroundImageAlpha();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeGridlineStroke();
        try {
            categoryPlot0.mapDatasetToRangeAxis((-1), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMaximumBarWidth();
        boolean boolean3 = statisticalBarRenderer0.isSeriesItemLabelsVisible(192);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(100, categoryToolTipGenerator5, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = statisticalBarRenderer0.getBaseToolTipGenerator();
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke28 = statisticalBarRenderer0.getItemOutlineStroke(4, (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font1);
        java.awt.Paint paint3 = textFragment2.getPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer4.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean10 = plotRenderingInfo8.equals((java.lang.Object) color9);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets14, (java.awt.Paint) color15);
        legendTitle12.setItemPaint((java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace18 = color15.getColorSpace();
        float[] floatArray24 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray25 = color9.getComponents(colorSpace18, floatArray24);
        statisticalBarRenderer4.setBaseItemLabelPaint((java.awt.Paint) color9);
        boolean boolean27 = textFragment2.equals((java.lang.Object) statisticalBarRenderer4);
        java.awt.Font font28 = null;
        try {
            statisticalBarRenderer4.setBaseItemLabelFont(font28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape18 = statisticalBarRenderer0.lookupSeriesShape((int) (short) 100);
        boolean boolean19 = statisticalBarRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint21 = statisticalBarRenderer0.lookupSeriesPaint((int) (short) 1);
        statisticalBarRenderer0.setBaseSeriesVisible(false);
        boolean boolean24 = statisticalBarRenderer0.isDrawBarOutline();
        java.awt.Paint paint26 = statisticalBarRenderer0.getSeriesOutlinePaint(0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot6);
        jFreeChart9.fireChartChanged();
        float float11 = jFreeChart9.getBackgroundImageAlpha();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis13.setLeftArrow(shape15);
        numberAxis13.setNegativeArrowVisible(true);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection22 = categoryPlot0.getRangeMarkers((int) ' ', layer21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray13, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray17);
        java.lang.Comparable comparable19 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.data.general.Dataset) categoryDataset18, comparable19);
        categoryPlot3.setDataset(2, categoryDataset18);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset18);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor7, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape0, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer14.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean20 = plotRenderingInfo18.equals((java.lang.Object) color19);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis23.getLabelInsets();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(rectangleInsets24, (java.awt.Paint) color25);
        legendTitle22.setItemPaint((java.awt.Paint) color25);
        java.awt.color.ColorSpace colorSpace28 = color25.getColorSpace();
        float[] floatArray34 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray35 = color19.getComponents(colorSpace28, floatArray34);
        statisticalBarRenderer14.setBaseItemLabelPaint((java.awt.Paint) color19);
        java.awt.Stroke stroke39 = statisticalBarRenderer14.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint41 = statisticalBarRenderer14.lookupSeriesPaint((int) (byte) -1);
        java.awt.Paint paint42 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        statisticalBarRenderer14.setBasePaint(paint42);
        boolean boolean44 = tickLabelEntity13.equals((java.lang.Object) statisticalBarRenderer14);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        statisticalBarRenderer14.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator46);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator48 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        statisticalBarRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator48);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle0.setTextAlignment(horizontalAlignment6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment8, (double) 100, (double) 255);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range16 = numberAxis15.getRange();
        double double17 = range16.getLowerBound();
        boolean boolean20 = range16.intersects((-5.0d), 16.0d);
        org.jfree.data.Range range22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(100.0d, range22);
        double double24 = rectangleConstraint23.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint23.toFixedHeight((double) 4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = rectangleConstraint23.getWidthConstraintType();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis29.setLeftArrow(shape31);
        boolean boolean33 = numberAxis29.getAutoRangeStickyZero();
        org.jfree.data.Range range34 = numberAxis29.getDefaultAutoRange();
        double double35 = range34.getUpperBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range16, lengthConstraintType27, 0.05d, range34, lengthConstraintType36);
        java.lang.String str38 = rectangleConstraint37.toString();
        try {
            org.jfree.chart.util.Size2D size2D39 = columnArrangement11.arrange(blockContainer12, graphics2D13, rectangleConstraint37);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=97.0, height=0.05]" + "'", str38.equals("RectangleConstraint[LengthConstraintType.FIXED: width=97.0, height=0.05]"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range2 = numberAxis1.getRange();
        double double3 = range2.getLowerBound();
        boolean boolean6 = range2.intersects((-5.0d), 16.0d);
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(100.0d, range8);
        double double10 = rectangleConstraint9.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedHeight((double) 4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = rectangleConstraint9.getWidthConstraintType();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis15.setLeftArrow(shape17);
        boolean boolean19 = numberAxis15.getAutoRangeStickyZero();
        org.jfree.data.Range range20 = numberAxis15.getDefaultAutoRange();
        double double21 = range20.getUpperBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range2, lengthConstraintType13, 0.05d, range20, lengthConstraintType22);
        java.lang.String str24 = lengthConstraintType13.toString();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "LengthConstraintType.FIXED" + "'", str24.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range5 = numberAxis4.getRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) ' ');
        numberAxis1.setDefaultAutoRange(range7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(0.2d, range7);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = statisticalBarRenderer0.getBaseToolTipGenerator();
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint27 = statisticalBarRenderer0.getSeriesItemLabelPaint(4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean27 = statisticalBarRenderer0.getSeriesVisible(2);
        java.awt.Paint paint29 = statisticalBarRenderer0.getSeriesOutlinePaint(255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = blockContainer0.equals((java.lang.Object) "GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setAutoRangeStickyZero(false);
        boolean boolean6 = numberAxis3.isInverted();
        org.jfree.data.Range range7 = numberAxis3.getRange();
        boolean boolean8 = blockContainer0.equals((java.lang.Object) numberAxis3);
        double double9 = blockContainer0.getHeight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot6);
        jFreeChart9.fireChartChanged();
        float float11 = jFreeChart9.getBackgroundImageAlpha();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.setNoDataMessage("EXPAND");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        blockResult0.setEntityCollection(entityCollection2);
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ItemLabelAnchor.OUTSIDE2", "HorizontalAlignment.RIGHT", "Range[0.0,1.0]", "RectangleEdge.RIGHT");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        java.awt.Paint paint14 = statisticalBarRenderer0.lookupSeriesOutlinePaint((-15));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint5);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition((int) '4');
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesPaint(4);
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeGridlinesVisible();
        java.awt.Image image19 = null;
        categoryPlot17.setBackgroundImage(image19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot17.getFixedRangeAxisSpace();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(false);
        boolean boolean25 = numberAxis22.isInverted();
        org.jfree.data.Range range26 = numberAxis22.getRange();
        double double27 = numberAxis22.getLowerBound();
        numberAxis22.setTickLabelsVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis22.setMarkerBand(markerAxisBand30);
        boolean boolean32 = numberAxis22.getAutoRangeStickyZero();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel34 = null;
        java.awt.Rectangle rectangle35 = null;
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        java.awt.Paint paint38 = null;
        legendTitle37.setBackgroundPaint(paint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle37.setLegendItemGraphicAnchor(rectangleAnchor40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle37.setVerticalAlignment(verticalAlignment42);
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle37.getBounds();
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color33.createContext(colorModel34, rectangle35, rectangle2D44, affineTransform45, renderingHints46);
        try {
            statisticalBarRenderer0.drawRangeGridline(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis22, (java.awt.geom.Rectangle2D) rectangle35, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(paintContext47);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        boolean boolean3 = numberAxis0.isInverted();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint10);
        statisticalBarRenderer5.setBaseItemLabelPaint(paint10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape14 = defaultDrawingSupplier13.getNextShape();
        java.awt.Stroke stroke15 = defaultDrawingSupplier13.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj18 = categoryAxis17.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean20 = categoryPlot19.isRangeGridlinesVisible();
        categoryAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot19);
        java.lang.Object obj23 = jFreeChart22.clone();
        java.lang.Object obj24 = jFreeChart22.getTextAntiAlias();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke26, rectangleInsets28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = lineBorder29.getInsets();
        jFreeChart22.setPadding(rectangleInsets30);
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder(paint10, stroke15, rectangleInsets30);
        numberAxis0.setLabelInsets(rectangleInsets30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis35.setLeftArrow(shape37);
        numberAxis35.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape42 = defaultDrawingSupplier41.getNextShape();
        numberAxis35.setLeftArrow(shape42);
        statisticalBarRenderer34.setBaseShape(shape42);
        java.awt.Font font46 = statisticalBarRenderer34.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer34.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape52 = statisticalBarRenderer34.lookupSeriesShape((int) (short) 100);
        boolean boolean53 = statisticalBarRenderer34.getIncludeBaseInRange();
        java.awt.Paint paint55 = statisticalBarRenderer34.lookupSeriesPaint((int) (short) 1);
        boolean boolean56 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) numberAxis0, (java.lang.Object) paint55);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(font46);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("Range[0.0,1.0]", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        jFreeChart6.fireChartChanged();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) (byte) 100, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        flowArrangement12.add((org.jfree.chart.block.Block) textTitle13, (java.lang.Object) itemLabelAnchor14);
        jFreeChart6.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart6.getLegend(10);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNull(legendTitle18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.setLabelToolTip("EXPAND");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape6, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape6, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj17 = categoryAxis16.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean19 = categoryPlot18.isRangeGridlinesVisible();
        categoryAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = categoryAxis16.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition();
        double double23 = categoryLabelPosition22.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions21, categoryLabelPosition22);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions24);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        categoryPlot0.setRangeGridlinePaint(paint18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 255);
        double double3 = blockParams0.getTranslateX();
        double double4 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean5 = legendItemCollection3.equals((java.lang.Object) layer4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle6.getVerticalAlignment();
        double double13 = textTitle6.getWidth();
        boolean boolean14 = layer4.equals((java.lang.Object) double13);
        java.util.Collection collection15 = categoryPlot2.getRangeMarkers(layer4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        categoryPlot2.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot2.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.util.BooleanList booleanList22 = new org.jfree.chart.util.BooleanList();
        booleanList22.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray29, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray33);
        java.lang.Comparable comparable35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer36 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement24, (org.jfree.data.general.Dataset) categoryDataset34, comparable35);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList22, (org.jfree.data.general.Dataset) categoryDataset34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot2.getRendererForDataset(categoryDataset34);
        boolean boolean39 = categoryPlot2.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis40.setLabel("hi!");
        java.awt.Paint paint43 = categoryAxis40.getLabelPaint();
        float float44 = categoryAxis40.getMaximumCategoryLabelWidthRatio();
        categoryPlot2.setDomainAxis(categoryAxis40);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("GradientPaintTransformType.CENTER_VERTICAL", "hi!", "VerticalAlignment.CENTER", "", "");
        basicProjectInfo5.setVersion("TextAnchor.CENTER");
        basicProjectInfo5.setName("GradientPaintTransformType.CENTER_VERTICAL");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleEdge.RIGHT", graphics2D1, (float) 1L, 100.0f, (double) 8, (float) (-1), (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (short) 1, (java.lang.Boolean) false, true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle0.setTextAlignment(horizontalAlignment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj10 = categoryAxis9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis9.getLabelInsets();
        double double13 = rectangleInsets11.trimHeight(1.0d);
        double double15 = rectangleInsets11.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        java.awt.Paint paint18 = null;
        legendTitle17.setBackgroundPaint(paint18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle17.setLegendItemGraphicAnchor(rectangleAnchor20);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle17.setVerticalAlignment(verticalAlignment22);
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle17.getBounds();
        rectangleInsets11.trim(rectangle2D24);
        java.awt.Color color26 = java.awt.Color.darkGray;
        java.lang.Object obj27 = textTitle0.draw(graphics2D8, rectangle2D24, (java.lang.Object) color26);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        textTitle28.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        textTitle28.setExpandToFitSpace(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle28.setHorizontalAlignment(horizontalAlignment36);
        textTitle0.setTextAlignment(horizontalAlignment36);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-5.0d) + "'", double13 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape29, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape29, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor36, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape29, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        numberAxis28.setUpArrow(shape29);
        statisticalBarRenderer0.setBaseShape(shape29, true);
        java.awt.Paint paint47 = statisticalBarRenderer0.getSeriesPaint(4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.TickType tickType4 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str8 = textAnchor7.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10, categoryLabelWidthType11, 0.0f);
        double double14 = categoryLabelPosition13.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor15 = categoryLabelPosition13.getRotationAnchor();
        org.jfree.chart.axis.NumberTick numberTick17 = new org.jfree.chart.axis.NumberTick(tickType4, 16.0d, "", textAnchor7, textAnchor15, (double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType21 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20, categoryLabelWidthType21, 0.0f);
        double double24 = categoryLabelPosition23.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryLabelPosition23.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor26 = categoryLabelPosition23.getRotationAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", graphics2D1, (float) 100, (float) 4, textAnchor15, 20.0d, textAnchor26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickType4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.CENTER" + "'", str8.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(categoryLabelWidthType21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) categoryPlot3);
        java.util.List list7 = categoryPlot3.getCategories();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot3.notifyListeners(plotChangeEvent8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot3.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) (-1L));
        java.lang.String str6 = numberTick5.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape29, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape29, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor36, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape29, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        numberAxis28.setUpArrow(shape29);
        statisticalBarRenderer0.setBaseShape(shape29, true);
        java.awt.Paint paint47 = statisticalBarRenderer0.getSeriesPaint(4);
        boolean boolean50 = statisticalBarRenderer0.getItemVisible(128, 192);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder52 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot51.setRowRenderingOrder(sortOrder52);
        java.lang.String str54 = categoryPlot51.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection55 = categoryPlot51.getLegendItems();
        boolean boolean56 = statisticalBarRenderer0.equals((java.lang.Object) legendItemCollection55);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(sortOrder52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Category Plot" + "'", str54.equals("Category Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint4 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(16.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot3.getDomainAxisEdge(15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = categoryLabelPositions0.getLabelPosition(rectangleEdge7);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(categoryLabelPosition8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMaximumBarWidth();
        double double2 = statisticalBarRenderer0.getMinimumBarLength();
        double double3 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        categoryAxis4.setLabelToolTip("hi!");
        boolean boolean8 = categoryAxis4.isTickMarksVisible();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis4.setLabelFont(font9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj12 = categoryAxis11.clone();
        categoryAxis11.setLabelToolTip("hi!");
        boolean boolean15 = categoryAxis11.isTickMarksVisible();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis11.setLabelFont(font16);
        categoryAxis4.setLabelFont(font16);
        statisticalBarRenderer0.setBaseItemLabelFont(font16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setLabel("hi!");
        java.awt.Paint paint5 = categoryAxis2.getLabelPaint();
        categoryAxis2.setTickMarksVisible(false);
        java.awt.Font font9 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 1L);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj11 = categoryAxis10.clone();
        java.lang.String str13 = categoryAxis10.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis10.setLabelInsets(rectangleInsets14);
        java.awt.Paint paint16 = categoryAxis10.getTickLabelPaint();
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("hi!", font9, paint16);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("TextAnchor.CENTER", font9);
        java.awt.Font font19 = textFragment18.getFont();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        java.lang.Object obj4 = categoryAxis0.clone();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "TextAnchor.CENTER");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke2, rectangleInsets4);
        java.awt.Paint paint6 = lineBorder5.getPaint();
        boolean boolean7 = layer0.equals((java.lang.Object) lineBorder5);
        java.awt.Paint paint8 = lineBorder5.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = lineBorder5.getInsets();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = categoryPlot0.getRangeAxisIndex(valueAxis5);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.setLabelToolTip("EXPAND");
        java.lang.Object obj6 = null;
        boolean boolean7 = categoryAxis0.equals(obj6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj10 = categoryAxis9.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isRangeGridlinesVisible();
        categoryAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot11);
        boolean boolean15 = categoryAxis0.hasListener((java.util.EventListener) jFreeChart14);
        try {
            org.jfree.chart.plot.XYPlot xYPlot16 = jFreeChart14.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = categoryAxis0.getTickLabelFont();
        java.lang.String str6 = categoryAxis0.getLabel();
        categoryAxis0.setCategoryMargin((double) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        double double14 = rectangleInsets10.calculateRightInset((double) 0L);
        double double16 = rectangleInsets10.extendHeight((double) (short) 10);
        double double18 = rectangleInsets10.calculateTopInset((double) ' ');
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 16.0d + "'", double16 == 16.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = statisticalBarRenderer0.getSeriesToolTipGenerator(0);
        java.awt.Font font3 = null;
        try {
            statisticalBarRenderer0.setBaseItemLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        statisticalBarRenderer0.setBasePaint(paint28);
        boolean boolean31 = statisticalBarRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Font font32 = statisticalBarRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint34 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder(paint34);
        try {
            statisticalBarRenderer0.setSeriesFillPaint((int) (byte) -1, paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
        centerArrangement0.clear();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Color color2 = java.awt.Color.RED;
        java.awt.Color color3 = color2.darker();
        boolean boolean4 = defaultDrawingSupplier0.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("HorizontalAlignment.RIGHT", graphics2D1, (float) 500, 0.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("HorizontalAlignment.RIGHT", "VerticalAlignment.CENTER", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", "-4,-4,4,4");
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("RectangleEdge.TOP");
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.util.List list4 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.CENTER" + "'", str3.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        java.awt.Stroke stroke14 = legendItem13.getLineStroke();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem13.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer15);
        java.awt.GradientPaint gradientPaint17 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer18.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean24 = plotRenderingInfo22.equals((java.lang.Object) color23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getLabelInsets();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder(rectangleInsets28, (java.awt.Paint) color29);
        legendTitle26.setItemPaint((java.awt.Paint) color29);
        java.awt.color.ColorSpace colorSpace32 = color29.getColorSpace();
        float[] floatArray38 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray39 = color23.getComponents(colorSpace32, floatArray38);
        statisticalBarRenderer18.setBaseItemLabelPaint((java.awt.Paint) color23);
        java.awt.Stroke stroke43 = statisticalBarRenderer18.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint45 = statisticalBarRenderer18.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape47, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity53 = new org.jfree.chart.entity.ChartEntity(shape47, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape47, rectangleAnchor54, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity60 = new org.jfree.chart.entity.TickLabelEntity(shape47, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        numberAxis46.setUpArrow(shape47);
        statisticalBarRenderer18.setBaseShape(shape47, true);
        try {
            java.awt.GradientPaint gradientPaint64 = standardGradientPaintTransformer15.transform(gradientPaint17, shape47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(shape57);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryPlot2.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj7 = categoryAxis6.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isRangeGridlinesVisible();
        categoryAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot8);
        jFreeChart11.fireChartChanged();
        float float13 = jFreeChart11.getBackgroundImageAlpha();
        categoryPlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart11);
        java.awt.Stroke stroke15 = categoryPlot2.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot16.setRowRenderingOrder(sortOrder17);
        java.lang.String str19 = categoryPlot16.getPlotType();
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot16.setRangeGridlinePaint((java.awt.Paint) color20);
        java.awt.Color color22 = color20.darker();
        java.awt.Stroke stroke23 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(2.0d, paint1, stroke15, (java.awt.Paint) color20, stroke23, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean2 = blockBorder0.equals((java.lang.Object) categoryLabelPositions1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        double double27 = statisticalBarRenderer0.getUpperClip();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape29, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape29, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor36, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape29, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        numberAxis28.setUpArrow(shape29);
        statisticalBarRenderer0.setBaseShape(shape29, true);
        java.awt.Paint paint47 = statisticalBarRenderer0.getSeriesPaint(4);
        java.awt.Paint paint49 = statisticalBarRenderer0.getSeriesItemLabelPaint((int) (short) -1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNull(paint49);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 192, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", textAnchor2, textAnchor3, (-1.6777208E7d));
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((int) (short) 100);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        categoryAxis0.setTickMarksVisible(false);
        categoryAxis0.setUpperMargin(20.0d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis0.setNumberFormatOverride(numberFormat4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range7 = numberAxis6.getRange();
        numberAxis0.setRangeWithMargins(range7);
        boolean boolean9 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getRed();
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj17 = categoryAxis16.clone();
        boolean boolean18 = categoryAxis16.isVisible();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis16.setAxisLinePaint((java.awt.Paint) color19);
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape21, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape21, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity30 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis16, shape21, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj32 = categoryAxis31.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis31.getLabelInsets();
        double double35 = rectangleInsets33.trimHeight(1.0d);
        double double37 = rectangleInsets33.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        java.awt.Paint paint40 = null;
        legendTitle39.setBackgroundPaint(paint40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle39.setLegendItemGraphicAnchor(rectangleAnchor42);
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle39.setVerticalAlignment(verticalAlignment44);
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle39.getBounds();
        rectangleInsets33.trim(rectangle2D46);
        axisLabelEntity30.setArea((java.awt.Shape) rectangle2D46);
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color12.createContext(colorModel14, rectangle15, rectangle2D46, affineTransform49, renderingHints50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list53 = numberAxis0.refreshTicks(graphics2D10, axisState11, (java.awt.geom.Rectangle2D) rectangle15, rectangleEdge52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-5.0d) + "'", double35 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(paintContext51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("EXPAND", "HorizontalAlignment.RIGHT", "hi!", "HorizontalAlignment.RIGHT");
        basicProjectInfo4.addOptionalLibrary("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("HorizontalAlignment.RIGHT", "rect", "TextAnchor.CENTER", "VerticalAlignment.CENTER");
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        jFreeChart6.setPadding(rectangleInsets14);
        org.jfree.chart.plot.Plot plot16 = jFreeChart6.getPlot();
        jFreeChart6.setAntiAlias(false);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        java.awt.Paint paint21 = null;
        legendTitle20.setBackgroundPaint(paint21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle20.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle20.getMargin();
        jFreeChart6.addSubtitle((org.jfree.chart.title.Title) legendTitle20);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        java.awt.Color color6 = color4.darker();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean10 = legendItemCollection8.equals((java.lang.Object) layer9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle11.getVerticalAlignment();
        double double18 = textTitle11.getWidth();
        boolean boolean19 = layer9.equals((java.lang.Object) double18);
        java.util.Collection collection20 = categoryPlot7.getRangeMarkers(layer9);
        java.awt.Stroke stroke21 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis22.getLabelInsets();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, (java.awt.Paint) color24);
        double double27 = rectangleInsets23.calculateRightInset((double) 0L);
        double double29 = rectangleInsets23.extendHeight((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke21, rectangleInsets23);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj32 = categoryAxis31.clone();
        boolean boolean33 = categoryAxis31.isVisible();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis31.setAxisLinePaint((java.awt.Paint) color34);
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape36, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity(shape36, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity45 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis31, shape36, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj47 = categoryAxis46.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryAxis46.getLabelInsets();
        double double50 = rectangleInsets48.trimHeight(1.0d);
        double double52 = rectangleInsets48.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource53 = null;
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle(legendItemSource53);
        java.awt.Paint paint55 = null;
        legendTitle54.setBackgroundPaint(paint55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle54.setLegendItemGraphicAnchor(rectangleAnchor57);
        org.jfree.chart.util.VerticalAlignment verticalAlignment59 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle54.setVerticalAlignment(verticalAlignment59);
        java.awt.geom.Rectangle2D rectangle2D61 = legendTitle54.getBounds();
        rectangleInsets48.trim(rectangle2D61);
        axisLabelEntity45.setArea((java.awt.Shape) rectangle2D61);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.Shape shape65 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape69 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape65, (double) 2, (float) 100, (float) 100);
        boolean boolean70 = lengthAdjustmentType64.equals((java.lang.Object) shape69);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType71 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets23.createAdjustedRectangle(rectangle2D61, lengthAdjustmentType64, lengthAdjustmentType71);
        boolean boolean74 = lengthAdjustmentType64.equals((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 16.0d + "'", double29 == 16.0d);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-5.0d) + "'", double50 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 4.0d + "'", double52 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(verticalAlignment59);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(lengthAdjustmentType64);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        jFreeChart6.clearSubtitles();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor7, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape0, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray20, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset25);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "VerticalAlignment.CENTER", "Range[0.0,1.0]", categoryDataset25, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Comparable) 20.0d);
        org.jfree.data.KeyedObjects2D keyedObjects2D30 = new org.jfree.data.KeyedObjects2D();
        int int31 = keyedObjects2D30.getRowCount();
        java.util.List list32 = keyedObjects2D30.getRowKeys();
        boolean boolean33 = categoryItemEntity29.equals((java.lang.Object) list32);
        java.lang.String str34 = categoryItemEntity29.getShapeType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass36 = chartChangeEventType35.getClass();
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] { numberArray42, numberArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray46);
        java.lang.Comparable comparable48 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement37, (org.jfree.data.general.Dataset) categoryDataset47, comparable48);
        boolean boolean50 = chartChangeEventType35.equals((java.lang.Object) flowArrangement37);
        boolean boolean51 = categoryItemEntity29.equals((java.lang.Object) boolean50);
        java.lang.Comparable comparable52 = categoryItemEntity29.getColumnKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 20.0d + "'", number26.equals(20.0d));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "rect" + "'", str34.equals("rect"));
        org.junit.Assert.assertNotNull(chartChangeEventType35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 20.0d + "'", comparable52.equals(20.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        legendTitle1.setNotify(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj12 = categoryAxis11.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isRangeGridlinesVisible();
        categoryAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getDomainAxisEdge(15);
        int int18 = categoryPlot13.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font10, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        int int22 = jFreeChart20.getSubtitleCount();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition8, true);
        statisticalBarRenderer0.setBase((double) 100L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray5, numberArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray9);
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) categoryDataset10, comparable11);
        org.jfree.data.general.Dataset dataset13 = legendItemBlockContainer12.getDataset();
        org.jfree.chart.block.Arrangement arrangement14 = legendItemBlockContainer12.getArrangement();
        legendItemBlockContainer12.setHeight((-1.0d));
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(dataset13);
        org.junit.Assert.assertNotNull(arrangement14);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        categoryPlot0.setRangeGridlinePaint(paint18);
        categoryPlot0.mapDatasetToDomainAxis(0, (-192));
        org.jfree.chart.plot.Plot plot24 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(plot24);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        double double7 = textTitle0.getWidth();
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle0.arrange(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray13, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray17);
        java.lang.Comparable comparable19 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.data.general.Dataset) categoryDataset18, comparable19);
        categoryPlot3.setDataset(2, categoryDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace22);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 0.0d);
        try {
            keyedObjects2D0.removeRow(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        boolean boolean3 = numberAxis0.isInverted();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint10);
        statisticalBarRenderer5.setBaseItemLabelPaint(paint10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape14 = defaultDrawingSupplier13.getNextShape();
        java.awt.Stroke stroke15 = defaultDrawingSupplier13.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj18 = categoryAxis17.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean20 = categoryPlot19.isRangeGridlinesVisible();
        categoryAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot19);
        java.lang.Object obj23 = jFreeChart22.clone();
        java.lang.Object obj24 = jFreeChart22.getTextAntiAlias();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke26, rectangleInsets28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = lineBorder29.getInsets();
        jFreeChart22.setPadding(rectangleInsets30);
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder(paint10, stroke15, rectangleInsets30);
        numberAxis0.setLabelInsets(rectangleInsets30);
        float float34 = numberAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) (-1L));
        java.lang.Object obj6 = numberTick5.clone();
        org.jfree.chart.text.TextAnchor textAnchor7 = numberTick5.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick5.getTextAnchor();
        java.lang.Object obj9 = numberTick5.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        double double7 = range5.constrain((double) (short) -1);
        java.lang.String str8 = range5.toString();
        org.jfree.data.Range range11 = org.jfree.data.Range.expand(range5, (double) (-1.0f), (double) '#');
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range5, 0.0d, 3.0d);
        double double15 = range14.getLowerBound();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Range[0.0,1.0]" + "'", str8.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        categoryPlot0.setAnchorValue(4.0d, true);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        categoryPlot3.clearAnnotations();
        categoryPlot3.mapDatasetToDomainAxis((int) (byte) 1, 128);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot3.getOrientation();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        statisticalBarRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        double double14 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.BooleanList booleanList15 = new org.jfree.chart.util.BooleanList();
        booleanList15.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray22, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray26);
        java.lang.Comparable comparable28 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17, (org.jfree.data.general.Dataset) categoryDataset27, comparable28);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList15, (org.jfree.data.general.Dataset) categoryDataset27);
        org.jfree.data.general.Dataset dataset31 = datasetChangeEvent30.getDataset();
        categoryPlot0.datasetChanged(datasetChangeEvent30);
        java.awt.Stroke stroke33 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot0.getDomainAxisLocation(1);
        categoryPlot0.setRangeCrosshairValue(3.0d);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(dataset31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape6 = defaultDrawingSupplier5.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape6, "hi!", "hi!");
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        labelBlock11.setPaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("rect", "", "", "MINOR", shape6, (java.awt.Paint) color12);
        java.awt.Shape shape16 = legendItem15.getLine();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape18 = statisticalBarRenderer0.lookupSeriesShape((int) (short) 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer0.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isRangeGridlinesVisible();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj26 = categoryAxis25.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean28 = categoryPlot27.isRangeGridlinesVisible();
        categoryAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot27);
        jFreeChart30.fireChartChanged();
        float float32 = jFreeChart30.getBackgroundImageAlpha();
        categoryPlot21.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart30);
        java.awt.Stroke stroke34 = categoryPlot21.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedDimension((double) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj40 = categoryAxis39.clone();
        boolean boolean41 = categoryAxis39.isVisible();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis39.setAxisLinePaint((java.awt.Paint) color42);
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape44, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity(shape44, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity53 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis39, shape44, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj55 = categoryAxis54.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = categoryAxis54.getLabelInsets();
        double double58 = rectangleInsets56.trimHeight(1.0d);
        double double60 = rectangleInsets56.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        java.awt.Paint paint63 = null;
        legendTitle62.setBackgroundPaint(paint63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle62.setLegendItemGraphicAnchor(rectangleAnchor65);
        org.jfree.chart.util.VerticalAlignment verticalAlignment67 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle62.setVerticalAlignment(verticalAlignment67);
        java.awt.geom.Rectangle2D rectangle2D69 = legendTitle62.getBounds();
        rectangleInsets56.trim(rectangle2D69);
        axisLabelEntity53.setArea((java.awt.Shape) rectangle2D69);
        org.jfree.chart.axis.AxisCollection axisCollection72 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj74 = categoryAxis73.clone();
        boolean boolean75 = categoryAxis73.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisCollection72.add((org.jfree.chart.axis.Axis) categoryAxis73, rectangleEdge76);
        double double78 = numberAxis35.valueToJava2D(20.0d, rectangle2D69, rectangleEdge76);
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D20, categoryPlot21, rectangle2D69, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.5f + "'", float32 == 0.5f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-5.0d) + "'", double58 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 4.0d + "'", double60 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(verticalAlignment67);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + (-117.0d) + "'", double78 == (-117.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        java.lang.String str6 = numberAxis0.getLabelToolTip();
        java.awt.Shape shape7 = numberAxis0.getRightArrow();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis0.getMarkerBand();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis0.setNumberFormatOverride(numberFormat9);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(markerAxisBand8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Shape shape27 = statisticalBarRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        boolean boolean7 = categoryPlot3.isOutlineVisible();
        categoryPlot3.mapDatasetToDomainAxis((int) (byte) 10, 64);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot3);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint5);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition((int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis16.setLeftArrow(shape18);
        numberAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape23 = defaultDrawingSupplier22.getNextShape();
        numberAxis16.setLeftArrow(shape23);
        statisticalBarRenderer15.setBaseShape(shape23);
        java.awt.Font font27 = statisticalBarRenderer15.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer15.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape33 = statisticalBarRenderer15.lookupSeriesShape((int) (short) 100);
        try {
            statisticalBarRenderer0.setSeriesShape((int) (short) -1, shape33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        categoryPlot3.clearAnnotations();
        int int8 = categoryPlot3.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot10.setRowRenderingOrder(sortOrder11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot10.setRangeAxisLocation(axisLocation13, true);
        categoryPlot3.setRangeAxisLocation(64, axisLocation13, false);
        categoryPlot3.setNoDataMessage("Category Plot");
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj22 = categoryAxis21.clone();
        boolean boolean23 = categoryAxis21.isVisible();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis21.setAxisLinePaint((java.awt.Paint) color24);
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape26, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape26, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity35 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis21, shape26, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        boolean boolean36 = categoryAxis21.isVisible();
        categoryAxis21.setLabelAngle((double) (byte) 100);
        categoryPlot3.setDomainAxis((int) ' ', categoryAxis21);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj6 = categoryAxis5.clone();
        categoryAxis5.setLabelToolTip("hi!");
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets12);
        categoryAxis5.setTickMarkStroke(stroke10);
        java.util.List list15 = categoryPlot0.getCategoriesForAxis(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        categoryPlot0.setRangeGridlinePaint(paint18);
        java.lang.String str21 = categoryPlot0.getNoDataMessage();
        java.lang.Object obj22 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge(15);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font1, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.lang.Object obj12 = jFreeChart11.clone();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart11.getLegend();
        java.awt.Stroke stroke14 = jFreeChart11.getBorderStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor7, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape0, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray20, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset25);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "VerticalAlignment.CENTER", "Range[0.0,1.0]", categoryDataset25, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Comparable) 20.0d);
        java.lang.String str30 = categoryItemEntity29.toString();
        java.awt.Font font32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean36 = legendItemCollection34.equals((java.lang.Object) layer35);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        textTitle37.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = textTitle37.getVerticalAlignment();
        double double44 = textTitle37.getWidth();
        boolean boolean45 = layer35.equals((java.lang.Object) double44);
        java.util.Collection collection46 = categoryPlot33.getRangeMarkers(layer35);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        categoryPlot33.datasetChanged(datasetChangeEvent47);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        categoryPlot33.rendererChanged(rendererChangeEvent49);
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("Category Plot", font32, (org.jfree.chart.plot.Plot) categoryPlot33, false);
        org.jfree.chart.util.BooleanList booleanList53 = new org.jfree.chart.util.BooleanList();
        booleanList53.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement55 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray60 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray64 = new java.lang.Number[][] { numberArray60, numberArray63 };
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray64);
        java.lang.Comparable comparable66 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer67 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement55, (org.jfree.data.general.Dataset) categoryDataset65, comparable66);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent68 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList53, (org.jfree.data.general.Dataset) categoryDataset65);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = categoryPlot33.getRendererForDataset(categoryDataset65);
        categoryItemEntity29.setDataset(categoryDataset65);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 20.0d + "'", number26.equals(20.0d));
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNull(categoryItemRenderer69);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint42 = statisticalBarRenderer0.getBasePaint();
        boolean boolean43 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        statisticalBarRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle1.setPosition(rectangleEdge8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray4, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset9, false);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-2.0d) + "'", number12.equals((-2.0d)));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getDomainAxisEdge(15);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj11 = categoryAxis10.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        categoryAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets20);
        java.awt.Paint paint22 = lineBorder21.getPaint();
        boolean boolean23 = layer16.equals((java.lang.Object) lineBorder21);
        java.util.Collection collection24 = categoryPlot12.getDomainMarkers(layer16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick34 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor31, textAnchor32, (double) (-1L));
        boolean boolean35 = plotRenderingInfo28.equals((java.lang.Object) numberTick34);
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot12.zoomRangeAxes(10.0d, (double) 1L, plotRenderingInfo28, point2D36);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState38 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo28);
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot2.zoomRangeAxes(0.0d, (double) 255, plotRenderingInfo28, point2D39);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape2, "hi!", "hi!");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity5.setArea(shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        java.awt.Font font10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = legendItemCollection12.equals((java.lang.Object) layer13);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        textTitle15.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle15.getVerticalAlignment();
        double double22 = textTitle15.getWidth();
        boolean boolean23 = layer13.equals((java.lang.Object) double22);
        java.util.Collection collection24 = categoryPlot11.getRangeMarkers(layer13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("Category Plot", font10, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        org.jfree.chart.util.BooleanList booleanList31 = new org.jfree.chart.util.BooleanList();
        booleanList31.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray38, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray42);
        java.lang.Comparable comparable44 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer45 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, (org.jfree.data.general.Dataset) categoryDataset43, comparable44);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList31, (org.jfree.data.general.Dataset) categoryDataset43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot11.getRendererForDataset(categoryDataset43);
        legendItemEntity8.setDataset((org.jfree.data.general.Dataset) categoryDataset43);
        java.lang.String str49 = legendItemEntity8.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(categoryItemRenderer47);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition5);
        statisticalBarRenderer0.setDrawBarOutline(true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj4 = categoryAxis3.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean6 = categoryPlot5.isRangeGridlinesVisible();
        categoryAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot5.getDomainAxisEdge(15);
        int int10 = categoryPlot5.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font2, (org.jfree.chart.plot.Plot) categoryPlot5, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean16 = plotRenderingInfo14.equals((java.lang.Object) color15);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, (java.awt.Paint) color21);
        legendTitle18.setItemPaint((java.awt.Paint) color21);
        java.awt.color.ColorSpace colorSpace24 = color21.getColorSpace();
        float[] floatArray30 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray31 = color15.getComponents(colorSpace24, floatArray30);
        org.jfree.chart.text.TextMeasurer textMeasurer34 = null;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color15, (float) 4, 0, textMeasurer34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor40 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType41 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition43 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor39, textBlockAnchor40, categoryLabelWidthType41, 0.0f);
        double double44 = categoryLabelPosition43.getAngle();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = categoryLabelPosition43.getLabelAnchor();
        java.awt.Shape shape49 = textBlock35.calculateBounds(graphics2D36, 10.0f, (float) (byte) -1, textBlockAnchor45, (float) 192, 2.0f, (double) 4);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis51.setLabel("hi!");
        java.awt.Paint paint54 = categoryAxis51.getLabelPaint();
        categoryAxis51.setTickMarksVisible(false);
        java.awt.Font font58 = categoryAxis51.getTickLabelFont((java.lang.Comparable) 1L);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj60 = categoryAxis59.clone();
        java.lang.String str62 = categoryAxis59.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis59.setLabelInsets(rectangleInsets63);
        java.awt.Paint paint65 = categoryAxis59.getTickLabelPaint();
        org.jfree.chart.text.TextLine textLine66 = new org.jfree.chart.text.TextLine("hi!", font58, paint65);
        textBlock35.addLine(textLine66);
        java.awt.Font font69 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment70 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font69);
        java.awt.Font font71 = textFragment70.getFont();
        float float72 = textFragment70.getBaselineOffset();
        textLine66.removeFragment(textFragment70);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(textBlock35);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(textBlockAnchor40);
        org.junit.Assert.assertNotNull(categoryLabelWidthType41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertTrue("'" + float72 + "' != '" + 0.0f + "'", float72 == 0.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.RangeType rangeType5 = numberAxis0.getRangeType();
        numberAxis0.setLowerBound(0.0d);
        try {
            numberAxis0.setRange((double) (byte) 1, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        org.jfree.chart.text.TextFragment textFragment3 = null;
        textLine0.removeFragment(textFragment3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = textLine0.calculateDimensions(graphics2D5);
        org.junit.Assert.assertNotNull(size2D6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        categoryPlot3.clearAnnotations();
        org.jfree.chart.axis.TickType tickType8 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot9.setRowRenderingOrder(sortOrder10);
        java.lang.String str12 = categoryPlot9.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        boolean boolean14 = tickType8.equals((java.lang.Object) legendItemCollection13);
        categoryPlot3.setFixedLegendItems(legendItemCollection13);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(tickType8);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean27 = statisticalBarRenderer0.getSeriesVisible(2);
        double double28 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        java.awt.Shape shape29 = statisticalBarRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Stroke stroke3 = defaultDrawingSupplier1.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis4.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke3, rectangleInsets5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean5 = legendItemCollection3.equals((java.lang.Object) layer4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle6.getVerticalAlignment();
        double double13 = textTitle6.getWidth();
        boolean boolean14 = layer4.equals((java.lang.Object) double13);
        java.util.Collection collection15 = categoryPlot2.getRangeMarkers(layer4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        categoryPlot2.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot2.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.util.BooleanList booleanList22 = new org.jfree.chart.util.BooleanList();
        booleanList22.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray29, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray33);
        java.lang.Comparable comparable35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer36 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement24, (org.jfree.data.general.Dataset) categoryDataset34, comparable35);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList22, (org.jfree.data.general.Dataset) categoryDataset34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot2.getRendererForDataset(categoryDataset34);
        boolean boolean39 = categoryPlot2.isRangeZoomable();
        categoryPlot2.configureRangeAxes();
        categoryPlot2.setRangeCrosshairValue(0.05d);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = categoryAxis0.getTickLabelFont();
        java.lang.String str6 = categoryAxis0.getLabel();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot4);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis((-15));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray11);
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement2, (org.jfree.data.general.Dataset) categoryDataset12, comparable13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList0, (org.jfree.data.general.Dataset) categoryDataset12);
        int int16 = booleanList0.size();
        booleanList0.setBoolean((int) (byte) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.setLabelToolTip("EXPAND");
        java.lang.Object obj6 = null;
        boolean boolean7 = categoryAxis0.equals(obj6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj10 = categoryAxis9.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isRangeGridlinesVisible();
        categoryAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot11);
        boolean boolean15 = categoryAxis0.hasListener((java.util.EventListener) jFreeChart14);
        java.awt.Color color16 = java.awt.Color.yellow;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape18 = statisticalBarRenderer0.lookupSeriesShape((int) (short) 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer0.getLegendItemURLGenerator();
        java.lang.Object obj20 = statisticalBarRenderer0.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        legendTitle1.setNotify(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj12 = categoryAxis11.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isRangeGridlinesVisible();
        categoryAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getDomainAxisEdge(15);
        int int18 = categoryPlot13.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font10, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(paint22);
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder23);
        java.awt.Graphics2D graphics2D25 = null;
        try {
            org.jfree.chart.util.Size2D size2D26 = legendTitle1.arrange(graphics2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Range[0.0,1.0]");
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(drawingSupplier2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        numberAxis0.setLowerBound((double) (byte) -1);
        boolean boolean11 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0.0d, (java.lang.Object) rectangleInsets13);
        numberAxis0.setLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis0.getTickUnit();
        boolean boolean17 = numberAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge(15);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font1, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.util.List list12 = jFreeChart11.getSubtitles();
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart11.addProgressListener(chartProgressListener13);
        java.awt.RenderingHints renderingHints15 = jFreeChart11.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        textTitle16.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle16.getVerticalAlignment();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj26 = textTitle16.draw(graphics2D23, rectangle2D24, (java.lang.Object) flowArrangement25);
        jFreeChart11.addSubtitle((org.jfree.chart.title.Title) textTitle16);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(renderingHints15);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean27 = statisticalBarRenderer0.getSeriesVisible(2);
        double double28 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        java.awt.Paint paint31 = statisticalBarRenderer0.getItemLabelPaint(0, 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("-4,-4,4,4", "", "LengthConstraintType.FIXED", "");
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets11);
        java.awt.Paint paint13 = lineBorder12.getPaint();
        boolean boolean14 = layer7.equals((java.lang.Object) lineBorder12);
        java.util.Collection collection15 = categoryPlot3.getDomainMarkers(layer7);
        float float16 = categoryPlot3.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot3.getRangeAxisLocation(192);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        statisticalBarRenderer0.setBasePaint(paint28);
        boolean boolean31 = statisticalBarRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Paint paint32 = statisticalBarRenderer0.getErrorIndicatorPaint();
        try {
            statisticalBarRenderer0.setSeriesVisible((-15), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        java.lang.String str6 = labelBlock5.getURLText();
        java.awt.Font font7 = labelBlock5.getFont();
        java.awt.Color color8 = java.awt.Color.white;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        java.awt.Paint paint11 = null;
        legendTitle10.setBackgroundPaint(paint11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle10.setVerticalAlignment(verticalAlignment15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle10.setPosition(rectangleEdge17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(false);
        boolean boolean24 = numberAxis21.isInverted();
        org.jfree.data.Range range25 = numberAxis21.getRange();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint31);
        statisticalBarRenderer26.setBaseItemLabelPaint(paint31);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape35 = defaultDrawingSupplier34.getNextShape();
        java.awt.Stroke stroke36 = defaultDrawingSupplier34.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj39 = categoryAxis38.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean41 = categoryPlot40.isRangeGridlinesVisible();
        categoryAxis38.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot40);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot40);
        java.lang.Object obj44 = jFreeChart43.clone();
        java.lang.Object obj45 = jFreeChart43.getTextAntiAlias();
        java.awt.Color color46 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis48.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color46, stroke47, rectangleInsets49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = lineBorder50.getInsets();
        jFreeChart43.setPadding(rectangleInsets51);
        org.jfree.chart.block.LineBorder lineBorder53 = new org.jfree.chart.block.LineBorder(paint31, stroke36, rectangleInsets51);
        numberAxis21.setLabelInsets(rectangleInsets51);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("GradientPaintTransformType.CENTER_VERTICAL", font7, (java.awt.Paint) color8, rectangleEdge17, horizontalAlignment19, verticalAlignment20, rectangleInsets51);
        categoryAxis0.setTickLabelFont(font7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = blockContainer0.equals((java.lang.Object) "GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setAutoRangeStickyZero(false);
        boolean boolean6 = numberAxis3.isInverted();
        org.jfree.data.Range range7 = numberAxis3.getRange();
        boolean boolean8 = blockContainer0.equals((java.lang.Object) numberAxis3);
        boolean boolean9 = numberAxis3.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment6);
        double double8 = legendTitle1.getContentYOffset();
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-192), (double) ' ', 0.0d, (double) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("hi!");
        java.awt.Paint paint9 = categoryAxis6.getLabelPaint();
        categoryAxis6.setTickMarksVisible(false);
        java.awt.Font font13 = categoryAxis6.getTickLabelFont((java.lang.Comparable) 1L);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj15 = categoryAxis14.clone();
        java.lang.String str17 = categoryAxis14.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis14.setLabelInsets(rectangleInsets18);
        java.awt.Paint paint20 = categoryAxis14.getTickLabelPaint();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font13, paint20);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint20);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean27 = statisticalBarRenderer0.getSeriesVisible(2);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint33);
        statisticalBarRenderer28.setBaseItemLabelPaint(paint33);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalBarRenderer28.getSeriesPositiveItemLabelPosition((int) '4');
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition37);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(3, categoryToolTipGenerator40);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = statisticalBarRenderer0.getPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(categoryPlot5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        legendTitle1.setID("TextAnchor.CENTER");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        jFreeChart6.setPadding(rectangleInsets14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        textTitle16.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle16.getVerticalAlignment();
        textTitle16.setText("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        jFreeChart6.setTitle(textTitle16);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(verticalAlignment22);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("EXPAND", "HorizontalAlignment.RIGHT", "hi!", "HorizontalAlignment.RIGHT");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("", "TextAnchor.CENTER", "TextAnchor.CENTER", "GradientPaintTransformType.CENTER_VERTICAL");
        basicProjectInfo9.setInfo("TextAnchor.CENTER");
        java.lang.String str12 = basicProjectInfo9.getInfo();
        java.lang.String str13 = basicProjectInfo9.getName();
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        basicProjectInfo9.addOptionalLibrary("TextAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.CENTER" + "'", str12.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.setLabelToolTip("EXPAND");
        java.lang.Object obj6 = null;
        boolean boolean7 = categoryAxis0.equals(obj6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj10 = categoryAxis9.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isRangeGridlinesVisible();
        categoryAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot11);
        boolean boolean15 = categoryAxis0.hasListener((java.util.EventListener) jFreeChart14);
        java.lang.Object obj16 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getDomainAxisEdge(15);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.LegendItemCollection legendItemCollection8 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean10 = legendItemCollection8.equals((java.lang.Object) layer9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle11.getVerticalAlignment();
        double double18 = textTitle11.getWidth();
        boolean boolean19 = layer9.equals((java.lang.Object) double18);
        try {
            categoryPlot2.addRangeMarker(marker7, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        java.text.AttributedString attributedString14 = legendItem13.getAttributedLabel();
        int int15 = legendItem13.getSeriesIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNull(attributedString14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        boolean boolean3 = numberAxis0.isInverted();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        java.awt.Shape shape5 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        java.awt.Stroke stroke14 = legendItem13.getLineStroke();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem13.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer15);
        legendItem13.setSeriesIndex(0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        java.awt.Paint paint27 = null;
        legendTitle26.setBackgroundPaint(paint27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle26.getLegendItemGraphicLocation();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, rectangleAnchor29, (double) (short) 1, (double) 2);
        statisticalBarRenderer0.setBaseShape(shape24, false);
        java.awt.Font font37 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font37);
        java.awt.Font font39 = textFragment38.getFont();
        statisticalBarRenderer0.setSeriesItemLabelFont(4, font39, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot2.setDomainAxisLocation((int) '#', axisLocation6, true);
        categoryPlot2.setRangeGridlinesVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            categoryPlot2.addAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getLabelInsets();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, (java.awt.Paint) color5);
        legendTitle2.setItemPaint((java.awt.Paint) color5);
        double double8 = legendTitle2.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle2.getMargin();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer10.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean16 = plotRenderingInfo14.equals((java.lang.Object) color15);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, (java.awt.Paint) color21);
        legendTitle18.setItemPaint((java.awt.Paint) color21);
        java.awt.color.ColorSpace colorSpace24 = color21.getColorSpace();
        float[] floatArray30 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray31 = color15.getComponents(colorSpace24, floatArray30);
        statisticalBarRenderer10.setBaseItemLabelPaint((java.awt.Paint) color15);
        java.awt.Stroke stroke35 = statisticalBarRenderer10.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint37 = statisticalBarRenderer10.lookupSeriesPaint((int) (byte) -1);
        statisticalBarRenderer10.setIncludeBaseInRange(false);
        java.awt.Stroke stroke40 = statisticalBarRenderer10.getBaseOutlineStroke();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment41, verticalAlignment42, (double) (byte) 100, (double) (-1));
        flowArrangement45.clear();
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle();
        textTitle47.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = textTitle47.getVerticalAlignment();
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj57 = textTitle47.draw(graphics2D54, rectangle2D55, (java.lang.Object) flowArrangement56);
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer10, (org.jfree.chart.block.Arrangement) flowArrangement45, (org.jfree.chart.block.Arrangement) flowArrangement56);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) legendTitle58);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.title.LegendTitle cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertNull(obj57);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass3 = chartChangeEventType2.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass5 = chartChangeEventType4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        boolean boolean7 = textAnchor0.equals((java.lang.Object) wildcardClass3);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis8.setLeftArrow(shape10);
        boolean boolean12 = numberAxis8.getAutoRangeStickyZero();
        boolean boolean13 = textAnchor0.equals((java.lang.Object) boolean12);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        jFreeChart6.fireChartChanged();
        float float8 = jFreeChart6.getBackgroundImageAlpha();
        boolean boolean9 = jFreeChart6.getAntiAlias();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(false);
        boolean boolean14 = numberAxis11.isInverted();
        org.jfree.data.Range range15 = numberAxis11.getRange();
        double double16 = numberAxis11.getLowerBound();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis11.setMarkerBand(markerAxisBand17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis22.getLabelInsets();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, (java.awt.Paint) color24);
        double double27 = rectangleInsets23.calculateLeftOutset((double) (byte) 1);
        boolean boolean28 = plotRenderingInfo21.equals((java.lang.Object) double27);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo21.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = numberAxis11.valueToJava2D(0.0d, rectangle2D29, rectangleEdge30);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        try {
            jFreeChart6.draw(graphics2D10, rectangle2D29, chartRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets11);
        java.awt.Paint paint13 = lineBorder12.getPaint();
        boolean boolean14 = layer7.equals((java.lang.Object) lineBorder12);
        java.util.Collection collection15 = categoryPlot3.getDomainMarkers(layer7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor22, textAnchor23, (double) (-1L));
        boolean boolean26 = plotRenderingInfo19.equals((java.lang.Object) numberTick25);
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot3.zoomRangeAxes(10.0d, (double) 1L, plotRenderingInfo19, point2D27);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo19);
        org.jfree.chart.entity.EntityCollection entityCollection30 = categoryItemRendererState29.getEntityCollection();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(entityCollection30);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = plotRenderingInfo7.equals((java.lang.Object) color8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getLabelInsets();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets13, (java.awt.Paint) color14);
        legendTitle11.setItemPaint((java.awt.Paint) color14);
        java.awt.color.ColorSpace colorSpace17 = color14.getColorSpace();
        float[] floatArray23 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray24 = color8.getComponents(colorSpace17, floatArray23);
        statisticalBarRenderer3.setBaseItemLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.util.BooleanList booleanList26 = new org.jfree.chart.util.BooleanList();
        booleanList26.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement28 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray33, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray37);
        java.lang.Comparable comparable39 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement28, (org.jfree.data.general.Dataset) categoryDataset38, comparable39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList26, (org.jfree.data.general.Dataset) categoryDataset38);
        org.jfree.data.Range range42 = statisticalBarRenderer3.findRangeBounds(categoryDataset38);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset38);
        numberAxis0.setRangeWithMargins(range43);
        numberAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        labelBlock1.setURLText("HorizontalAlignment.RIGHT");
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        labelBlock1.setFont(font4);
        labelBlock1.setToolTipText("AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isAxisLineVisible();
        boolean boolean10 = labelBlock1.equals((java.lang.Object) boolean9);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot6);
        jFreeChart9.fireChartChanged();
        float float11 = jFreeChart9.getBackgroundImageAlpha();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart9.createBufferedImage(255, (int) 'a', 15, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("RectangleEdge.TOP");
        java.awt.Image image3 = null;
        projectInfo0.setLogo(image3);
        java.util.List list5 = projectInfo0.getContributors();
        java.lang.String str6 = projectInfo0.toString();
        projectInfo0.setLicenceName("LengthConstraintType.FIXED");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextAnchor.CENTER" + "'", str6.equals("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextAnchor.CENTER"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        boolean boolean7 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis8.getLabelInsets();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, (java.awt.Paint) color10);
        double double13 = rectangleInsets9.calculateRightInset((double) 0L);
        double double15 = rectangleInsets9.extendHeight((double) (short) 10);
        categoryPlot3.setAxisOffset(rectangleInsets9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj19 = categoryAxis18.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean21 = categoryPlot20.isRangeGridlinesVisible();
        categoryAxis18.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke26, rectangleInsets28);
        java.awt.Paint paint30 = lineBorder29.getPaint();
        boolean boolean31 = layer24.equals((java.lang.Object) lineBorder29);
        java.util.Collection collection32 = categoryPlot20.getDomainMarkers(layer24);
        java.util.Collection collection33 = categoryPlot3.getRangeMarkers(layer24);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 16.0d + "'", double15 == 16.0d);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNull(collection33);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Font font1 = categoryPlot0.getNoDataMessageFont();
        boolean boolean2 = categoryPlot0.isSubplot();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((-1.6777208E7d), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge(15);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font1, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.util.List list12 = jFreeChart11.getSubtitles();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        try {
            jFreeChart11.plotChanged(plotChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        categoryPlot0.setNoDataMessage("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation3, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot0.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot0.getParent();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        plotRenderingInfo12.setPlotArea(rectangle2D13);
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomDomainAxes(16.0d, 0.0d, plotRenderingInfo12, point2D15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj18 = categoryAxis17.clone();
        categoryAxis17.setLabelToolTip("hi!");
        boolean boolean21 = categoryAxis17.isTickMarksVisible();
        java.awt.Font font22 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis17.setLabelFont(font22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj25 = categoryAxis24.clone();
        categoryAxis24.setLabelToolTip("hi!");
        boolean boolean28 = categoryAxis24.isTickMarksVisible();
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis24.setLabelFont(font29);
        categoryAxis17.setLabelFont(font29);
        int int32 = categoryAxis17.getMaximumCategoryLabelLines();
        categoryAxis17.setTickLabelsVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder36 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot35.setRowRenderingOrder(sortOrder36);
        java.lang.String str38 = categoryPlot35.getPlotType();
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot35.setRangeGridlinePaint((java.awt.Paint) color39);
        java.awt.Color color41 = color39.darker();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean45 = legendItemCollection43.equals((java.lang.Object) layer44);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        textTitle46.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment52 = textTitle46.getVerticalAlignment();
        double double53 = textTitle46.getWidth();
        boolean boolean54 = layer44.equals((java.lang.Object) double53);
        java.util.Collection collection55 = categoryPlot42.getRangeMarkers(layer44);
        java.awt.Stroke stroke56 = categoryPlot42.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = categoryAxis57.getLabelInsets();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder60 = new org.jfree.chart.block.BlockBorder(rectangleInsets58, (java.awt.Paint) color59);
        double double62 = rectangleInsets58.calculateRightInset((double) 0L);
        double double64 = rectangleInsets58.extendHeight((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder65 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color39, stroke56, rectangleInsets58);
        categoryAxis17.setTickMarkStroke(stroke56);
        categoryPlot0.setOutlineStroke(stroke56);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Category Plot" + "'", str38.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(verticalAlignment52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 3.0d + "'", double62 == 3.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 16.0d + "'", double64 == 16.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) categoryPlot3);
        java.util.List list7 = categoryPlot3.getCategories();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot3.notifyListeners(plotChangeEvent8);
        categoryPlot3.clearRangeMarkers();
        java.lang.String str11 = categoryPlot3.getPlotType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        int int3 = color0.getRed();
        int int4 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass3 = chartChangeEventType2.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass5 = chartChangeEventType4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        java.lang.ClassLoader classLoader7 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleEdge.RIGHT", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(classLoader7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean9 = plotRenderingInfo7.equals((java.lang.Object) color8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getLabelInsets();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets13, (java.awt.Paint) color14);
        legendTitle11.setItemPaint((java.awt.Paint) color14);
        java.awt.color.ColorSpace colorSpace17 = color14.getColorSpace();
        float[] floatArray23 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray24 = color8.getComponents(colorSpace17, floatArray23);
        statisticalBarRenderer3.setBaseItemLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.util.BooleanList booleanList26 = new org.jfree.chart.util.BooleanList();
        booleanList26.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement28 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray33, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray37);
        java.lang.Comparable comparable39 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement28, (org.jfree.data.general.Dataset) categoryDataset38, comparable39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList26, (org.jfree.data.general.Dataset) categoryDataset38);
        org.jfree.data.Range range42 = statisticalBarRenderer3.findRangeBounds(categoryDataset38);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset38);
        numberAxis0.setRangeWithMargins(range43);
        org.jfree.data.Range range47 = org.jfree.data.Range.expand(range43, (double) 8, 261.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range47);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        legendTitle1.setNotify(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment10, (double) (byte) 100, (double) (-1));
        legendTitle1.setVerticalAlignment(verticalAlignment10);
        java.awt.Font font15 = legendTitle1.getItemFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = legendTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = statisticalBarRenderer0.getSeriesURLGenerator((int) (short) -1);
        statisticalBarRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("MINOR");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle0.setTextAlignment(horizontalAlignment6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment8, (double) 100, (double) 255);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean16 = plotRenderingInfo14.equals((java.lang.Object) color15);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, (java.awt.Paint) color21);
        legendTitle18.setItemPaint((java.awt.Paint) color21);
        java.awt.color.ColorSpace colorSpace24 = color21.getColorSpace();
        float[] floatArray30 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray31 = color15.getComponents(colorSpace24, floatArray30);
        float[] floatArray32 = color12.getColorComponents(floatArray31);
        boolean boolean33 = horizontalAlignment6.equals((java.lang.Object) floatArray32);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent4.setChart(jFreeChart5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent4.setType(chartChangeEventType7);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-192));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot2.setDomainAxisLocation((int) '#', axisLocation6, true);
        categoryPlot2.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range12 = numberAxis11.getRange();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets14, (java.awt.Paint) color15);
        double double18 = rectangleInsets14.trimHeight(0.0d);
        numberAxis11.setLabelInsets(rectangleInsets14);
        int int20 = categoryPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        categoryPlot2.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-6.0d) + "'", double18 == (-6.0d));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9, categoryLabelWidthType10, 0.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor9);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType14 = categoryLabelPosition13.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16, categoryLabelWidthType17, 0.0f);
        double double20 = categoryLabelPosition19.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor22 = categoryLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition19.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType26 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition28 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor24, textBlockAnchor25, categoryLabelWidthType26, 0.0f);
        double double29 = categoryLabelPosition28.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor30 = categoryLabelPosition28.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor31 = categoryLabelPosition28.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType34 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor32, textBlockAnchor33, categoryLabelWidthType34, 0.0f);
        double double37 = categoryLabelPosition36.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor38 = categoryLabelPosition36.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition39 = new org.jfree.chart.axis.CategoryLabelPosition();
        double double40 = categoryLabelPosition39.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions41 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition19, categoryLabelPosition28, categoryLabelPosition36, categoryLabelPosition39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType44 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition46 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor42, textBlockAnchor43, categoryLabelWidthType44, 0.0f);
        double double47 = categoryLabelPosition46.getAngle();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor48 = categoryLabelPosition46.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor50 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType51 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition53 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor49, textBlockAnchor50, categoryLabelWidthType51, 0.0f);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions54 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition13, categoryLabelPosition39, categoryLabelPosition46, categoryLabelPosition53);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(categoryLabelWidthType26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertNotNull(categoryLabelWidthType34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertNotNull(categoryLabelWidthType44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor48);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(textBlockAnchor50);
        org.junit.Assert.assertNotNull(categoryLabelWidthType51);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle1.getLegendItemGraphicEdge();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        categoryAxis0.setLowerMargin((double) (byte) 10);
        java.awt.Paint paint7 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType1 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass2 = chartChangeEventType1.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass4 = chartChangeEventType3.getClass();
        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass2, (java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader6);
        org.junit.Assert.assertNotNull(chartChangeEventType1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(classLoader6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation8, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = statisticalBarRenderer0.getToolTipGenerator(3, 10);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int48 = color47.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color47);
        statisticalBarRenderer0.setSeriesPaint(0, (java.awt.Paint) color47);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(categoryToolTipGenerator45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        jFreeChart6.setPadding(rectangleInsets14);
        org.jfree.chart.plot.Plot plot16 = jFreeChart6.getPlot();
        jFreeChart6.setAntiAlias(false);
        float float19 = jFreeChart6.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        categoryAxis0.setTickMarksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getTickLabelInsets();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        textTitle0.setExpandToFitSpace(false);
        java.lang.String str8 = textTitle0.getText();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setLabel("hi!");
        java.awt.Paint paint13 = categoryAxis10.getLabelPaint();
        categoryAxis10.setTickMarksVisible(false);
        java.awt.Font font17 = categoryAxis10.getTickLabelFont((java.lang.Comparable) 1L);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj19 = categoryAxis18.clone();
        java.lang.String str21 = categoryAxis18.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis18.setLabelInsets(rectangleInsets22);
        java.awt.Paint paint24 = categoryAxis18.getTickLabelPaint();
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("hi!", font17, paint24);
        textTitle0.setFont(font17);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation3, true);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        categoryPlot0.setRangeGridlinePaint(paint18);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot0.getFixedLegendItems();
        float float22 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Stroke stroke23 = categoryPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        java.text.NumberFormat numberFormat5 = null;
        numberAxis1.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range8 = numberAxis7.getRange();
        numberAxis1.setRangeWithMargins(range8);
        boolean boolean10 = color0.equals((java.lang.Object) range8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = legendTitle1.getHorizontalAlignment();
        java.lang.String str9 = horizontalAlignment8.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "HorizontalAlignment.CENTER" + "'", str9.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot2.setDomainAxisLocation((int) '#', axisLocation6, true);
        categoryPlot2.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range12 = numberAxis11.getRange();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets14, (java.awt.Paint) color15);
        double double18 = rectangleInsets14.trimHeight(0.0d);
        numberAxis11.setLabelInsets(rectangleInsets14);
        int int20 = categoryPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        numberAxis11.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-6.0d) + "'", double18 == (-6.0d));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        boolean boolean14 = legendItem13.isShapeVisible();
        java.awt.Paint paint15 = legendItem13.getLinePaint();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape16, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, rectangleAnchor23, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity29 = new org.jfree.chart.entity.TickLabelEntity(shape16, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray36, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray40);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset41);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "VerticalAlignment.CENTER", "Range[0.0,1.0]", categoryDataset41, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Comparable) 20.0d);
        org.jfree.data.KeyedObjects2D keyedObjects2D46 = new org.jfree.data.KeyedObjects2D();
        int int47 = keyedObjects2D46.getRowCount();
        java.util.List list48 = keyedObjects2D46.getRowKeys();
        boolean boolean49 = categoryItemEntity45.equals((java.lang.Object) list48);
        java.lang.String str50 = categoryItemEntity45.getShapeType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer51 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        boolean boolean52 = categoryItemEntity45.equals((java.lang.Object) standardGradientPaintTransformer51);
        legendItem13.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer51);
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        java.awt.Paint paint56 = null;
        legendTitle55.setBackgroundPaint(paint56);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle55.setLegendItemGraphicAnchor(rectangleAnchor58);
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle55.setVerticalAlignment(verticalAlignment60);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment62 = legendTitle55.getHorizontalAlignment();
        boolean boolean63 = standardGradientPaintTransformer51.equals((java.lang.Object) horizontalAlignment62);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 20.0d + "'", number42.equals(20.0d));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "rect" + "'", str50.equals("rect"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(verticalAlignment60);
        org.junit.Assert.assertNotNull(horizontalAlignment62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 128);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (short) 10, (java.lang.Number) 10.0f, (java.lang.Comparable) (short) 100, (java.lang.Comparable) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj3 = keyedObjects0.clone();
        java.lang.Object obj5 = keyedObjects0.getObject((int) (short) 100);
        java.lang.Object obj7 = keyedObjects0.getObject((java.lang.Comparable) 10.0d);
        int int9 = keyedObjects0.getIndex((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape2, "hi!", "hi!");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity5.setArea(shape6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        legendItemEntity8.setSeriesKey((java.lang.Comparable) 0.2d);
        java.lang.Comparable comparable11 = legendItemEntity8.getSeriesKey();
        java.lang.String str12 = legendItemEntity8.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.2d + "'", comparable11.equals(0.2d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LegendItemEntity: seriesKey=0.2, dataset=null" + "'", str12.equals("LegendItemEntity: seriesKey=0.2, dataset=null"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer4.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean10 = plotRenderingInfo8.equals((java.lang.Object) color9);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets14, (java.awt.Paint) color15);
        legendTitle12.setItemPaint((java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace18 = color15.getColorSpace();
        float[] floatArray24 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray25 = color9.getComponents(colorSpace18, floatArray24);
        statisticalBarRenderer4.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Stroke stroke29 = statisticalBarRenderer4.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean31 = statisticalBarRenderer4.getSeriesVisible(2);
        java.awt.Stroke stroke33 = statisticalBarRenderer4.getSeriesStroke((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator34 = statisticalBarRenderer4.getLegendItemURLGenerator();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4, true);
        java.awt.Font font38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = legendItemCollection40.equals((java.lang.Object) layer41);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        textTitle43.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = textTitle43.getVerticalAlignment();
        double double50 = textTitle43.getWidth();
        boolean boolean51 = layer41.equals((java.lang.Object) double50);
        java.util.Collection collection52 = categoryPlot39.getRangeMarkers(layer41);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent53 = null;
        categoryPlot39.datasetChanged(datasetChangeEvent53);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent55 = null;
        categoryPlot39.rendererChanged(rendererChangeEvent55);
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Category Plot", font38, (org.jfree.chart.plot.Plot) categoryPlot39, false);
        org.jfree.chart.util.BooleanList booleanList59 = new org.jfree.chart.util.BooleanList();
        booleanList59.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement61 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray66 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] { numberArray66, numberArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray70);
        java.lang.Comparable comparable72 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer73 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement61, (org.jfree.data.general.Dataset) categoryDataset71, comparable72);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent74 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList59, (org.jfree.data.general.Dataset) categoryDataset71);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = categoryPlot39.getRendererForDataset(categoryDataset71);
        org.jfree.data.Range range76 = statisticalBarRenderer4.findRangeBounds(categoryDataset71);
        try {
            org.jfree.data.general.PieDataset pieDataset78 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset71, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator34);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNull(categoryItemRenderer75);
        org.junit.Assert.assertNotNull(range76);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = blockContainer0.equals((java.lang.Object) "GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockContainer0.getPadding();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj6 = categoryAxis5.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis5.getLabelInsets();
        double double9 = rectangleInsets7.trimHeight(1.0d);
        double double11 = rectangleInsets7.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        java.awt.Paint paint14 = null;
        legendTitle13.setBackgroundPaint(paint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle13.setLegendItemGraphicAnchor(rectangleAnchor16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle13.setVerticalAlignment(verticalAlignment18);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle13.getBounds();
        rectangleInsets7.trim(rectangle2D20);
        try {
            blockContainer0.draw(graphics2D4, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-5.0d) + "'", double9 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj43 = categoryAxis42.clone();
        categoryAxis42.setLabelToolTip("hi!");
        boolean boolean46 = categoryAxis42.isTickMarksVisible();
        java.awt.Font font47 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis42.setLabelFont(font47);
        java.awt.Font font49 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis42.setTickLabelFont(font49);
        statisticalBarRenderer0.setBaseItemLabelFont(font49, false);
        boolean boolean53 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint54 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.lang.Number[] numberArray59 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray63 = new java.lang.Number[][] { numberArray59, numberArray62 };
        org.jfree.data.category.CategoryDataset categoryDataset64 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray63);
        org.jfree.data.Range range65 = statisticalBarRenderer0.findRangeBounds(categoryDataset64);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(categoryDataset64);
        org.junit.Assert.assertNotNull(range65);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = categoryLabelPosition9.getCategoryAnchor();
        java.awt.Font font12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean16 = legendItemCollection14.equals((java.lang.Object) layer15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = textTitle17.getVerticalAlignment();
        double double24 = textTitle17.getWidth();
        boolean boolean25 = layer15.equals((java.lang.Object) double24);
        java.util.Collection collection26 = categoryPlot13.getRangeMarkers(layer15);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot13.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Category Plot", font12, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        java.awt.Paint paint33 = categoryPlot13.getNoDataMessagePaint();
        boolean boolean34 = categoryLabelPosition9.equals((java.lang.Object) paint33);
        java.awt.Stroke stroke35 = null;
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color37 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = categoryAxis39.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color37, stroke38, rectangleInsets40);
        java.awt.Paint paint42 = lineBorder41.getPaint();
        boolean boolean43 = layer36.equals((java.lang.Object) lineBorder41);
        java.awt.Paint paint44 = lineBorder41.getPaint();
        try {
            org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "GradientPaintTransformType.CENTER_VERTICAL", shape8, paint33, stroke35, paint44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape18 = statisticalBarRenderer0.lookupSeriesShape((int) (short) 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint20 = statisticalBarRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setText("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!");
        java.lang.String str3 = textTitle0.getURLText();
        boolean boolean4 = textTitle0.getNotify();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor7, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape0, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray20, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset25);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "VerticalAlignment.CENTER", "Range[0.0,1.0]", categoryDataset25, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Comparable) 20.0d);
        java.awt.Shape shape30 = categoryItemEntity29.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 20.0d + "'", number26.equals(20.0d));
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj3 = keyedObjects0.clone();
        java.lang.Object obj5 = keyedObjects0.getObject((int) (short) 100);
        java.util.List list6 = keyedObjects0.getKeys();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor12, textAnchor13, (double) (-1L));
        boolean boolean16 = plotRenderingInfo9.equals((java.lang.Object) numberTick15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        java.awt.Paint paint22 = null;
        legendTitle21.setBackgroundPaint(paint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle21.setLegendItemGraphicAnchor(rectangleAnchor24);
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle21.setVerticalAlignment(verticalAlignment26);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle21.getBounds();
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color17.createContext(colorModel18, rectangle19, rectangle2D28, affineTransform29, renderingHints30);
        plotRenderingInfo9.setDataArea(rectangle2D28);
        keyedObjects0.addObject((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT", (java.lang.Object) plotRenderingInfo9);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        java.awt.Paint paint37 = null;
        legendTitle36.setBackgroundPaint(paint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle36.setLegendItemGraphicAnchor(rectangleAnchor39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj42 = categoryAxis41.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryAxis41.getLabelInsets();
        double double45 = rectangleInsets43.trimHeight(1.0d);
        legendTitle36.setItemLabelPadding(rectangleInsets43);
        keyedObjects0.addObject((java.lang.Comparable) (-198.0d), (java.lang.Object) legendTitle36);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis48.getLabelInsets();
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder51 = new org.jfree.chart.block.BlockBorder(rectangleInsets49, (java.awt.Paint) color50);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        numberAxis52.setFixedDimension((double) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj57 = categoryAxis56.clone();
        boolean boolean58 = categoryAxis56.isVisible();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis56.setAxisLinePaint((java.awt.Paint) color59);
        java.awt.Shape shape61 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape65 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape61, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity67 = new org.jfree.chart.entity.ChartEntity(shape61, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity70 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis56, shape61, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj72 = categoryAxis71.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = categoryAxis71.getLabelInsets();
        double double75 = rectangleInsets73.trimHeight(1.0d);
        double double77 = rectangleInsets73.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource78 = null;
        org.jfree.chart.title.LegendTitle legendTitle79 = new org.jfree.chart.title.LegendTitle(legendItemSource78);
        java.awt.Paint paint80 = null;
        legendTitle79.setBackgroundPaint(paint80);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle79.setLegendItemGraphicAnchor(rectangleAnchor82);
        org.jfree.chart.util.VerticalAlignment verticalAlignment84 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle79.setVerticalAlignment(verticalAlignment84);
        java.awt.geom.Rectangle2D rectangle2D86 = legendTitle79.getBounds();
        rectangleInsets73.trim(rectangle2D86);
        axisLabelEntity70.setArea((java.awt.Shape) rectangle2D86);
        org.jfree.chart.axis.AxisCollection axisCollection89 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis90 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj91 = categoryAxis90.clone();
        boolean boolean92 = categoryAxis90.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisCollection89.add((org.jfree.chart.axis.Axis) categoryAxis90, rectangleEdge93);
        double double95 = numberAxis52.valueToJava2D(20.0d, rectangle2D86, rectangleEdge93);
        java.awt.geom.Rectangle2D rectangle2D98 = rectangleInsets49.createInsetRectangle(rectangle2D86, false, false);
        legendTitle36.setItemLabelPadding(rectangleInsets49);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-5.0d) + "'", double45 == (-5.0d));
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + (-5.0d) + "'", double75 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 4.0d + "'", double77 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNotNull(verticalAlignment84);
        org.junit.Assert.assertNotNull(rectangle2D86);
        org.junit.Assert.assertNotNull(obj91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(rectangleEdge93);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + (-117.0d) + "'", double95 == (-117.0d));
        org.junit.Assert.assertNotNull(rectangle2D98);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) categoryPlot3);
        java.util.List list7 = categoryPlot3.getCategories();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot3.notifyListeners(plotChangeEvent8);
        categoryPlot3.clearAnnotations();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        java.awt.Font font4 = numberAxis0.getTickLabelFont();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        java.awt.Paint paint9 = null;
        legendTitle8.setBackgroundPaint(paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        textTitle12.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        textTitle12.setPaint((java.awt.Paint) color18);
        legendTitle8.setItemPaint((java.awt.Paint) color18);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        java.awt.Paint paint23 = null;
        legendTitle22.setBackgroundPaint(paint23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle22.setLegendItemGraphicAnchor(rectangleAnchor25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle22.setVerticalAlignment(verticalAlignment27);
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle22.getBounds();
        legendTitle8.setBounds(rectangle2D29);
        try {
            legendTitle1.draw(graphics2D6, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation3, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot0.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot0.getParent();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        plotRenderingInfo12.setPlotArea(rectangle2D13);
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomDomainAxes(16.0d, 0.0d, plotRenderingInfo12, point2D15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot0.setDomainAxis(255, categoryAxis18);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment6);
        legendTitle1.setPadding(0.0d, (double) (short) -1, 0.0d, (double) 2);
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray18, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray22);
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement13, (org.jfree.data.general.Dataset) categoryDataset23, comparable24);
        java.lang.String str26 = legendItemBlockContainer25.getURLText();
        java.lang.Object obj27 = null;
        boolean boolean28 = legendItemBlockContainer25.equals(obj27);
        java.awt.Font font30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean34 = legendItemCollection32.equals((java.lang.Object) layer33);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        textTitle35.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = textTitle35.getVerticalAlignment();
        double double42 = textTitle35.getWidth();
        boolean boolean43 = layer33.equals((java.lang.Object) double42);
        java.util.Collection collection44 = categoryPlot31.getRangeMarkers(layer33);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = null;
        categoryPlot31.datasetChanged(datasetChangeEvent45);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent47 = null;
        categoryPlot31.rendererChanged(rendererChangeEvent47);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Category Plot", font30, (org.jfree.chart.plot.Plot) categoryPlot31, false);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        textTitle51.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment57 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle51.setTextAlignment(horizontalAlignment57);
        jFreeChart50.addSubtitle((org.jfree.chart.title.Title) textTitle51);
        legendItemBlockContainer25.add((org.jfree.chart.block.Block) textTitle51);
        legendTitle1.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer25);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(horizontalAlignment57);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean5 = legendItemCollection3.equals((java.lang.Object) layer4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle6.getVerticalAlignment();
        double double13 = textTitle6.getWidth();
        boolean boolean14 = layer4.equals((java.lang.Object) double13);
        java.util.Collection collection15 = categoryPlot2.getRangeMarkers(layer4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        categoryPlot2.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot2.rendererChanged(rendererChangeEvent18);
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(paint20);
        categoryPlot2.setRangeGridlinePaint(paint20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_YELLOW;
        categoryPlot2.setRangeGridlinePaint((java.awt.Paint) color23);
        categoryPlot2.clearRangeAxes();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("EXPAND", font1, (org.jfree.chart.plot.Plot) categoryPlot2, true);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, 0.0f);
        double double5 = categoryLabelPosition4.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition4.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor7 = categoryLabelPosition4.getRotationAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = categoryLabelPosition4.getLabelAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10, categoryLabelWidthType11, 0.0f);
        double double14 = categoryLabelPosition13.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor15 = categoryLabelPosition13.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryLabelPosition13.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType19 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor17, textBlockAnchor18, categoryLabelWidthType19, 0.0f);
        double double22 = categoryLabelPosition21.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryLabelPosition21.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = new org.jfree.chart.axis.CategoryLabelPosition();
        double double25 = categoryLabelPosition24.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition4, categoryLabelPosition13, categoryLabelPosition21, categoryLabelPosition24);
        boolean boolean28 = categoryLabelPosition4.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelWidthType19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape18 = statisticalBarRenderer0.lookupSeriesShape((int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(itemLabelPosition19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) categoryPlot3);
        java.util.List list7 = categoryPlot3.getCategories();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis8.setLeftArrow(shape10);
        java.text.NumberFormat numberFormat12 = null;
        numberAxis8.setNumberFormatOverride(numberFormat12);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis14.setLeftArrow(shape16);
        numberAxis14.setNegativeArrowVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis20.setLeftArrow(shape22);
        java.text.NumberFormat numberFormat24 = null;
        numberAxis20.setNumberFormatOverride(numberFormat24);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis28.setLeftArrow(shape30);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { numberAxis8, numberAxis14, numberAxis20, numberAxis26, numberAxis27, numberAxis28 };
        categoryPlot3.setRangeAxes(valueAxisArray32);
        categoryPlot3.setNoDataMessage("HorizontalAlignment.CENTER");
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(valueAxisArray32);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape9 = numberAxis0.getUpArrow();
        java.awt.Shape shape10 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3);
        java.lang.Object obj6 = keyedObjects0.getObject((int) (short) 1);
        java.lang.Object obj8 = null;
        keyedObjects0.addObject((java.lang.Comparable) 10.0f, obj8);
        java.util.List list10 = keyedObjects0.getKeys();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        java.lang.String str6 = numberAxis0.getLabelToolTip();
        java.awt.Shape shape7 = numberAxis0.getRightArrow();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis0.getMarkerBand();
        numberAxis0.centerRange((double) 0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(markerAxisBand8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) (-1L));
        java.lang.Number number6 = numberTick5.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font4);
        java.awt.Font font6 = textFragment5.getFont();
        float float7 = textFragment5.getBaselineOffset();
        textLine0.addFragment(textFragment5);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        java.awt.Stroke stroke30 = statisticalBarRenderer0.getBaseOutlineStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        statisticalBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator36);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot4);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color9);
        double double11 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint18);
        statisticalBarRenderer13.setBaseItemLabelPaint(paint18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = statisticalBarRenderer13.getSeriesPositiveItemLabelPosition((int) '4');
        java.awt.Paint paint24 = statisticalBarRenderer13.lookupSeriesPaint(4);
        statisticalBarRenderer13.setAutoPopulateSeriesFillPaint(false);
        statisticalBarRenderer13.setBaseCreateEntities(true, false);
        try {
            categoryPlot0.setRenderer((-15), (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor4, textAnchor5, (double) (-1L));
        boolean boolean8 = plotRenderingInfo1.equals((java.lang.Object) numberTick7);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        int int10 = color9.getRed();
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj14 = categoryAxis13.clone();
        boolean boolean15 = categoryAxis13.isVisible();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis13.setAxisLinePaint((java.awt.Paint) color16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape18, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape18, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis13, shape18, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj29 = categoryAxis28.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis28.getLabelInsets();
        double double32 = rectangleInsets30.trimHeight(1.0d);
        double double34 = rectangleInsets30.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        java.awt.Paint paint37 = null;
        legendTitle36.setBackgroundPaint(paint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle36.setLegendItemGraphicAnchor(rectangleAnchor39);
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle36.setVerticalAlignment(verticalAlignment41);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle36.getBounds();
        rectangleInsets30.trim(rectangle2D43);
        axisLabelEntity27.setArea((java.awt.Shape) rectangle2D43);
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color9.createContext(colorModel11, rectangle12, rectangle2D43, affineTransform46, renderingHints47);
        plotRenderingInfo1.setDataArea(rectangle2D43);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-5.0d) + "'", double32 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(paintContext48);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 128);
        try {
            java.lang.Number number5 = defaultStatisticalCategoryDataset0.getStdDevValue(255, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) (-1L));
        java.lang.Object obj6 = numberTick5.clone();
        java.lang.String str7 = numberTick5.toString();
        java.lang.Object obj8 = numberTick5.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = (short) 0;
        size2D0.setWidth((double) 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) "", (java.lang.Object) itemLabelAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor8, textAnchor9, (double) (-1L));
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "EXPAND", textAnchor5, textAnchor9, 10.0d);
        org.jfree.chart.axis.TickType tickType14 = numberTick13.getTickType();
        keyedObject2.setObject((java.lang.Object) numberTick13);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(tickType14);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator24, true);
        boolean boolean27 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator28, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = statisticalBarRenderer0.getSeriesNegativeItemLabelPosition(255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor7, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape0, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray20, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset25);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity29 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "VerticalAlignment.CENTER", "Range[0.0,1.0]", categoryDataset25, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Comparable) 20.0d);
        org.jfree.data.KeyedObjects2D keyedObjects2D30 = new org.jfree.data.KeyedObjects2D();
        int int31 = keyedObjects2D30.getRowCount();
        java.util.List list32 = keyedObjects2D30.getRowKeys();
        boolean boolean33 = categoryItemEntity29.equals((java.lang.Object) list32);
        java.lang.String str34 = categoryItemEntity29.getShapeType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer35 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        boolean boolean36 = categoryItemEntity29.equals((java.lang.Object) standardGradientPaintTransformer35);
        categoryItemEntity29.setRowKey((java.lang.Comparable) "LengthConstraintType.FIXED");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 20.0d + "'", number26.equals(20.0d));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "rect" + "'", str34.equals("rect"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", font1, (java.awt.Paint) color2, (float) 0, (-16777216), textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getDomainAxisEdge(15);
        int int11 = categoryPlot6.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font3, (org.jfree.chart.plot.Plot) categoryPlot6, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean17 = plotRenderingInfo15.equals((java.lang.Object) color16);
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, (java.awt.Paint) color22);
        legendTitle19.setItemPaint((java.awt.Paint) color22);
        java.awt.color.ColorSpace colorSpace25 = color22.getColorSpace();
        float[] floatArray31 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray32 = color16.getComponents(colorSpace25, floatArray31);
        org.jfree.chart.text.TextMeasurer textMeasurer35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color16, (float) 4, 0, textMeasurer35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType42 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor40, textBlockAnchor41, categoryLabelWidthType42, 0.0f);
        double double45 = categoryLabelPosition44.getAngle();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor46 = categoryLabelPosition44.getLabelAnchor();
        java.awt.Shape shape50 = textBlock36.calculateBounds(graphics2D37, 10.0f, (float) (byte) -1, textBlockAnchor46, (float) 192, 2.0f, (double) 4);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis52.setLabel("hi!");
        java.awt.Paint paint55 = categoryAxis52.getLabelPaint();
        categoryAxis52.setTickMarksVisible(false);
        java.awt.Font font59 = categoryAxis52.getTickLabelFont((java.lang.Comparable) 1L);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj61 = categoryAxis60.clone();
        java.lang.String str63 = categoryAxis60.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis60.setLabelInsets(rectangleInsets64);
        java.awt.Paint paint66 = categoryAxis60.getTickLabelPaint();
        org.jfree.chart.text.TextLine textLine67 = new org.jfree.chart.text.TextLine("hi!", font59, paint66);
        textBlock36.addLine(textLine67);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor69 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor70 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick72 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 2.0f, textBlock36, textBlockAnchor69, textAnchor70, (double) (-192));
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor73 = categoryTick72.getLabelAnchor();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(textBlockAnchor41);
        org.junit.Assert.assertNotNull(categoryLabelWidthType42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor46);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(textBlockAnchor69);
        org.junit.Assert.assertNotNull(textAnchor70);
        org.junit.Assert.assertNotNull(textBlockAnchor73);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        boolean boolean2 = categoryAxis0.isVisible();
        boolean boolean3 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3);
        int int6 = keyedObjects0.getIndex((java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.chart.util.BooleanList booleanList8 = new org.jfree.chart.util.BooleanList();
        booleanList8.clear();
        keyedObjects0.addObject((java.lang.Comparable) (short) -1, (java.lang.Object) booleanList8);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        try {
            keyedObjects2D0.removeRow(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(4, categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator26);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 128);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = legendItemCollection4.equals((java.lang.Object) layer5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        textTitle7.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = textTitle7.getVerticalAlignment();
        double double14 = textTitle7.getWidth();
        boolean boolean15 = layer5.equals((java.lang.Object) double14);
        java.util.Collection collection16 = categoryPlot3.getRangeMarkers(layer5);
        java.awt.Stroke stroke17 = categoryPlot3.getDomainGridlineStroke();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis0.setLabelFont(font5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj8 = categoryAxis7.clone();
        categoryAxis7.setLabelToolTip("hi!");
        boolean boolean11 = categoryAxis7.isTickMarksVisible();
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis7.setLabelFont(font12);
        categoryAxis0.setLabelFont(font12);
        int int15 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder19 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot18.setRowRenderingOrder(sortOrder19);
        java.lang.String str21 = categoryPlot18.getPlotType();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot18.setRangeGridlinePaint((java.awt.Paint) color22);
        java.awt.Color color24 = color22.darker();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean28 = legendItemCollection26.equals((java.lang.Object) layer27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        textTitle29.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = textTitle29.getVerticalAlignment();
        double double36 = textTitle29.getWidth();
        boolean boolean37 = layer27.equals((java.lang.Object) double36);
        java.util.Collection collection38 = categoryPlot25.getRangeMarkers(layer27);
        java.awt.Stroke stroke39 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryAxis40.getLabelInsets();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder(rectangleInsets41, (java.awt.Paint) color42);
        double double45 = rectangleInsets41.calculateRightInset((double) 0L);
        double double47 = rectangleInsets41.extendHeight((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color22, stroke39, rectangleInsets41);
        categoryAxis0.setTickMarkStroke(stroke39);
        categoryAxis0.setUpperMargin(2.7d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 3.0d + "'", double45 == 3.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 16.0d + "'", double47 == 16.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        boolean boolean14 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot4);
        categoryPlot4.setWeight(128);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets4);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer7.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean13 = plotRenderingInfo11.equals((java.lang.Object) color12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis16.getLabelInsets();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color18);
        legendTitle15.setItemPaint((java.awt.Paint) color18);
        java.awt.color.ColorSpace colorSpace21 = color18.getColorSpace();
        float[] floatArray27 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray28 = color12.getComponents(colorSpace21, floatArray27);
        statisticalBarRenderer7.setBaseItemLabelPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke32 = statisticalBarRenderer7.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint34 = statisticalBarRenderer7.lookupSeriesPaint((int) (byte) -1);
        java.awt.Paint paint35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        statisticalBarRenderer7.setBasePaint(paint35);
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "rect", paint35);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace21);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape1, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor8, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape1, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        numberAxis0.setUpArrow(shape1);
        double double16 = numberAxis0.getAutoRangeMinimumSize();
        org.jfree.data.RangeType rangeType17 = numberAxis0.getRangeType();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-8d + "'", double16 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rangeType17);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor4, textAnchor5, (double) (-1L));
        boolean boolean8 = plotRenderingInfo1.equals((java.lang.Object) numberTick7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        java.awt.Paint paint14 = null;
        legendTitle13.setBackgroundPaint(paint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle13.setLegendItemGraphicAnchor(rectangleAnchor16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle13.setVerticalAlignment(verticalAlignment18);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle13.getBounds();
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color9.createContext(colorModel10, rectangle11, rectangle2D20, affineTransform21, renderingHints22);
        plotRenderingInfo1.setDataArea(rectangle2D20);
        int int25 = plotRenderingInfo1.getSubplotCount();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font4);
        java.awt.Font font6 = textFragment5.getFont();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        valueMarker1.setLabelFont(font6);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis0.setLabelFont(font5);
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis0.setTickLabelFont(font7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj11 = categoryAxis10.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        categoryAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot12);
        boolean boolean16 = categoryPlot12.isOutlineVisible();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        try {
            categoryPlot12.addDomainMarker(categoryMarker18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        int int18 = categoryPlot0.getWeight();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        categoryPlot0.markerChanged(markerChangeEvent19);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle1.getPosition();
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray7 = legendTitle1.getSources();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(legendItemSourceArray7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        org.jfree.data.general.Dataset dataset14 = legendItem13.getDataset();
        java.text.AttributedString attributedString15 = legendItem13.getAttributedLabel();
        java.lang.String str16 = legendItem13.getDescription();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNull(dataset14);
        org.junit.Assert.assertNull(attributedString15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getDomainAxisEdge(15);
        int int7 = categoryPlot2.getDatasetCount();
        categoryPlot2.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot2.setRangeAxisLocation((int) (byte) 10, axisLocation11);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape1, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor8, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape1, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray21, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray25);
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "VerticalAlignment.CENTER", "Range[0.0,1.0]", categoryDataset26, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Comparable) 20.0d);
        org.jfree.data.KeyedObjects2D keyedObjects2D31 = new org.jfree.data.KeyedObjects2D();
        int int32 = keyedObjects2D31.getRowCount();
        java.util.List list33 = keyedObjects2D31.getRowKeys();
        boolean boolean34 = categoryItemEntity30.equals((java.lang.Object) list33);
        java.lang.String str35 = categoryItemEntity30.getShapeType();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range37 = numberAxis36.getRange();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryAxis38.getLabelInsets();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder(rectangleInsets39, (java.awt.Paint) color40);
        double double43 = rectangleInsets39.trimHeight(0.0d);
        numberAxis36.setLabelInsets(rectangleInsets39);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '4');
        numberAxis36.setRightArrow(shape46);
        boolean boolean48 = categoryItemEntity30.equals((java.lang.Object) shape46);
        boolean boolean49 = centerArrangement0.equals((java.lang.Object) boolean48);
        org.jfree.chart.block.BlockContainer blockContainer50 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 20.0d + "'", number27.equals(20.0d));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "rect" + "'", str35.equals("rect"));
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-6.0d) + "'", double43 == (-6.0d));
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        statisticalBarRenderer0.setDrawBarOutline(false);
        boolean boolean28 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(10, categoryItemLabelGenerator30);
        boolean boolean34 = statisticalBarRenderer0.isItemLabelVisible((-15), (int) (short) 1);
        java.awt.Paint paint37 = statisticalBarRenderer0.getItemLabelPaint(255, 64);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint37);
    }
}

