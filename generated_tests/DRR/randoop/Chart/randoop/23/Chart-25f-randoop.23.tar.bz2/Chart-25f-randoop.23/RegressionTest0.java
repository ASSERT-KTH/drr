import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Color color2 = java.awt.Color.getColor("", 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10L, (double) 1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 1L, (float) (short) 10, (double) 10L, (float) (byte) -1, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2, 0.0f, (int) (byte) 1, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.awt.Font font2 = null;
        try {
            categoryAxis0.setTickLabelFont(font2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        try {
            org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, dataset1, (java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Point2D point2D2 = null;
        try {
            int int3 = plotRenderingInfo1.getSubplotIndex(point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        double double5 = rectangleInsets1.calculateBottomOutset((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis15.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color13, stroke14, rectangleInsets16);
        java.awt.Paint paint18 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER", true, shape5, true, paint7, true, (java.awt.Paint) color9, stroke10, false, shape12, stroke14, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("TextAnchor.CENTER");
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = java.awt.Color.YELLOW;
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis8.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke7, rectangleInsets9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "", "hi!", shape4, (java.awt.Paint) color5, stroke7, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets12);
        try {
            java.lang.Object obj14 = legendTitle1.draw(graphics2D7, rectangle2D8, (java.lang.Object) lineBorder13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        java.awt.Font font3 = null;
        try {
            categoryAxis0.setTickLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        int int4 = color2.getGreen();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        boolean boolean7 = color2.equals((java.lang.Object) legendItemSource5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) (byte) 0, 1.0f, 10.0d, (float) (short) 1, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toRangeWidth(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = null;
        try {
            legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        double double5 = rectangleInsets1.calculateRightInset((double) 0L);
        boolean boolean7 = rectangleInsets1.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, 0.0d);
        org.jfree.data.Range range5 = rectangleConstraint4.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle0.arrange(graphics2D1, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.ui.Contributor contributor3 = new org.jfree.chart.ui.Contributor("hi!", "");
        boolean boolean4 = itemLabelAnchor0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100.0f);
        double double3 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        double double5 = rectangleInsets1.calculateLeftOutset((double) (byte) 1);
        double double7 = rectangleInsets1.calculateTopInset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.Plot plot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace8 = categoryAxis0.reserveSpace(graphics2D3, plot4, rectangle2D5, rectangleEdge6, axisSpace7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis0.getLabelInsets();
        java.awt.Font font3 = null;
        try {
            categoryAxis0.setTickLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) 4.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass1 = chartChangeEventType0.getClass();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        boolean boolean3 = chartChangeEventType0.equals((java.lang.Object) itemLabelAnchor2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (-1), 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "TextAnchor.CENTER", "VerticalAlignment.CENTER", categoryDataset3, (java.lang.Comparable) false, (java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            legendTitle1.setBounds(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("GradientPaintTransformType.CENTER_VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name GradientPaintTransformType.CENTER_VERTICAL, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1), (float) (byte) 0, (float) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-15) + "'", int3 == (-15));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (short) 100, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke5, rectangleInsets7);
        categoryAxis0.setTickMarkStroke(stroke5);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double14 = categoryAxis0.getCategoryStart((int) (short) 1, (int) (byte) 100, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle(100, 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) (-15), font8);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 255, (double) (short) 0, 1, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toRangeHeight(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        java.lang.String str7 = verticalAlignment6.toString();
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "VerticalAlignment.CENTER" + "'", str7.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        java.awt.Paint paint7 = null;
        try {
            textTitle0.setPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("GradientPaintTransformType.CENTER_VERTICAL", graphics2D1, (float) 4, (float) 4, textAnchor4, 16.0d, (float) 0L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0L, (double) (short) -1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "TextAnchor.CENTER" + "'", str0.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        textTitle0.setURLText("GradientPaintTransformType.CENTER_VERTICAL");
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color2 = java.awt.Color.getColor("", (-1));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        double double4 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeHeight(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        size2D0.setHeight((double) (byte) 1);
        size2D0.setWidth((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 1.0f, (-6.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (double) 100, 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (short) -1, (-6.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-1.0) <= upper (-6.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        try {
            categoryPlot0.setRenderer((-192), categoryItemRenderer3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass1 = chartChangeEventType0.getClass();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        boolean boolean3 = chartChangeEventType0.equals((java.lang.Object) verticalAlignment2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "VerticalAlignment.CENTER", font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean11 = legendItemCollection9.equals((java.lang.Object) layer10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        textTitle12.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = textTitle12.getVerticalAlignment();
        double double19 = textTitle12.getWidth();
        boolean boolean20 = layer10.equals((java.lang.Object) double19);
        java.util.Collection collection21 = categoryPlot8.getRangeMarkers(layer10);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        java.awt.Paint paint25 = null;
        legendTitle24.setBackgroundPaint(paint25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle24.getLegendItemGraphicEdge();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace29 = categoryAxis0.reserveSpace(graphics2D7, (org.jfree.chart.plot.Plot) categoryPlot8, rectangle2D22, rectangleEdge27, axisSpace28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TextAnchor.CENTER", graphics2D1, 0.0f, (float) 10L, (double) 10L, (float) (short) 0, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Paint paint1 = null;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis4.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets5);
        java.awt.Paint paint7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke3, paint7, stroke9, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.addFragment(textFragment1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) (-1L));
        java.lang.Object obj6 = numberTick5.clone();
        org.jfree.chart.text.TextAnchor textAnchor7 = numberTick5.getRotationAnchor();
        java.lang.String str8 = numberTick5.getText();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        java.awt.Paint paint9 = null;
        legendTitle8.setBackgroundPaint(paint9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle8.getPosition();
        try {
            double double13 = categoryAxis0.getCategoryEnd((int) (byte) 0, 0, rectangle2D6, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setPadding(1.0d, (double) 0.5f, (double) 2, (double) 255);
        java.util.List list6 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = categoryAxis0.getTickLabelFont();
        java.awt.Font font6 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor6, textAnchor7, (double) (-1L));
        java.lang.Object obj10 = numberTick9.clone();
        org.jfree.chart.text.TextAnchor textAnchor11 = numberTick9.getRotationAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", graphics2D1, (float) 1L, 0.0f, textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis0.setLabelFont(font5);
        boolean boolean7 = categoryAxis0.isVisible();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        boolean boolean3 = sortOrder0.equals(obj2);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.lang.Object obj5 = plotRenderingInfo4.clone();
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getPlotArea();
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (-5.0d), plotRenderingInfo4, point2D7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        try {
            categoryPlot0.draw(graphics2D9, rectangle2D10, point2D11, plotState12, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(rectangle2D6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, (int) (short) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, range1);
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeHeight(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape2, "hi!", "hi!");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity5.setArea(shape6);
        java.lang.Object obj8 = categoryLabelEntity5.clone();
        java.lang.String str9 = categoryLabelEntity5.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        double double7 = legendTitle1.getHeight();
        java.lang.Object obj8 = legendTitle1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (-1.0f));
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        try {
            numberAxis0.zoomRange((double) 255, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (255.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray11);
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement2, (org.jfree.data.general.Dataset) categoryDataset12, comparable13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList0, (org.jfree.data.general.Dataset) categoryDataset12);
        try {
            org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset12, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.lang.Object obj2 = plotRenderingInfo1.clone();
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = plotRenderingInfo1.getSubplotInfo((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(rectangle2D3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str1.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartChangeListener chartChangeListener7 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape7, "hi!", "hi!");
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity10.setArea(shape11);
        java.awt.Paint paint14 = null;
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis18.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color16, stroke17, rectangleInsets19);
        java.awt.Paint paint21 = lineBorder20.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke23 = categoryPlot22.getRangeGridlineStroke();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        java.awt.Paint paint29 = null;
        legendTitle28.setBackgroundPaint(paint29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle28.getLegendItemGraphicLocation();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor31, (double) (short) 1, (double) 2);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("TextAnchor.CENTER", "TextAnchor.CENTER", "", "VerticalAlignment.CENTER", false, shape11, false, paint14, false, paint21, stroke23, true, shape26, stroke35, (java.awt.Paint) color36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 10L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "TextAnchor.CENTER", "TextAnchor.CENTER", "GradientPaintTransformType.CENTER_VERTICAL");
        basicProjectInfo4.setName("");
        basicProjectInfo4.setName("HorizontalAlignment.RIGHT");
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int2 = color1.getGreen();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke4 = categoryPlot3.getRangeGridlineStroke();
        java.awt.Color color5 = java.awt.Color.darkGray;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj7 = categoryAxis6.clone();
        categoryAxis6.setLabelToolTip("hi!");
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke11, rectangleInsets13);
        categoryAxis6.setTickMarkStroke(stroke11);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 100L, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color5, stroke11, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        boolean boolean3 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        java.awt.Paint paint6 = null;
        legendTitle5.setBackgroundPaint(paint6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle5.getLegendItemGraphicLocation();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor8, (double) (short) 1, (double) 2);
        try {
            java.awt.GradientPaint gradientPaint12 = standardGradientPaintTransformer0.transform(gradientPaint1, shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj3 = keyedObjects0.clone();
        java.lang.Object obj5 = keyedObjects0.getObject((int) (short) 100);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("VerticalAlignment.CENTER", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = legendItemCollection5.equals((java.lang.Object) layer6);
        try {
            categoryPlot0.addRangeMarker((int) ' ', marker4, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 1, 0.0d, (double) 10L, (double) 10L);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis0.setNumberFormatOverride(numberFormat4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.lang.Object obj12 = plotRenderingInfo11.clone();
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomRangeAxes((double) 10.0f, (-5.0d), plotRenderingInfo11, point2D14);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace19 = numberAxis0.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot7, rectangle2D16, rectangleEdge17, axisSpace18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(rectangle2D13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        categoryPlot0.setAnchorValue((double) (byte) 100);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.setLabelToolTip("EXPAND");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape6, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape6, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        java.awt.Stroke stroke16 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        double double7 = legendTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            legendTitle1.setItemLabelPadding(rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        double double5 = rectangleInsets1.calculateRightInset((double) 0L);
        double double7 = rectangleInsets1.extendHeight((double) (short) 10);
        double double9 = rectangleInsets1.extendHeight((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.0d + "'", double7 == 16.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 261.0d + "'", double9 == 261.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj10 = textTitle0.draw(graphics2D7, rectangle2D8, (java.lang.Object) flowArrangement9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.Range range13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(100.0d, range13);
        double double15 = rectangleConstraint14.getWidth();
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle0.arrange(graphics2D11, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets4);
        java.awt.Paint paint6 = categoryAxis0.getTickLabelPaint();
        java.awt.Font font7 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray13, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray17);
        java.lang.Comparable comparable19 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.data.general.Dataset) categoryDataset18, comparable19);
        categoryPlot3.setDataset(2, categoryDataset18);
        org.jfree.data.KeyToGroupMap keyToGroupMap22 = null;
        try {
            org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18, keyToGroupMap22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        int int3 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "VerticalAlignment.CENTER", font5);
        categoryAxis0.setUpperMargin((double) 10.0f);
        categoryAxis0.setLabel("EXPAND");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        textTitle0.setExpandToFitSpace(false);
        double double8 = textTitle0.getWidth();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject((int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj3 = keyedObjects0.clone();
        try {
            keyedObjects0.removeValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 4.0d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        java.awt.Paint paint5 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.util.BooleanList booleanList6 = new org.jfree.chart.util.BooleanList();
        booleanList6.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray13, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray17);
        java.lang.Comparable comparable19 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.data.general.Dataset) categoryDataset18, comparable19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList6, (org.jfree.data.general.Dataset) categoryDataset18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot2.getRendererForDataset(categoryDataset18);
        try {
            org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(categoryItemRenderer22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7, categoryLabelWidthType8, 0.0f);
        double double11 = categoryLabelPosition10.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryLabelPosition10.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = categoryLabelPosition10.getRotationAnchor();
        try {
            textFragment2.draw(graphics2D3, (float) 15, (float) (short) -1, textAnchor13, (float) (-15), (float) 255, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) (short) -1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (byte) 1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        double double2 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("GradientPaintTransformType.CENTER_VERTICAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape2, "hi!", "hi!");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity5.setArea(shape6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor8, (double) 0.0f, (double) (short) 0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, (java.awt.Paint) color13);
        legendTitle10.setItemPaint((java.awt.Paint) color13);
        legendTitle10.setID("TextAnchor.CENTER");
        try {
            jFreeChart6.setTextAntiAlias((java.lang.Object) "TextAnchor.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TextAnchor.CENTER incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis2.setLeftArrow(shape4);
        boolean boolean6 = numberAxis2.getAutoRangeStickyZero();
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range7);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) layer1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean5 = legendItemCollection3.equals((java.lang.Object) layer4);
        legendItemCollection0.addAll(legendItemCollection3);
        try {
            org.jfree.chart.LegendItem legendItem8 = legendItemCollection3.get((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        double double3 = statisticalBarRenderer0.getLowerClip();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) (-1L));
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj8 = categoryAxis7.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean10 = categoryPlot9.isRangeGridlinesVisible();
        categoryAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot9);
        boolean boolean13 = numberTick5.equals((java.lang.Object) "TextAnchor.CENTER");
        org.jfree.chart.text.TextAnchor textAnchor14 = numberTick5.getTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        java.awt.Paint paint4 = null;
        legendTitle3.setBackgroundPaint(paint4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle3.getLegendItemGraphicLocation();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor6, (double) (short) 1, (double) 2);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape1, "EXPAND");
        java.lang.Object obj12 = chartEntity11.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis5.setLeftArrow(shape7);
        numberAxis5.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape12 = defaultDrawingSupplier11.getNextShape();
        numberAxis5.setLeftArrow(shape12);
        java.awt.Font font16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean20 = legendItemCollection18.equals((java.lang.Object) layer19);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        textTitle21.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = textTitle21.getVerticalAlignment();
        double double28 = textTitle21.getWidth();
        boolean boolean29 = layer19.equals((java.lang.Object) double28);
        java.util.Collection collection30 = categoryPlot17.getRangeMarkers(layer19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("Category Plot", font16, (org.jfree.chart.plot.Plot) categoryPlot17, false);
        java.awt.Paint paint37 = categoryPlot17.getNoDataMessagePaint();
        java.awt.Paint paint39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj41 = categoryAxis40.clone();
        categoryAxis40.setLabelToolTip("hi!");
        java.awt.Color color44 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryAxis46.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color44, stroke45, rectangleInsets47);
        categoryAxis40.setTickMarkStroke(stroke45);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier52 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape53 = defaultDrawingSupplier52.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity56 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape53, "hi!", "hi!");
        java.awt.Shape shape57 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity56.setArea(shape57);
        java.lang.String str59 = categoryLabelEntity56.toString();
        java.lang.Comparable comparable60 = categoryLabelEntity56.getKey();
        java.awt.Shape shape61 = categoryLabelEntity56.getArea();
        java.awt.Stroke stroke62 = null;
        java.awt.Color color63 = java.awt.Color.orange;
        try {
            org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("HorizontalAlignment.RIGHT", "TextAnchor.CENTER", "EXPAND", "", false, shape12, false, paint37, true, paint39, stroke45, false, shape61, stroke62, (java.awt.Paint) color63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!" + "'", str59.equals("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!"));
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + (-1L) + "'", comparable60.equals((-1L)));
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color63);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle1.getPosition();
        java.awt.Paint paint6 = legendTitle1.getBackgroundPaint();
        legendTitle1.setID("TextAnchor.CENTER");
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("EXPAND", "TextAnchor.CENTER", "TextAnchor.CENTER", "EXPAND");
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str2 = textAnchor1.toString();
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor3, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.CENTER" + "'", str2.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleEdge.RIGHT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) (-1));
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle5, (java.lang.Object) itemLabelAnchor6);
        textTitle5.setPadding(0.0d, (double) (short) 100, (double) 10, 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "HorizontalAlignment.RIGHT");
        java.lang.String str3 = chartEntity2.getURLText();
        java.lang.String str4 = chartEntity2.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        categoryAxis0.setTickMarksVisible(false);
        java.awt.Font font7 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        java.awt.Paint paint8 = null;
        try {
            categoryAxis0.setTickMarkPaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-1.0f), (double) 10, (-15), (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getLabelInsets();
        boolean boolean4 = flowArrangement0.equals((java.lang.Object) categoryAxis1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj6 = categoryAxis5.clone();
        categoryAxis5.setLabelToolTip("hi!");
        boolean boolean9 = categoryAxis5.isTickMarksVisible();
        java.awt.Font font10 = categoryAxis5.getTickLabelFont();
        boolean boolean11 = flowArrangement0.equals((java.lang.Object) categoryAxis5);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 2, (float) 100, (float) 100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int10 = color9.getRGB();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer11.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean17 = plotRenderingInfo15.equals((java.lang.Object) color16);
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, (java.awt.Paint) color22);
        legendTitle19.setItemPaint((java.awt.Paint) color22);
        java.awt.color.ColorSpace colorSpace25 = color22.getColorSpace();
        float[] floatArray31 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray32 = color16.getComponents(colorSpace25, floatArray31);
        statisticalBarRenderer11.setBaseItemLabelPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke36 = statisticalBarRenderer11.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Color color37 = java.awt.Color.darkGray;
        try {
            org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem(attributedString0, "EXPAND", "EXPAND", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", shape8, (java.awt.Paint) color9, stroke36, (java.awt.Paint) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-192) + "'", int10 == (-192));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        textTitle0.setExpandToFitSpace(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setHorizontalAlignment(horizontalAlignment8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle0.getVerticalAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor2, textAnchor3, (double) (-1L));
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj8 = categoryAxis7.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean10 = categoryPlot9.isRangeGridlinesVisible();
        categoryAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot9);
        boolean boolean13 = numberTick5.equals((java.lang.Object) "TextAnchor.CENTER");
        java.lang.Object obj14 = numberTick5.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "TextAnchor.CENTER", "TextAnchor.CENTER", "GradientPaintTransformType.CENTER_VERTICAL");
        basicProjectInfo4.setName("");
        basicProjectInfo4.setVersion("MINOR");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, (float) 64, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_LEFT");
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10.0f, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        java.awt.Paint paint5 = null;
        legendTitle4.setBackgroundPaint(paint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle4.setLegendItemGraphicAnchor(rectangleAnchor7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle4.setVerticalAlignment(verticalAlignment9);
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle4.getBounds();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator13 = legendItemCollection12.iterator();
        try {
            java.lang.Object obj14 = labelBlock1.draw(graphics2D2, rectangle2D11, (java.lang.Object) legendItemCollection12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(iterator13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot4);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart7.addChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedDimension();
        try {
            numberAxis0.zoomRange(1.0d, (double) (-15));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (-15.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str2.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.lang.Object obj5 = plotRenderingInfo4.clone();
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getPlotArea();
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (-5.0d), plotRenderingInfo4, point2D7);
        java.awt.geom.Point2D point2D9 = null;
        try {
            int int10 = plotRenderingInfo4.getSubplotIndex(point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(rectangle2D6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("EXPAND", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color1 = java.awt.Color.getColor("GradientPaintTransformType.CENTER_VERTICAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        labelBlock1.setURLText("HorizontalAlignment.RIGHT");
        java.awt.Font font4 = null;
        try {
            labelBlock1.setFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        boolean boolean7 = legendTitle1.equals((java.lang.Object) 0L);
        java.awt.Font font8 = null;
        try {
            legendTitle1.setItemFont(font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = statisticalBarRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType25 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj27 = categoryAxis26.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean29 = categoryPlot28.isRangeGridlinesVisible();
        categoryAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        boolean boolean31 = gradientPaintTransformType25.equals((java.lang.Object) categoryPlot28);
        java.util.List list32 = categoryPlot28.getCategories();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        categoryPlot28.notifyListeners(plotChangeEvent33);
        categoryPlot28.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj37 = categoryAxis36.clone();
        java.lang.String str39 = categoryAxis36.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis36.setLabelInsets(rectangleInsets40);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = null;
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        java.awt.Paint paint45 = null;
        legendTitle44.setBackgroundPaint(paint45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle44.setLegendItemGraphicAnchor(rectangleAnchor47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment49 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle44.setVerticalAlignment(verticalAlignment49);
        java.awt.geom.Rectangle2D rectangle2D51 = legendTitle44.getBounds();
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D24, categoryPlot28, categoryAxis36, categoryMarker42, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNotNull(gradientPaintTransformType25);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(verticalAlignment49);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj6 = categoryAxis5.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis5.getLabelInsets();
        double double9 = rectangleInsets7.trimHeight(1.0d);
        double double11 = rectangleInsets7.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        java.awt.Paint paint14 = null;
        legendTitle13.setBackgroundPaint(paint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle13.setLegendItemGraphicAnchor(rectangleAnchor16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle13.setVerticalAlignment(verticalAlignment18);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle13.getBounds();
        rectangleInsets7.trim(rectangle2D20);
        try {
            categoryPlot0.drawBackground(graphics2D4, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-5.0d) + "'", double9 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean27 = statisticalBarRenderer0.getSeriesVisible(2);
        java.awt.Paint paint30 = statisticalBarRenderer0.getItemLabelPaint((int) (short) -1, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition32, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint4 = null;
        statisticalBarRenderer0.setSeriesPaint((int) ' ', paint4, true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        legendTitle1.setNotify(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj12 = categoryAxis11.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isRangeGridlinesVisible();
        categoryAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getDomainAxisEdge(15);
        int int18 = categoryPlot13.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font10, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.Range range24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(100.0d, range24);
        double double26 = rectangleConstraint25.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint25.toFixedHeight((double) 4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint25.toFixedHeight(0.2d);
        try {
            org.jfree.chart.util.Size2D size2D31 = legendTitle1.arrange(graphics2D22, rectangleConstraint30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis0.setLabelFont(font5);
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot2.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer4.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean10 = plotRenderingInfo8.equals((java.lang.Object) color9);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets14, (java.awt.Paint) color15);
        legendTitle12.setItemPaint((java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace18 = color15.getColorSpace();
        float[] floatArray24 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray25 = color9.getComponents(colorSpace18, floatArray24);
        statisticalBarRenderer4.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.util.BooleanList booleanList27 = new org.jfree.chart.util.BooleanList();
        booleanList27.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray34, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray38);
        java.lang.Comparable comparable40 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement29, (org.jfree.data.general.Dataset) categoryDataset39, comparable40);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList27, (org.jfree.data.general.Dataset) categoryDataset39);
        org.jfree.data.Range range43 = statisticalBarRenderer4.findRangeBounds(categoryDataset39);
        statisticalBarRenderer4.setBaseItemLabelsVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj47 = categoryAxis46.clone();
        categoryAxis46.setLabelToolTip("hi!");
        boolean boolean50 = categoryAxis46.isTickMarksVisible();
        java.awt.Font font51 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis46.setLabelFont(font51);
        java.awt.Font font53 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis46.setTickLabelFont(font53);
        statisticalBarRenderer4.setBaseItemLabelFont(font53, false);
        labelBlock1.setFont(font53);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(font53);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        java.awt.Paint paint4 = null;
        legendTitle3.setBackgroundPaint(paint4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle3.setLegendItemGraphicAnchor(rectangleAnchor6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle3.setVerticalAlignment(verticalAlignment8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle3.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        double double2 = labelBlock1.getWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("GradientPaintTransformType.CENTER_VERTICAL", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        java.lang.Object obj4 = categoryAxis0.clone();
        java.lang.String str5 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setUpperMargin((-6.0d));
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape3 = defaultDrawingSupplier2.getNextShape();
        numberAxis0.setLeftArrow(shape3);
        java.awt.Shape shape5 = numberAxis0.getRightArrow();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        java.lang.Object obj4 = numberAxis0.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor7, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape0, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 10.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        boolean boolean2 = categoryAxis0.isVisible();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape5, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape5, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        java.lang.Object obj15 = axisLabelEntity14.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("GradientPaintTransformType.CENTER_VERTICAL", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        jFreeChart6.setPadding(rectangleInsets14);
        double double17 = rectangleInsets14.trimWidth((double) (-192));
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-198.0d) + "'", double17 == (-198.0d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation3, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation3, plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3);
        int int6 = keyedObjects0.getIndex((java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.chart.util.BooleanList booleanList8 = new org.jfree.chart.util.BooleanList();
        booleanList8.clear();
        keyedObjects0.addObject((java.lang.Comparable) (short) -1, (java.lang.Object) booleanList8);
        java.lang.Object obj11 = booleanList8.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Color color2 = java.awt.Color.getColor("Range[0.0,1.0]", (int) (byte) 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) categoryPlot3);
        java.util.List list7 = categoryPlot3.getCategories();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis8.setLeftArrow(shape10);
        java.text.NumberFormat numberFormat12 = null;
        numberAxis8.setNumberFormatOverride(numberFormat12);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis14.setLeftArrow(shape16);
        numberAxis14.setNegativeArrowVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis20.setLeftArrow(shape22);
        java.text.NumberFormat numberFormat24 = null;
        numberAxis20.setNumberFormatOverride(numberFormat24);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis28.setLeftArrow(shape30);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { numberAxis8, numberAxis14, numberAxis20, numberAxis26, numberAxis27, numberAxis28 };
        categoryPlot3.setRangeAxes(valueAxisArray32);
        int int34 = categoryPlot3.getDatasetCount();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        boolean boolean7 = categoryPlot3.isOutlineVisible();
        java.lang.Object obj8 = categoryPlot3.clone();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.LegendItemCollection legendItemCollection11 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = legendItemCollection11.equals((java.lang.Object) layer12);
        try {
            categoryPlot3.addRangeMarker((int) '4', marker10, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((-1));
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        double double5 = rectangleInsets1.calculateRightInset((double) 0L);
        double double7 = rectangleInsets1.extendHeight((double) (short) 10);
        double double9 = rectangleInsets1.calculateTopInset((double) ' ');
        double double11 = rectangleInsets1.calculateBottomInset((double) ' ');
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.0d + "'", double7 == 16.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj3 = keyedObjects0.clone();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot2.setDomainAxisLocation((int) '#', axisLocation6, true);
        categoryPlot2.setRangeGridlinesVisible(true);
        categoryPlot2.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextAnchor.CENTER", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("AxisLocation.BOTTOM_OR_LEFT", graphics2D1, (float) 15, (float) 500, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2, categoryLabelWidthType3, 0.0f);
        double double6 = categoryLabelPosition5.getAngle();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = categoryLabelPosition5.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition5);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = categoryLabelPosition5.getWidthType();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        boolean boolean11 = categoryLabelWidthType9.equals((java.lang.Object) itemLabelAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj7 = categoryAxis6.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isRangeGridlinesVisible();
        categoryAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getDomainAxisEdge(15);
        int int13 = categoryPlot8.getDatasetCount();
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color15 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis17.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color15, stroke16, rectangleInsets18);
        java.awt.Paint paint20 = lineBorder19.getPaint();
        boolean boolean21 = layer14.equals((java.lang.Object) lineBorder19);
        java.util.Collection collection22 = categoryPlot8.getDomainMarkers(layer14);
        try {
            categoryPlot0.addDomainMarker((-16777216), categoryMarker5, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        double double14 = categoryPlot0.getRangeCrosshairValue();
        boolean boolean15 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj11 = categoryAxis10.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getLabelInsets();
        double double14 = rectangleInsets12.trimHeight(1.0d);
        double double16 = rectangleInsets12.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        java.awt.Paint paint19 = null;
        legendTitle18.setBackgroundPaint(paint19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle18.setVerticalAlignment(verticalAlignment23);
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle18.getBounds();
        rectangleInsets12.trim(rectangle2D25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        try {
            jFreeChart6.draw(graphics2D9, rectangle2D25, chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-5.0d) + "'", double14 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font2);
        java.awt.Paint paint4 = textFragment3.getPaint();
        textLine0.removeFragment(textFragment3);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("GradientPaintTransformType.CENTER_VERTICAL", "hi!", "VerticalAlignment.CENTER", "", "");
        basicProjectInfo5.setVersion("TextAnchor.CENTER");
        java.lang.String str8 = basicProjectInfo5.getName();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str8.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 128);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, 0.0f);
        double double5 = categoryLabelPosition4.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition4.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor7 = categoryLabelPosition4.getRotationAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = categoryLabelPosition4.getLabelAnchor();
        float float9 = categoryLabelPosition4.getWidthRatio();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        categoryPlot0.setRangeGridlinePaint(paint18);
        boolean boolean21 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Image image22 = null;
        categoryPlot0.setBackgroundImage(image22);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        double double7 = legendTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle1.getMargin();
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        labelBlock1.setPaint((java.awt.Paint) color2);
        int int4 = color2.getRed();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint5);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition((int) '4');
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesPaint(4);
        boolean boolean14 = statisticalBarRenderer0.getItemCreateEntity(15, (-16777216));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str7 = chartEntity6.getShapeCoords();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator8 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator9 = null;
        java.lang.String str10 = chartEntity6.getImageMapAreaTag(toolTipTagFragmentGenerator8, uRLTagFragmentGenerator9);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-4,-4,4,4" + "'", str7.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = (byte) 100;
        double double3 = size2D0.height;
        double double4 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("rect");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        numberAxis0.setLeftArrow(shape7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit9, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean5 = legendItemCollection3.equals((java.lang.Object) layer4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle6.getVerticalAlignment();
        double double13 = textTitle6.getWidth();
        boolean boolean14 = layer4.equals((java.lang.Object) double13);
        java.util.Collection collection15 = categoryPlot2.getRangeMarkers(layer4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        categoryPlot2.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot2.rendererChanged(rendererChangeEvent18);
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(paint20);
        categoryPlot2.setRangeGridlinePaint(paint20);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("RectangleEdge.RIGHT", font1, paint20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj7 = categoryAxis6.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getLabelInsets();
        double double10 = rectangleInsets8.trimHeight(1.0d);
        double double12 = rectangleInsets8.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        java.awt.Paint paint15 = null;
        legendTitle14.setBackgroundPaint(paint15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle14.setLegendItemGraphicAnchor(rectangleAnchor17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle14.setVerticalAlignment(verticalAlignment19);
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle14.getBounds();
        rectangleInsets8.trim(rectangle2D21);
        try {
            blockBorder3.draw(graphics2D5, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-5.0d) + "'", double10 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.awt.Image image3 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator40 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator40);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setHorizontalAlignment(horizontalAlignment1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        double double23 = statisticalBarRenderer0.getLowerClip();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setToolTipText("MINOR");
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMaximumBarWidth();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        boolean boolean9 = gradientPaintTransformType3.equals((java.lang.Object) categoryPlot6);
        java.util.List list10 = categoryPlot6.getCategories();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            statisticalBarRenderer0.drawRangeGridline(graphics2D2, categoryPlot6, valueAxis11, rectangle2D12, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleEdge.TOP");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape9 = numberAxis0.getUpArrow();
        numberAxis0.resizeRange((double) 4, 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        java.awt.Paint paint10 = null;
        legendTitle9.setBackgroundPaint(paint10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle9.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle9.setVerticalAlignment(verticalAlignment14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle9.getBounds();
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color5.createContext(colorModel6, rectangle7, rectangle2D16, affineTransform17, renderingHints18);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer20.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = statisticalBarRenderer20.getSeriesURLGenerator((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = statisticalBarRenderer20.getPlot();
        try {
            java.lang.Object obj26 = labelBlock1.draw(graphics2D4, rectangle2D16, (java.lang.Object) statisticalBarRenderer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNull(categoryURLGenerator24);
        org.junit.Assert.assertNull(categoryPlot25);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getDomainAxisEdge(15);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = categoryPlot2.getDataRange(valueAxis7);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray6, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray10);
        java.lang.Comparable comparable12 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement1, (org.jfree.data.general.Dataset) categoryDataset11, comparable12);
        org.jfree.data.general.Dataset dataset14 = legendItemBlockContainer13.getDataset();
        org.jfree.chart.block.Arrangement arrangement15 = legendItemBlockContainer13.getArrangement();
        boolean boolean16 = rectangleAnchor0.equals((java.lang.Object) arrangement15);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(dataset14);
        org.junit.Assert.assertNotNull(arrangement15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 4, (double) 0.0f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        java.awt.Paint paint3 = null;
        legendTitle2.setBackgroundPaint(paint3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle2.setVerticalAlignment(verticalAlignment7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle2.getHorizontalAlignment();
        boolean boolean10 = gradientPaintTransformType0.equals((java.lang.Object) horizontalAlignment9);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        boolean boolean5 = categoryAxis0.equals((java.lang.Object) "RectangleEdge.TOP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        java.awt.Paint paint5 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.util.BooleanList booleanList6 = new org.jfree.chart.util.BooleanList();
        booleanList6.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray13, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray17);
        java.lang.Comparable comparable19 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.data.general.Dataset) categoryDataset18, comparable19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList6, (org.jfree.data.general.Dataset) categoryDataset18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot2.getRendererForDataset(categoryDataset18);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            categoryPlot2.setDomainAxisLocation((int) (byte) -1, axisLocation24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendHeight((double) (-16777216));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6777214E7d) + "'", double2 == (-1.6777214E7d));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType24 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj26 = categoryAxis25.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean28 = categoryPlot27.isRangeGridlinesVisible();
        categoryAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        boolean boolean30 = gradientPaintTransformType24.equals((java.lang.Object) categoryPlot27);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel34 = null;
        java.awt.Rectangle rectangle35 = null;
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        java.awt.Paint paint38 = null;
        legendTitle37.setBackgroundPaint(paint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle37.setLegendItemGraphicAnchor(rectangleAnchor40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle37.setVerticalAlignment(verticalAlignment42);
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle37.getBounds();
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color33.createContext(colorModel34, rectangle35, rectangle2D44, affineTransform45, renderingHints46);
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D23, categoryPlot27, categoryAxis31, categoryMarker32, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(gradientPaintTransformType24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(paintContext47);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        jFreeChart6.fireChartChanged();
        float float8 = jFreeChart6.getBackgroundImageAlpha();
        java.awt.Paint paint9 = jFreeChart6.getBorderPaint();
        boolean boolean10 = jFreeChart6.getAntiAlias();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis0.setNumberFormatOverride(numberFormat4);
        java.text.NumberFormat numberFormat6 = numberAxis0.getNumberFormatOverride();
        numberAxis0.setUpperBound((double) (-192));
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.setLabelToolTip("EXPAND");
        java.lang.Object obj6 = null;
        boolean boolean7 = categoryAxis0.equals(obj6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj10 = categoryAxis9.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isRangeGridlinesVisible();
        categoryAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot11);
        boolean boolean15 = categoryAxis0.hasListener((java.util.EventListener) jFreeChart14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        try {
            jFreeChart14.draw(graphics2D16, rectangle2D17, point2D18, chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        numberAxis0.setLowerBound((double) (byte) -1);
        boolean boolean11 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0.0d, (java.lang.Object) rectangleInsets13);
        numberAxis0.setLabelInsets(rectangleInsets13);
        numberAxis0.resizeRange((-1.6777214E7d), (double) '4');
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        double double6 = legendTitle1.getHeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj9 = categoryAxis8.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        categoryAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj14 = jFreeChart13.clone();
        java.lang.Object obj15 = jFreeChart13.getTextAntiAlias();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis18.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color16, stroke17, rectangleInsets19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder20.getInsets();
        jFreeChart13.setPadding(rectangleInsets21);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range6, 4.0d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        java.lang.String str3 = labelBlock2.getURLText();
        java.awt.Font font4 = labelBlock2.getFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(paint5);
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font4, paint5, 0.0f, 2, textMeasurer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        java.awt.Paint paint27 = null;
        legendTitle26.setBackgroundPaint(paint27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle26.getLegendItemGraphicLocation();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, rectangleAnchor29, (double) (short) 1, (double) 2);
        statisticalBarRenderer0.setBaseShape(shape24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator((int) 'a', categoryToolTipGenerator36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int39 = color38.getRGB();
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color38, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-192) + "'", int39 == (-192));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge(15);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font1, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.lang.Object obj12 = jFreeChart11.clone();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart11.getLegend();
        org.jfree.chart.event.ChartProgressListener chartProgressListener14 = null;
        jFreeChart11.addProgressListener(chartProgressListener14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(legendTitle13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape2, "hi!", "hi!");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        categoryLabelEntity5.setArea(shape6);
        java.lang.Object obj8 = categoryLabelEntity5.clone();
        java.lang.Comparable comparable9 = categoryLabelEntity5.getKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1L) + "'", comparable9.equals((-1L)));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range6);
        java.lang.String str8 = rectangleConstraint7.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str8.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("MINOR", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray11);
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement2, (org.jfree.data.general.Dataset) categoryDataset12, comparable13);
        boolean boolean15 = legendItemBlockContainer14.isEmpty();
        org.jfree.chart.block.Arrangement arrangement16 = legendItemBlockContainer14.getArrangement();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range18, range19);
        java.lang.String str21 = rectangleConstraint20.toString();
        try {
            org.jfree.chart.util.Size2D size2D22 = centerArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer14, graphics2D17, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(arrangement16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str21.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(2);
        paintList0.clear();
        java.awt.Paint paint5 = paintList0.getPaint((int) ' ');
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot2.setDomainAxisLocation((int) '#', axisLocation6, true);
        categoryPlot2.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj15 = categoryAxis14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getLabelInsets();
        org.jfree.chart.plot.Plot plot17 = categoryAxis14.getPlot();
        categoryPlot2.setDomainAxis((int) '#', categoryAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot2.getDomainAxisLocation(10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMaximumBarWidth();
        boolean boolean3 = statisticalBarRenderer0.isSeriesItemLabelsVisible(192);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        statisticalBarRenderer0.setPlot(categoryPlot4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = statisticalBarRenderer0.getBaseToolTipGenerator();
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        boolean boolean26 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        java.awt.Paint paint3 = null;
        legendTitle2.setBackgroundPaint(paint3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle2.getLegendItemGraphicLocation();
        boolean boolean6 = itemLabelAnchor0.equals((java.lang.Object) rectangleAnchor5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        double double7 = rectangleInsets3.trimHeight(0.0d);
        numberAxis0.setLabelInsets(rectangleInsets3);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '4');
        numberAxis0.setRightArrow(shape10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj13 = categoryAxis12.clone();
        boolean boolean14 = categoryAxis12.isVisible();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis12.setAxisLinePaint((java.awt.Paint) color15);
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape17, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape17, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis12, shape17, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        numberAxis0.setLeftArrow(shape17);
        org.jfree.data.Range range28 = null;
        try {
            numberAxis0.setRange(range28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-6.0d) + "'", double7 == (-6.0d));
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray5, numberArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray9);
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) categoryDataset10, comparable11);
        legendItemBlockContainer12.setToolTipText("-4,-4,4,4");
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedDimension((double) (-1));
        numberAxis0.setLowerMargin((double) (short) 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 500);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.data.Range range16 = null;
        try {
            numberAxis14.setRange(range16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, 0.0f);
        java.lang.String str5 = categoryLabelWidthType2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str5.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot6);
        jFreeChart9.fireChartChanged();
        float float11 = jFreeChart9.getBackgroundImageAlpha();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot0.getInsets();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint5);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition((int) '4');
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesPaint(4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator12, true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        numberAxis0.setLowerBound((double) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis12.setLeftArrow(shape14);
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape19 = defaultDrawingSupplier18.getNextShape();
        numberAxis12.setLeftArrow(shape19);
        statisticalBarRenderer11.setBaseShape(shape19);
        numberAxis0.setDownArrow(shape19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(markerAxisBand23);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj3 = categoryAxis2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge(15);
        int int9 = categoryPlot4.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font1, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.lang.Object obj12 = jFreeChart11.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart11.createBufferedImage((int) (short) 0, (-192), (int) (byte) 1, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-192) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.centerRange((double) (-1.0f));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        numberAxis0.setLowerBound((double) (byte) -1);
        org.jfree.chart.plot.Plot plot11 = numberAxis0.getPlot();
        numberAxis0.setUpperBound(0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range40, (double) '#');
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range40);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape9 = numberAxis0.getUpArrow();
        boolean boolean10 = numberAxis0.isVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        double double2 = range1.getLowerBound();
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range1, (double) 2.0f, 10.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot2.setRowRenderingOrder(sortOrder3);
        java.lang.String str5 = categoryPlot2.getPlotType();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot2.setRangeGridlinePaint((java.awt.Paint) color6);
        java.awt.Color color8 = color6.darker();
        barRenderer0.setSeriesPaint(0, (java.awt.Paint) color8, true);
        barRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        double double7 = legendTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle1.getMargin();
        java.awt.Paint paint9 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.lang.Object obj2 = plotRenderingInfo1.clone();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        java.awt.Paint paint5 = null;
        legendTitle4.setBackgroundPaint(paint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle4.setLegendItemGraphicAnchor(rectangleAnchor7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle4.setVerticalAlignment(verticalAlignment9);
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle4.getBounds();
        plotRenderingInfo1.setPlotArea(rectangle2D11);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        java.lang.String str2 = labelBlock1.getURLText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        java.awt.Paint paint6 = null;
        legendTitle5.setBackgroundPaint(paint6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle5.setVerticalAlignment(verticalAlignment10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle5.getBounds();
        try {
            labelBlock1.draw(graphics2D3, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        java.lang.Object obj4 = categoryAxis0.clone();
        java.lang.String str5 = categoryAxis0.getLabelToolTip();
        java.awt.Paint paint6 = null;
        try {
            categoryAxis0.setTickMarkPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray4, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset9);
        try {
            org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 20.0d + "'", number10.equals(20.0d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        categoryPlot0.setRangeGridlinePaint(paint18);
        boolean boolean21 = categoryPlot0.isRangeCrosshairVisible();
        int int22 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        boolean boolean4 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape1, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor8, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape1, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        numberAxis0.setUpArrow(shape1);
        numberAxis0.setAutoRangeIncludesZero(false);
        numberAxis0.resizeRange((double) (-1));
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getRange();
        double double2 = range1.getCentralValue();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.Number number0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor8, textAnchor9, (double) (-1L));
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "EXPAND", textAnchor5, textAnchor9, 10.0d);
        try {
            org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick(number0, "TextAnchor.CENTER", textAnchor2, textAnchor9, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        textTitle0.setText("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.lang.String str9 = textTitle0.getText();
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str9.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        int int2 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", font2);
        java.awt.Font font4 = textFragment3.getFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getLabelInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, (java.awt.Paint) color7);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("TextAnchor.CENTER", font4, (java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        statisticalBarRenderer0.setDrawBarOutline(false);
        boolean boolean28 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Color color29 = java.awt.Color.WHITE;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        boolean boolean2 = categoryAxis0.isVisible();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape5, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape5, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape5, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj16 = categoryAxis15.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis15.getLabelInsets();
        double double19 = rectangleInsets17.trimHeight(1.0d);
        double double21 = rectangleInsets17.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        java.awt.Paint paint24 = null;
        legendTitle23.setBackgroundPaint(paint24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle23.setLegendItemGraphicAnchor(rectangleAnchor26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle23.setVerticalAlignment(verticalAlignment28);
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle23.getBounds();
        rectangleInsets17.trim(rectangle2D30);
        axisLabelEntity14.setArea((java.awt.Shape) rectangle2D30);
        java.lang.String str33 = axisLabelEntity14.toString();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-5.0d) + "'", double19 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLabelEntity: label = null" + "'", str33.equals("AxisLabelEntity: label = null"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 100.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        java.awt.Stroke stroke30 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean34 = legendItemCollection32.equals((java.lang.Object) layer33);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        textTitle35.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = textTitle35.getVerticalAlignment();
        double double42 = textTitle35.getWidth();
        boolean boolean43 = layer33.equals((java.lang.Object) double42);
        java.util.Collection collection44 = categoryPlot31.getRangeMarkers(layer33);
        java.awt.Stroke stroke45 = categoryPlot31.getDomainGridlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke45, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator48 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator48, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.util.Locale locale1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass4 = chartChangeEventType3.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass6 = chartChangeEventType5.getClass();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        try {
            java.util.ResourceBundle resourceBundle9 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", locale1, classLoader8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(classLoader8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass4 = chartChangeEventType3.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass6 = chartChangeEventType5.getClass();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", (java.lang.Class) wildcardClass4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass12 = chartChangeEventType11.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass14 = chartChangeEventType13.getClass();
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass14);
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass18 = chartChangeEventType17.getClass();
        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass18);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.CENTER", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass18);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(classLoader16);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) categoryPlot3);
        java.util.List list7 = categoryPlot3.getCategories();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        categoryPlot3.notifyListeners(plotChangeEvent8);
        categoryPlot3.clearRangeMarkers();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer11.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean17 = plotRenderingInfo15.equals((java.lang.Object) color16);
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, (java.awt.Paint) color22);
        legendTitle19.setItemPaint((java.awt.Paint) color22);
        java.awt.color.ColorSpace colorSpace25 = color22.getColorSpace();
        float[] floatArray31 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray32 = color16.getComponents(colorSpace25, floatArray31);
        statisticalBarRenderer11.setBaseItemLabelPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke36 = statisticalBarRenderer11.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint38 = statisticalBarRenderer11.lookupSeriesPaint((int) (byte) -1);
        statisticalBarRenderer11.setIncludeBaseInRange(false);
        java.awt.Stroke stroke41 = statisticalBarRenderer11.getBaseOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean45 = legendItemCollection43.equals((java.lang.Object) layer44);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        textTitle46.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment52 = textTitle46.getVerticalAlignment();
        double double53 = textTitle46.getWidth();
        boolean boolean54 = layer44.equals((java.lang.Object) double53);
        java.util.Collection collection55 = categoryPlot42.getRangeMarkers(layer44);
        java.awt.Stroke stroke56 = categoryPlot42.getDomainGridlineStroke();
        statisticalBarRenderer11.setBaseOutlineStroke(stroke56, false);
        categoryPlot3.setDomainGridlineStroke(stroke56);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(verticalAlignment52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets11);
        java.awt.Paint paint13 = lineBorder12.getPaint();
        boolean boolean14 = layer7.equals((java.lang.Object) lineBorder12);
        java.util.Collection collection15 = categoryPlot3.getDomainMarkers(layer7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor22, textAnchor23, (double) (-1L));
        boolean boolean26 = plotRenderingInfo19.equals((java.lang.Object) numberTick25);
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot3.zoomRangeAxes(10.0d, (double) 1L, plotRenderingInfo19, point2D27);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo19);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = plotRenderingInfo19.getSubplotInfo(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean27 = statisticalBarRenderer0.getSeriesVisible(2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = new org.jfree.chart.labels.ItemLabelPosition();
        double double30 = itemLabelPosition29.getAngle();
        try {
            statisticalBarRenderer0.setSeriesNegativeItemLabelPosition((-192), itemLabelPosition29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        boolean boolean2 = categoryAxis0.isVisible();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        float float5 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.util.List list2 = keyedObjects2D0.getRowKeys();
        java.lang.Object obj5 = keyedObjects2D0.getObject((java.lang.Comparable) (short) 0, (java.lang.Comparable) "TextAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color4);
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor7);
        legendTitle1.setWidth((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj3 = keyedObjects0.clone();
        java.lang.Object obj5 = keyedObjects0.getObject((int) (short) 100);
        java.util.List list6 = keyedObjects0.getKeys();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE2" + "'", str1.equals("ItemLabelAnchor.OUTSIDE2"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets11);
        java.awt.Paint paint13 = lineBorder12.getPaint();
        boolean boolean14 = layer7.equals((java.lang.Object) lineBorder12);
        java.util.Collection collection15 = categoryPlot3.getDomainMarkers(layer7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor22, textAnchor23, (double) (-1L));
        boolean boolean26 = plotRenderingInfo19.equals((java.lang.Object) numberTick25);
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot3.zoomRangeAxes(10.0d, (double) 1L, plotRenderingInfo19, point2D27);
        java.awt.Paint paint29 = categoryPlot3.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        categoryPlot0.setRangeGridlinePaint(paint18);
        boolean boolean21 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        jFreeChart6.setPadding(rectangleInsets14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        jFreeChart6.setBackgroundPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 500, 2.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "rect");
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            categoryPlot4.addRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        java.lang.Object obj3 = objectList1.get(10);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        textTitle1.setPaint((java.awt.Paint) color7);
        java.awt.Color color9 = java.awt.Color.getColor("", color7);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation3, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot0.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot0.getParent();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        plotRenderingInfo12.setPlotArea(rectangle2D13);
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomDomainAxes(16.0d, 0.0d, plotRenderingInfo12, point2D15);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = legendItemCollection19.equals((java.lang.Object) layer20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        textTitle22.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = textTitle22.getVerticalAlignment();
        double double29 = textTitle22.getWidth();
        boolean boolean30 = layer20.equals((java.lang.Object) double29);
        java.util.Collection collection31 = categoryPlot18.getRangeMarkers(layer20);
        try {
            categoryPlot0.addRangeMarker(marker17, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(collection31);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint42 = statisticalBarRenderer0.getBasePaint();
        boolean boolean43 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape46, (double) (short) 100, (float) 192, (float) 500);
        statisticalBarRenderer0.setSeriesShape(0, shape46, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        numberAxis0.setLowerBound((double) (byte) -1);
        boolean boolean11 = numberAxis0.getAutoRangeIncludesZero();
        try {
            numberAxis0.zoomRange(261.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (521.0) <= upper (-3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedDimension((double) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        boolean boolean6 = categoryAxis4.isVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color7);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape9, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis4, shape9, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj20 = categoryAxis19.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis19.getLabelInsets();
        double double23 = rectangleInsets21.trimHeight(1.0d);
        double double25 = rectangleInsets21.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        java.awt.Paint paint28 = null;
        legendTitle27.setBackgroundPaint(paint28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle27.setLegendItemGraphicAnchor(rectangleAnchor30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle27.setVerticalAlignment(verticalAlignment32);
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle27.getBounds();
        rectangleInsets21.trim(rectangle2D34);
        axisLabelEntity18.setArea((java.awt.Shape) rectangle2D34);
        org.jfree.chart.axis.AxisCollection axisCollection37 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj39 = categoryAxis38.clone();
        boolean boolean40 = categoryAxis38.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisCollection37.add((org.jfree.chart.axis.Axis) categoryAxis38, rectangleEdge41);
        double double43 = numberAxis0.valueToJava2D(20.0d, rectangle2D34, rectangleEdge41);
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D34, "MINOR", "RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-5.0d) + "'", double23 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-117.0d) + "'", double43 == (-117.0d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 4);
        double double6 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart6.getLegend(0);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        java.awt.Paint paint14 = null;
        legendTitle13.setBackgroundPaint(paint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle13.getLegendItemGraphicLocation();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        textTitle17.setPaint((java.awt.Paint) color23);
        legendTitle13.setItemPaint((java.awt.Paint) color23);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        java.awt.Paint paint28 = null;
        legendTitle27.setBackgroundPaint(paint28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle27.setLegendItemGraphicAnchor(rectangleAnchor30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle27.setVerticalAlignment(verticalAlignment32);
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle27.getBounds();
        legendTitle13.setBounds(rectangle2D34);
        java.awt.geom.Point2D point2D36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        try {
            jFreeChart6.draw(graphics2D11, rectangle2D34, point2D36, chartRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        double double9 = numberAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer1 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) layer1);
        org.jfree.chart.LegendItem legendItem3 = null;
        legendItemCollection0.add(legendItem3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = legendItemCollection5.equals((java.lang.Object) layer6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean10 = legendItemCollection8.equals((java.lang.Object) layer9);
        legendItemCollection5.addAll(legendItemCollection8);
        legendItemCollection0.addAll(legendItemCollection5);
        org.junit.Assert.assertNotNull(layer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        categoryPlot3.clearAnnotations();
        java.lang.String str8 = categoryPlot3.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot3.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint42 = statisticalBarRenderer0.getBasePaint();
        boolean boolean43 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        try {
            statisticalBarRenderer0.setSeriesItemLabelsVisible((-16777216), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isRangeGridlinesVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getDomainAxisEdge(15);
        int int7 = categoryPlot2.getDatasetCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = null;
        try {
            categoryPlot2.setDatasetRenderingOrder(datasetRenderingOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        boolean boolean14 = legendItem13.isShapeVisible();
        int int15 = legendItem13.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = legendItem13.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean3 = plotRenderingInfo1.equals((java.lang.Object) color2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = plotRenderingInfo5.getOwner();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(chartRenderingInfo7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(16.0d, (double) 10.0f);
        size2D2.setWidth((double) (byte) 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("RectangleEdge.TOP");
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.lang.String str4 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str4.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        boolean boolean14 = legendItem13.isShapeVisible();
        java.lang.String str15 = legendItem13.getURLText();
        boolean boolean16 = legendItem13.isShapeVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str15.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (short) 0);
        java.lang.String str6 = rectangleConstraint2.toString();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str6.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", "-4,-4,4,4", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        java.awt.Stroke stroke30 = statisticalBarRenderer0.getBaseOutlineStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.Font font35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean39 = legendItemCollection37.equals((java.lang.Object) layer38);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        textTitle40.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle40.getVerticalAlignment();
        double double47 = textTitle40.getWidth();
        boolean boolean48 = layer38.equals((java.lang.Object) double47);
        java.util.Collection collection49 = categoryPlot36.getRangeMarkers(layer38);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
        categoryPlot36.datasetChanged(datasetChangeEvent50);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        categoryPlot36.rendererChanged(rendererChangeEvent52);
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("Category Plot", font35, (org.jfree.chart.plot.Plot) categoryPlot36, false);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel57 = null;
        java.awt.Rectangle rectangle58 = null;
        org.jfree.chart.LegendItemSource legendItemSource59 = null;
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle(legendItemSource59);
        java.awt.Paint paint61 = null;
        legendTitle60.setBackgroundPaint(paint61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle60.setLegendItemGraphicAnchor(rectangleAnchor63);
        org.jfree.chart.util.VerticalAlignment verticalAlignment65 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle60.setVerticalAlignment(verticalAlignment65);
        java.awt.geom.Rectangle2D rectangle2D67 = legendTitle60.getBounds();
        java.awt.geom.AffineTransform affineTransform68 = null;
        java.awt.RenderingHints renderingHints69 = null;
        java.awt.PaintContext paintContext70 = color56.createContext(colorModel57, rectangle58, rectangle2D67, affineTransform68, renderingHints69);
        try {
            statisticalBarRenderer0.drawOutline(graphics2D33, categoryPlot36, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(verticalAlignment65);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(paintContext70);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        labelBlock1.setPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = labelBlock1.getPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setSeriesVisible(128, (java.lang.Boolean) true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setFixedDimension((double) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj11 = categoryAxis10.clone();
        boolean boolean12 = categoryAxis10.isVisible();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis10.setAxisLinePaint((java.awt.Paint) color13);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape15, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape15, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis10, shape15, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj26 = categoryAxis25.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryAxis25.getLabelInsets();
        double double29 = rectangleInsets27.trimHeight(1.0d);
        double double31 = rectangleInsets27.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        java.awt.Paint paint34 = null;
        legendTitle33.setBackgroundPaint(paint34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle33.setLegendItemGraphicAnchor(rectangleAnchor36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle33.setVerticalAlignment(verticalAlignment38);
        java.awt.geom.Rectangle2D rectangle2D40 = legendTitle33.getBounds();
        rectangleInsets27.trim(rectangle2D40);
        axisLabelEntity24.setArea((java.awt.Shape) rectangle2D40);
        org.jfree.chart.axis.AxisCollection axisCollection43 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj45 = categoryAxis44.clone();
        boolean boolean46 = categoryAxis44.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisCollection43.add((org.jfree.chart.axis.Axis) categoryAxis44, rectangleEdge47);
        double double49 = numberAxis6.valueToJava2D(20.0d, rectangle2D40, rectangleEdge47);
        org.jfree.chart.plot.Marker marker50 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo51);
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick58 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "", textAnchor55, textAnchor56, (double) (-1L));
        boolean boolean59 = plotRenderingInfo52.equals((java.lang.Object) numberTick58);
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel61 = null;
        java.awt.Rectangle rectangle62 = null;
        org.jfree.chart.LegendItemSource legendItemSource63 = null;
        org.jfree.chart.title.LegendTitle legendTitle64 = new org.jfree.chart.title.LegendTitle(legendItemSource63);
        java.awt.Paint paint65 = null;
        legendTitle64.setBackgroundPaint(paint65);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle64.setLegendItemGraphicAnchor(rectangleAnchor67);
        org.jfree.chart.util.VerticalAlignment verticalAlignment69 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle64.setVerticalAlignment(verticalAlignment69);
        java.awt.geom.Rectangle2D rectangle2D71 = legendTitle64.getBounds();
        java.awt.geom.AffineTransform affineTransform72 = null;
        java.awt.RenderingHints renderingHints73 = null;
        java.awt.PaintContext paintContext74 = color60.createContext(colorModel61, rectangle62, rectangle2D71, affineTransform72, renderingHints73);
        plotRenderingInfo52.setDataArea(rectangle2D71);
        statisticalBarRenderer0.drawRangeMarker(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) numberAxis6, marker50, rectangle2D71);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-5.0d) + "'", double29 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-117.0d) + "'", double49 == (-117.0d));
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(verticalAlignment69);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(paintContext74);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '#', 15, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("MINOR", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        java.awt.Stroke stroke14 = legendItem13.getLineStroke();
        org.jfree.chart.util.PaintList paintList15 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint17 = paintList15.getPaint(2);
        paintList15.clear();
        boolean boolean19 = legendItem13.equals((java.lang.Object) paintList15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        boolean boolean7 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj9 = categoryAxis8.clone();
        categoryAxis8.setLabelToolTip("hi!");
        boolean boolean12 = categoryAxis8.isTickMarksVisible();
        categoryAxis8.setUpperMargin(0.05d);
        int int15 = categoryPlot3.getDomainAxisIndex(categoryAxis8);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor9, (double) (byte) 100, (double) 0L);
        try {
            java.awt.GradientPaint gradientPaint13 = standardGradientPaintTransformer0.transform(gradientPaint1, shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        java.lang.String str6 = numberAxis0.getLabelToolTip();
        java.awt.Shape shape7 = numberAxis0.getRightArrow();
        numberAxis0.setAutoRangeMinimumSize((double) 1.0f, false);
        float float11 = numberAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        statisticalBarRenderer0.setBasePaint(paint28);
        boolean boolean31 = statisticalBarRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Font font32 = statisticalBarRenderer0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator33);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray5, numberArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray9);
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) categoryDataset10, comparable11);
        boolean boolean13 = legendItemBlockContainer12.isEmpty();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj16 = categoryAxis15.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean18 = categoryPlot17.isRangeGridlinesVisible();
        categoryAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis15.getCategoryLabelPositions();
        org.jfree.data.Range range22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(100.0d, range22);
        double double24 = rectangleConstraint23.getWidth();
        boolean boolean25 = categoryAxis15.equals((java.lang.Object) rectangleConstraint23);
        try {
            org.jfree.chart.util.Size2D size2D26 = legendItemBlockContainer12.arrange(graphics2D14, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        boolean boolean3 = numberAxis0.isInverted();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        double double5 = numberAxis0.getLowerBound();
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis0.setMarkerBand(markerAxisBand8);
        numberAxis0.setPositiveArrowVisible(true);
        numberAxis0.resizeRange(100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        boolean boolean14 = legendItem13.isShapeVisible();
        java.awt.Paint paint15 = legendItem13.getLinePaint();
        org.jfree.data.general.Dataset dataset16 = legendItem13.getDataset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(dataset16);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.calculateBottomInset((-5.0d));
        double double5 = rectangleInsets1.trimHeight((double) (-192));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-198.0d) + "'", double5 == (-198.0d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3);
        int int6 = keyedObjects0.getIndex((java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL");
        int int7 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = null;
        legendTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle1.setPosition(rectangleEdge8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        double double5 = rectangleInsets1.calculateRightInset((double) 0L);
        double double7 = rectangleInsets1.extendHeight((double) (short) 10);
        double double9 = rectangleInsets1.calculateTopInset((double) ' ');
        double double10 = rectangleInsets1.getLeft();
        double double12 = rectangleInsets1.extendWidth((-1.6777214E7d));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.0d + "'", double7 == 16.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.6777208E7d) + "'", double12 == (-1.6777208E7d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint42 = statisticalBarRenderer0.getBasePaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator((int) 'a', categoryToolTipGenerator44);
        org.jfree.chart.LegendItem legendItem48 = statisticalBarRenderer0.getLegendItem(192, 128);
        org.jfree.chart.LegendItemCollection legendItemCollection49 = statisticalBarRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(legendItem48);
        org.junit.Assert.assertNotNull(legendItemCollection49);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray11);
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement2, (org.jfree.data.general.Dataset) categoryDataset12, comparable13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList0, (org.jfree.data.general.Dataset) categoryDataset12);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset12);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 20.0d + "'", number16.equals(20.0d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range3 = numberAxis2.getRange();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis4.getLabelInsets();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color6);
        double double9 = rectangleInsets5.trimHeight(0.0d);
        numberAxis2.setLabelInsets(rectangleInsets5);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '4');
        numberAxis2.setRightArrow(shape12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.Paint paint16 = null;
        legendTitle15.setBackgroundPaint(paint16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle15.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle15.getPosition();
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge19);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-6.0d) + "'", double9 == (-6.0d));
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("-4,-4,4,4", "", "", "AxisLocation.BOTTOM_OR_LEFT", shape4, stroke6, (java.awt.Paint) color10);
        boolean boolean14 = legendItem13.isShapeVisible();
        java.lang.String str15 = legendItem13.getURLText();
        java.awt.Shape shape16 = legendItem13.getLine();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str15.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Color color2 = java.awt.Color.getColor("rect", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType7 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6, categoryLabelWidthType7, 0.0f);
        double double10 = categoryLabelPosition9.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor11 = categoryLabelPosition9.getRotationAnchor();
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick(tickType0, 16.0d, "", textAnchor3, textAnchor11, (double) 100);
        java.lang.Number number14 = numberTick13.getNumber();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.CENTER" + "'", str4.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelWidthType7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 16.0d + "'", number14.equals(16.0d));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("RectangleEdge.TOP");
        java.awt.Image image3 = null;
        projectInfo0.setLogo(image3);
        java.util.List list5 = projectInfo0.getContributors();
        try {
            java.util.Collection collection6 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list5);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        java.lang.Object obj7 = jFreeChart6.clone();
        java.lang.Object obj8 = jFreeChart6.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart6.getLegend(0);
        jFreeChart6.setBackgroundImageAlignment(1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(legendTitle10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMaximumBarWidth();
        boolean boolean3 = statisticalBarRenderer0.isSeriesItemLabelsVisible(192);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(16.0d, 0.05d, (double) (-1), 0.05d, paint10);
        statisticalBarRenderer5.setBaseItemLabelPaint(paint10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer5.getSeriesPositiveItemLabelPosition((int) '4');
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Font font1 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color11, stroke12, rectangleInsets14);
        java.awt.Paint paint16 = lineBorder15.getPaint();
        boolean boolean17 = layer10.equals((java.lang.Object) lineBorder15);
        java.util.Collection collection18 = categoryPlot6.getDomainMarkers(layer10);
        java.util.Collection collection19 = categoryPlot0.getDomainMarkers(15, layer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, (java.awt.Paint) color22);
        double double25 = rectangleInsets21.calculateRightInset((double) 0L);
        double double27 = rectangleInsets21.extendHeight((double) (short) 10);
        double double29 = rectangleInsets21.calculateTopInset((double) ' ');
        double double30 = rectangleInsets21.getLeft();
        categoryPlot0.setInsets(rectangleInsets21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 16.0d + "'", double27 == 16.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        boolean boolean3 = numberAxis0.isInverted();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        numberAxis0.zoomRange((double) (byte) 0, 20.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray5, numberArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray9);
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) categoryDataset10, comparable11);
        java.lang.String str13 = legendItemBlockContainer12.getURLText();
        java.lang.Object obj14 = null;
        boolean boolean15 = legendItemBlockContainer12.equals(obj14);
        java.awt.Font font17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = legendItemCollection19.equals((java.lang.Object) layer20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        textTitle22.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = textTitle22.getVerticalAlignment();
        double double29 = textTitle22.getWidth();
        boolean boolean30 = layer20.equals((java.lang.Object) double29);
        java.util.Collection collection31 = categoryPlot18.getRangeMarkers(layer20);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = null;
        categoryPlot18.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("Category Plot", font17, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        textTitle38.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle38.setTextAlignment(horizontalAlignment44);
        jFreeChart37.addSubtitle((org.jfree.chart.title.Title) textTitle38);
        legendItemBlockContainer12.add((org.jfree.chart.block.Block) textTitle38);
        java.awt.Color color48 = java.awt.Color.YELLOW;
        int int49 = color48.getRed();
        java.awt.image.ColorModel colorModel50 = null;
        java.awt.Rectangle rectangle51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj53 = categoryAxis52.clone();
        boolean boolean54 = categoryAxis52.isVisible();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis52.setAxisLinePaint((java.awt.Paint) color55);
        java.awt.Shape shape57 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape57, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity63 = new org.jfree.chart.entity.ChartEntity(shape57, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity66 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis52, shape57, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj68 = categoryAxis67.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = categoryAxis67.getLabelInsets();
        double double71 = rectangleInsets69.trimHeight(1.0d);
        double double73 = rectangleInsets69.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource74 = null;
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle(legendItemSource74);
        java.awt.Paint paint76 = null;
        legendTitle75.setBackgroundPaint(paint76);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle75.setLegendItemGraphicAnchor(rectangleAnchor78);
        org.jfree.chart.util.VerticalAlignment verticalAlignment80 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle75.setVerticalAlignment(verticalAlignment80);
        java.awt.geom.Rectangle2D rectangle2D82 = legendTitle75.getBounds();
        rectangleInsets69.trim(rectangle2D82);
        axisLabelEntity66.setArea((java.awt.Shape) rectangle2D82);
        java.awt.geom.AffineTransform affineTransform85 = null;
        java.awt.RenderingHints renderingHints86 = null;
        java.awt.PaintContext paintContext87 = color48.createContext(colorModel50, rectangle51, rectangle2D82, affineTransform85, renderingHints86);
        textTitle38.setPaint((java.awt.Paint) color48);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 255 + "'", int49 == 255);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + (-5.0d) + "'", double71 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 4.0d + "'", double73 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor78);
        org.junit.Assert.assertNotNull(verticalAlignment80);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(paintContext87);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot3);
        jFreeChart6.fireChartChanged();
        float float8 = jFreeChart6.getBackgroundImageAlpha();
        java.awt.Paint paint9 = jFreeChart6.getBorderPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart6.getPadding();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator24, true);
        boolean boolean27 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape29, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape29, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor36, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape29, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray53 = new java.lang.Number[][] { numberArray49, numberArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray53);
        java.lang.Number number55 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset54);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity58 = new org.jfree.chart.entity.CategoryItemEntity(shape29, "VerticalAlignment.CENTER", "Range[0.0,1.0]", categoryDataset54, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Comparable) 20.0d);
        statisticalBarRenderer0.setSeriesShape((int) (byte) 1, shape29, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 20.0d + "'", number55.equals(20.0d));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis1.setLeftArrow(shape3);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        numberAxis1.setLeftArrow(shape8);
        statisticalBarRenderer0.setBaseShape(shape8);
        java.awt.Font font12 = statisticalBarRenderer0.getSeriesItemLabelFont((int) ' ');
        statisticalBarRenderer0.setSeriesVisible((int) (short) 0, (java.lang.Boolean) false, false);
        java.awt.Shape shape18 = statisticalBarRenderer0.lookupSeriesShape((int) (short) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = statisticalBarRenderer0.getURLGenerator((int) (short) 10, (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        try {
            statisticalBarRenderer0.setPlot(categoryPlot22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryURLGenerator21);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray4, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape6 = defaultDrawingSupplier5.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-1L), shape6, "hi!", "hi!");
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        labelBlock11.setPaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("rect", "", "", "MINOR", shape6, (java.awt.Paint) color12);
        java.lang.String str16 = legendItem15.getToolTipText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range5 = numberAxis4.getRange();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color8);
        double double11 = rectangleInsets7.trimHeight(0.0d);
        numberAxis4.setLabelInsets(rectangleInsets7);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '4');
        numberAxis4.setRightArrow(shape14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj17 = categoryAxis16.clone();
        boolean boolean18 = categoryAxis16.isVisible();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis16.setAxisLinePaint((java.awt.Paint) color19);
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape21, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape21, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity30 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis16, shape21, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        numberAxis4.setLeftArrow(shape21);
        java.awt.Paint paint32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean34 = categoryPlot33.isRangeGridlinesVisible();
        categoryPlot33.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj38 = categoryAxis37.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean40 = categoryPlot39.isRangeGridlinesVisible();
        categoryAxis37.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot39);
        jFreeChart42.fireChartChanged();
        float float44 = jFreeChart42.getBackgroundImageAlpha();
        categoryPlot33.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart42);
        java.awt.Stroke stroke46 = categoryPlot33.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder48 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot47.setRowRenderingOrder(sortOrder48);
        java.lang.String str50 = categoryPlot47.getPlotType();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot47.setRangeGridlinePaint((java.awt.Paint) color51);
        try {
            org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "ItemLabelAnchor.OUTSIDE2", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", shape21, paint32, stroke46, (java.awt.Paint) color51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-6.0d) + "'", double11 == (-6.0d));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.5f + "'", float44 == 0.5f);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Category Plot" + "'", str50.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("hi!");
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray11);
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement2, (org.jfree.data.general.Dataset) categoryDataset12, comparable13);
        java.lang.String str15 = legendItemBlockContainer14.getURLText();
        java.lang.String str16 = legendItemBlockContainer14.getURLText();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = null;
        try {
            org.jfree.chart.util.Size2D size2D19 = centerArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer14, graphics2D17, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        java.lang.String str3 = categoryPlot0.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        categoryPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj9 = categoryAxis8.clone();
        categoryAxis8.setLabelToolTip("hi!");
        boolean boolean12 = categoryAxis8.isTickMarksVisible();
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis8.setLabelFont(font13);
        java.util.List list15 = categoryPlot0.getCategoriesForAxis(categoryAxis8);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        numberAxis0.setLeftArrow(shape2);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoTickUnitSelection(false, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis0.getStandardTickUnits();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.setLabelToolTip("hi!");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        java.awt.Paint paint12 = null;
        legendTitle11.setBackgroundPaint(paint12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle11.setVerticalAlignment(verticalAlignment16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle11.getBounds();
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color7.createContext(colorModel8, rectangle9, rectangle2D18, affineTransform19, renderingHints20);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setFixedDimension((double) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj27 = categoryAxis26.clone();
        boolean boolean28 = categoryAxis26.isVisible();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis26.setAxisLinePaint((java.awt.Paint) color29);
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape31, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape31, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity40 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis26, shape31, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj42 = categoryAxis41.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryAxis41.getLabelInsets();
        double double45 = rectangleInsets43.trimHeight(1.0d);
        double double47 = rectangleInsets43.trimHeight((double) 10L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        java.awt.Paint paint50 = null;
        legendTitle49.setBackgroundPaint(paint50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle49.setLegendItemGraphicAnchor(rectangleAnchor52);
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle49.setVerticalAlignment(verticalAlignment54);
        java.awt.geom.Rectangle2D rectangle2D56 = legendTitle49.getBounds();
        rectangleInsets43.trim(rectangle2D56);
        axisLabelEntity40.setArea((java.awt.Shape) rectangle2D56);
        org.jfree.chart.axis.AxisCollection axisCollection59 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj61 = categoryAxis60.clone();
        boolean boolean62 = categoryAxis60.isVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisCollection59.add((org.jfree.chart.axis.Axis) categoryAxis60, rectangleEdge63);
        double double65 = numberAxis22.valueToJava2D(20.0d, rectangle2D56, rectangleEdge63);
        double double66 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor4, (int) (byte) -1, (int) (short) 10, rectangle2D18, rectangleEdge63);
        boolean boolean67 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge63);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-5.0d) + "'", double45 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-117.0d) + "'", double65 == (-117.0d));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        double double14 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.BooleanList booleanList15 = new org.jfree.chart.util.BooleanList();
        booleanList15.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray22, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray26);
        java.lang.Comparable comparable28 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement17, (org.jfree.data.general.Dataset) categoryDataset27, comparable28);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList15, (org.jfree.data.general.Dataset) categoryDataset27);
        org.jfree.data.general.Dataset dataset31 = datasetChangeEvent30.getDataset();
        categoryPlot0.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj35 = categoryAxis34.clone();
        categoryAxis34.setLabelToolTip("hi!");
        categoryAxis34.setLabelToolTip("EXPAND");
        java.awt.Shape shape40 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape40, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity(shape40, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis34, shape40, "GradientPaintTransformType.CENTER_VERTICAL", "VerticalAlignment.CENTER");
        categoryAxis34.setTickLabelsVisible(false);
        categoryPlot0.setDomainAxis(128, categoryAxis34);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(dataset31);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape44);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.lang.Boolean boolean27 = statisticalBarRenderer0.getSeriesVisible(2);
        double double28 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        statisticalBarRenderer0.setItemLabelAnchorOffset((-198.0d));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("RectangleEdge.TOP");
        projectInfo0.setLicenceText("");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isRangeGridlinesVisible();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER", (org.jfree.chart.plot.Plot) categoryPlot6);
        jFreeChart9.fireChartChanged();
        float float11 = jFreeChart9.getBackgroundImageAlpha();
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(0, axisLocation15, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color0 = java.awt.Color.white;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean7 = plotRenderingInfo5.equals((java.lang.Object) color6);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getLabelInsets();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, (java.awt.Paint) color12);
        legendTitle9.setItemPaint((java.awt.Paint) color12);
        java.awt.color.ColorSpace colorSpace15 = color12.getColorSpace();
        float[] floatArray21 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray22 = color6.getComponents(colorSpace15, floatArray21);
        float[] floatArray23 = java.awt.Color.RGBtoHSB(100, (int) '#', 0, floatArray22);
        float[] floatArray24 = color0.getRGBComponents(floatArray23);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.CENTER");
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass3 = chartChangeEventType2.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Class<?> wildcardClass5 = chartChangeEventType4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("GradientPaintTransformType.CENTER_VERTICAL", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResource("VerticalAlignment.CENTER", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(uRL7);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean3 = legendItemCollection1.equals((java.lang.Object) layer2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        double double11 = textTitle4.getWidth();
        boolean boolean12 = layer2.equals((java.lang.Object) double11);
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(layer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent16);
        categoryPlot0.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemOutlineStroke((int) (byte) -1, (-1));
        java.awt.Paint paint27 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape29, (double) 2, (float) 100, (float) 100);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape29, "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor36, (double) (byte) 100, (double) 0L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape29, "CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "HorizontalAlignment.RIGHT");
        numberAxis28.setUpArrow(shape29);
        statisticalBarRenderer0.setBaseShape(shape29, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 100, 15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator24, true);
        boolean boolean27 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        java.lang.String str31 = labelBlock30.getURLText();
        java.awt.Font font32 = labelBlock30.getFont();
        statisticalBarRenderer0.setSeriesItemLabelFont(4, font32, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean2 = rangeType0.equals((java.lang.Object) unitType1);
        java.lang.String str3 = unitType1.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = legendItemCollection5.equals((java.lang.Object) layer6);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.setPadding((double) 4, (double) (short) 0, (double) 4, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = textTitle8.getVerticalAlignment();
        double double15 = textTitle8.getWidth();
        boolean boolean16 = layer6.equals((java.lang.Object) double15);
        java.util.Collection collection17 = categoryPlot4.getRangeMarkers(layer6);
        boolean boolean18 = unitType1.equals((java.lang.Object) collection17);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UnitType.ABSOLUTE" + "'", str3.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setGenerateEntities(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets4);
        int int6 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(100.0d, range4);
        double double6 = rectangleConstraint5.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint5.toFixedHeight((double) 4);
        try {
            org.jfree.chart.util.Size2D size2D9 = labelBlock1.arrange(graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        boolean boolean6 = plotRenderingInfo4.equals((java.lang.Object) color5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color11);
        legendTitle8.setItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        float[] floatArray20 = new float[] { 2, 100L, (byte) 10, (short) 10, (byte) 10 };
        float[] floatArray21 = color5.getComponents(colorSpace14, floatArray20);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.BooleanList booleanList23 = new org.jfree.chart.util.BooleanList();
        booleanList23.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (-1.0d), 10 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=-1, tooltip=hi!, url=hi!", "TextAnchor.CENTER", numberArray34);
        java.lang.Comparable comparable36 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, (org.jfree.data.general.Dataset) categoryDataset35, comparable36);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) booleanList23, (org.jfree.data.general.Dataset) categoryDataset35);
        org.jfree.data.Range range39 = statisticalBarRenderer0.findRangeBounds(categoryDataset35);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint42 = statisticalBarRenderer0.getBasePaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator((int) 'a', categoryToolTipGenerator44);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryAxis49.getLabelInsets();
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color51);
        legendTitle48.setItemPaint((java.awt.Paint) color51);
        legendTitle48.setNotify(false);
        java.awt.Font font57 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj59 = categoryAxis58.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean61 = categoryPlot60.isRangeGridlinesVisible();
        categoryAxis58.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot60);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot60.getDomainAxisEdge(15);
        int int65 = categoryPlot60.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart67 = new org.jfree.chart.JFreeChart("AxisLocation.BOTTOM_OR_LEFT", font57, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        legendTitle48.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart67);
        java.awt.Paint paint69 = jFreeChart67.getBorderPaint();
        try {
            statisticalBarRenderer0.setSeriesItemLabelPaint((-16777216), paint69, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(paint69);
    }
}

