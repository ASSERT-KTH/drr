import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, 0.0f, (float) (short) 100, textAnchor4, (double) (short) -1, textAnchor6);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", graphics2D1, (float) (short) -1, (float) (byte) 100, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNull(classLoader0);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = null;
        try {
            ringPlot0.setBaseSectionOutlineStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Comparable comparable1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            strokeMap0.put(comparable1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Pie Plot");
        java.awt.Paint paint2 = textFragment1.getPaint();
        java.awt.Stroke stroke3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder(paint2, stroke3, rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeWidth(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.util.Size2D size2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = rectangleConstraint2.calculateConstrainedSize(size2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryStart((int) (short) 100, 1, rectangle2D3, rectangleEdge4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = categoryAxis3D0.draw(graphics2D6, (double) '4', rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            xYPlot5.setDomainAxisLocation(axisLocation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = null;
        try {
            categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 1L, 1.0f, (double) (byte) 1, (float) (-1), 0.0f);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        valueAxis9.setFixedDimension((double) 100L);
        org.jfree.data.Range range12 = null;
        try {
            valueAxis9.setRangeWithMargins(range12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = null;
        try {
            xYPlot5.setInsets(rectangleInsets17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.title.LegendTitle legendTitle8 = null;
        try {
            jFreeChart7.addLegend(legendTitle8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = null;
        try {
            jFreeChart7.titleChanged(titleChangeEvent8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 100.0f, (-1.0d), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Pie Plot");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            xYPlot6.addRangeMarker(marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        double double10 = numberAxis3D9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer12);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        xYPlot13.rendererChanged(rendererChangeEvent14);
        boolean boolean16 = xYPlot13.isRangeZoomable();
        boolean boolean17 = xYPlot13.isDomainZeroBaselineVisible();
        int int18 = xYPlot13.getDatasetCount();
        xYPlot13.setRangeCrosshairLockedOnData(false);
        int int21 = xYPlot13.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot13.getRangeAxisEdge();
        try {
            double double23 = numberAxis3D3.java2DToValue((double) 100, rectangle2D7, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets8.createInsetRectangle(rectangle2D9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.LEFT", graphics2D1, (float) (byte) 10, 0.0f, (double) (short) -1, (float) 500, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickMarkOutsideLength((float) (-1L));
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        double double6 = numberAxis3D5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, xYItemRenderer8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot9.rendererChanged(rendererChangeEvent10);
        boolean boolean12 = xYPlot9.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot9.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot9.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint18 = xYPlot9.getRangeTickBandPaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        double double22 = numberAxis3D21.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, xYItemRenderer24);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        xYPlot25.rendererChanged(rendererChangeEvent26);
        boolean boolean28 = xYPlot25.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot25.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot25.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace35 = categoryAxis3D0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot9, rectangle2D19, rectangleEdge33, axisSpace34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(valueAxis29);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) '#', (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelOutlineStroke();
        java.awt.Paint paint7 = ringPlot0.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot0.getURLGenerator();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setBorderVisible(true);
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("PieSection: 10, -16777216(DateTickUnit[DAY, 1])", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            xYPlot5.drawBackground(graphics2D36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        xYPlot5.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot5.getDataset();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            xYPlot5.drawOutline(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(xYDataset9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        ringPlot0.notifyListeners(plotChangeEvent1);
        double double3 = ringPlot0.getShadowXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            ringPlot0.setSimpleLabelOffset(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        java.awt.Color color3 = java.awt.Color.GRAY;
        int int4 = color3.getBlue();
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = null;
        try {
            ringPlot0.setLabelPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeHeight(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryStart((int) (short) 100, 1, rectangle2D3, rectangleEdge4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        double double12 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYPlot15.rendererChanged(rendererChangeEvent16);
        boolean boolean18 = xYPlot15.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot15.getRangeAxisEdge((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = categoryAxis3D0.draw(graphics2D6, 10.0d, rectangle2D8, rectangle2D9, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        boolean boolean34 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ChartChangeEventType.NEW_DATASET", "ChartChangeEventType.NEW_DATASET", "PieSection: 10, -16777216(DateTickUnit[DAY, 1])", "ChartChangeEventType.NEW_DATASET");
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        xYPlot5.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            xYPlot5.handleClick(0, (int) '4', plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            xYPlot5.drawBackground(graphics2D36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("Pie Plot", font1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot8.rendererChanged(rendererChangeEvent9);
        boolean boolean11 = xYPlot8.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot8.getRangeAxis();
        java.awt.Paint paint13 = xYPlot8.getDomainTickBandPaint();
        xYPlot8.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot8.setRenderer(0, xYItemRenderer17, true);
        boolean boolean20 = textLine2.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxis12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        double double6 = numberAxis3D1.getLowerMargin();
        try {
            numberAxis3D1.setAutoRangeMinimumSize((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        double double12 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYPlot15.rendererChanged(rendererChangeEvent16);
        boolean boolean18 = xYPlot15.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot15.getRangeAxisEdge((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = numberAxis3D3.draw(graphics2D6, 0.0d, rectangle2D8, rectangle2D9, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryStart((int) (short) 100, 1, rectangle2D3, rectangleEdge4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        double double10 = numberAxis3D9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer12);
        xYPlot13.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot13.getDataset();
        boolean boolean18 = lineBorder7.equals((java.lang.Object) xYPlot13);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace22 = categoryAxis3D0.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) xYPlot13, rectangle2D19, rectangleEdge20, axisSpace21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        int int13 = xYPlot5.getRangeAxisCount();
        boolean boolean14 = xYPlot5.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=255,g=255,b=64]", graphics2D1, 10.0f, (float) (byte) 100, textAnchor4, 0.0d, (float) 0L, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Shape shape3 = ringPlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=255,b=64]", font1, paint2, (float) '#', 500, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.lang.String str6 = numberAxis3D3.getLabel();
        boolean boolean7 = numberAxis3D3.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D1.setPositiveArrowVisible(false);
        numberAxis3D1.setLabelAngle((double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        org.jfree.chart.title.TextTitle textTitle9 = null;
        jFreeChart7.setTitle(textTitle9);
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart7.addChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("XY Plot", graphics2D1, (float) (-1L), (float) 1L, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) true);
        strokeMap0.clear();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        double double6 = numberAxis3D5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, xYItemRenderer8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        double double12 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYPlot15.rendererChanged(rendererChangeEvent16);
        boolean boolean18 = xYPlot15.isRangeZoomable();
        java.awt.Image image19 = null;
        xYPlot15.setBackgroundImage(image19);
        java.lang.String str21 = xYPlot15.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str23 = ringPlot22.getPlotType();
        ringPlot22.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        ringPlot22.datasetChanged(datasetChangeEvent26);
        java.awt.Stroke stroke28 = ringPlot22.getLabelOutlineStroke();
        xYPlot15.setRangeGridlineStroke(stroke28);
        numberAxis3D7.setAxisLineStroke(stroke28);
        boolean boolean31 = strokeMap0.equals((java.lang.Object) stroke28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pie Plot" + "'", str23.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) (-1), 0.0f, (double) (-16777216), 0.0f, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint8 = ringPlot0.getSeparatorPaint();
        double double10 = ringPlot0.getExplodePercent((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) image9, jFreeChart11, (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        xYPlot5.setWeight(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, paint4, (float) (byte) 1);
        textLine1.removeFragment(textFragment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            textLine1.draw(graphics2D8, (float) (short) 0, 10.0f, textAnchor11, (float) 100L, (float) 2, 45.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = legendTitle1.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.toString();
        java.lang.String str11 = pieSectionEntity9.getShapeCoords();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 10, -16777216(DateTickUnit[DAY, 1])" + "'", str10.equals("PieSection: 10, -16777216(DateTickUnit[DAY, 1])"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0,0,-2,-2,-2,2,-2,2" + "'", str11.equals("0,0,-2,-2,-2,2,-2,2"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        boolean boolean7 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.getToolTipText();
        int int11 = pieSectionEntity9.getPieIndex();
        pieSectionEntity9.setPieIndex((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = textTitle17.getPaint();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            textTitle17.setBounds(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        int int13 = xYPlot5.getRangeAxisCount();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = xYPlot5.removeDomainMarker(marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace12, true);
        int int15 = xYPlot5.getSeriesCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setBackgroundImageAlpha(100.0f);
        boolean boolean17 = jFreeChart8.isBorderVisible();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot5.getDataset();
        xYPlot5.clearDomainAxes();
        boolean boolean12 = xYPlot5.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color7);
        ringPlot0.setSectionDepth(0.0d);
        java.awt.Paint paint11 = null;
        try {
            ringPlot0.setLabelLinkPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = new org.jfree.chart.LegendItemCollection();
        boolean boolean13 = legendItemCollection11.equals((java.lang.Object) 4.0d);
        xYPlot5.setFixedLegendItems(legendItemCollection11);
        try {
            org.jfree.chart.LegendItem legendItem16 = legendItemCollection11.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot6.getDatasetRenderingOrder();
        java.awt.Paint paint9 = xYPlot6.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        java.awt.Image image15 = null;
        xYPlot11.setBackgroundImage(image15);
        java.lang.String str17 = xYPlot11.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str19 = ringPlot18.getPlotType();
        ringPlot18.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        ringPlot18.datasetChanged(datasetChangeEvent22);
        java.awt.Stroke stroke24 = ringPlot18.getLabelOutlineStroke();
        xYPlot11.setRangeGridlineStroke(stroke24);
        numberAxis3D3.setAxisLineStroke(stroke24);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        double double30 = numberAxis3D29.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, xYItemRenderer32);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        double double37 = numberAxis3D36.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, xYItemRenderer39);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYPlot40.rendererChanged(rendererChangeEvent41);
        boolean boolean43 = xYPlot40.isRangeZoomable();
        boolean boolean44 = xYPlot40.isDomainZeroBaselineVisible();
        int int45 = xYPlot40.getDatasetCount();
        xYPlot40.setRangeCrosshairLockedOnData(false);
        int int48 = xYPlot40.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot40.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace51 = numberAxis3D3.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) xYPlot33, rectangle2D34, rectangleEdge49, axisSpace50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pie Plot" + "'", str19.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color14 = java.awt.Color.black;
        int int15 = color14.getRGB();
        float[] floatArray21 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray22 = color14.getRGBColorComponents(floatArray21);
        xYPlot5.setRangeTickBandPaint((java.awt.Paint) color14);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot5.setDataset((int) (short) 10, xYDataset25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot5.setDataset(xYDataset27);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16777216) + "'", int15 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleEdge.LEFT", graphics2D1, (float) (-16777216), (float) 10L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot5.getDomainMarkers(layer12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color7);
        try {
            ringPlot0.setInteriorGap((double) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (500.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        java.lang.Object obj15 = jFreeChart8.getTextAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart8.addProgressListener(chartProgressListener16);
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        double double42 = numberAxis3D41.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer44);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        xYPlot45.rendererChanged(rendererChangeEvent46);
        boolean boolean48 = xYPlot45.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot45.getRangeAxis();
        java.awt.Paint paint50 = xYPlot45.getDomainTickBandPaint();
        xYPlot45.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        xYPlot45.setRenderer(0, xYItemRenderer54, false);
        org.jfree.chart.plot.RingPlot ringPlot57 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str58 = ringPlot57.getPlotType();
        ringPlot57.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent61 = null;
        ringPlot57.datasetChanged(datasetChangeEvent61);
        java.awt.Stroke stroke63 = ringPlot57.getLabelLinkStroke();
        xYPlot45.setRangeGridlineStroke(stroke63);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot45.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation67 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation66, plotOrientation67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        try {
            org.jfree.chart.axis.AxisState axisState70 = numberAxis3D30.draw(graphics2D36, (double) 128, rectangle2D38, rectangle2D39, rectangleEdge68, plotRenderingInfo69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Pie Plot" + "'", str58.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(plotOrientation67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        xYPlot6.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot6.getDataset();
        boolean boolean11 = lineBorder0.equals((java.lang.Object) xYPlot6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        xYPlot6.datasetChanged(datasetChangeEvent12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection3 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        boolean boolean9 = ringPlot0.equals((java.lang.Object) (short) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = ringPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        double double19 = numberAxis3D18.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, xYItemRenderer21);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYPlot22.rendererChanged(rendererChangeEvent23);
        boolean boolean25 = xYPlot22.isRangeZoomable();
        java.awt.Image image26 = null;
        xYPlot22.setBackgroundImage(image26);
        java.lang.String str28 = xYPlot22.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str30 = ringPlot29.getPlotType();
        ringPlot29.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        ringPlot29.datasetChanged(datasetChangeEvent33);
        java.awt.Stroke stroke35 = ringPlot29.getLabelOutlineStroke();
        xYPlot22.setRangeGridlineStroke(stroke35);
        numberAxis3D14.setAxisLineStroke(stroke35);
        numberAxis3D14.setTickLabelsVisible(true);
        numberAxis3D14.setLowerMargin(0.0d);
        boolean boolean42 = ringPlot0.equals((java.lang.Object) numberAxis3D14);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "XY Plot" + "'", str28.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Pie Plot" + "'", str30.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        double double10 = rectangleInsets8.calculateRightOutset((double) (byte) -1);
        double double12 = rectangleInsets8.calculateLeftOutset(0.0d);
        double double14 = rectangleInsets8.trimWidth((double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = xYPlot5.removeRangeMarker(marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        java.awt.Image image2 = ringPlot0.getBackgroundImage();
        java.awt.Paint paint3 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1.0d), (double) (byte) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot5.getRangeAxis((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel((int) '4');
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        double double6 = numberAxis3D5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, xYItemRenderer8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot9.rendererChanged(rendererChangeEvent10);
        boolean boolean12 = xYPlot9.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot9.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot9.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint18 = xYPlot9.getRangeTickBandPaint();
        boolean boolean19 = standardPieSectionLabelGenerator0.equals((java.lang.Object) xYPlot9);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryMargin((double) 3);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot12.rendererChanged(rendererChangeEvent13);
        boolean boolean15 = xYPlot12.isRangeZoomable();
        boolean boolean16 = xYPlot12.isDomainZeroBaselineVisible();
        int int17 = xYPlot12.getDatasetCount();
        xYPlot12.setRangeCrosshairLockedOnData(false);
        int int20 = xYPlot12.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot12.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            org.jfree.chart.axis.AxisState axisState23 = categoryAxis3D0.draw(graphics2D3, (double) 8, rectangle2D5, rectangle2D6, rectangleEdge21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        ringPlot0.setMinimumArcAngleToDraw((double) 10);
        ringPlot0.setLabelGap(8.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.data.Range range20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) 8, range20);
        try {
            org.jfree.chart.util.Size2D size2D22 = textTitle17.arrange(graphics2D18, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "java.awt.Color[r=255,g=255,b=64]", "", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        java.lang.String str7 = basicProjectInfo5.getName();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "java.awt.Color[r=255,g=255,b=64]", "", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        boolean boolean8 = basicProjectInfo5.equals((java.lang.Object) rectangleAnchor7);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("Pie Plot");
        java.awt.Paint paint5 = textFragment4.getPaint();
        ringPlot0.setBaseSectionPaint(paint5);
        double double7 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-5d + "'", double7 == 1.0E-5d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        try {
            legendTitle1.setHorizontalAlignment(horizontalAlignment4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryMargin((double) 3);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = categoryAxis3D0.draw(graphics2D3, 0.0d, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        java.awt.Paint paint13 = jFreeChart8.getBorderPaint();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = null;
        try {
            jFreeChart8.titleChanged(titleChangeEvent14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setMinimumArcAngleToDraw(49.5d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        java.awt.Color color3 = java.awt.Color.GRAY;
        int int4 = color3.getBlue();
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        double double6 = ringPlot0.getStartAngle();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        org.jfree.chart.JFreeChart jFreeChart13 = chartProgressEvent12.getChart();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot14 = jFreeChart13.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.XYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(jFreeChart13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font1, (java.awt.Paint) color2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str5 = ringPlot4.getPlotType();
        ringPlot4.setStartAngle((double) 'a');
        double double8 = ringPlot4.getLabelLinkMargin();
        boolean boolean9 = textLine3.equals((java.lang.Object) double8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        try {
            org.jfree.chart.util.Size2D size2D4 = rectangleConstraint2.calculateConstrainedSize(size2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("ClassContext", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        java.awt.Shape shape7 = numberAxis3D1.getLeftArrow();
        numberAxis3D1.setInverted(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str11 = ringPlot10.getPlotType();
        float float12 = ringPlot10.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) 0, plotRenderingInfo14);
        org.jfree.chart.entity.EntityCollection entityCollection16 = piePlotState15.getEntityCollection();
        piePlotState15.setPieHRadius((double) 0.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = piePlotState15.getInfo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNull(entityCollection16);
        org.junit.Assert.assertNull(plotRenderingInfo19);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray19, numberArray24, numberArray29, numberArray34, numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset46, 1);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity54 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset48, (int) ' ', (-16777216), (java.lang.Comparable) 100.0f, "hi!", "");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(pieDataset48);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor5);
        java.lang.Object obj7 = null;
        boolean boolean8 = legendTitle1.equals(obj7);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.String str1 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        boolean boolean3 = numberAxis3D0.isVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 1, (float) 128, (double) (byte) 100, (float) (short) 0, (float) 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Object obj0 = null;
        java.awt.Stroke[] strokeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart9.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray1, jFreeChart9, (int) (byte) 100, 128);
        jFreeChart9.setAntiAlias(false);
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart9, (-16777216), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("PieSection: 10, -16777216(DateTickUnit[DAY, 1])");
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ChartChangeEventType.NEW_DATASET");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        double double7 = numberAxis3D6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, xYItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot10.rendererChanged(rendererChangeEvent11);
        boolean boolean13 = xYPlot10.isRangeZoomable();
        boolean boolean14 = xYPlot10.isDomainZeroBaselineVisible();
        int int15 = xYPlot10.getDatasetCount();
        xYPlot10.setRangeCrosshairLockedOnData(false);
        int int18 = xYPlot10.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot10.getRangeAxisEdge();
        java.lang.String str20 = rectangleEdge19.toString();
        try {
            double double21 = categoryAxis3D1.getCategoryMiddle(100, (int) (byte) 100, rectangle2D4, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleEdge.LEFT" + "'", str20.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie Plot");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        java.awt.Paint paint13 = numberAxis3D8.getLabelPaint();
        numberAxis3D8.setLabelToolTip("");
        xYPlot5.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, true);
        numberAxis3D8.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range6 = rectangleConstraint5.getWidthRange();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.geom.Point2D point2D12 = xYPlot5.getQuadrantOrigin();
        xYPlot5.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot5.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot5.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot5.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection17);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        int int25 = xYPlot5.getWeight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Stroke stroke2 = null;
        try {
            valueMarker1.setStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.text.NumberFormat numberFormat2 = numberAxis3D0.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(numberFormat2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("java.awt.Color[r=255,g=255,b=64]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) lineBorder1);
        boolean boolean4 = plotOrientation0.equals((java.lang.Object) 90.0d);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        numberAxis3D1.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            legendTitle1.draw(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYPlot16.rendererChanged(rendererChangeEvent17);
        boolean boolean19 = xYPlot16.isRangeZoomable();
        java.awt.Image image20 = null;
        xYPlot16.setBackgroundImage(image20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot16);
        java.awt.geom.Point2D point2D23 = xYPlot16.getQuadrantOrigin();
        xYPlot5.zoomRangeAxes((double) 0.0f, 1.05d, plotRenderingInfo10, point2D23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(point2D23);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        double double14 = numberAxis3D13.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        double double21 = numberAxis3D20.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, xYItemRenderer23);
        java.awt.Paint paint25 = numberAxis3D20.getLabelPaint();
        numberAxis3D20.setLabelToolTip("");
        xYPlot17.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, true);
        boolean boolean30 = xYPlot5.equals((java.lang.Object) true);
        double double31 = xYPlot5.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        xYPlot6.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot6.getDataset();
        boolean boolean11 = lineBorder0.equals((java.lang.Object) xYPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot6.zoomRangeAxes((double) 'a', plotRenderingInfo13, point2D14);
        xYPlot6.clearAnnotations();
        boolean boolean17 = xYPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ThreadContext\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D1.setPositiveArrowVisible(false);
        double double8 = numberAxis3D1.getUpperBound();
        numberAxis3D1.configure();
        double double10 = numberAxis3D1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0.0f, (double) (short) 10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color7);
        int int9 = color7.getTransparency();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 100, 90.0d, 0.0d, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = xYPlot6.isRangeZoomable();
        boolean boolean10 = xYPlot6.isDomainZeroBaselineVisible();
        int int11 = xYPlot6.getDatasetCount();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        int int14 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot6.getRangeAxisEdge();
        boolean boolean16 = objectList0.equals((java.lang.Object) xYPlot6);
        int int17 = objectList0.size();
        java.lang.Object obj19 = objectList0.get((int) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(obj19);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21, numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset38, true);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        double double43 = numberAxis3D42.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer45);
        org.jfree.data.Range range47 = numberAxis3D42.getDefaultAutoRange();
        org.jfree.data.Range range48 = org.jfree.data.Range.combine(range40, range47);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint2.toRangeWidth(range40);
        org.jfree.data.Range range52 = org.jfree.data.Range.expand(range40, (double) (short) 100, (double) 10L);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(range52);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str11 = ringPlot10.getPlotType();
        float float12 = ringPlot10.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) 0, plotRenderingInfo14);
        org.jfree.chart.entity.EntityCollection entityCollection16 = piePlotState15.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        piePlotState15.setPieArea(rectangle2D17);
        piePlotState15.setTotal(0.0d);
        piePlotState15.setPieCenterY((double) 3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNull(entityCollection16);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart7.getPadding();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font2, paint3, (float) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        double double14 = numberAxis3D13.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYPlot17.rendererChanged(rendererChangeEvent18);
        boolean boolean20 = xYPlot17.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot17.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot17.setFixedRangeAxisSpace(axisSpace22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot17.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color26 = java.awt.Color.black;
        int int27 = color26.getRGB();
        float[] floatArray33 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray34 = color26.getRGBColorComponents(floatArray33);
        xYPlot17.setRangeTickBandPaint((java.awt.Paint) color26);
        xYPlot11.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.text.TextMeasurer textMeasurer38 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock39 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=255,b=64]", font2, (java.awt.Paint) color26, (float) (byte) 10, textMeasurer38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(valueAxis21);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-16777216) + "'", int27 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        dateAxis0.setLowerMargin(10.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            jFreeChart7.handleClick((int) '#', (int) (byte) 0, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot5.getDataset();
        try {
            java.awt.Paint paint12 = xYPlot5.getQuadrantPaint(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10, layer11);
        java.awt.Paint paint13 = null;
        try {
            valueMarker10.setPaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryStart((int) (short) 100, 1, rectangle2D3, rectangleEdge4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        double double12 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYPlot15.rendererChanged(rendererChangeEvent16);
        boolean boolean18 = xYPlot15.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot15.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot15.getRangeAxisEdge((int) (short) 1);
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge23);
        try {
            double double25 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor6, 0, 100, rectangle2D9, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot5.getRangeAxis(2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D1.setPositiveArrowVisible(false);
        numberAxis3D1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis3D1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot16);
        java.awt.Paint paint18 = jFreeChart17.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle19 = jFreeChart17.getTitle();
        try {
            jFreeChart7.addSubtitle((int) (short) 100, (org.jfree.chart.title.Title) textTitle19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(textTitle19);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        legendTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        java.lang.Object obj4 = legendTitle1.clone();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        try {
            numberAxis3D30.setRange((double) (byte) 0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = xYPlot6.isRangeZoomable();
        boolean boolean10 = xYPlot6.isDomainZeroBaselineVisible();
        int int11 = xYPlot6.getDatasetCount();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        int int14 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot6.getRangeAxisEdge();
        boolean boolean16 = objectList0.equals((java.lang.Object) xYPlot6);
        int int17 = objectList0.size();
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot5.getRendererForDataset(xYDataset11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(xYItemRenderer12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        java.awt.Paint paint8 = jFreeChart7.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        try {
            textTitle9.setTextAlignment(horizontalAlignment10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textTitle9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot5.getDataset();
        xYPlot5.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17, numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        java.awt.Color color37 = java.awt.Color.red;
        boolean boolean38 = range36.equals((java.lang.Object) color37);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType39 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint(range41, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType44 = rectangleConstraint43.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toUnconstrainedHeight();
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray67 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray72 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray77 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray78 = new java.lang.Number[][] { numberArray52, numberArray57, numberArray62, numberArray67, numberArray72, numberArray77 };
        org.jfree.data.category.CategoryDataset categoryDataset79 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray78);
        org.jfree.data.Range range81 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset79, true);
        org.jfree.data.xy.XYDataset xYDataset82 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D83 = new org.jfree.chart.axis.NumberAxis3D();
        double double84 = numberAxis3D83.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D85 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer86 = null;
        org.jfree.chart.plot.XYPlot xYPlot87 = new org.jfree.chart.plot.XYPlot(xYDataset82, (org.jfree.chart.axis.ValueAxis) numberAxis3D83, (org.jfree.chart.axis.ValueAxis) numberAxis3D85, xYItemRenderer86);
        org.jfree.data.Range range88 = numberAxis3D83.getDefaultAutoRange();
        org.jfree.data.Range range89 = org.jfree.data.Range.combine(range81, range88);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint90 = rectangleConstraint43.toRangeWidth(range81);
        org.jfree.data.Range range92 = org.jfree.data.Range.shift(range81, 90.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType93 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint94 = new org.jfree.chart.block.RectangleConstraint((double) 500, range36, lengthConstraintType39, (double) (byte) 1, range92, lengthConstraintType93);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType39);
        org.junit.Assert.assertNotNull(lengthConstraintType44);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(numberArray77);
        org.junit.Assert.assertNotNull(numberArray78);
        org.junit.Assert.assertNotNull(categoryDataset79);
        org.junit.Assert.assertNotNull(range81);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(range88);
        org.junit.Assert.assertNotNull(range89);
        org.junit.Assert.assertNotNull(rectangleConstraint90);
        org.junit.Assert.assertNotNull(range92);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        java.lang.String str13 = chartProgressEvent12.toString();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str13 = ringPlot12.getPlotType();
        ringPlot12.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        ringPlot12.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = ringPlot12.getLabelOutlineStroke();
        xYPlot5.setRangeGridlineStroke(stroke18);
        xYPlot5.clearDomainMarkers((int) (byte) 100);
        boolean boolean22 = xYPlot5.isSubplot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, paint4, (float) (byte) 1);
        textLine1.removeFragment(textFragment6);
        boolean boolean9 = textLine1.equals((java.lang.Object) 600.0d);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint11 = ringPlot10.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str15 = ringPlot14.getPlotType();
        ringPlot14.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        ringPlot14.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = ringPlot14.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot21 = ringPlot14.getRootPlot();
        boolean boolean22 = ringPlot14.isCircular();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = ringPlot10.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 3, plotRenderingInfo24);
        boolean boolean26 = textLine1.equals((java.lang.Object) graphics2D12);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pie Plot" + "'", str15.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        java.awt.Image image15 = null;
        xYPlot11.setBackgroundImage(image15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot11);
        java.awt.geom.Point2D point2D18 = xYPlot11.getQuadrantOrigin();
        try {
            polarPlot0.zoomRangeAxes((double) 1, 4.0d, plotRenderingInfo5, point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, true);
        xYPlot5.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        double double22 = numberAxis3D21.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        double double28 = numberAxis3D27.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, xYItemRenderer30);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYPlot31.rendererChanged(rendererChangeEvent32);
        boolean boolean34 = xYPlot31.isRangeZoomable();
        java.awt.Image image35 = null;
        xYPlot31.setBackgroundImage(image35);
        java.lang.String str37 = xYPlot31.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str39 = ringPlot38.getPlotType();
        ringPlot38.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        ringPlot38.datasetChanged(datasetChangeEvent42);
        java.awt.Stroke stroke44 = ringPlot38.getLabelOutlineStroke();
        xYPlot31.setRangeGridlineStroke(stroke44);
        numberAxis3D23.setAxisLineStroke(stroke44);
        xYPlot5.setOutlineStroke(stroke44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "XY Plot" + "'", str37.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Pie Plot" + "'", str39.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D3.setAxisLineVisible(false);
        boolean boolean8 = numberAxis3D3.isVerticalTickLabels();
        numberAxis3D3.centerRange(45.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        java.awt.Paint paint13 = numberAxis3D8.getLabelPaint();
        numberAxis3D8.setLabelToolTip("");
        xYPlot5.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, true);
        numberAxis3D8.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D8.getLabelInsets();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        double double27 = numberAxis3D26.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer29);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        xYPlot30.rendererChanged(rendererChangeEvent31);
        boolean boolean33 = xYPlot30.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot30.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot30.getRangeAxisEdge((int) (short) 1);
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            org.jfree.chart.axis.AxisState axisState41 = numberAxis3D8.draw(graphics2D21, (double) (short) -1, rectangle2D23, rectangle2D24, rectangleEdge38, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot5.getDomainAxisForDataset(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 500 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.lang.String str36 = numberAxis3D30.getLabelURL();
        java.awt.Shape shape37 = numberAxis3D30.getLeftArrow();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.Color color13 = java.awt.Color.red;
        jFreeChart12.setBackgroundPaint((java.awt.Paint) color13);
        jFreeChart12.setNotify(true);
        java.awt.RenderingHints renderingHints17 = jFreeChart12.getRenderingHints();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(renderingHints17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        double double10 = numberAxis3D9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer12);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        xYPlot13.rendererChanged(rendererChangeEvent14);
        boolean boolean16 = xYPlot13.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot13.getRangeAxisEdge((int) '#');
        try {
            double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D7, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint8 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        ringPlot0.setBaseSectionPaint(paint9);
        java.lang.Object obj11 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D3.setAxisLineVisible(false);
        boolean boolean8 = numberAxis3D3.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, xYItemRenderer17);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYPlot18.rendererChanged(rendererChangeEvent19);
        boolean boolean21 = xYPlot18.isRangeZoomable();
        boolean boolean22 = xYPlot18.isDomainZeroBaselineVisible();
        int int23 = xYPlot18.getDatasetCount();
        xYPlot18.setRangeCrosshairLockedOnData(false);
        int int26 = xYPlot18.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot18.getRangeAxisEdge();
        java.lang.String str28 = rectangleEdge27.toString();
        java.lang.Class<?> wildcardClass29 = rectangleEdge27.getClass();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            org.jfree.chart.axis.AxisState axisState31 = numberAxis3D3.draw(graphics2D9, 0.2d, rectangle2D11, rectangle2D12, rectangleEdge27, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleEdge.LEFT" + "'", str28.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = xYPlot19.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker23, layer24);
        try {
            boolean boolean26 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        double double10 = rectangleInsets8.extendWidth((double) 1.0f);
        double double12 = rectangleInsets8.calculateLeftInset((double) 100L);
        double double14 = rectangleInsets8.calculateTopOutset((double) 0.5f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 100L);
        java.awt.Font font5 = legendTitle2.getItemFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        boolean boolean15 = xYPlot11.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke16 = xYPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("Pie Plot", font5, (org.jfree.chart.plot.Plot) xYPlot11, true);
        org.jfree.chart.event.ChartChangeListener chartChangeListener19 = null;
        try {
            jFreeChart18.addChangeListener(chartChangeListener19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        float float8 = xYPlot5.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color0 = java.awt.Color.PINK;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint14 = xYPlot5.getRangeTickBandPaint();
        float float15 = xYPlot5.getForegroundAlpha();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot5.getDatasetGroup();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            xYPlot5.addRangeMarker(marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNull(datasetGroup16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        java.awt.Color color57 = java.awt.Color.pink;
        categoryPlot54.setRangeCrosshairPaint((java.awt.Paint) color57);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        double double63 = numberAxis3D62.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset61, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, (org.jfree.chart.axis.ValueAxis) numberAxis3D64, xYItemRenderer65);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        xYPlot66.rendererChanged(rendererChangeEvent67);
        boolean boolean69 = xYPlot66.isRangeZoomable();
        java.awt.Image image70 = null;
        xYPlot66.setBackgroundImage(image70);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent72 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot66);
        java.awt.geom.Point2D point2D73 = xYPlot66.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        try {
            categoryPlot54.draw(graphics2D59, rectangle2D60, point2D73, plotState74, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(point2D73);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.getToolTipText();
        java.lang.Object obj11 = pieSectionEntity9.clone();
        java.lang.Object obj12 = pieSectionEntity9.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color14 = java.awt.Color.black;
        int int15 = color14.getRGB();
        float[] floatArray21 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray22 = color14.getRGBColorComponents(floatArray21);
        xYPlot5.setRangeTickBandPaint((java.awt.Paint) color14);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            xYPlot5.handleClick((int) (byte) 10, (int) '4', plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16777216) + "'", int15 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle1.getMargin();
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = legendTitle1.arrange(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle17.draw(graphics2D18, rectangle2D19);
        java.awt.Paint paint21 = textTitle17.getBackgroundPaint();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        textTitle17.draw(graphics2D22, rectangle2D23);
        double double25 = textTitle17.getContentYOffset();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getTransparency();
        java.lang.String str3 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str3.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        org.jfree.data.Range range4 = null;
        try {
            dateAxis0.setRange(range4, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        legendTitle1.setItemLabelPadding(rectangleInsets7);
        double double10 = rectangleInsets7.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        java.awt.Paint paint13 = numberAxis3D8.getLabelPaint();
        numberAxis3D8.setLabelToolTip("");
        xYPlot5.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, true);
        numberAxis3D8.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D8.getLabelInsets();
        java.lang.String str21 = rectangleInsets20.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str21.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot5.getDomainAxisLocation((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "java.awt.Color[r=255,g=255,b=64]", "", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        org.jfree.chart.ui.Library library7 = null;
        try {
            basicProjectInfo5.addOptionalLibrary(library7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        double double8 = dateAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray55 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot54.setRenderers(categoryItemRendererArray55);
        java.awt.Stroke stroke57 = categoryPlot54.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        double double60 = numberAxis3D59.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D61 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset58, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, (org.jfree.chart.axis.ValueAxis) numberAxis3D61, xYItemRenderer62);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent64 = null;
        xYPlot63.rendererChanged(rendererChangeEvent64);
        boolean boolean66 = xYPlot63.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis67 = xYPlot63.getRangeAxis();
        java.awt.Paint paint68 = xYPlot63.getDomainTickBandPaint();
        xYPlot63.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = null;
        xYPlot63.setRenderer(0, xYItemRenderer72, false);
        org.jfree.chart.plot.RingPlot ringPlot75 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str76 = ringPlot75.getPlotType();
        ringPlot75.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent79 = null;
        ringPlot75.datasetChanged(datasetChangeEvent79);
        java.awt.Stroke stroke81 = ringPlot75.getLabelLinkStroke();
        xYPlot63.setRangeGridlineStroke(stroke81);
        org.jfree.chart.axis.AxisLocation axisLocation84 = xYPlot63.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation85 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation84, plotOrientation85);
        categoryPlot54.setDomainAxisLocation(axisLocation84);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(categoryItemRendererArray55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(valueAxis67);
        org.junit.Assert.assertNull(paint68);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Pie Plot" + "'", str76.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(plotOrientation85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        double double12 = xYPlot5.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot19.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot19.isRangeZoomable();
        java.awt.Image image23 = null;
        xYPlot19.setBackgroundImage(image23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot19);
        java.awt.geom.Point2D point2D26 = xYPlot19.getQuadrantOrigin();
        xYPlot19.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot19.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot19.getRangeAxisLocation((int) (short) -1);
        xYPlot5.setRangeAxisLocation(100, axisLocation30, false);
        xYPlot5.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        xYPlot5.setDomainAxis((int) 'a', valueAxis26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot5.getRendererForDataset(xYDataset28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYItemRenderer29);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setOutlineVisible(true);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        double double6 = numberAxis3D5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, xYItemRenderer8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot9.rendererChanged(rendererChangeEvent10);
        boolean boolean12 = xYPlot9.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot9.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot9.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint18 = xYPlot9.getRangeTickBandPaint();
        java.awt.Paint paint19 = xYPlot9.getDomainZeroBaselinePaint();
        ringPlot0.setLabelOutlinePaint(paint19);
        ringPlot0.setShadowXOffset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        java.awt.Shape shape7 = numberAxis3D1.getRightArrow();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        double double6 = numberAxis3D5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, xYItemRenderer8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot9.rendererChanged(rendererChangeEvent10);
        boolean boolean12 = xYPlot9.isRangeZoomable();
        xYPlot9.setRangeCrosshairValue(1.05d, true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, xYItemRenderer20);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        xYPlot21.rendererChanged(rendererChangeEvent22);
        boolean boolean24 = xYPlot21.isRangeZoomable();
        java.awt.Image image25 = null;
        xYPlot21.setBackgroundImage(image25);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot21);
        java.awt.geom.Point2D point2D28 = xYPlot21.getQuadrantOrigin();
        xYPlot9.setQuadrantOrigin(point2D28);
        org.jfree.chart.plot.PlotState plotState30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            ringPlot0.draw(graphics2D2, rectangle2D3, point2D28, plotState30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = textLine1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        java.awt.Color color57 = java.awt.Color.pink;
        categoryPlot54.setRangeCrosshairPaint((java.awt.Paint) color57);
        double double59 = categoryPlot54.getAnchorValue();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier1);
        org.jfree.data.xy.XYDataset xYDataset3 = polarPlot0.getDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot0.datasetChanged(datasetChangeEvent4);
        try {
            polarPlot0.zoom((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        double double12 = xYPlot5.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot19.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot19.isRangeZoomable();
        java.awt.Image image23 = null;
        xYPlot19.setBackgroundImage(image23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot19);
        java.awt.geom.Point2D point2D26 = xYPlot19.getQuadrantOrigin();
        xYPlot19.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot19.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot19.getRangeAxisLocation((int) (short) -1);
        xYPlot5.setRangeAxisLocation(100, axisLocation30, false);
        xYPlot5.mapDatasetToDomainAxis(100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.lang.String str6 = numberAxis3D3.getLabel();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot14.rendererChanged(rendererChangeEvent15);
        boolean boolean17 = xYPlot14.isRangeZoomable();
        boolean boolean18 = xYPlot14.isDomainZeroBaselineVisible();
        int int19 = xYPlot14.getDatasetCount();
        xYPlot14.setRangeCrosshairLockedOnData(false);
        int int22 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot14.getRangeAxisEdge();
        java.lang.String str24 = rectangleEdge23.toString();
        org.jfree.chart.util.ObjectList objectList26 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        boolean boolean27 = rectangleEdge23.equals((java.lang.Object) (short) 1);
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge23);
        try {
            double double29 = numberAxis3D3.valueToJava2D((double) 255, rectangle2D8, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.LEFT" + "'", str24.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        double double10 = ringPlot0.getShadowYOffset();
        ringPlot0.setInnerSeparatorExtension((double) ' ');
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = ringPlot0.getLabelDistributor();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord14 = null;
        try {
            abstractPieLabelDistributor13.addPieLabelRecord(pieLabelRecord14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17, numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        double double37 = range36.getLowerBound();
        double double38 = range36.getCentralValue();
        dateAxis0.setDefaultAutoRange(range36);
        org.jfree.chart.axis.Timeline timeline40 = null;
        dateAxis0.setTimeline(timeline40);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 49.5d + "'", double38 == 49.5d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str5 = ringPlot4.getPlotType();
        ringPlot4.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        ringPlot4.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke10 = ringPlot4.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot11 = ringPlot4.getRootPlot();
        boolean boolean12 = ringPlot4.isCircular();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 3, plotRenderingInfo14);
        piePlotState15.setPieHRadius((double) (-1L));
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        piePlotState15.setExplodedPieArea(rectangle2D18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(piePlotState15);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.lang.String str36 = numberAxis3D30.getLabelURL();
        numberAxis3D30.setUpperBound((double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(str36);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        java.lang.Object obj7 = numberAxis3D1.clone();
        numberAxis3D1.setInverted(false);
        double double10 = numberAxis3D1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-1.0f), (-1.0d), (int) (short) 0, (java.lang.Comparable) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str11 = ringPlot10.getPlotType();
        float float12 = ringPlot10.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) 0, plotRenderingInfo14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        double double21 = numberAxis3D20.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, xYItemRenderer23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = jFreeChart25.getPadding();
        double double28 = rectangleInsets26.calculateRightOutset((double) (byte) -1);
        double double30 = rectangleInsets26.calculateLeftOutset((double) 0.0f);
        ringPlot0.setLabelPadding(rectangleInsets26);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            rectangleInsets26.trim(rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.BOTTOM_RIGHT");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = null;
        double[] doubleArray6 = new double[] { 45.0d, 4.0d, 128, 10 };
        double[] doubleArray11 = new double[] { 45.0d, 4.0d, 128, 10 };
        double[] doubleArray16 = new double[] { 45.0d, 4.0d, 128, 10 };
        double[] doubleArray21 = new double[] { 45.0d, 4.0d, 128, 10 };
        double[] doubleArray26 = new double[] { 45.0d, 4.0d, 128, 10 };
        double[][] doubleArray27 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot7 = ringPlot0.getRootPlot();
        boolean boolean8 = ringPlot0.isCircular();
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) ringPlot0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        xYPlot5.setDomainAxis((int) 'a', valueAxis26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font2, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.magenta;
        int int6 = color5.getTransparency();
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartChangeEventType.NEW_DATASET", font2, (java.awt.Paint) color5);
        java.awt.Color color8 = color5.darker();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double9 = dateAxis0.valueToJava2D(0.0d, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        java.awt.Shape shape12 = numberAxis3D10.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity(shape12, pieDataset13, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit16, "Pie Plot", "Pie Plot");
        valueAxis9.setDownArrow(shape12);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        double double23 = numberAxis3D22.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, xYItemRenderer25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot26.rendererChanged(rendererChangeEvent27);
        boolean boolean29 = xYPlot26.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot26.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        xYPlot26.setFixedRangeAxisSpace(axisSpace31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot26.getRangeAxisEdge((int) (short) 1);
        xYPlot26.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str38 = ringPlot37.getPlotType();
        ringPlot37.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        ringPlot37.datasetChanged(datasetChangeEvent41);
        java.awt.Stroke stroke43 = ringPlot37.getLabelOutlineStroke();
        xYPlot26.setRangeCrosshairStroke(stroke43);
        boolean boolean45 = valueAxis9.hasListener((java.util.EventListener) xYPlot26);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        xYPlot26.drawAnnotations(graphics2D46, rectangle2D47, plotRenderingInfo48);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Pie Plot" + "'", str38.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        org.jfree.chart.title.TextTitle textTitle9 = null;
        jFreeChart7.setTitle(textTitle9);
        jFreeChart7.setBackgroundImageAlignment(2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        double double7 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        ringPlot0.setURLGenerator(pieURLGenerator8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "", numberArray2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ChartChangeEventType.NEW_DATASET");
        categoryAxis3D1.setMaximumCategoryLabelLines(3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        xYPlot6.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot6.getDataset();
        boolean boolean11 = lineBorder0.equals((java.lang.Object) xYPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot6.zoomRangeAxes((double) 'a', plotRenderingInfo13, point2D14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, xYItemRenderer20);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        xYPlot21.rendererChanged(rendererChangeEvent22);
        boolean boolean24 = xYPlot21.isRangeZoomable();
        java.awt.Image image25 = null;
        xYPlot21.setBackgroundImage(image25);
        java.lang.String str27 = xYPlot21.getPlotType();
        xYPlot21.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        double double32 = numberAxis3D31.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, xYItemRenderer34);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent36 = null;
        xYPlot35.rendererChanged(rendererChangeEvent36);
        boolean boolean38 = xYPlot35.isRangeZoomable();
        java.awt.Image image39 = null;
        xYPlot35.setBackgroundImage(image39);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot35);
        java.awt.geom.Point2D point2D42 = xYPlot35.getQuadrantOrigin();
        xYPlot35.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset44 = xYPlot35.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot35.getRangeAxisLocation((int) (short) -1);
        xYPlot21.setRangeAxisLocation(axisLocation46);
        xYPlot6.setRangeAxisLocation(axisLocation46, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "XY Plot" + "'", str27.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        ringPlot0.setSectionDepth((double) (byte) 100);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray44);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, 3);
        ringPlot0.setDataset(pieDataset48);
        java.awt.Stroke stroke50 = ringPlot0.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 600.0d + "'", number46.equals(600.0d));
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextBlockAnchor.BOTTOM_RIGHT", "ThreadContext", "ThreadContext", "java.awt.Color[r=255,g=255,b=64]", "hi!");
        basicProjectInfo5.addOptionalLibrary("");
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.Plot plot10 = xYPlot5.getParent();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryMargin((double) 3);
        categoryAxis3D0.configure();
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor2);
        legendTitle1.setWidth(600.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.axis.Timeline timeline8 = null;
        dateAxis0.setTimeline(timeline8);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        double double7 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Stroke stroke9 = null;
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1.0f, stroke9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
        double double56 = numberAxis3D55.getFixedAutoRange();
        java.awt.Shape shape57 = numberAxis3D55.getRightArrow();
        categoryPlot54.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D55);
        boolean boolean59 = numberAxis3D55.isVisible();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickMarkOutsideLength((float) (-1L));
        categoryAxis3D0.setLabel("ChartChangeEventType.NEW_DATASET");
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        java.awt.Color color36 = java.awt.Color.red;
        boolean boolean37 = range35.equals((java.lang.Object) color36);
        double double38 = range35.getCentralValue();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 49.5d + "'", double38 == 49.5d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.LEFT" + "'", str1.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier1);
        java.awt.Paint paint3 = null;
        try {
            polarPlot0.setAngleLabelPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        ringPlot0.setSectionDepth((double) (byte) 100);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray44);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, 3);
        ringPlot0.setDataset(pieDataset48);
        ringPlot0.setNoDataMessage("ClassContext");
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str55 = ringPlot54.getPlotType();
        float float56 = ringPlot54.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D57 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint59 = categoryAxis3D57.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot54.setBaseSectionOutlinePaint(paint59);
        java.awt.Paint paint61 = ringPlot54.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart("PieSection: 10, -16777216(DateTickUnit[DAY, 1])", font53, (org.jfree.chart.plot.Plot) ringPlot54, false);
        ringPlot0.setLabelFont(font53);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 600.0d + "'", number46.equals(600.0d));
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Pie Plot" + "'", str55.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 1.0f + "'", float56 == 1.0f);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = jFreeChart8.getBorderPaint();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        legendTitle1.setWidth((double) 0.0f);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.title.Title title8 = titleChangeEvent7.getTitle();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer13);
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) title8, (java.lang.Object) xYItemRenderer13);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(title8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, paint4, (float) (byte) 1);
        textLine1.removeFragment(textFragment6);
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textLine1.calculateDimensions(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, xYItemRenderer17);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYPlot18.rendererChanged(rendererChangeEvent19);
        boolean boolean21 = xYPlot18.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot18.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot18.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot18);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle25.getBounds();
        try {
            xYPlot5.drawBackground(graphics2D12, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace12, true);
        xYPlot5.setWeight((int) '#');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        xYPlot5.datasetChanged(datasetChangeEvent17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        double double10 = ringPlot0.getShadowYOffset();
        ringPlot0.setInnerSeparatorExtension((double) ' ');
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = ringPlot0.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord15 = abstractPieLabelDistributor13.getPieLabelRecord((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17, numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        double double37 = range36.getLowerBound();
        double double38 = range36.getCentralValue();
        dateAxis0.setDefaultAutoRange(range36);
        double double40 = range36.getLength();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 49.5d + "'", double38 == 49.5d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.0d + "'", double40 == 101.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        org.jfree.data.KeyToGroupMap keyToGroupMap36 = null;
        try {
            org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33, keyToGroupMap36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        java.awt.Image image15 = null;
        xYPlot11.setBackgroundImage(image15);
        java.lang.String str17 = xYPlot11.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str19 = ringPlot18.getPlotType();
        ringPlot18.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        ringPlot18.datasetChanged(datasetChangeEvent22);
        java.awt.Stroke stroke24 = ringPlot18.getLabelOutlineStroke();
        xYPlot11.setRangeGridlineStroke(stroke24);
        numberAxis3D3.setAxisLineStroke(stroke24);
        numberAxis3D3.setTickLabelsVisible(true);
        numberAxis3D3.setLowerMargin(0.0d);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        double double34 = numberAxis3D33.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, xYItemRenderer36);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYPlot37.rendererChanged(rendererChangeEvent38);
        boolean boolean40 = xYPlot37.isRangeZoomable();
        boolean boolean41 = xYPlot37.isDomainZeroBaselineVisible();
        int int42 = xYPlot37.getDatasetCount();
        xYPlot37.setRangeCrosshairLockedOnData(false);
        int int45 = xYPlot37.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        xYPlot37.setRenderer(0, xYItemRenderer47, true);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        double double52 = numberAxis3D51.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis3D53, xYItemRenderer54);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = null;
        xYPlot55.rendererChanged(rendererChangeEvent56);
        boolean boolean58 = xYPlot55.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = xYPlot55.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection61 = xYPlot55.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot55);
        java.awt.geom.Rectangle2D rectangle2D63 = legendTitle62.getBounds();
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D65 = new org.jfree.chart.axis.NumberAxis3D();
        double double66 = numberAxis3D65.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset64, (org.jfree.chart.axis.ValueAxis) numberAxis3D65, (org.jfree.chart.axis.ValueAxis) numberAxis3D67, xYItemRenderer68);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent70 = null;
        xYPlot69.rendererChanged(rendererChangeEvent70);
        boolean boolean72 = xYPlot69.isRangeZoomable();
        boolean boolean73 = xYPlot69.isDomainZeroBaselineVisible();
        int int74 = xYPlot69.getDatasetCount();
        xYPlot69.setRangeCrosshairLockedOnData(false);
        int int77 = xYPlot69.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = xYPlot69.getRangeAxisEdge();
        java.lang.String str79 = rectangleEdge78.toString();
        java.lang.Class<?> wildcardClass80 = rectangleEdge78.getClass();
        org.jfree.chart.axis.AxisSpace axisSpace81 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace82 = numberAxis3D3.reserveSpace(graphics2D31, (org.jfree.chart.plot.Plot) xYPlot37, rectangle2D63, rectangleEdge78, axisSpace81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pie Plot" + "'", str19.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNull(legendItemCollection61);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "RectangleEdge.LEFT" + "'", str79.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass80);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot8.rendererChanged(rendererChangeEvent9);
        boolean boolean11 = xYPlot8.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot8.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = xYPlot8.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot8);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            multiplePiePlot0.draw(graphics2D2, rectangle2D16, point2D17, plotState18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        legendTitle1.setWidth((double) 0.0f);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.String str8 = titleChangeEvent7.toString();
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint14 = xYPlot5.getRangeTickBandPaint();
        xYPlot5.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot5.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(valueAxis18);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("0,0,-2,-2,-2,2,-2,2", graphics2D1, 0.5f, (float) 128, textAnchor4, 90.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray55 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot54.setRenderers(categoryItemRendererArray55);
        java.awt.Stroke stroke57 = categoryPlot54.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot54.setOrientation(plotOrientation58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray60 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot54.setRangeAxes(valueAxisArray60);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(categoryItemRendererArray55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(valueAxisArray60);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.TOP" + "'", str1.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        java.awt.Color color57 = java.awt.Color.pink;
        categoryPlot54.setRangeCrosshairPaint((java.awt.Paint) color57);
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) '#');
        float float61 = valueMarker60.getAlpha();
        java.lang.String str62 = valueMarker60.getLabel();
        try {
            boolean boolean63 = categoryPlot54.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.8f + "'", float61 == 0.8f);
        org.junit.Assert.assertNull(str62);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        valueAxis9.centerRange((double) '#');
        org.jfree.data.Range range12 = valueAxis9.getDefaultAutoRange();
        double double13 = range12.getUpperBound();
        double double14 = range12.getLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str11 = ringPlot10.getPlotType();
        float float12 = ringPlot10.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) 0, plotRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = piePlotState15.getPieArea();
        double double17 = piePlotState15.getPieWRadius();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        java.awt.Paint paint13 = numberAxis3D8.getLabelPaint();
        numberAxis3D8.setLabelToolTip("");
        xYPlot5.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, true);
        numberAxis3D8.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D8.getLabelInsets();
        numberAxis3D8.setRange(1.05d, (double) 500);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        double double7 = numberAxis3D6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, xYItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot10.rendererChanged(rendererChangeEvent11);
        boolean boolean13 = xYPlot10.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot10.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot10.getRangeAxisEdge((int) (short) 1);
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge18);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge18);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis22.getCategoryStart((-1), (int) 'a', rectangle2D25, rectangleEdge26);
        java.awt.Paint paint29 = categoryAxis22.getTickLabelPaint((java.lang.Comparable) (short) 10);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle31.setVerticalAlignment(verticalAlignment32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle31.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle31.getMargin();
        categoryAxis22.setTickLabelInsets(rectangleInsets35);
        legendTitle1.setItemLabelPadding(rectangleInsets35);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.NEW_DATASET", graphics2D1, (float) 10L, (float) (-1L), 1.0E-5d, 1.0f, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        legendTitle1.setWidth((double) 0.0f);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = jFreeChart15.getPadding();
        legendTitle1.setMargin(rectangleInsets16);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(600.0d, 4.0d);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=600.0, height=4.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=600.0, height=4.0]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        float float8 = dateAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
        double double56 = numberAxis3D55.getFixedAutoRange();
        java.awt.Shape shape57 = numberAxis3D55.getRightArrow();
        categoryPlot54.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D55);
        boolean boolean59 = numberAxis3D55.getAutoRangeIncludesZero();
        numberAxis3D55.setUpperBound((double) (short) 0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYPlot16.rendererChanged(rendererChangeEvent17);
        boolean boolean19 = xYPlot16.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot16.getRangeAxis();
        valueAxis20.centerRange((double) '#');
        org.jfree.data.Range range23 = valueAxis20.getDefaultAutoRange();
        xYPlot5.setDomainAxis(valueAxis20);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot5.getRangeAxis((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(valueAxis20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(valueAxis26);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        polarPlot1.setDrawingSupplier(drawingSupplier2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        double double6 = numberAxis3D5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, xYItemRenderer8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot9.rendererChanged(rendererChangeEvent10);
        boolean boolean12 = xYPlot9.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot9.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot9.getRangeAxisEdge((int) (short) 1);
        xYPlot9.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str21 = ringPlot20.getPlotType();
        ringPlot20.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        ringPlot20.datasetChanged(datasetChangeEvent24);
        java.awt.Stroke stroke26 = ringPlot20.getLabelOutlineStroke();
        xYPlot9.setRangeCrosshairStroke(stroke26);
        polarPlot1.setAngleGridlineStroke(stroke26);
        ringPlot0.setSeparatorStroke(stroke26);
        java.awt.Paint paint31 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pie Plot" + "'", str21.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        org.jfree.chart.JFreeChart jFreeChart13 = chartProgressEvent12.getChart();
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend((int) 'a');
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNull(legendTitle15);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot7.getRangeAxis();
        java.awt.Paint paint12 = xYPlot7.getDomainTickBandPaint();
        xYPlot7.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot7.setRenderer(0, xYItemRenderer16, false);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelLinkStroke();
        xYPlot7.setRangeGridlineStroke(stroke25);
        valueMarker1.setStroke(stroke25);
        java.awt.Color color28 = java.awt.Color.PINK;
        valueMarker1.setOutlinePaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        java.awt.Shape shape7 = numberAxis3D1.getLeftArrow();
        boolean boolean8 = numberAxis3D1.isAutoTickUnitSelection();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25, numberArray30, numberArray35, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray41);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset42, true);
        numberAxis3D1.setRange(range44, false, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33);
        try {
            org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset33, (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16777216");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot5.setRenderer(2, xYItemRenderer13);
        java.awt.Paint paint15 = xYPlot5.getOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        double double25 = numberAxis3D24.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer27);
        java.awt.Paint paint29 = numberAxis3D24.getLabelPaint();
        numberAxis3D24.setLabelToolTip("");
        xYPlot21.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, true);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot21.getDataset();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.setRange((double) 0L, (double) (short) 100);
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis35.setMaximumDate(date39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        double double43 = numberAxis3D42.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer45);
        numberAxis3D42.setPositiveArrowVisible(false);
        numberAxis3D42.setLabelAngle((double) ' ');
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        double double53 = numberAxis3D52.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis3D52, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, xYItemRenderer55);
        numberAxis3D54.setAxisLineVisible(false);
        boolean boolean59 = numberAxis3D54.isVerticalTickLabels();
        numberAxis3D54.centerRange(45.0d);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { dateAxis35, numberAxis3D42, numberAxis3D54 };
        xYPlot21.setDomainAxes(valueAxisArray62);
        xYPlot5.setDomainAxes(valueAxisArray62);
        java.awt.Image image65 = xYPlot5.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNull(image65);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.toString();
        pieSectionEntity9.setToolTipText("TextBlockAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 10, -16777216(DateTickUnit[DAY, 1])" + "'", str10.equals("PieSection: 10, -16777216(DateTickUnit[DAY, 1])"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        double double7 = numberAxis3D6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, xYItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot10.rendererChanged(rendererChangeEvent11);
        boolean boolean13 = xYPlot10.isRangeZoomable();
        java.awt.Image image14 = null;
        xYPlot10.setBackgroundImage(image14);
        java.lang.String str16 = xYPlot10.getPlotType();
        org.jfree.chart.plot.Plot plot17 = null;
        xYPlot10.setParent(plot17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        double double22 = numberAxis3D21.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, xYItemRenderer24);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        xYPlot25.rendererChanged(rendererChangeEvent26);
        boolean boolean28 = xYPlot25.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot25.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection31 = xYPlot25.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot25);
        java.awt.geom.Rectangle2D rectangle2D33 = legendTitle32.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYPlot10.drawAnnotations(graphics2D19, rectangle2D33, plotRenderingInfo34);
        try {
            ringPlot0.drawOutline(graphics2D4, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        multiplePiePlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        java.lang.String str6 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        try {
            dateAxis0.zoomRange(0.0d, (double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.6777216E9).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
        double double56 = numberAxis3D55.getFixedAutoRange();
        java.awt.Shape shape57 = numberAxis3D55.getRightArrow();
        categoryPlot54.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D55);
        boolean boolean59 = categoryPlot54.isRangeZoomable();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        categoryPlot54.setRangeAxisLocation(500, axisLocation82);
        boolean boolean86 = categoryPlot54.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset88 = categoryPlot54.getDataset(500);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNull(categoryDataset88);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        java.awt.Shape shape7 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "ClassContext", "ThreadContext");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        double double55 = categoryAxis3D36.getCategoryMargin();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.2d + "'", double55 == 0.2d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (-1.0f), (double) 0.0f);
        java.lang.Object obj5 = null;
        boolean boolean6 = flowArrangement4.equals(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot18 = jFreeChart8.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.XYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit6);
        dateAxis0.setLowerMargin(0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10, layer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        valueMarker10.notifyListeners(markerChangeEvent13);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker10.getLabelTextAnchor();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5);
        double double13 = legendTitle12.getHeight();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        legendTitle15.setWidth((double) 100L);
        java.awt.Font font18 = legendTitle15.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 'a', (double) '4', (double) (-1.0f));
        legendTitle15.setItemLabelPadding(rectangleInsets23);
        legendTitle12.setItemLabelPadding(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot7.getRangeAxis();
        java.awt.Paint paint12 = xYPlot7.getDomainTickBandPaint();
        xYPlot7.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot7.setRenderer(0, xYItemRenderer16, false);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelLinkStroke();
        xYPlot7.setRangeGridlineStroke(stroke25);
        valueMarker1.setStroke(stroke25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = ringPlot0.getToolTipGenerator();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        double double7 = numberAxis3D6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, xYItemRenderer9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = jFreeChart11.getPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis14.getCategoryStart((-1), (int) 'a', rectangle2D17, rectangleEdge18);
        java.awt.Paint paint21 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) 10);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, paint21);
        ringPlot0.setBaseSectionOutlinePaint(paint21);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        double double5 = rectangleConstraint4.getHeight();
        double double6 = rectangleConstraint4.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        java.awt.Shape shape7 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.plot.Plot plot8 = numberAxis3D1.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        java.awt.Image image2 = ringPlot0.getBackgroundImage();
        ringPlot0.setMaximumLabelWidth((double) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot5.getRangeMarkers(8, layer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot5.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33);
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] { numberArray44, numberArray49, numberArray54, numberArray59, numberArray64, numberArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray70);
        org.jfree.data.general.PieDataset pieDataset73 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset71, 1);
        org.jfree.data.Range range74 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset71);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset71);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint76 = new org.jfree.chart.block.RectangleConstraint(range37, range75);
        double double77 = range75.getUpperBound();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(pieDataset73);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 600.0d + "'", double77 == 600.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        xYPlot5.setRenderer((int) (short) 100, xYItemRenderer12, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        double double17 = numberAxis3D16.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYPlot20.rendererChanged(rendererChangeEvent21);
        boolean boolean23 = xYPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot20.getRangeAxis();
        java.awt.Paint paint25 = xYPlot20.getDomainTickBandPaint();
        xYPlot20.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot20.setRenderer(0, xYItemRenderer29, false);
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str33 = ringPlot32.getPlotType();
        ringPlot32.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        ringPlot32.datasetChanged(datasetChangeEvent36);
        java.awt.Stroke stroke38 = ringPlot32.getLabelLinkStroke();
        xYPlot20.setRangeGridlineStroke(stroke38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation41);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        double double46 = numberAxis3D45.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, (org.jfree.chart.axis.ValueAxis) numberAxis3D47, xYItemRenderer48);
        xYPlot20.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D45);
        java.lang.String str51 = numberAxis3D45.getLabelURL();
        int int52 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D45);
        org.jfree.chart.util.Layer layer53 = null;
        java.util.Collection collection54 = xYPlot5.getRangeMarkers(layer53);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Pie Plot" + "'", str33.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNull(collection54);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 2, 1.0d, 1.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        java.awt.Shape shape7 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis3D1.getTickUnit();
        org.jfree.data.Range range9 = null;
        try {
            numberAxis3D1.setRangeWithMargins(range9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        xYPlot6.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot6.getDataset();
        boolean boolean11 = lineBorder0.equals((java.lang.Object) xYPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot19.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot19.isRangeZoomable();
        boolean boolean23 = xYPlot19.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot19.getDataset();
        xYPlot19.clearDomainAxes();
        java.awt.Paint paint26 = xYPlot19.getRangeCrosshairPaint();
        java.awt.Font font27 = xYPlot19.getNoDataMessageFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        double double33 = numberAxis3D32.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer35);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYPlot36.rendererChanged(rendererChangeEvent37);
        boolean boolean39 = xYPlot36.isRangeZoomable();
        java.awt.Image image40 = null;
        xYPlot36.setBackgroundImage(image40);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot36);
        java.awt.geom.Point2D point2D43 = xYPlot36.getQuadrantOrigin();
        xYPlot19.zoomRangeAxes((double) (byte) 0, (double) 10.0f, plotRenderingInfo30, point2D43);
        xYPlot6.zoomDomainAxes((double) (short) -1, plotRenderingInfo13, point2D43, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isVisible();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) dateTickUnit3);
        boolean boolean5 = categoryAxis3D0.isVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint2 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        double double3 = categoryAxis3D0.getCategoryMargin();
        java.awt.Font font5 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) "hi!");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset33);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 600.0d + "'", number37.equals(600.0d));
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "java.awt.Color[r=255,g=255,b=64]", "", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        java.lang.String str7 = basicProjectInfo5.getVersion();
        java.lang.String str8 = basicProjectInfo5.getLicenceName();
        basicProjectInfo5.setVersion("java.awt.Color[r=255,g=255,b=64]");
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryStart((-1), (int) 'a', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) 10);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        double double10 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Paint paint3 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.getToolTipText();
        java.lang.String str11 = pieSectionEntity9.getURLText();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot8.rendererChanged(rendererChangeEvent9);
        boolean boolean11 = xYPlot8.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot8.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot8.getRangeAxisEdge((int) (short) 1);
        xYPlot8.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelOutlineStroke();
        xYPlot8.setRangeCrosshairStroke(stroke25);
        polarPlot0.setAngleGridlineStroke(stroke25);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        legendTitle29.setWidth((double) 100L);
        java.awt.Font font32 = legendTitle29.getItemFont();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        double double35 = numberAxis3D34.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, xYItemRenderer37);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYPlot38.rendererChanged(rendererChangeEvent39);
        boolean boolean41 = xYPlot38.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot38.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        xYPlot38.setFixedRangeAxisSpace(axisSpace43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot38.getRangeAxisEdge((int) (short) 1);
        boolean boolean47 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge46);
        legendTitle29.setLegendItemGraphicEdge(rectangleEdge46);
        java.lang.Object obj49 = legendTitle29.clone();
        java.awt.Paint paint50 = legendTitle29.getItemPaint();
        polarPlot0.setAngleGridlinePaint(paint50);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(valueAxis42);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        boolean boolean55 = numberAxis3D44.isPositiveArrowVisible();
        java.lang.Object obj56 = null;
        boolean boolean57 = numberAxis3D44.equals(obj56);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str5 = ringPlot4.getPlotType();
        ringPlot4.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        ringPlot4.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke10 = ringPlot4.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot11 = ringPlot4.getRootPlot();
        boolean boolean12 = ringPlot4.isCircular();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 3, plotRenderingInfo14);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getPlotType();
        ringPlot16.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        ringPlot16.datasetChanged(datasetChangeEvent20);
        ringPlot16.setSectionOutlinesVisible(false);
        ringPlot16.setInnerSeparatorExtension((double) 10L);
        double double26 = ringPlot16.getShadowYOffset();
        ringPlot16.setInnerSeparatorExtension((double) ' ');
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor29 = ringPlot16.getLabelDistributor();
        ringPlot0.setLabelDistributor(abstractPieLabelDistributor29);
        int int31 = abstractPieLabelDistributor29.getItemCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pie Plot" + "'", str17.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryStart((int) (short) 100, 1, rectangle2D3, rectangleEdge4);
        java.lang.String str6 = categoryAxis3D0.getLabelURL();
        categoryAxis3D0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17, numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        double double37 = range36.getLowerBound();
        double double38 = range36.getCentralValue();
        dateAxis0.setDefaultAutoRange(range36);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        double double42 = numberAxis3D41.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer44);
        org.jfree.data.Range range46 = numberAxis3D41.getDefaultAutoRange();
        dateAxis0.setRange(range46, false, false);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 49.5d + "'", double38 == 49.5d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        org.jfree.data.Range range8 = dateAxis0.getRange();
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis0.setTimeline(timeline9);
        java.awt.Color color15 = java.awt.Color.blue;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 0L, (double) '4', 0.0d, (double) 'a', (java.awt.Paint) color15);
        dateAxis0.setAxisLinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        java.awt.Color color3 = java.awt.Color.black;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 4.0d, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        java.awt.Image image15 = null;
        xYPlot11.setBackgroundImage(image15);
        java.lang.String str17 = xYPlot11.getPlotType();
        org.jfree.chart.plot.Plot plot18 = null;
        xYPlot11.setParent(plot18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        double double23 = numberAxis3D22.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, xYItemRenderer25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot26.rendererChanged(rendererChangeEvent27);
        boolean boolean29 = xYPlot26.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot26.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection32 = xYPlot26.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot26);
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle33.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        xYPlot11.drawAnnotations(graphics2D20, rectangle2D34, plotRenderingInfo35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        double double39 = numberAxis3D38.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer41);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = null;
        xYPlot42.rendererChanged(rendererChangeEvent43);
        boolean boolean45 = xYPlot42.isRangeZoomable();
        xYPlot42.setRangeCrosshairValue(1.05d, true);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        double double51 = numberAxis3D50.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, (org.jfree.chart.axis.ValueAxis) numberAxis3D52, xYItemRenderer53);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent55 = null;
        xYPlot54.rendererChanged(rendererChangeEvent55);
        boolean boolean57 = xYPlot54.isRangeZoomable();
        java.awt.Image image58 = null;
        xYPlot54.setBackgroundImage(image58);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent60 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot54);
        java.awt.geom.Point2D point2D61 = xYPlot54.getQuadrantOrigin();
        xYPlot42.setQuadrantOrigin(point2D61);
        org.jfree.chart.plot.PlotState plotState63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            ringPlot0.draw(graphics2D5, rectangle2D34, point2D61, plotState63, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(point2D61);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        legendTitle1.setItemLabelPadding(rectangleInsets7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle1.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel((int) '4');
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset4, (java.lang.Comparable) "java.awt.Color[r=255,g=255,b=64]");
        java.text.AttributedString attributedString8 = standardPieSectionLabelGenerator0.getAttributedLabel(0);
        java.lang.String str9 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(attributedString8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{0}" + "'", str9.equals("{0}"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        boolean boolean6 = dateAxis0.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
        dateAxis7.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis7.setMaximumDate(date11);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date14 = dateAxis7.calculateLowestVisibleTickValue(dateTickUnit13);
        dateAxis0.setTickUnit(dateTickUnit13);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot5);
        jFreeChart12.setBorderVisible(true);
        boolean boolean15 = jFreeChart12.isNotify();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray55 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot54.setRenderers(categoryItemRendererArray55);
        java.awt.Stroke stroke57 = categoryPlot54.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        categoryPlot54.setRenderer(categoryItemRenderer58);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(categoryItemRendererArray55);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryStart((int) (short) 100, 1, rectangle2D3, rectangleEdge4);
        java.lang.String str6 = categoryAxis3D0.getLabelURL();
        float float7 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj8 = categoryAxis3D0.clone();
        java.lang.String str9 = categoryAxis3D0.getLabel();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20, numberArray25, numberArray30, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        double double42 = numberAxis3D41.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer44);
        org.jfree.data.Range range46 = numberAxis3D41.getDefaultAutoRange();
        org.jfree.data.Range range47 = org.jfree.data.Range.combine(range39, range46);
        dateAxis0.setRange(range46);
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray80 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray81 = new java.lang.Number[][] { numberArray55, numberArray60, numberArray65, numberArray70, numberArray75, numberArray80 };
        org.jfree.data.category.CategoryDataset categoryDataset82 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray81);
        org.jfree.data.general.PieDataset pieDataset84 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset82, 1);
        org.jfree.data.Range range85 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset82);
        boolean boolean86 = range46.equals((java.lang.Object) range85);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray80);
        org.junit.Assert.assertNotNull(numberArray81);
        org.junit.Assert.assertNotNull(categoryDataset82);
        org.junit.Assert.assertNotNull(pieDataset84);
        org.junit.Assert.assertNotNull(range85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        double double10 = ringPlot0.getShadowYOffset();
        ringPlot0.setInnerSeparatorExtension((double) ' ');
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = ringPlot0.getLabelDistributor();
        abstractPieLabelDistributor13.clear();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.mapDatasetToRangeAxis(0, (int) '#');
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot54.setOrientation(plotOrientation58);
        categoryPlot54.clearRangeMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation61 = null;
        try {
            categoryPlot54.addAnnotation(categoryAnnotation61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation58);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke13 = xYPlot5.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isVisible();
        java.awt.Color color3 = java.awt.Color.PINK;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "ClassContext", (java.awt.Paint) color3);
        int int5 = color3.getAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot7 = ringPlot0.getRootPlot();
        double double8 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font3, paint4, (float) (byte) 1);
        textLine1.removeFragment(textFragment6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            textFragment6.draw(graphics2D8, (float) 2, (float) (short) 0, textAnchor11, (float) 3, (-1.0f), (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        categoryPlot54.clearRangeAxes();
        boolean boolean59 = categoryPlot54.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str3 = ringPlot2.getPlotType();
        float float4 = ringPlot2.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint7 = categoryAxis3D5.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot2.setBaseSectionOutlinePaint(paint7);
        java.awt.Paint paint9 = ringPlot2.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("PieSection: 10, -16777216(DateTickUnit[DAY, 1])", font1, (org.jfree.chart.plot.Plot) ringPlot2, false);
        java.awt.Image image12 = null;
        jFreeChart11.setBackgroundImage(image12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font2, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.magenta;
        int int6 = color5.getTransparency();
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartChangeEventType.NEW_DATASET", font2, (java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.lang.String str12 = textBlockAnchor11.toString();
        try {
            textBlock7.draw(graphics2D8, 0.5f, (float) (short) 0, textBlockAnchor11, (float) (byte) 0, 0.0f, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str12.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        ringPlot0.setSectionDepth((double) (byte) 100);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray44);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, 3);
        ringPlot0.setDataset(pieDataset48);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        java.awt.Stroke stroke52 = piePlot50.getSectionOutlineStroke((java.lang.Comparable) "VerticalAlignment.TOP");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 600.0d + "'", number46.equals(600.0d));
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNull(stroke52);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 3, (float) (-1L), textAnchor4, 0.0d, 2.0f, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        int int2 = objectList1.size();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        ringPlot3.notifyListeners(plotChangeEvent4);
        double double6 = ringPlot3.getShadowXOffset();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot12.rendererChanged(rendererChangeEvent13);
        boolean boolean15 = xYPlot12.isRangeZoomable();
        java.awt.Image image16 = null;
        xYPlot12.setBackgroundImage(image16);
        java.lang.String str18 = xYPlot12.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot12);
        java.awt.Color color20 = java.awt.Color.red;
        jFreeChart19.setBackgroundPaint((java.awt.Paint) color20);
        ringPlot3.setBaseSectionOutlinePaint((java.awt.Paint) color20);
        java.awt.Color color23 = color20.darker();
        int int24 = objectList1.indexOf((java.lang.Object) color20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "XY Plot" + "'", str18.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = textTitle17.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint18);
        java.awt.Paint paint20 = blockBorder19.getPaint();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("Pie Plot", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine2.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.Color color13 = java.awt.Color.red;
        jFreeChart12.setBackgroundPaint((java.awt.Paint) color13);
        jFreeChart12.setAntiAlias(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        java.awt.Paint paint7 = numberAxis3D2.getLabelPaint();
        java.awt.Shape shape8 = numberAxis3D2.getLeftArrow();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D2.getPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        double double14 = numberAxis3D13.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYPlot17.rendererChanged(rendererChangeEvent18);
        boolean boolean20 = xYPlot17.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot17.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection23 = xYPlot17.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot17.getRenderer((int) (byte) 1);
        numberAxis3D2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNull(xYItemRenderer26);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "", numberArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 1);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset5, (java.lang.Comparable) 101.0d, (double) '4');
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        ringPlot0.setSectionDepth((double) (byte) 100);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray44);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, 3);
        ringPlot0.setDataset(pieDataset48);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        org.jfree.data.general.PieDataset pieDataset53 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset48, (java.lang.Comparable) 0.5f, (double) (-16777216));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 600.0d + "'", number46.equals(600.0d));
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(pieDataset53);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        double double58 = categoryPlot54.getRangeCrosshairValue();
        java.awt.Paint paint59 = categoryPlot54.getDomainGridlinePaint();
        categoryPlot54.clearRangeMarkers(1);
        categoryPlot54.setAnchorValue((double) 1);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str4 = ringPlot3.getPlotType();
        ringPlot3.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        ringPlot3.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = ringPlot3.getLabelLinkStroke();
        java.awt.Paint paint10 = ringPlot3.getLabelShadowPaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint10);
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie Plot" + "'", str4.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        java.lang.Object obj15 = jFreeChart8.getTextAntiAlias();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot16 = jFreeChart8.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.XYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str3 = ringPlot2.getPlotType();
        float float4 = ringPlot2.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint7 = categoryAxis3D5.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot2.setBaseSectionOutlinePaint(paint7);
        java.awt.Paint paint9 = ringPlot2.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("PieSection: 10, -16777216(DateTickUnit[DAY, 1])", font1, (org.jfree.chart.plot.Plot) ringPlot2, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot2.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        categoryPlot54.setRangeAxisLocation(500, axisLocation82);
        org.jfree.chart.util.SortOrder sortOrder86 = null;
        try {
            categoryPlot54.setRowRenderingOrder(sortOrder86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray55 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot54.setRenderers(categoryItemRendererArray55);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot54.getRangeAxisEdge((-1));
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(categoryItemRendererArray55);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str11 = ringPlot10.getPlotType();
        float float12 = ringPlot10.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) ringPlot10, (java.lang.Integer) 0, plotRenderingInfo14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = ringPlot0.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.FIXED" + "'", str1.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot5.getDataset();
        xYPlot5.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot5.setDataset((int) (byte) 100, xYDataset13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot11.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot11.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getRGB();
        float[] floatArray27 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color20);
        xYPlot5.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState35 = null;
        boolean boolean36 = xYPlot5.render(graphics2D31, rectangle2D32, (int) (short) -1, plotRenderingInfo34, crosshairState35);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str39 = ringPlot38.getPlotType();
        float float40 = ringPlot38.getBackgroundAlpha();
        java.awt.Color color41 = java.awt.Color.GRAY;
        int int42 = color41.getBlue();
        ringPlot38.setLabelPaint((java.awt.Paint) color41);
        xYPlot5.setQuadrantPaint(3, (java.awt.Paint) color41);
        java.awt.Font font46 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("", font46, paint47, (float) (byte) 1);
        xYPlot5.setDomainGridlinePaint(paint47);
        int int51 = xYPlot5.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-16777216) + "'", int21 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Pie Plot" + "'", str39.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 128 + "'", int42 == 128);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        ringPlot2.notifyListeners(plotChangeEvent3);
        double double5 = ringPlot2.getShadowXOffset();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        java.awt.Image image15 = null;
        xYPlot11.setBackgroundImage(image15);
        java.lang.String str17 = xYPlot11.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot11);
        java.awt.Color color19 = java.awt.Color.red;
        jFreeChart18.setBackgroundPaint((java.awt.Paint) color19);
        ringPlot2.setBaseSectionOutlinePaint((java.awt.Paint) color19);
        java.awt.Color color22 = color19.darker();
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", font1, (java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setNotify(false);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        java.awt.Paint paint19 = legendTitle18.getItemPaint();
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle18);
        boolean boolean21 = jFreeChart8.getAntiAlias();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot5.getDataset();
        xYPlot5.clearDomainAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = null;
        try {
            xYPlot5.setSeriesRenderingOrder(seriesRenderingOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint57 = categoryAxis3D55.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        float float58 = categoryAxis3D55.getTickMarkInsideLength();
        java.util.List list59 = categoryPlot54.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D55);
        org.jfree.chart.util.Layer layer60 = null;
        java.util.Collection collection61 = categoryPlot54.getDomainMarkers(layer60);
        categoryPlot54.configureRangeAxes();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.0f + "'", float58 == 0.0f);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNull(collection61);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        java.awt.Shape shape3 = numberAxis3D1.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity10 = new org.jfree.chart.entity.PieSectionEntity(shape3, pieDataset4, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit7, "Pie Plot", "Pie Plot");
        java.util.Date date11 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint8 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        ringPlot0.setBaseSectionPaint(paint9);
        ringPlot0.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D1.setPositiveArrowVisible(false);
        double double8 = numberAxis3D1.getUpperBound();
        numberAxis3D1.configure();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str11 = ringPlot10.getPlotType();
        ringPlot10.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        ringPlot10.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = ringPlot10.getLabelLinkStroke();
        java.lang.Object obj17 = null;
        boolean boolean18 = ringPlot10.equals(obj17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        ringPlot10.setLabelLinkStroke(stroke19);
        numberAxis3D1.setTickMarkStroke(stroke19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier1);
        java.awt.Paint paint3 = polarPlot0.getAngleGridlinePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint14 = xYPlot5.getRangeTickBandPaint();
        float float15 = xYPlot5.getForegroundAlpha();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        double double21 = numberAxis3D20.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, xYItemRenderer23);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        xYPlot24.rendererChanged(rendererChangeEvent25);
        boolean boolean27 = xYPlot24.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot24.getRangeAxis();
        java.awt.Paint paint29 = xYPlot24.getDomainTickBandPaint();
        xYPlot24.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot24.setRenderer(0, xYItemRenderer33, false);
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str37 = ringPlot36.getPlotType();
        ringPlot36.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
        ringPlot36.datasetChanged(datasetChangeEvent40);
        java.awt.Stroke stroke42 = ringPlot36.getLabelLinkStroke();
        xYPlot24.setRangeGridlineStroke(stroke42);
        valueMarker18.setStroke(stroke42);
        org.jfree.data.Range range45 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint(range45, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType48 = rectangleConstraint47.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint47.toUnconstrainedHeight();
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray81 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray82 = new java.lang.Number[][] { numberArray56, numberArray61, numberArray66, numberArray71, numberArray76, numberArray81 };
        org.jfree.data.category.CategoryDataset categoryDataset83 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray82);
        org.jfree.data.Range range85 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset83, true);
        org.jfree.data.xy.XYDataset xYDataset86 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D87 = new org.jfree.chart.axis.NumberAxis3D();
        double double88 = numberAxis3D87.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D89 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer90 = null;
        org.jfree.chart.plot.XYPlot xYPlot91 = new org.jfree.chart.plot.XYPlot(xYDataset86, (org.jfree.chart.axis.ValueAxis) numberAxis3D87, (org.jfree.chart.axis.ValueAxis) numberAxis3D89, xYItemRenderer90);
        org.jfree.data.Range range92 = numberAxis3D87.getDefaultAutoRange();
        org.jfree.data.Range range93 = org.jfree.data.Range.combine(range85, range92);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint94 = rectangleConstraint47.toRangeWidth(range85);
        boolean boolean95 = valueMarker18.equals((java.lang.Object) range85);
        org.jfree.chart.util.Layer layer96 = null;
        xYPlot5.addRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker18, layer96);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Pie Plot" + "'", str37.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(lengthConstraintType48);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray81);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(categoryDataset83);
        org.junit.Assert.assertNotNull(range85);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(range92);
        org.junit.Assert.assertNotNull(range93);
        org.junit.Assert.assertNotNull(rectangleConstraint94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        boolean boolean58 = categoryPlot54.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 10);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        java.awt.Paint paint13 = numberAxis3D8.getLabelPaint();
        numberAxis3D8.setLabelToolTip("");
        xYPlot5.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, true);
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot5.getDataset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot5.markerChanged(markerChangeEvent19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(xYDataset18);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toRangeWidth(range5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font2, paint3, (float) (byte) 1);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str8 = color7.toString();
        int int9 = color7.getTransparency();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0.5f, paint3, stroke6, (java.awt.Paint) color7, stroke10, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str8.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle17.draw(graphics2D18, rectangle2D19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.lang.Object obj24 = textTitle17.draw(graphics2D21, rectangle2D22, (java.lang.Object) textBlockAnchor23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle17.setHorizontalAlignment(horizontalAlignment25);
        org.jfree.chart.ui.ProjectInfo projectInfo27 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list28 = projectInfo27.getContributors();
        projectInfo27.setInfo("XY Plot");
        boolean boolean31 = horizontalAlignment25.equals((java.lang.Object) "XY Plot");
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement35 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment32, (double) (byte) -1, (double) 2);
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(projectInfo27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(verticalAlignment32);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryStart((-1), (int) 'a', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot14.rendererChanged(rendererChangeEvent15);
        boolean boolean17 = xYPlot14.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot14.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot14.getFixedLegendItems();
        double double21 = xYPlot14.getDomainCrosshairValue();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot14);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = new org.jfree.chart.LegendItemCollection();
        boolean boolean13 = legendItemCollection11.equals((java.lang.Object) 4.0d);
        xYPlot5.setFixedLegendItems(legendItemCollection11);
        boolean boolean15 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot5.getDomainMarkers(layer16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        java.awt.Shape shape7 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.plot.Plot plot8 = numberAxis3D1.getPlot();
        java.text.NumberFormat numberFormat9 = numberAxis3D1.getNumberFormatOverride();
        numberAxis3D1.setAutoTickUnitSelection(true);
        boolean boolean12 = numberAxis3D1.isAutoRange();
        boolean boolean13 = numberAxis3D1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.String str2 = chartChangeEventType0.toString();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str4 = ringPlot3.getPlotType();
        ringPlot3.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        ringPlot3.datasetChanged(datasetChangeEvent7);
        ringPlot3.setSectionOutlinesVisible(false);
        ringPlot3.setInnerSeparatorExtension((double) 10L);
        org.jfree.chart.util.Rotation rotation13 = ringPlot3.getDirection();
        java.awt.Stroke stroke14 = ringPlot3.getSeparatorStroke();
        boolean boolean15 = chartChangeEventType0.equals((java.lang.Object) ringPlot3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str2.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie Plot" + "'", str4.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(rotation13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot5.getRangeMarkers(8, layer9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        int int12 = xYPlot5.getIndexOf(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21, numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset38, true);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        double double43 = numberAxis3D42.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer45);
        org.jfree.data.Range range47 = numberAxis3D42.getDefaultAutoRange();
        org.jfree.data.Range range48 = org.jfree.data.Range.combine(range40, range47);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint2.toRangeWidth(range40);
        double double50 = rectangleConstraint49.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-1.0d) + "'", double50 == (-1.0d));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        multiplePiePlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        multiplePiePlot0.setLimit(1.0E-5d);
        java.lang.String str8 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Multiple Pie Plot" + "'", str8.equals("Multiple Pie Plot"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.getToolTipText();
        org.jfree.data.general.PieDataset pieDataset11 = pieSectionEntity9.getDataset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertNull(pieDataset11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryStart((int) (short) 100, 1, rectangle2D3, rectangleEdge4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.Plot plot7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        double double10 = numberAxis3D9.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer12);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        xYPlot13.rendererChanged(rendererChangeEvent14);
        boolean boolean16 = xYPlot13.isRangeZoomable();
        java.awt.Image image17 = null;
        xYPlot13.setBackgroundImage(image17);
        java.lang.String str19 = xYPlot13.getPlotType();
        org.jfree.chart.plot.Plot plot20 = null;
        xYPlot13.setParent(plot20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        double double25 = numberAxis3D24.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, xYItemRenderer27);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYPlot28.rendererChanged(rendererChangeEvent29);
        boolean boolean31 = xYPlot28.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot28.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot28.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot28);
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle35.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        xYPlot13.drawAnnotations(graphics2D22, rectangle2D36, plotRenderingInfo37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        double double41 = numberAxis3D40.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, xYItemRenderer43);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = null;
        xYPlot44.rendererChanged(rendererChangeEvent45);
        boolean boolean47 = xYPlot44.isRangeZoomable();
        java.awt.Image image48 = null;
        xYPlot44.setBackgroundImage(image48);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent50 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot44);
        java.awt.geom.Point2D point2D51 = xYPlot44.getQuadrantOrigin();
        xYPlot44.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset53 = xYPlot44.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot44.getRangeAxisLocation((int) (short) -1);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation55, plotOrientation83);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge85);
        org.jfree.chart.axis.AxisSpace axisSpace87 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace88 = categoryAxis3D0.reserveSpace(graphics2D6, plot7, rectangle2D36, rectangleEdge85, axisSpace87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "XY Plot" + "'", str19.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertNull(xYDataset53);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryStart((-1), (int) 'a', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) 10);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setLowerMargin(49.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        dateAxis8.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis8.setMaximumDate(date12);
        java.util.TimeZone timeZone14 = dateAxis8.getTimeZone();
        dateAxis0.setTimeZone(timeZone14);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        xYPlot5.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getPlotType();
        ringPlot16.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        ringPlot16.datasetChanged(datasetChangeEvent20);
        java.awt.Stroke stroke22 = ringPlot16.getLabelOutlineStroke();
        xYPlot5.setRangeCrosshairStroke(stroke22);
        xYPlot5.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot5.getRangeAxisLocation((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pie Plot" + "'", str17.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
    }
}

