import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color14 = java.awt.Color.black;
        int int15 = color14.getRGB();
        float[] floatArray21 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray22 = color14.getRGBColorComponents(floatArray21);
        xYPlot5.setRangeTickBandPaint((java.awt.Paint) color14);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot5.setDataset((int) (short) 10, xYDataset25);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = xYPlot5.getRangeMarkers((int) (short) 10, layer28);
        org.jfree.chart.plot.Plot plot30 = xYPlot5.getRootPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16777216) + "'", int15 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(plot30);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        numberAxis3D1.setLabelToolTip("");
        numberAxis3D1.zoomRange(0.0d, 8.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        legendTitle1.setWidth((double) 0.0f);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray7 = legendTitle1.getSources();
        java.awt.Stroke[] strokeArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        double double12 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart16.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent20 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray8, jFreeChart16, (int) (byte) 100, 128);
        boolean boolean21 = jFreeChart16.isBorderVisible();
        jFreeChart16.setBackgroundImageAlpha((float) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = jFreeChart16.getPadding();
        legendTitle1.setItemLabelPadding(rectangleInsets24);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(legendItemSourceArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        xYPlot5.setDomainCrosshairValue((double) (byte) 1);
        java.awt.Paint paint14 = xYPlot5.getOutlinePaint();
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYPlot5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.lang.String str2 = standardPieSectionLabelGenerator0.getLabelFormat();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        java.lang.String str5 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset3, (java.lang.Comparable) "{0}");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.mapDatasetToRangeAxis(0, (int) '#');
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot54.setOrientation(plotOrientation58);
        categoryPlot54.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace61 = null;
        categoryPlot54.setFixedRangeAxisSpace(axisSpace61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        categoryPlot54.datasetChanged(datasetChangeEvent63);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation58);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        xYPlot5.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getPlotType();
        ringPlot16.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        ringPlot16.datasetChanged(datasetChangeEvent20);
        java.awt.Stroke stroke22 = ringPlot16.getLabelOutlineStroke();
        xYPlot5.setRangeCrosshairStroke(stroke22);
        java.awt.geom.Point2D point2D24 = xYPlot5.getQuadrantOrigin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pie Plot" + "'", str17.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace12, true);
        xYPlot5.setWeight((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot5.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.025d, (double) (-1.0f));
        org.jfree.chart.ui.Licences licences3 = org.jfree.chart.ui.Licences.getInstance();
        boolean boolean4 = size2D2.equals((java.lang.Object) licences3);
        java.lang.String str5 = licences3.getLGPL();
        org.junit.Assert.assertNotNull(licences3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        java.awt.Stroke[] strokeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart17.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray9, jFreeChart17, (int) (byte) 100, 128);
        org.jfree.chart.JFreeChart jFreeChart22 = chartProgressEvent21.getChart();
        jFreeChart22.removeLegend();
        xYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(jFreeChart22);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace12, true);
        xYPlot5.setWeight((int) '#');
        xYPlot5.clearDomainMarkers();
        boolean boolean18 = xYPlot5.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        int int10 = pieSectionEntity9.getPieIndex();
        pieSectionEntity9.setSectionKey((java.lang.Comparable) "java.awt.Color[r=255,g=255,b=64]");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        categoryPlot54.setRangeAxisLocation(500, axisLocation82);
        org.jfree.chart.plot.ValueMarker valueMarker87 = new org.jfree.chart.plot.ValueMarker((double) '#');
        float float88 = valueMarker87.getAlpha();
        org.jfree.chart.util.Layer layer89 = null;
        boolean boolean90 = categoryPlot54.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker87, layer89);
        boolean boolean91 = categoryPlot54.isDomainZoomable();
        categoryPlot54.clearDomainMarkers();
        categoryPlot54.clearAnnotations();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + float88 + "' != '" + 0.8f + "'", float88 == 0.8f);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot2.getDataset();
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection4 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        double double61 = numberAxis3D60.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, xYItemRenderer63);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent65 = null;
        xYPlot64.rendererChanged(rendererChangeEvent65);
        boolean boolean67 = xYPlot64.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot64.getRangeAxis();
        valueAxis68.centerRange((double) '#');
        categoryPlot54.setRangeAxis(0, valueAxis68, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        java.awt.geom.Point2D point2D75 = null;
        categoryPlot54.zoomDomainAxes((double) (byte) -1, plotRenderingInfo74, point2D75);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(valueAxis68);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        boolean boolean9 = ringPlot0.equals((java.lang.Object) (short) 0);
        ringPlot0.setCircular(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot0.getSimpleLabelOffset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        org.jfree.chart.title.TextTitle textTitle9 = null;
        jFreeChart7.setTitle(textTitle9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color11);
        java.lang.String str13 = color11.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=0,g=128,b=128]" + "'", str13.equals("java.awt.Color[r=0,g=128,b=128]"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = xYPlot6.isRangeZoomable();
        boolean boolean10 = xYPlot6.isDomainZeroBaselineVisible();
        int int11 = xYPlot6.getDatasetCount();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        int int14 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot6.getRangeAxisEdge();
        java.lang.String str16 = rectangleEdge15.toString();
        java.lang.Class<?> wildcardClass17 = rectangleEdge15.getClass();
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleEdge.LEFT" + "'", str16.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(classLoader18);
        org.junit.Assert.assertNull(uRL19);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        legendTitle1.setPadding(600.0d, 45.0d, (double) (short) 100, (double) 10.0f);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 100, 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (1.0E-5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryStart((-1), (int) 'a', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) 10);
        double double9 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20, numberArray25, numberArray30, numberArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        double double40 = range39.getLowerBound();
        double double41 = range39.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint2.toRangeHeight(range39);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-1.0d) + "'", double40 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 49.5d + "'", double41 == 49.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setTitle("VerticalAlignment.TOP");
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        org.jfree.chart.util.Rotation rotation10 = ringPlot0.getDirection();
        java.awt.Stroke stroke11 = ringPlot0.getSeparatorStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        double double14 = numberAxis3D13.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        double double21 = numberAxis3D20.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, xYItemRenderer23);
        java.awt.Paint paint25 = numberAxis3D20.getLabelPaint();
        numberAxis3D20.setLabelToolTip("");
        xYPlot17.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, true);
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot17.getDataset();
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        double double34 = numberAxis3D33.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, xYItemRenderer36);
        xYPlot37.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot37.getDataset();
        boolean boolean42 = lineBorder31.equals((java.lang.Object) xYPlot37);
        java.awt.Stroke stroke43 = lineBorder31.getStroke();
        xYPlot17.setDomainCrosshairStroke(stroke43);
        ringPlot0.setLabelOutlineStroke(stroke43);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        java.lang.Object obj7 = numberAxis3D1.clone();
        numberAxis3D1.setInverted(false);
        double double10 = numberAxis3D1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint8 = ringPlot0.getSeparatorPaint();
        boolean boolean9 = ringPlot0.getSectionOutlinesVisible();
        ringPlot0.setShadowYOffset(2.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot5);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.plot.Plot plot15 = jFreeChart12.getPlot();
        org.jfree.chart.plot.Plot plot16 = jFreeChart12.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        categoryPlot54.setRangeAxisLocation(500, axisLocation82);
        boolean boolean86 = categoryPlot54.isRangeCrosshairLockedOnData();
        categoryPlot54.configureDomainAxes();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        ringPlot0.notifyListeners(plotChangeEvent1);
        ringPlot0.setMaximumLabelWidth((double) 10L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYPlot16.rendererChanged(rendererChangeEvent17);
        boolean boolean19 = xYPlot16.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot16.getRangeAxis();
        valueAxis20.centerRange((double) '#');
        org.jfree.data.Range range23 = valueAxis20.getDefaultAutoRange();
        xYPlot5.setDomainAxis(valueAxis20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot5.getRenderer((int) (byte) 100);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        double double29 = numberAxis3D28.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer31);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        xYPlot32.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = xYPlot32.isRangeZoomable();
        boolean boolean36 = xYPlot32.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset37 = xYPlot32.getDataset();
        xYPlot32.clearDomainAxes();
        java.awt.Paint paint39 = xYPlot32.getRangeCrosshairPaint();
        java.awt.Font font40 = xYPlot32.getNoDataMessageFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        double double46 = numberAxis3D45.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, (org.jfree.chart.axis.ValueAxis) numberAxis3D47, xYItemRenderer48);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYPlot49.rendererChanged(rendererChangeEvent50);
        boolean boolean52 = xYPlot49.isRangeZoomable();
        java.awt.Image image53 = null;
        xYPlot49.setBackgroundImage(image53);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot49);
        java.awt.geom.Point2D point2D56 = xYPlot49.getQuadrantOrigin();
        xYPlot32.zoomRangeAxes((double) (byte) 0, (double) 10.0f, plotRenderingInfo43, point2D56);
        xYPlot5.setQuadrantOrigin(point2D56);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(valueAxis20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(point2D56);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 500, 101.0d, (double) (short) 10, (double) (byte) 1, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle1.getBounds();
        java.awt.Font font6 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot7.getRangeAxis();
        java.awt.Paint paint12 = xYPlot7.getDomainTickBandPaint();
        xYPlot7.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot7.setRenderer(0, xYItemRenderer16, false);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelLinkStroke();
        xYPlot7.setRangeGridlineStroke(stroke25);
        valueMarker1.setStroke(stroke25);
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("Pie Plot", font29);
        valueMarker1.setLabelFont(font29);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        double double7 = numberAxis3D6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, xYItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYPlot10.rendererChanged(rendererChangeEvent11);
        boolean boolean13 = xYPlot10.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot10.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot10.getRangeAxisEdge((int) (short) 1);
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge18);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge18);
        java.lang.Object obj21 = legendTitle1.clone();
        java.awt.Paint paint22 = legendTitle1.getItemPaint();
        org.jfree.chart.block.BlockContainer blockContainer23 = null;
        legendTitle1.setWrapper(blockContainer23);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Paint paint6 = numberAxis3D1.getLabelPaint();
        java.awt.Shape shape7 = numberAxis3D1.getLeftArrow();
        boolean boolean8 = numberAxis3D1.isAutoRange();
        java.awt.Shape shape9 = numberAxis3D1.getRightArrow();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D3.setAxisLineVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str9 = ringPlot8.getPlotType();
        ringPlot8.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        ringPlot8.datasetChanged(datasetChangeEvent12);
        java.awt.Stroke stroke14 = ringPlot8.getLabelLinkStroke();
        java.awt.Paint paint15 = ringPlot8.getLabelShadowPaint();
        java.awt.Paint paint16 = ringPlot8.getSeparatorPaint();
        boolean boolean17 = ringPlot8.getIgnoreNullValues();
        boolean boolean18 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = null;
        ringPlot8.setLegendLabelURLGenerator(pieURLGenerator19);
        ringPlot8.setInnerSeparatorExtension(0.08d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie Plot" + "'", str9.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        xYPlot6.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot6.getDataset();
        boolean boolean11 = lineBorder0.equals((java.lang.Object) xYPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot6.zoomRangeAxes((double) 'a', plotRenderingInfo13, point2D14);
        java.awt.Image image16 = xYPlot6.getBackgroundImage();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str19 = ringPlot18.getPlotType();
        float float20 = ringPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint23 = categoryAxis3D21.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot18.setBaseSectionOutlinePaint(paint23);
        java.awt.Color color25 = java.awt.Color.GRAY;
        ringPlot18.setLabelLinkPaint((java.awt.Paint) color25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        double double29 = numberAxis3D28.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, xYItemRenderer31);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        xYPlot32.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = xYPlot32.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot32.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot32.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot32.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color41 = java.awt.Color.black;
        int int42 = color41.getRGB();
        float[] floatArray48 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray49 = color41.getRGBColorComponents(floatArray48);
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color41);
        java.awt.Color color51 = java.awt.Color.black;
        int int52 = color51.getRGB();
        float[] floatArray58 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray59 = color51.getRGBColorComponents(floatArray58);
        float[] floatArray60 = color41.getComponents(floatArray59);
        float[] floatArray61 = color25.getRGBComponents(floatArray59);
        xYPlot6.setQuadrantPaint(0, (java.awt.Paint) color25);
        xYPlot6.clearRangeMarkers((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pie Plot" + "'", str19.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-16777216) + "'", int42 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-16777216) + "'", int52 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("ThreadContext", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = textTitle17.getPaint();
        boolean boolean19 = textTitle17.getExpandToFitSpace();
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str21 = ringPlot20.getPlotType();
        float float22 = ringPlot20.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint25 = categoryAxis3D23.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot20.setBaseSectionOutlinePaint(paint25);
        ringPlot20.setMinimumArcAngleToDraw((double) 10);
        java.awt.Paint paint29 = ringPlot20.getBaseSectionOutlinePaint();
        textTitle17.setBackgroundPaint(paint29);
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pie Plot" + "'", str21.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        ringPlot0.notifyListeners(plotChangeEvent1);
        double double3 = ringPlot0.getShadowXOffset();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        double double6 = numberAxis3D5.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, xYItemRenderer8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYPlot9.rendererChanged(rendererChangeEvent10);
        boolean boolean12 = xYPlot9.isRangeZoomable();
        java.awt.Image image13 = null;
        xYPlot9.setBackgroundImage(image13);
        java.lang.String str15 = xYPlot9.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot9);
        java.awt.Color color17 = java.awt.Color.red;
        jFreeChart16.setBackgroundPaint((java.awt.Paint) color17);
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color17);
        java.awt.Color color20 = color17.darker();
        java.lang.String str21 = color17.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "XY Plot" + "'", str15.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str21.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        double double61 = numberAxis3D60.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, xYItemRenderer63);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent65 = null;
        xYPlot64.rendererChanged(rendererChangeEvent65);
        boolean boolean67 = xYPlot64.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot64.getRangeAxis();
        valueAxis68.centerRange((double) '#');
        categoryPlot54.setRangeAxis(0, valueAxis68, false);
        categoryPlot54.clearDomainAxes();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(valueAxis68);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str1 = color0.toString();
        float[] floatArray6 = new float[] { 0, 100, ' ', 0.0f };
        float[] floatArray7 = color0.getComponents(floatArray6);
        java.awt.Color color8 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        boolean boolean55 = categoryPlot54.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset56 = categoryPlot54.getDataset();
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D();
        double double59 = numberAxis3D58.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) numberAxis3D58, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, xYItemRenderer61);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent63 = null;
        xYPlot62.rendererChanged(rendererChangeEvent63);
        boolean boolean65 = xYPlot62.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot62.getRangeAxis();
        valueAxis66.setFixedDimension((double) 100L);
        int int69 = categoryPlot54.getRangeAxisIndex(valueAxis66);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(valueAxis66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        valueMarker1.setPaint(paint5);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.awt.Image image6 = xYPlot5.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        java.awt.Paint paint13 = numberAxis3D8.getLabelPaint();
        numberAxis3D8.setLabelToolTip("");
        xYPlot5.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, true);
        numberAxis3D8.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D8.getLabelInsets();
        java.awt.Shape shape21 = numberAxis3D8.getUpArrow();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        double double26 = numberAxis3D25.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, xYItemRenderer28);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYPlot29.rendererChanged(rendererChangeEvent30);
        boolean boolean32 = xYPlot29.isRangeZoomable();
        java.awt.Image image33 = null;
        xYPlot29.setBackgroundImage(image33);
        java.lang.String str35 = xYPlot29.getPlotType();
        org.jfree.chart.plot.Plot plot36 = null;
        xYPlot29.setParent(plot36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        double double41 = numberAxis3D40.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, xYItemRenderer43);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = null;
        xYPlot44.rendererChanged(rendererChangeEvent45);
        boolean boolean47 = xYPlot44.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot44.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection50 = xYPlot44.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot44);
        java.awt.geom.Rectangle2D rectangle2D52 = legendTitle51.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        xYPlot29.drawAnnotations(graphics2D38, rectangle2D52, plotRenderingInfo53);
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D56 = new org.jfree.chart.axis.NumberAxis3D();
        double double57 = numberAxis3D56.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) numberAxis3D56, (org.jfree.chart.axis.ValueAxis) numberAxis3D58, xYItemRenderer59);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent61 = null;
        xYPlot60.rendererChanged(rendererChangeEvent61);
        boolean boolean63 = xYPlot60.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot60.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection66 = xYPlot60.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot60);
        java.awt.geom.Rectangle2D rectangle2D68 = legendTitle67.getBounds();
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D();
        double double71 = numberAxis3D70.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D72 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset69, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, (org.jfree.chart.axis.ValueAxis) numberAxis3D72, xYItemRenderer73);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent75 = null;
        xYPlot74.rendererChanged(rendererChangeEvent75);
        boolean boolean77 = xYPlot74.isRangeZoomable();
        boolean boolean78 = xYPlot74.isDomainZeroBaselineVisible();
        int int79 = xYPlot74.getDatasetCount();
        xYPlot74.setRangeCrosshairLockedOnData(false);
        int int82 = xYPlot74.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = xYPlot74.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo84 = null;
        try {
            org.jfree.chart.axis.AxisState axisState85 = numberAxis3D8.draw(graphics2D22, (double) (short) 10, rectangle2D52, rectangle2D68, rectangleEdge83, plotRenderingInfo84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNull(legendItemCollection50);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertNull(legendItemCollection66);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge83);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.data.Range range2 = null;
        try {
            dateAxis0.setRange(range2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setNotify(false);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        java.awt.Paint paint19 = legendTitle18.getItemPaint();
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle18);
        int int21 = jFreeChart8.getSubtitleCount();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        categoryPlot54.setRangeAxisLocation(500, axisLocation82);
        org.jfree.chart.plot.ValueMarker valueMarker87 = new org.jfree.chart.plot.ValueMarker((double) '#');
        float float88 = valueMarker87.getAlpha();
        org.jfree.chart.util.Layer layer89 = null;
        boolean boolean90 = categoryPlot54.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker87, layer89);
        boolean boolean91 = categoryPlot54.isDomainZoomable();
        org.jfree.chart.util.Layer layer93 = null;
        java.util.Collection collection94 = categoryPlot54.getRangeMarkers((int) (byte) 10, layer93);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + float88 + "' != '" + 0.8f + "'", float88 == 0.8f);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(collection94);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        java.awt.Paint paint7 = numberAxis3D2.getLabelPaint();
        java.awt.Shape shape8 = numberAxis3D2.getLeftArrow();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D2.getPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = polarPlot11.getDataset();
        java.lang.Object obj13 = null;
        boolean boolean14 = polarPlot11.equals(obj13);
        polarPlot11.clearCornerTextItems();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = polarPlot11.getLegendItems();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font1, (java.awt.Paint) color2);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("Pie Plot", font7);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str10 = ringPlot9.getPlotType();
        ringPlot9.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        ringPlot9.datasetChanged(datasetChangeEvent13);
        java.awt.Stroke stroke15 = ringPlot9.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot16 = ringPlot9.getRootPlot();
        boolean boolean17 = ringPlot9.isCircular();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("PieSection: 10, -16777216(DateTickUnit[DAY, 1])", font7, (org.jfree.chart.plot.Plot) ringPlot9, true);
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("ThreadContext", font7);
        org.jfree.chart.text.TextFragment textFragment21 = textLine20.getFirstTextFragment();
        textLine3.removeFragment(textFragment21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(textFragment21);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.data.Range range7 = numberAxis3D2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(45.0d, range7);
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range7, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint8 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        ringPlot0.setBaseSectionPaint(paint9);
        ringPlot0.setLabelLinksVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = null;
        ringPlot0.setURLGenerator(pieURLGenerator13);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        categoryPlot54.setRangeAxisLocation(500, axisLocation82);
        boolean boolean86 = categoryPlot54.isRangeCrosshairLockedOnData();
        java.awt.Stroke stroke87 = categoryPlot54.getRangeGridlineStroke();
        categoryPlot54.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor89 = categoryPlot54.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(categoryAnchor89);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        java.lang.Object obj15 = jFreeChart8.getTextAntiAlias();
        jFreeChart8.setAntiAlias(true);
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart7.getPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis10.getCategoryStart((-1), (int) 'a', rectangle2D13, rectangleEdge14);
        java.awt.Paint paint17 = categoryAxis10.getTickLabelPaint((java.lang.Comparable) (short) 10);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, paint17);
        double double20 = rectangleInsets8.trimWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot7 = ringPlot0.getRootPlot();
        boolean boolean8 = ringPlot0.isCircular();
        java.awt.Stroke stroke9 = ringPlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle17.draw(graphics2D18, rectangle2D19);
        java.awt.Font font21 = textTitle17.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle17.getTextAlignment();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        org.jfree.data.Range range5 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        java.awt.Color color3 = java.awt.Color.GRAY;
        int int4 = color3.getBlue();
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        int int6 = color3.getRGB();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-8355712) + "'", int6 == (-8355712));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot11.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot11.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getRGB();
        float[] floatArray27 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color20);
        xYPlot5.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState35 = null;
        boolean boolean36 = xYPlot5.render(graphics2D31, rectangle2D32, (int) (short) -1, plotRenderingInfo34, crosshairState35);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str39 = ringPlot38.getPlotType();
        float float40 = ringPlot38.getBackgroundAlpha();
        java.awt.Color color41 = java.awt.Color.GRAY;
        int int42 = color41.getBlue();
        ringPlot38.setLabelPaint((java.awt.Paint) color41);
        xYPlot5.setQuadrantPaint(3, (java.awt.Paint) color41);
        java.awt.Font font46 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("", font46, paint47, (float) (byte) 1);
        xYPlot5.setDomainGridlinePaint(paint47);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D();
        double double53 = numberAxis3D52.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D54 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis3D52, (org.jfree.chart.axis.ValueAxis) numberAxis3D54, xYItemRenderer55);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent57 = null;
        xYPlot56.rendererChanged(rendererChangeEvent57);
        boolean boolean59 = xYPlot56.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis60 = xYPlot56.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace61 = null;
        xYPlot56.setFixedRangeAxisSpace(axisSpace61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot56.getRangeAxisEdge((int) (short) 1);
        xYPlot56.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.RingPlot ringPlot67 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str68 = ringPlot67.getPlotType();
        ringPlot67.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent71 = null;
        ringPlot67.datasetChanged(datasetChangeEvent71);
        java.awt.Stroke stroke73 = ringPlot67.getLabelOutlineStroke();
        xYPlot56.setRangeCrosshairStroke(stroke73);
        xYPlot5.setRangeGridlineStroke(stroke73);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-16777216) + "'", int21 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Pie Plot" + "'", str39.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 128 + "'", int42 == 128);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(valueAxis60);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Pie Plot" + "'", str68.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
        double double56 = numberAxis3D55.getFixedAutoRange();
        java.awt.Shape shape57 = numberAxis3D55.getRightArrow();
        categoryPlot54.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D55);
        boolean boolean59 = numberAxis3D55.getAutoRangeIncludesZero();
        float float60 = numberAxis3D55.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.0f + "'", float60 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        double double4 = ringPlot0.getLabelLinkMargin();
        try {
            ringPlot0.setInteriorGap((double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (35.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        int int2 = objectList1.size();
        java.lang.Object obj3 = objectList1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot7.getRangeAxis();
        java.awt.Paint paint12 = xYPlot7.getDomainTickBandPaint();
        xYPlot7.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot7.setRenderer(0, xYItemRenderer16, false);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelLinkStroke();
        xYPlot7.setRangeGridlineStroke(stroke25);
        valueMarker1.setStroke(stroke25);
        org.jfree.data.Range range28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range28, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint30.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint30.toUnconstrainedHeight();
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray65 = new java.lang.Number[][] { numberArray39, numberArray44, numberArray49, numberArray54, numberArray59, numberArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray65);
        org.jfree.data.Range range68 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset66, true);
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D();
        double double71 = numberAxis3D70.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D72 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset69, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, (org.jfree.chart.axis.ValueAxis) numberAxis3D72, xYItemRenderer73);
        org.jfree.data.Range range75 = numberAxis3D70.getDefaultAutoRange();
        org.jfree.data.Range range76 = org.jfree.data.Range.combine(range68, range75);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = rectangleConstraint30.toRangeWidth(range68);
        boolean boolean78 = valueMarker1.equals((java.lang.Object) range68);
        java.lang.Object obj79 = valueMarker1.clone();
        java.awt.Font font80 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker1.setLabelFont(font80);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(font80);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("TextAnchor.CENTER_LEFT", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        java.awt.Color color57 = java.awt.Color.pink;
        categoryPlot54.setRangeCrosshairPaint((java.awt.Paint) color57);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D61 = new org.jfree.chart.axis.NumberAxis3D();
        double double62 = numberAxis3D61.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D63 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) numberAxis3D61, (org.jfree.chart.axis.ValueAxis) numberAxis3D63, xYItemRenderer64);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D68 = new org.jfree.chart.axis.NumberAxis3D();
        double double69 = numberAxis3D68.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot(xYDataset67, (org.jfree.chart.axis.ValueAxis) numberAxis3D68, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, xYItemRenderer71);
        java.awt.Paint paint73 = numberAxis3D68.getLabelPaint();
        numberAxis3D68.setLabelToolTip("");
        xYPlot65.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D68, true);
        numberAxis3D68.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = numberAxis3D68.getLabelInsets();
        java.awt.Shape shape81 = numberAxis3D68.getUpArrow();
        try {
            categoryPlot54.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis) numberAxis3D68, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertNotNull(shape81);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.mapDatasetToRangeAxis(0, (int) '#');
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot54.setOrientation(plotOrientation58);
        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font62 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color63 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine64 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font62, (java.awt.Paint) color63);
        ringPlot60.setLabelFont(font62);
        ringPlot60.setIgnoreNullValues(true);
        ringPlot60.setLabelGap(90.0d);
        boolean boolean70 = plotOrientation58.equals((java.lang.Object) 90.0d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setSectionOutlinesVisible(false);
        ringPlot0.setInnerSeparatorExtension((double) 10L);
        ringPlot0.setSectionDepth((double) (byte) 100);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray18, numberArray23, numberArray28, numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray44);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, 3);
        ringPlot0.setDataset(pieDataset48);
        org.jfree.data.general.PieDataset pieDataset52 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset48, (java.lang.Comparable) 0.0d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 600.0d + "'", number46.equals(600.0d));
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(pieDataset52);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint8 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        ringPlot0.setBaseSectionPaint(paint9);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font12, (java.awt.Paint) color13);
        float[] floatArray15 = null;
        float[] floatArray16 = color13.getRGBComponents(floatArray15);
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabel("ThreadContext");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis5.getTickUnit();
        dateAxis4.setTickUnit(dateTickUnit6, true, true);
        java.util.Date date10 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        legendTitle12.setWidth((double) 100L);
        java.awt.Font font15 = legendTitle12.getItemFont();
        dateAxis0.setLabelFont(font15);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 100L);
        java.awt.Font font5 = legendTitle2.getItemFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        boolean boolean15 = xYPlot11.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke16 = xYPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("Pie Plot", font5, (org.jfree.chart.plot.Plot) xYPlot11, true);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        legendTitle20.setWidth((double) 100L);
        java.awt.Font font23 = legendTitle20.getItemFont();
        legendTitle20.setWidth((double) 0.0f);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle20.getSources();
        jFreeChart18.removeSubtitle((org.jfree.chart.title.Title) legendTitle20);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ClassContext", "VerticalAlignment.TOP", "{0}", "");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33);
        try {
            org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset33, (java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.Range range6 = numberAxis3D1.getDefaultAutoRange();
        float float7 = numberAxis3D1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot11.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot11.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getRGB();
        float[] floatArray27 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color20);
        xYPlot5.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState35 = null;
        boolean boolean36 = xYPlot5.render(graphics2D31, rectangle2D32, (int) (short) -1, plotRenderingInfo34, crosshairState35);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str39 = ringPlot38.getPlotType();
        float float40 = ringPlot38.getBackgroundAlpha();
        java.awt.Color color41 = java.awt.Color.GRAY;
        int int42 = color41.getBlue();
        ringPlot38.setLabelPaint((java.awt.Paint) color41);
        xYPlot5.setQuadrantPaint(3, (java.awt.Paint) color41);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        int int46 = xYPlot5.getIndexOf(xYItemRenderer45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-16777216) + "'", int21 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Pie Plot" + "'", str39.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 128 + "'", int42 == 128);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D3.setLabel("XY Plot");
        numberAxis3D3.setFixedAutoRange((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot14.rendererChanged(rendererChangeEvent15);
        boolean boolean17 = xYPlot14.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot14.getRangeAxis();
        java.awt.Paint paint19 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(0, xYItemRenderer23, false);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str27 = ringPlot26.getPlotType();
        ringPlot26.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        ringPlot26.datasetChanged(datasetChangeEvent30);
        java.awt.Stroke stroke32 = ringPlot26.getLabelLinkStroke();
        xYPlot14.setRangeGridlineStroke(stroke32);
        valueMarker8.setStroke(stroke32);
        org.jfree.data.Range range35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(range35, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType38 = rectangleConstraint37.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint37.toUnconstrainedHeight();
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] { numberArray46, numberArray51, numberArray56, numberArray61, numberArray66, numberArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray72);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset73, true);
        org.jfree.data.xy.XYDataset xYDataset76 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D77 = new org.jfree.chart.axis.NumberAxis3D();
        double double78 = numberAxis3D77.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D79 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset76, (org.jfree.chart.axis.ValueAxis) numberAxis3D77, (org.jfree.chart.axis.ValueAxis) numberAxis3D79, xYItemRenderer80);
        org.jfree.data.Range range82 = numberAxis3D77.getDefaultAutoRange();
        org.jfree.data.Range range83 = org.jfree.data.Range.combine(range75, range82);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint84 = rectangleConstraint37.toRangeWidth(range75);
        boolean boolean85 = valueMarker8.equals((java.lang.Object) range75);
        java.lang.Object obj86 = valueMarker8.clone();
        org.jfree.chart.util.Layer layer87 = null;
        try {
            xYPlot5.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker8, layer87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pie Plot" + "'", str27.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(lengthConstraintType38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(range82);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(rectangleConstraint84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(obj86);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.data.xy.XYDataset xYDataset37 = xYPlot5.getDataset(0);
        xYPlot5.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(xYDataset37);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getBaseSectionPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset33);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        double double41 = range39.constrain((double) 'a');
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 600.0d + "'", number37.equals(600.0d));
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 97.0d + "'", double41 == 97.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        projectInfo0.setInfo("XY Plot");
        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "", numberArray2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, false);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleEdge.LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint14 = xYPlot5.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, xYItemRenderer20);
        java.lang.String str22 = numberAxis3D19.getLabel();
        xYPlot5.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date7 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        xYPlot16.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot16.getDataset();
        boolean boolean21 = lineBorder10.equals((java.lang.Object) xYPlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot16.zoomRangeAxes((double) 'a', plotRenderingInfo23, point2D24);
        xYPlot16.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot16.getDomainAxisEdge((int) (short) 1);
        try {
            double double29 = dateAxis0.java2DToValue(0.0d, rectangle2D9, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.geom.Point2D point2D12 = xYPlot5.getQuadrantOrigin();
        xYPlot5.configureDomainAxes();
        xYPlot5.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        int int13 = xYPlot5.getRangeAxisCount();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextOutlineStroke();
        java.awt.Paint paint16 = defaultDrawingSupplier14.getNextFillPaint();
        xYPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier14);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        double double20 = numberAxis3D19.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, xYItemRenderer22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot23.rendererChanged(rendererChangeEvent24);
        boolean boolean26 = xYPlot23.isRangeZoomable();
        java.awt.Image image27 = null;
        xYPlot23.setBackgroundImage(image27);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot23);
        java.awt.geom.Point2D point2D30 = xYPlot23.getQuadrantOrigin();
        xYPlot23.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset32 = xYPlot23.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot23.getRangeAxisLocation((int) (short) -1);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        double double37 = numberAxis3D36.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, xYItemRenderer39);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYPlot40.rendererChanged(rendererChangeEvent41);
        boolean boolean43 = xYPlot40.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis44 = xYPlot40.getRangeAxis();
        java.awt.Paint paint45 = xYPlot40.getDomainTickBandPaint();
        xYPlot40.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        xYPlot40.setRenderer(0, xYItemRenderer49, false);
        org.jfree.chart.plot.RingPlot ringPlot52 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str53 = ringPlot52.getPlotType();
        ringPlot52.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        ringPlot52.datasetChanged(datasetChangeEvent56);
        java.awt.Stroke stroke58 = ringPlot52.getLabelLinkStroke();
        xYPlot40.setRangeGridlineStroke(stroke58);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot40.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation62 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation61, plotOrientation62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation34, plotOrientation62);
        xYPlot5.setDomainAxisLocation(axisLocation34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(valueAxis44);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Pie Plot" + "'", str53.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(plotOrientation62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot11.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot11.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getRGB();
        float[] floatArray27 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color20);
        xYPlot5.setBackgroundPaint((java.awt.Paint) color20);
        int int31 = color20.getBlue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-16777216) + "'", int21 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        boolean boolean9 = ringPlot0.equals((java.lang.Object) (short) 0);
        ringPlot0.setCircular(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot0.getLabelPadding();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        xYPlot5.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot5.getDataset();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot5.getDomainAxisForDataset((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(xYDataset9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Stroke stroke1 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart9.getPadding();
        double double12 = rectangleInsets10.calculateRightOutset((double) (byte) -1);
        try {
            org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) (-1.0f), (double) 0.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment17, verticalAlignment18, (double) (-1.0f), (double) 0.0f);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) flowArrangement21);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement16);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        double double27 = numberAxis3D26.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer29);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        xYPlot30.rendererChanged(rendererChangeEvent31);
        boolean boolean33 = xYPlot30.isRangeZoomable();
        java.awt.Image image34 = null;
        xYPlot30.setBackgroundImage(image34);
        java.lang.String str36 = xYPlot30.getPlotType();
        org.jfree.chart.plot.Plot plot37 = null;
        xYPlot30.setParent(plot37);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        double double42 = numberAxis3D41.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, xYItemRenderer44);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        xYPlot45.rendererChanged(rendererChangeEvent46);
        boolean boolean48 = xYPlot45.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot45.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection51 = xYPlot45.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot45);
        java.awt.geom.Rectangle2D rectangle2D53 = legendTitle52.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        xYPlot30.drawAnnotations(graphics2D39, rectangle2D53, plotRenderingInfo54);
        try {
            java.lang.Object obj57 = blockContainer23.draw(graphics2D24, rectangle2D53, (java.lang.Object) "PieSection: 10, -16777216(DateTickUnit[DAY, 1])");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "XY Plot" + "'", str36.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNull(legendItemCollection51);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.getToolTipText();
        int int11 = pieSectionEntity9.getPieIndex();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        java.awt.Shape shape14 = numberAxis3D12.getRightArrow();
        pieSectionEntity9.setArea(shape14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextOutlineStroke();
        boolean boolean18 = pieSectionEntity9.equals((java.lang.Object) defaultDrawingSupplier16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot54.getFixedLegendItems();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        double double61 = numberAxis3D60.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, xYItemRenderer63);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent65 = null;
        xYPlot64.rendererChanged(rendererChangeEvent65);
        boolean boolean67 = xYPlot64.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot64.getRangeAxis();
        java.awt.Paint paint69 = xYPlot64.getDomainTickBandPaint();
        xYPlot64.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        xYPlot64.setRenderer(0, xYItemRenderer73, false);
        org.jfree.chart.plot.RingPlot ringPlot76 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str77 = ringPlot76.getPlotType();
        ringPlot76.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent80 = null;
        ringPlot76.datasetChanged(datasetChangeEvent80);
        java.awt.Stroke stroke82 = ringPlot76.getLabelLinkStroke();
        xYPlot64.setRangeGridlineStroke(stroke82);
        org.jfree.chart.axis.AxisLocation axisLocation85 = xYPlot64.getRangeAxisLocation((int) (short) 10);
        categoryPlot54.setDomainAxisLocation(axisLocation85);
        java.awt.Graphics2D graphics2D87 = null;
        org.jfree.chart.LegendItemSource legendItemSource88 = null;
        org.jfree.chart.title.LegendTitle legendTitle89 = new org.jfree.chart.title.LegendTitle(legendItemSource88);
        legendTitle89.setWidth((double) 100L);
        java.awt.Font font92 = legendTitle89.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D93 = legendTitle89.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo95 = null;
        boolean boolean96 = categoryPlot54.render(graphics2D87, rectangle2D93, 500, plotRenderingInfo95);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(valueAxis68);
        org.junit.Assert.assertNull(paint69);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Pie Plot" + "'", str77.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertNotNull(font92);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18, numberArray23, numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset35, true);
        double double38 = range37.getLowerBound();
        double double39 = range37.getCentralValue();
        dateAxis1.setDefaultAutoRange(range37);
        boolean boolean41 = polarPlot0.equals((java.lang.Object) range37);
        boolean boolean42 = polarPlot0.isRangeZoomable();
        boolean boolean43 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 49.5d + "'", double39 == 49.5d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        dateAxis58.setRange((double) 0L, (double) (short) 100);
        java.util.Date date62 = dateAxis58.getMaximumDate();
        java.text.DateFormat dateFormat63 = dateAxis58.getDateFormatOverride();
        categoryPlot54.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis58);
        boolean boolean65 = categoryPlot54.isRangeCrosshairVisible();
        org.jfree.chart.util.SortOrder sortOrder66 = null;
        try {
            categoryPlot54.setColumnRenderingOrder(sortOrder66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNull(dateFormat63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        categoryPlot54.clearRangeAxes();
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor62 = valueMarker61.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer63 = null;
        try {
            boolean boolean64 = categoryPlot54.removeRangeMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker61, layer63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(textAnchor62);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("Pie Plot", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.lang.String str7 = textAnchor6.toString();
        try {
            textLine2.draw(graphics2D3, (float) (-8355712), (float) 1L, textAnchor6, (float) (byte) 10, 0.0f, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str7.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = new org.jfree.chart.LegendItemCollection();
        boolean boolean13 = legendItemCollection11.equals((java.lang.Object) 4.0d);
        xYPlot5.setFixedLegendItems(legendItemCollection11);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot5.setRangeAxis(500, valueAxis16, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str20 = color19.toString();
        xYPlot5.setDomainZeroBaselinePaint((java.awt.Paint) color19);
        java.awt.color.ColorSpace colorSpace22 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        double double28 = numberAxis3D27.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, xYItemRenderer30);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYPlot31.rendererChanged(rendererChangeEvent32);
        boolean boolean34 = xYPlot31.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot31.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot31.setFixedRangeAxisSpace(axisSpace36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot31.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color40 = java.awt.Color.black;
        int int41 = color40.getRGB();
        float[] floatArray47 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray48 = color40.getRGBColorComponents(floatArray47);
        xYPlot31.setRangeTickBandPaint((java.awt.Paint) color40);
        java.awt.Color color50 = java.awt.Color.black;
        int int51 = color50.getRGB();
        float[] floatArray57 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray58 = color50.getRGBColorComponents(floatArray57);
        float[] floatArray59 = color40.getComponents(floatArray58);
        float[] floatArray60 = java.awt.Color.RGBtoHSB((int) (short) 100, (int) (short) 10, (int) (short) 1, floatArray58);
        try {
            float[] floatArray61 = color19.getComponents(colorSpace22, floatArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str20.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-16777216) + "'", int41 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-16777216) + "'", int51 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18, numberArray23, numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset35, true);
        double double38 = range37.getLowerBound();
        double double39 = range37.getCentralValue();
        dateAxis1.setDefaultAutoRange(range37);
        boolean boolean41 = polarPlot0.equals((java.lang.Object) range37);
        boolean boolean42 = polarPlot0.isRangeZoomable();
        polarPlot0.removeCornerTextItem("ThreadContext");
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 49.5d + "'", double39 == 49.5d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("Pie Plot");
        java.awt.Paint paint5 = textFragment4.getPaint();
        ringPlot0.setBaseSectionPaint(paint5);
        boolean boolean7 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot0.getURLGenerator();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        double double12 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot15);
        java.awt.Paint paint17 = jFreeChart16.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart16.getTitle();
        ringPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textTitle18);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        polarPlot0.setDataset(xYDataset1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = polarPlot0.getLegendItems();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str5 = ringPlot4.getPlotType();
        float float6 = ringPlot4.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint9 = categoryAxis3D7.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot4.setBaseSectionOutlinePaint(paint9);
        java.awt.Paint paint11 = ringPlot4.getLabelPaint();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str15 = ringPlot14.getPlotType();
        float float16 = ringPlot14.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = ringPlot4.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.PiePlot) ringPlot14, (java.lang.Integer) 0, plotRenderingInfo18);
        org.jfree.chart.entity.EntityCollection entityCollection20 = piePlotState19.getEntityCollection();
        piePlotState19.setPieHRadius((-1.0d));
        boolean boolean23 = legendItemCollection3.equals((java.lang.Object) (-1.0d));
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Pie Plot" + "'", str15.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNull(entityCollection20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        dateAxis0.zoomRange((double) 0L, 0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str1 = color0.toString();
        float[] floatArray6 = new float[] { 0, 100, ' ', 0.0f };
        float[] floatArray7 = color0.getComponents(floatArray6);
        int int8 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=64]"));
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Multiple Pie Plot");
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Multiple Pie Plot", "java.awt.Color[r=255,g=0,b=0]", "TextAnchor.CENTER_LEFT", "0,0,-2,-2,-2,2,-2,2", "XY Plot");
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str5 = ringPlot4.getPlotType();
        ringPlot4.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        ringPlot4.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke10 = ringPlot4.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot11 = ringPlot4.getRootPlot();
        boolean boolean12 = ringPlot4.isCircular();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 3, plotRenderingInfo14);
        piePlotState15.setPieHRadius((double) (-1L));
        java.awt.geom.Rectangle2D rectangle2D18 = piePlotState15.getLinkArea();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertNull(rectangle2D18);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        java.awt.Image image2 = ringPlot0.getBackgroundImage();
        org.jfree.chart.block.BlockResult blockResult3 = new org.jfree.chart.block.BlockResult();
        boolean boolean4 = ringPlot0.equals((java.lang.Object) blockResult3);
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        blockResult3.setEntityCollection(entityCollection5);
        org.jfree.chart.entity.EntityCollection entityCollection7 = blockResult3.getEntityCollection();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(entityCollection7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(paint7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.mapDatasetToRangeAxis(0, (int) '#');
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot54.setOrientation(plotOrientation58);
        categoryPlot54.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace61 = null;
        categoryPlot54.setFixedRangeAxisSpace(axisSpace61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot54.getIndexOf(categoryItemRenderer63);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT");
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace12, true);
        xYPlot5.setWeight((int) '#');
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        double double21 = numberAxis3D20.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, xYItemRenderer23);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        xYPlot24.rendererChanged(rendererChangeEvent25);
        boolean boolean27 = xYPlot24.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot24.getRangeAxis();
        java.awt.Paint paint29 = xYPlot24.getDomainTickBandPaint();
        xYPlot24.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot24.setRenderer(0, xYItemRenderer33, false);
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str37 = ringPlot36.getPlotType();
        ringPlot36.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
        ringPlot36.datasetChanged(datasetChangeEvent40);
        java.awt.Stroke stroke42 = ringPlot36.getLabelLinkStroke();
        xYPlot24.setRangeGridlineStroke(stroke42);
        valueMarker18.setStroke(stroke42);
        try {
            boolean boolean45 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Pie Plot" + "'", str37.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = textTitle17.getPaint();
        java.lang.String str19 = textTitle17.getURLText();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot11.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot11.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getRGB();
        float[] floatArray27 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color20);
        xYPlot5.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState35 = null;
        boolean boolean36 = xYPlot5.render(graphics2D31, rectangle2D32, (int) (short) -1, plotRenderingInfo34, crosshairState35);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str39 = ringPlot38.getPlotType();
        float float40 = ringPlot38.getBackgroundAlpha();
        java.awt.Color color41 = java.awt.Color.GRAY;
        int int42 = color41.getBlue();
        ringPlot38.setLabelPaint((java.awt.Paint) color41);
        xYPlot5.setQuadrantPaint(3, (java.awt.Paint) color41);
        java.awt.Paint paint45 = xYPlot5.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-16777216) + "'", int21 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Pie Plot" + "'", str39.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 128 + "'", int42 == 128);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        categoryPlot54.setRangeAxisLocation(500, axisLocation82);
        boolean boolean86 = categoryPlot54.isRangeCrosshairLockedOnData();
        java.awt.Stroke stroke87 = categoryPlot54.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection88 = categoryPlot54.getLegendItems();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(legendItemCollection88);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) (-1.0f), (double) 0.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment17, verticalAlignment18, (double) (-1.0f), (double) 0.0f);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) flowArrangement21);
        flowArrangement21.clear();
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        legendTitle25.setWidth((double) 100L);
        java.awt.Font font28 = legendTitle25.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle25.getLegendItemGraphicLocation();
        legendTitle25.setMargin((double) (byte) 100, 1.05d, (double) (-1.0f), (double) (-1L));
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str36 = ringPlot35.getPlotType();
        ringPlot35.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        ringPlot35.datasetChanged(datasetChangeEvent39);
        java.awt.Stroke stroke41 = ringPlot35.getLabelLinkStroke();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        double double44 = numberAxis3D43.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, xYItemRenderer46);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        double double50 = numberAxis3D49.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, xYItemRenderer52);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent54 = null;
        xYPlot53.rendererChanged(rendererChangeEvent54);
        boolean boolean56 = xYPlot53.isRangeZoomable();
        java.awt.Image image57 = null;
        xYPlot53.setBackgroundImage(image57);
        java.lang.String str59 = xYPlot53.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str61 = ringPlot60.getPlotType();
        ringPlot60.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent64 = null;
        ringPlot60.datasetChanged(datasetChangeEvent64);
        java.awt.Stroke stroke66 = ringPlot60.getLabelOutlineStroke();
        xYPlot53.setRangeGridlineStroke(stroke66);
        numberAxis3D45.setAxisLineStroke(stroke66);
        ringPlot35.setSeparatorStroke(stroke66);
        flowArrangement21.add((org.jfree.chart.block.Block) legendTitle25, (java.lang.Object) ringPlot35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Pie Plot" + "'", str36.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "XY Plot" + "'", str59.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Pie Plot" + "'", str61.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        org.jfree.chart.JFreeChart jFreeChart13 = chartProgressEvent12.getChart();
        java.awt.Image image14 = jFreeChart13.getBackgroundImage();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNull(image14);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint14 = xYPlot5.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        double double18 = numberAxis3D17.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, xYItemRenderer20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = xYPlot21.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot21.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        valueMarker25.notifyListeners(markerChangeEvent28);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        valueMarker25.setLabelTextAnchor(textAnchor30);
        try {
            boolean boolean32 = xYPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(textAnchor30);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        xYPlot5.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ringPlot0);
        java.awt.Paint paint4 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str3 = ringPlot2.getPlotType();
        float float4 = ringPlot2.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint7 = categoryAxis3D5.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot2.setBaseSectionOutlinePaint(paint7);
        java.awt.Paint paint9 = ringPlot2.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("PieSection: 10, -16777216(DateTickUnit[DAY, 1])", font1, (org.jfree.chart.plot.Plot) ringPlot2, false);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        legendTitle13.setWidth((double) 100L);
        java.awt.Font font16 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle13.setLegendItemGraphicLocation(rectangleAnchor17);
        jFreeChart11.addLegend(legendTitle13);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray20 = legendTitle13.getSources();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(legendItemSourceArray20);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setNotify(false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener17 = null;
        try {
            jFreeChart8.addChangeListener(chartChangeListener17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        java.awt.Paint paint13 = jFreeChart8.getBorderPaint();
        float float14 = jFreeChart8.getBackgroundImageAlpha();
        java.awt.Paint paint15 = jFreeChart8.getBorderPaint();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        boolean boolean11 = xYPlot7.isDomainZeroBaselineVisible();
        int int12 = xYPlot7.getDatasetCount();
        xYPlot7.setRangeCrosshairLockedOnData(false);
        int int15 = xYPlot7.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot7.getRangeAxisEdge();
        java.lang.String str17 = rectangleEdge16.toString();
        java.lang.Class<?> wildcardClass18 = rectangleEdge16.getClass();
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=255,g=255,b=64]", (java.lang.Class) wildcardClass18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass18);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.LEFT" + "'", str17.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(uRL19);
        org.junit.Assert.assertNull(inputStream20);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.toString();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        double double14 = numberAxis3D13.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer16);
        xYPlot17.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot17.getDataset();
        boolean boolean22 = lineBorder11.equals((java.lang.Object) xYPlot17);
        boolean boolean23 = pieSectionEntity9.equals((java.lang.Object) boolean22);
        java.lang.String str24 = pieSectionEntity9.getToolTipText();
        pieSectionEntity9.setURLText("java.awt.Color[r=255,g=255,b=64]");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 10, -16777216(DateTickUnit[DAY, 1])" + "'", str10.equals("PieSection: 10, -16777216(DateTickUnit[DAY, 1])"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pie Plot" + "'", str24.equals("Pie Plot"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        legendTitle1.setItemLabelPadding(rectangleInsets7);
        double double9 = rectangleInsets7.getTop();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = null;
        ringPlot0.notifyListeners(plotChangeEvent1);
        double double3 = ringPlot0.getShadowXOffset();
        ringPlot0.setMaximumLabelWidth((double) 100);
        int int6 = ringPlot0.getPieIndex();
        double double7 = ringPlot0.getStartAngle();
        boolean boolean8 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot11.rendererChanged(rendererChangeEvent12);
        boolean boolean14 = xYPlot11.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot11.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot11.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getRGB();
        float[] floatArray27 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color20);
        xYPlot5.setBackgroundPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState35 = null;
        boolean boolean36 = xYPlot5.render(graphics2D31, rectangle2D32, (int) (short) -1, plotRenderingInfo34, crosshairState35);
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str39 = ringPlot38.getPlotType();
        float float40 = ringPlot38.getBackgroundAlpha();
        java.awt.Color color41 = java.awt.Color.GRAY;
        int int42 = color41.getBlue();
        ringPlot38.setLabelPaint((java.awt.Paint) color41);
        xYPlot5.setQuadrantPaint(3, (java.awt.Paint) color41);
        java.lang.String str45 = color41.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-16777216) + "'", int21 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Pie Plot" + "'", str39.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 128 + "'", int42 == 128);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str45.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
        double double56 = numberAxis3D55.getFixedAutoRange();
        java.awt.Shape shape57 = numberAxis3D55.getRightArrow();
        categoryPlot54.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D55);
        categoryPlot54.configureRangeAxes();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        double double15 = numberAxis3D14.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, xYItemRenderer17);
        java.lang.String str19 = numberAxis3D16.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis3D16.setMarkerBand(markerAxisBand20);
        xYPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) lineBorder1);
        java.lang.String str3 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.VERTICAL" + "'", str3.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryStart((-1), (int) 'a', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) 10);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 10);
        float float11 = categoryAxis1.getTickMarkOutsideLength();
        java.lang.String str13 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        double double12 = numberAxis3D11.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, xYItemRenderer14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYPlot15.rendererChanged(rendererChangeEvent16);
        boolean boolean18 = xYPlot15.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot15.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot15.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot15);
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle22.getBounds();
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        double double27 = numberAxis3D26.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYItemRenderer29);
        xYPlot30.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot30.getDataset();
        boolean boolean35 = lineBorder24.equals((java.lang.Object) xYPlot30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot30.zoomRangeAxes((double) 'a', plotRenderingInfo37, point2D38);
        xYPlot30.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot30.getDomainAxisEdge((int) (short) 1);
        try {
            java.util.List list43 = dateAxis0.refreshTicks(graphics2D8, axisState9, rectangle2D23, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        double double6 = numberAxis3D1.getLowerMargin();
        java.lang.String str7 = numberAxis3D1.getLabelToolTip();
        double double8 = numberAxis3D1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        double double9 = numberAxis3D8.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer11);
        java.awt.Paint paint13 = numberAxis3D8.getLabelPaint();
        numberAxis3D8.setLabelToolTip("");
        xYPlot5.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, true);
        numberAxis3D8.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D8.getLabelInsets();
        java.awt.Shape shape21 = numberAxis3D8.getUpArrow();
        numberAxis3D8.setRange(0.0d, (double) 2);
        boolean boolean25 = numberAxis3D8.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = textTitle17.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle17.getPadding();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        float float2 = valueMarker1.getAlpha();
        java.awt.Stroke stroke3 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8f + "'", float2 == 0.8f);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33);
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray69 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] { numberArray44, numberArray49, numberArray54, numberArray59, numberArray64, numberArray69 };
        org.jfree.data.category.CategoryDataset categoryDataset71 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray70);
        org.jfree.data.general.PieDataset pieDataset73 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset71, 1);
        org.jfree.data.Range range74 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset71);
        org.jfree.data.Range range75 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset71);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint76 = new org.jfree.chart.block.RectangleConstraint(range37, range75);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint78 = rectangleConstraint76.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(categoryDataset71);
        org.junit.Assert.assertNotNull(pieDataset73);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(rectangleConstraint78);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        boolean boolean9 = ringPlot0.equals((java.lang.Object) (short) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = ringPlot0.getLegendItems();
        org.jfree.data.general.PieDataset pieDataset11 = ringPlot0.getDataset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNull(pieDataset11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) 4.0d);
        org.jfree.chart.LegendItem legendItem3 = null;
        legendItemCollection0.add(legendItem3);
        org.jfree.chart.LegendItem legendItem5 = null;
        legendItemCollection0.add(legendItem5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        xYPlot5.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot19.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot19.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot19.getRangeAxis();
        org.jfree.data.Range range24 = xYPlot5.getDataRange(valueAxis23);
        java.awt.Paint paint25 = xYPlot5.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.toString();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        double double14 = numberAxis3D13.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer16);
        xYPlot17.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot17.getDataset();
        boolean boolean22 = lineBorder11.equals((java.lang.Object) xYPlot17);
        boolean boolean23 = pieSectionEntity9.equals((java.lang.Object) boolean22);
        java.lang.String str24 = pieSectionEntity9.toString();
        pieSectionEntity9.setPieIndex((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 10, -16777216(DateTickUnit[DAY, 1])" + "'", str10.equals("PieSection: 10, -16777216(DateTickUnit[DAY, 1])"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PieSection: 10, -16777216(DateTickUnit[DAY, 1])" + "'", str24.equals("PieSection: 10, -16777216(DateTickUnit[DAY, 1])"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot5);
        jFreeChart12.setBorderVisible(true);
        org.jfree.chart.plot.Plot plot15 = jFreeChart12.getPlot();
        java.awt.Paint paint16 = jFreeChart12.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        jFreeChart8.setNotify(false);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        java.awt.Paint paint19 = legendTitle18.getItemPaint();
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle18);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot21 = jFreeChart8.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.XYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.TOP");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.geom.Point2D point2D12 = xYPlot5.getQuadrantOrigin();
        xYPlot5.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = xYPlot5.getDomainAxisIndex(valueAxis14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        double double8 = ringPlot0.getShadowYOffset();
        java.awt.Paint paint9 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        java.awt.Image image17 = null;
        xYPlot5.setBackgroundImage(image17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        categoryAxis1.setMaximumCategoryLabelLines((int) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis4.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabel("ThreadContext");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis4.getTickUnit();
        dateAxis4.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis4.setMaximumDate(date8);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date11 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit10);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str13 = ringPlot12.getPlotType();
        float float14 = ringPlot12.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint17 = categoryAxis3D15.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot12.setBaseSectionOutlinePaint(paint17);
        java.awt.Paint paint19 = ringPlot12.getLabelPaint();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str23 = ringPlot22.getPlotType();
        float float24 = ringPlot22.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = ringPlot12.initialise(graphics2D20, rectangle2D21, (org.jfree.chart.plot.PiePlot) ringPlot22, (java.lang.Integer) 0, plotRenderingInfo26);
        org.jfree.chart.entity.EntityCollection entityCollection28 = piePlotState27.getEntityCollection();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        legendTitle30.setWidth((double) 100L);
        java.awt.Font font33 = legendTitle30.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle30.getBounds();
        piePlotState27.setLinkArea(rectangle2D34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        double double38 = numberAxis3D37.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, xYItemRenderer40);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        xYPlot41.rendererChanged(rendererChangeEvent42);
        boolean boolean44 = xYPlot41.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot41.getRangeAxis();
        java.awt.Paint paint46 = xYPlot41.getDomainTickBandPaint();
        xYPlot41.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        xYPlot41.setRenderer(0, xYItemRenderer50, false);
        org.jfree.chart.plot.RingPlot ringPlot53 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str54 = ringPlot53.getPlotType();
        ringPlot53.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent57 = null;
        ringPlot53.datasetChanged(datasetChangeEvent57);
        java.awt.Stroke stroke59 = ringPlot53.getLabelLinkStroke();
        xYPlot41.setRangeGridlineStroke(stroke59);
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot41.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation62, plotOrientation63);
        double double65 = dateAxis0.dateToJava2D(date11, rectangle2D34, rectangleEdge64);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline67 = dateAxis66.getTimeline();
        boolean boolean68 = rectangleEdge64.equals((java.lang.Object) dateAxis66);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pie Plot" + "'", str23.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertNull(entityCollection28);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(valueAxis45);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Pie Plot" + "'", str54.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(timeline67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("", "", "java.awt.Color[r=255,g=255,b=64]", "", "");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo7.getOptionalLibraries();
        java.lang.String str9 = basicProjectInfo7.getVersion();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        double double19 = numberAxis3D18.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, xYItemRenderer21);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYPlot22.rendererChanged(rendererChangeEvent23);
        boolean boolean25 = xYPlot22.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot22.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot22.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot22.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color31 = java.awt.Color.black;
        int int32 = color31.getRGB();
        float[] floatArray38 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray39 = color31.getRGBColorComponents(floatArray38);
        xYPlot22.setRangeTickBandPaint((java.awt.Paint) color31);
        xYPlot16.setBackgroundPaint((java.awt.Paint) color31);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.plot.CrosshairState crosshairState46 = null;
        boolean boolean47 = xYPlot16.render(graphics2D42, rectangle2D43, (int) (short) -1, plotRenderingInfo45, crosshairState46);
        org.jfree.chart.plot.RingPlot ringPlot49 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str50 = ringPlot49.getPlotType();
        float float51 = ringPlot49.getBackgroundAlpha();
        java.awt.Color color52 = java.awt.Color.GRAY;
        int int53 = color52.getBlue();
        ringPlot49.setLabelPaint((java.awt.Paint) color52);
        xYPlot16.setQuadrantPaint(3, (java.awt.Paint) color52);
        java.awt.Font font57 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint58 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment60 = new org.jfree.chart.text.TextFragment("", font57, paint58, (float) (byte) 1);
        xYPlot16.setDomainGridlinePaint(paint58);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo64 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list65 = projectInfo64.getContributors();
        xYPlot16.drawRangeTickBands(graphics2D62, rectangle2D63, list65);
        projectInfo0.setContributors(list65);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-16777216) + "'", int32 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Pie Plot" + "'", str50.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 1.0f + "'", float51 == 1.0f);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 128 + "'", int53 == 128);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(projectInfo64);
        org.junit.Assert.assertNotNull(list65);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getRed();
        int int2 = color0.getBlue();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        java.awt.Color color3 = java.awt.Color.GRAY;
        int int4 = color3.getBlue();
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke10 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYPlot16.rendererChanged(rendererChangeEvent17);
        boolean boolean19 = xYPlot16.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot16.getRangeAxis();
        valueAxis20.centerRange((double) '#');
        org.jfree.data.Range range23 = valueAxis20.getDefaultAutoRange();
        xYPlot5.setDomainAxis(valueAxis20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot5.getRenderer((int) (byte) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot5.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(valueAxis20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLegendLabelGenerator();
        int int8 = ringPlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = textTitle17.getPaint();
        boolean boolean19 = textTitle17.getExpandToFitSpace();
        double double20 = textTitle17.getHeight();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot14.rendererChanged(rendererChangeEvent15);
        boolean boolean17 = xYPlot14.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot14.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot14.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot14);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle21.getBounds();
        try {
            jFreeChart7.draw(graphics2D8, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setOuterSeparatorExtension((double) 0.5f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = dateAxis56.getTickUnit();
        dateAxis56.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date60 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis56.setMaximumDate(date60);
        try {
            org.jfree.data.general.PieDataset pieDataset62 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, (java.lang.Comparable) date60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(date60);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier1);
        org.jfree.data.xy.XYDataset xYDataset3 = polarPlot0.getDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = polarPlot0.getRadiusGridlineStroke();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        double double11 = numberAxis3D10.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, xYItemRenderer13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot14.rendererChanged(rendererChangeEvent15);
        boolean boolean17 = xYPlot14.isRangeZoomable();
        java.awt.Image image18 = null;
        xYPlot14.setBackgroundImage(image18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot14);
        java.awt.geom.Point2D point2D21 = xYPlot14.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            polarPlot0.draw(graphics2D7, rectangle2D8, point2D21, plotState22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(point2D21);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int3 = java.awt.Color.HSBtoRGB((float) (-8355712), (float) 1L, (float) 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-131072) + "'", int3 == (-131072));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot54.getFixedLegendItems();
        boolean boolean59 = categoryPlot54.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Paint paint18 = textTitle17.getPaint();
        java.awt.Color color19 = java.awt.Color.magenta;
        textTitle17.setPaint((java.awt.Paint) color19);
        textTitle17.setExpandToFitSpace(false);
        textTitle17.setID("ThreadContext");
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        java.awt.Paint paint7 = numberAxis3D2.getLabelPaint();
        java.awt.Shape shape8 = numberAxis3D2.getLeftArrow();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D2.getPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis12.getTickUnit();
        dateAxis12.setFixedDimension((double) 0L);
        polarPlot11.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        polarPlot11.setDataset(xYDataset17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(dateTickUnit13);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        projectInfo0.setInfo("XY Plot");
        java.util.List list4 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str5 = ringPlot4.getPlotType();
        ringPlot4.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        ringPlot4.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke10 = ringPlot4.getLabelLinkStroke();
        org.jfree.chart.plot.Plot plot11 = ringPlot4.getRootPlot();
        boolean boolean12 = ringPlot4.isCircular();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 3, plotRenderingInfo14);
        double double16 = piePlotState15.getPieCenterY();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        piePlotState15.setPieArea(rectangle2D17);
        piePlotState15.setLatestAngle((double) (short) -1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(piePlotState15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) 0L, (double) (short) 100);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = new org.jfree.chart.LegendItemCollection();
        boolean boolean10 = legendItemCollection8.equals((java.lang.Object) 4.0d);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setRange((double) 0L, (double) (short) 100);
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis11.setMaximumDate(date15);
        boolean boolean17 = legendItemCollection8.equals((java.lang.Object) date15);
        dateAxis0.setMaximumDate(date15);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = dateAxis20.getTickUnit();
        dateAxis20.setLabel("ThreadContext");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis24.getTickUnit();
        dateAxis24.setLabelToolTip("RectangleEdge.LEFT");
        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis24.setMaximumDate(date28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date31 = dateAxis24.calculateLowestVisibleTickValue(dateTickUnit30);
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str33 = ringPlot32.getPlotType();
        float float34 = ringPlot32.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint37 = categoryAxis3D35.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot32.setBaseSectionOutlinePaint(paint37);
        java.awt.Paint paint39 = ringPlot32.getLabelPaint();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str43 = ringPlot42.getPlotType();
        float float44 = ringPlot42.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot32.initialise(graphics2D40, rectangle2D41, (org.jfree.chart.plot.PiePlot) ringPlot42, (java.lang.Integer) 0, plotRenderingInfo46);
        org.jfree.chart.entity.EntityCollection entityCollection48 = piePlotState47.getEntityCollection();
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        legendTitle50.setWidth((double) 100L);
        java.awt.Font font53 = legendTitle50.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D54 = legendTitle50.getBounds();
        piePlotState47.setLinkArea(rectangle2D54);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D57 = new org.jfree.chart.axis.NumberAxis3D();
        double double58 = numberAxis3D57.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D59 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis3D57, (org.jfree.chart.axis.ValueAxis) numberAxis3D59, xYItemRenderer60);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        xYPlot61.rendererChanged(rendererChangeEvent62);
        boolean boolean64 = xYPlot61.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot61.getRangeAxis();
        java.awt.Paint paint66 = xYPlot61.getDomainTickBandPaint();
        xYPlot61.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot61.setRenderer(0, xYItemRenderer70, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        ringPlot73.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent77 = null;
        ringPlot73.datasetChanged(datasetChangeEvent77);
        java.awt.Stroke stroke79 = ringPlot73.getLabelLinkStroke();
        xYPlot61.setRangeGridlineStroke(stroke79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot61.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
        double double85 = dateAxis20.dateToJava2D(date31, rectangle2D54, rectangleEdge84);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        try {
            double double87 = dateAxis0.java2DToValue((double) 10, rectangle2D54, rectangleEdge86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Pie Plot" + "'", str33.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Pie Plot" + "'", str43.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNull(entityCollection48);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(plotOrientation83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        multiplePiePlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        double double6 = multiplePiePlot0.getLimit();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        xYPlot5.setDomainAxis((int) 'a', valueAxis26);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(0.025d, (double) (-1.0f));
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        double double33 = numberAxis3D32.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, xYItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D();
        double double39 = numberAxis3D38.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) numberAxis3D38, (org.jfree.chart.axis.ValueAxis) numberAxis3D40, xYItemRenderer41);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = null;
        xYPlot42.rendererChanged(rendererChangeEvent43);
        boolean boolean45 = xYPlot42.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis46 = xYPlot42.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        xYPlot42.setFixedRangeAxisSpace(axisSpace47);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot42.getRangeAxisEdge((int) (short) 1);
        java.awt.Color color51 = java.awt.Color.black;
        int int52 = color51.getRGB();
        float[] floatArray58 = new float[] { (-1.0f), (short) 1, (-1.0f), (short) 0, 0.0f };
        float[] floatArray59 = color51.getRGBColorComponents(floatArray58);
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color51);
        xYPlot36.setBackgroundPaint((java.awt.Paint) color51);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        org.jfree.chart.plot.CrosshairState crosshairState66 = null;
        boolean boolean67 = xYPlot36.render(graphics2D62, rectangle2D63, (int) (short) -1, plotRenderingInfo65, crosshairState66);
        org.jfree.chart.plot.RingPlot ringPlot69 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str70 = ringPlot69.getPlotType();
        float float71 = ringPlot69.getBackgroundAlpha();
        java.awt.Color color72 = java.awt.Color.GRAY;
        int int73 = color72.getBlue();
        ringPlot69.setLabelPaint((java.awt.Paint) color72);
        xYPlot36.setQuadrantPaint(3, (java.awt.Paint) color72);
        java.awt.Font font77 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint78 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment80 = new org.jfree.chart.text.TextFragment("", font77, paint78, (float) (byte) 1);
        xYPlot36.setDomainGridlinePaint(paint78);
        java.awt.Stroke stroke82 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot36.setRangeZeroBaselineStroke(stroke82);
        boolean boolean84 = size2D30.equals((java.lang.Object) stroke82);
        xYPlot5.setRangeGridlineStroke(stroke82);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(valueAxis46);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-16777216) + "'", int52 == (-16777216));
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Pie Plot" + "'", str70.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float71 + "' != '" + 1.0f + "'", float71 == 1.0f);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 128 + "'", int73 == 128);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        java.awt.Image image2 = ringPlot0.getBackgroundImage();
        double double3 = ringPlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) '#', (double) 0.5f, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        int int2 = objectList1.size();
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, xYItemRenderer10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart12.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent16 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray4, jFreeChart12, (int) (byte) 100, 128);
        org.jfree.chart.JFreeChart jFreeChart17 = chartProgressEvent16.getChart();
        jFreeChart17.removeLegend();
        objectList1.set(1, (java.lang.Object) jFreeChart17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(jFreeChart17);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        java.awt.Color color3 = java.awt.Color.GRAY;
        int int4 = color3.getBlue();
        ringPlot0.setLabelPaint((java.awt.Paint) color3);
        boolean boolean6 = ringPlot0.isSubplot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelLinkStroke();
        java.lang.Object obj7 = null;
        boolean boolean8 = ringPlot0.equals(obj7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        ringPlot0.setLabelLinkStroke(stroke9);
        ringPlot0.setPieIndex(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18, numberArray23, numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset35, true);
        double double38 = range37.getLowerBound();
        double double39 = range37.getCentralValue();
        dateAxis1.setDefaultAutoRange(range37);
        boolean boolean41 = polarPlot0.equals((java.lang.Object) range37);
        polarPlot0.clearCornerTextItems();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 49.5d + "'", double39 == 49.5d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        xYPlot5.setRenderer((int) (short) 100, xYItemRenderer12, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        double double17 = numberAxis3D16.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYPlot20.rendererChanged(rendererChangeEvent21);
        boolean boolean23 = xYPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot20.getRangeAxis();
        java.awt.Paint paint25 = xYPlot20.getDomainTickBandPaint();
        xYPlot20.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot20.setRenderer(0, xYItemRenderer29, false);
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str33 = ringPlot32.getPlotType();
        ringPlot32.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        ringPlot32.datasetChanged(datasetChangeEvent36);
        java.awt.Stroke stroke38 = ringPlot32.getLabelLinkStroke();
        xYPlot20.setRangeGridlineStroke(stroke38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        xYPlot20.setRangeAxisLocation((int) ' ', axisLocation41);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        double double46 = numberAxis3D45.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, (org.jfree.chart.axis.ValueAxis) numberAxis3D47, xYItemRenderer48);
        xYPlot20.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D45);
        java.lang.String str51 = numberAxis3D45.getLabelURL();
        int int52 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D45);
        java.awt.Paint paint53 = xYPlot5.getDomainCrosshairPaint();
        xYPlot5.clearRangeMarkers(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Pie Plot" + "'", str33.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.025d, (double) (-1.0f));
        size2D2.height = 600.0d;
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.getToolTipText();
        java.lang.String str11 = pieSectionEntity9.getToolTipText();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie Plot" + "'", str11.equals("Pie Plot"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.util.Locale locale1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        boolean boolean11 = xYPlot7.isDomainZeroBaselineVisible();
        int int12 = xYPlot7.getDatasetCount();
        xYPlot7.setRangeCrosshairLockedOnData(false);
        int int15 = xYPlot7.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot7.getRangeAxisEdge();
        java.lang.String str17 = rectangleEdge16.toString();
        java.lang.Class<?> wildcardClass18 = rectangleEdge16.getClass();
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader19);
        java.util.ResourceBundle.Control control21 = null;
        try {
            java.util.ResourceBundle resourceBundle22 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", locale1, classLoader19, control21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.LEFT" + "'", str17.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(classLoader19);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Color color18 = java.awt.Color.orange;
        jFreeChart8.setBorderPaint((java.awt.Paint) color18);
        boolean boolean20 = jFreeChart8.getAntiAlias();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.025d, (double) (-1.0f));
        double double3 = size2D2.getHeight();
        double double4 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        boolean boolean11 = xYPlot7.isDomainZeroBaselineVisible();
        int int12 = xYPlot7.getDatasetCount();
        xYPlot7.setRangeCrosshairLockedOnData(false);
        int int15 = xYPlot7.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot7.getRangeAxisEdge();
        java.lang.String str17 = rectangleEdge16.toString();
        java.lang.Class<?> wildcardClass18 = rectangleEdge16.getClass();
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=255,g=255,b=64]", (java.lang.Class) wildcardClass18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ClassContext", (java.lang.Class) wildcardClass18);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.LEFT" + "'", str17.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(uRL19);
        org.junit.Assert.assertNull(inputStream20);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D3.setAxisLineVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str9 = ringPlot8.getPlotType();
        ringPlot8.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        ringPlot8.datasetChanged(datasetChangeEvent12);
        java.awt.Stroke stroke14 = ringPlot8.getLabelLinkStroke();
        java.awt.Paint paint15 = ringPlot8.getLabelShadowPaint();
        java.awt.Paint paint16 = ringPlot8.getSeparatorPaint();
        boolean boolean17 = ringPlot8.getIgnoreNullValues();
        boolean boolean18 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot8);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis3D3.setTickLabelFont(font19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie Plot" + "'", str9.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot5.getDataset();
        xYPlot5.clearDomainAxes();
        java.awt.Paint paint12 = xYPlot5.getRangeCrosshairPaint();
        xYPlot5.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        double double12 = xYPlot5.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot19.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot19.isRangeZoomable();
        java.awt.Image image23 = null;
        xYPlot19.setBackgroundImage(image23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot19);
        java.awt.geom.Point2D point2D26 = xYPlot19.getQuadrantOrigin();
        xYPlot19.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot19.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot19.getRangeAxisLocation((int) (short) -1);
        xYPlot5.setRangeAxisLocation(100, axisLocation30, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot5.getRangeAxisEdge((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) (-1.0f), (double) 0.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment17, verticalAlignment18, (double) (-1.0f), (double) 0.0f);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5, (org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.chart.block.Arrangement) flowArrangement21);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement21);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str26 = ringPlot25.getPlotType();
        float float27 = ringPlot25.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint30 = categoryAxis3D28.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot25.setBaseSectionOutlinePaint(paint30);
        java.awt.Paint paint32 = ringPlot25.getLabelPaint();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str36 = ringPlot35.getPlotType();
        float float37 = ringPlot35.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.plot.PiePlotState piePlotState40 = ringPlot25.initialise(graphics2D33, rectangle2D34, (org.jfree.chart.plot.PiePlot) ringPlot35, (java.lang.Integer) 0, plotRenderingInfo39);
        org.jfree.chart.entity.EntityCollection entityCollection41 = piePlotState40.getEntityCollection();
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        legendTitle43.setWidth((double) 100L);
        java.awt.Font font46 = legendTitle43.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle43.getBounds();
        piePlotState40.setLinkArea(rectangle2D47);
        try {
            blockContainer23.draw(graphics2D24, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pie Plot" + "'", str26.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Pie Plot" + "'", str36.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState40);
        org.junit.Assert.assertNull(entityCollection41);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(rectangle2D47);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint5 = categoryAxis3D3.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot0.setBaseSectionOutlinePaint(paint5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLegendLabelGenerator();
        ringPlot0.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot54.getFixedLegendItems();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        double double61 = numberAxis3D60.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, xYItemRenderer63);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent65 = null;
        xYPlot64.rendererChanged(rendererChangeEvent65);
        boolean boolean67 = xYPlot64.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot64.getRangeAxis();
        java.awt.Paint paint69 = xYPlot64.getDomainTickBandPaint();
        xYPlot64.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        xYPlot64.setRenderer(0, xYItemRenderer73, false);
        org.jfree.chart.plot.RingPlot ringPlot76 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str77 = ringPlot76.getPlotType();
        ringPlot76.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent80 = null;
        ringPlot76.datasetChanged(datasetChangeEvent80);
        java.awt.Stroke stroke82 = ringPlot76.getLabelLinkStroke();
        xYPlot64.setRangeGridlineStroke(stroke82);
        org.jfree.chart.axis.AxisLocation axisLocation85 = xYPlot64.getRangeAxisLocation((int) (short) 10);
        categoryPlot54.setDomainAxisLocation(axisLocation85);
        boolean boolean87 = categoryPlot54.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(legendItemCollection58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(valueAxis68);
        org.junit.Assert.assertNull(paint69);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Pie Plot" + "'", str77.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot6.getDatasetRenderingOrder();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, xYItemRenderer15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYPlot16.rendererChanged(rendererChangeEvent17);
        boolean boolean19 = xYPlot16.isRangeZoomable();
        java.awt.Image image20 = null;
        xYPlot16.setBackgroundImage(image20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot16);
        java.awt.geom.Point2D point2D23 = xYPlot16.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            xYPlot6.draw(graphics2D9, rectangle2D10, point2D23, plotState24, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(point2D23);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint39 = categoryAxis3D37.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        double double40 = categoryAxis3D37.getCategoryMargin();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = dateAxis41.getTickUnit();
        dateAxis41.setLabel("ThreadContext");
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = dateAxis46.getTickUnit();
        dateAxis45.setTickUnit(dateTickUnit47, true, true);
        java.util.Date date51 = dateAxis41.calculateHighestVisibleTickValue(dateTickUnit47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, (org.jfree.chart.axis.ValueAxis) dateAxis41, categoryItemRenderer52);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertNotNull(dateTickUnit42);
        org.junit.Assert.assertNotNull(dateTickUnit47);
        org.junit.Assert.assertNotNull(date51);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.awt.Paint paint36 = xYPlot5.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        xYPlot6.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot6.getDataset();
        boolean boolean11 = lineBorder0.equals((java.lang.Object) xYPlot6);
        java.awt.Stroke stroke12 = xYPlot6.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = xYPlot6.isRangeZoomable();
        boolean boolean10 = xYPlot6.isDomainZeroBaselineVisible();
        int int11 = xYPlot6.getDatasetCount();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        int int14 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot6.getRangeAxisEdge();
        java.lang.String str16 = rectangleEdge15.toString();
        java.lang.Class<?> wildcardClass17 = rectangleEdge15.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=255,g=255,b=64]", (java.lang.Class) wildcardClass17);
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass17);
        java.util.ResourceBundle.clearCache(classLoader19);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleEdge.LEFT" + "'", str16.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNotNull(classLoader19);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        boolean boolean11 = xYPlot7.isDomainZeroBaselineVisible();
        int int12 = xYPlot7.getDatasetCount();
        xYPlot7.setRangeCrosshairLockedOnData(false);
        int int15 = xYPlot7.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot7.getRangeAxisEdge();
        java.lang.String str17 = rectangleEdge16.toString();
        java.lang.Class<?> wildcardClass18 = rectangleEdge16.getClass();
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=255,g=255,b=64]", (java.lang.Class) wildcardClass18);
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ChartChangeEventType.NEW_DATASET", (java.lang.Class) wildcardClass18);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.LEFT" + "'", str17.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(uRL19);
        org.junit.Assert.assertNotNull(classLoader20);
        org.junit.Assert.assertNull(uRL21);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        double double58 = categoryPlot54.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot54.setFixedDomainAxisSpace(axisSpace59);
        org.jfree.chart.block.LineBorder lineBorder61 = new org.jfree.chart.block.LineBorder();
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D63 = new org.jfree.chart.axis.NumberAxis3D();
        double double64 = numberAxis3D63.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D65 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset62, (org.jfree.chart.axis.ValueAxis) numberAxis3D63, (org.jfree.chart.axis.ValueAxis) numberAxis3D65, xYItemRenderer66);
        xYPlot67.setRangeCrosshairValue((double) '4', true);
        org.jfree.data.xy.XYDataset xYDataset71 = xYPlot67.getDataset();
        boolean boolean72 = lineBorder61.equals((java.lang.Object) xYPlot67);
        java.awt.Stroke stroke73 = lineBorder61.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = lineBorder61.getInsets();
        java.awt.Paint paint75 = lineBorder61.getPaint();
        categoryPlot54.setRangeCrosshairPaint(paint75);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        try {
            categoryPlot54.setRenderer((int) (byte) -1, categoryItemRenderer78, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNull(xYDataset71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(paint75);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot5.getDataset();
        xYPlot5.clearDomainAxes();
        java.awt.Paint paint12 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke[] strokeArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        double double17 = numberAxis3D16.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = jFreeChart21.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent25 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray13, jFreeChart21, (int) (byte) 100, 128);
        java.awt.Paint paint26 = jFreeChart21.getBorderPaint();
        xYPlot5.setDomainZeroBaselinePaint(paint26);
        boolean boolean28 = xYPlot5.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18, numberArray23, numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset35, true);
        double double38 = range37.getLowerBound();
        double double39 = range37.getCentralValue();
        dateAxis1.setDefaultAutoRange(range37);
        boolean boolean41 = polarPlot0.equals((java.lang.Object) range37);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        polarPlot0.setDataset(xYDataset42);
        boolean boolean44 = polarPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 49.5d + "'", double39 == 49.5d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryStart((-1), (int) 'a', rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) 10);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 10);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 101.0d, font12);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot5.setRenderer(2, xYItemRenderer13);
        java.awt.Paint paint15 = xYPlot5.getOutlinePaint();
        java.awt.Paint paint16 = xYPlot5.getDomainTickBandPaint();
        double double17 = xYPlot5.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset33);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33);
        org.jfree.data.Range range40 = org.jfree.data.Range.shift(range37, 8.0d, false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range40);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.plot.RingPlot ringPlot58 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str59 = ringPlot58.getPlotType();
        float float60 = ringPlot58.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D61 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint63 = categoryAxis3D61.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot58.setBaseSectionOutlinePaint(paint63);
        java.awt.Paint paint65 = ringPlot58.getLabelPaint();
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.plot.RingPlot ringPlot68 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str69 = ringPlot68.getPlotType();
        float float70 = ringPlot68.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        org.jfree.chart.plot.PiePlotState piePlotState73 = ringPlot58.initialise(graphics2D66, rectangle2D67, (org.jfree.chart.plot.PiePlot) ringPlot68, (java.lang.Integer) 0, plotRenderingInfo72);
        org.jfree.chart.entity.EntityCollection entityCollection74 = piePlotState73.getEntityCollection();
        org.jfree.chart.LegendItemSource legendItemSource75 = null;
        org.jfree.chart.title.LegendTitle legendTitle76 = new org.jfree.chart.title.LegendTitle(legendItemSource75);
        legendTitle76.setWidth((double) 100L);
        java.awt.Font font79 = legendTitle76.getItemFont();
        java.awt.geom.Rectangle2D rectangle2D80 = legendTitle76.getBounds();
        piePlotState73.setLinkArea(rectangle2D80);
        try {
            categoryPlot54.drawBackground(graphics2D57, rectangle2D80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Pie Plot" + "'", str59.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 1.0f + "'", float60 == 1.0f);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Pie Plot" + "'", str69.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState73);
        org.junit.Assert.assertNull(entityCollection74);
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D3.setAxisLineVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str9 = ringPlot8.getPlotType();
        ringPlot8.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        ringPlot8.datasetChanged(datasetChangeEvent12);
        java.awt.Stroke stroke14 = ringPlot8.getLabelLinkStroke();
        java.awt.Paint paint15 = ringPlot8.getLabelShadowPaint();
        java.awt.Paint paint16 = ringPlot8.getSeparatorPaint();
        boolean boolean17 = ringPlot8.getIgnoreNullValues();
        boolean boolean18 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot8);
        double double19 = ringPlot8.getStartAngle();
        float float20 = ringPlot8.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie Plot" + "'", str9.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel((int) '4');
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset4, (java.lang.Comparable) "java.awt.Color[r=255,g=255,b=64]");
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean8 = standardPieSectionLabelGenerator0.equals((java.lang.Object) font7);
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("", font10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        boolean boolean13 = textTitle11.equals((java.lang.Object) textAnchor12);
        boolean boolean14 = standardPieSectionLabelGenerator0.equals((java.lang.Object) textAnchor12);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        double double12 = xYPlot5.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        double double16 = numberAxis3D15.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, xYItemRenderer18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot19.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot19.isRangeZoomable();
        java.awt.Image image23 = null;
        xYPlot19.setBackgroundImage(image23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot19);
        java.awt.geom.Point2D point2D26 = xYPlot19.getQuadrantOrigin();
        xYPlot19.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot19.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot19.getRangeAxisLocation((int) (short) -1);
        xYPlot5.setRangeAxisLocation(100, axisLocation30, false);
        int int33 = xYPlot5.getWeight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot8.rendererChanged(rendererChangeEvent9);
        boolean boolean11 = xYPlot8.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot8.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot8.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint17 = xYPlot8.getRangeTickBandPaint();
        java.awt.Paint paint18 = xYPlot8.getDomainZeroBaselinePaint();
        java.awt.Paint paint19 = xYPlot8.getRangeGridlinePaint();
        boolean boolean20 = textAnchor2.equals((java.lang.Object) paint19);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D(pieDataset35);
        double double37 = piePlot3D36.getDepthFactor();
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle39.setVerticalAlignment(verticalAlignment40);
        boolean boolean42 = piePlot3D36.equals((java.lang.Object) verticalAlignment40);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.12d + "'", double37 == 0.12d);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis3D1.setPlot(plot2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        int int13 = xYPlot5.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot5.getRangeAxisEdge();
        java.lang.String str15 = rectangleEdge14.toString();
        java.lang.Class<?> wildcardClass16 = rectangleEdge14.getClass();
        java.lang.ClassLoader classLoader17 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass16);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader17);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.LEFT" + "'", str15.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(classLoader17);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D1.setPositiveArrowVisible(false);
        numberAxis3D1.setAutoRangeIncludesZero(true);
        try {
            numberAxis3D1.setAutoRangeMinimumSize((double) 0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        xYPlot5.setRangeCrosshairValue(1.05d, true);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        double double14 = numberAxis3D13.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYItemRenderer16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYPlot17.rendererChanged(rendererChangeEvent18);
        boolean boolean20 = xYPlot17.isRangeZoomable();
        java.awt.Image image21 = null;
        xYPlot17.setBackgroundImage(image21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot17);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        xYPlot5.setQuadrantOrigin(point2D24);
        xYPlot5.mapDatasetToRangeAxis(0, 3);
        xYPlot5.clearAnnotations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        java.awt.Paint paint7 = numberAxis3D2.getLabelPaint();
        java.awt.Shape shape8 = numberAxis3D2.getLeftArrow();
        org.jfree.chart.plot.Plot plot9 = numberAxis3D2.getPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("RectangleEdge.LEFT");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        polarPlot11.rendererChanged(rendererChangeEvent14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17, numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset34, true);
        double double37 = range36.getLowerBound();
        double double38 = range36.getCentralValue();
        dateAxis0.setDefaultAutoRange(range36);
        org.jfree.data.Range range42 = org.jfree.data.Range.expand(range36, (double) 'a', (double) (short) 0);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 49.5d + "'", double38 == 49.5d);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        float float2 = ringPlot0.getBackgroundAlpha();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ringPlot0);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot0.markerChanged(markerChangeEvent5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        org.jfree.chart.block.BlockFrame blockFrame4 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle17.draw(graphics2D18, rectangle2D19);
        java.awt.Paint paint21 = textTitle17.getBackgroundPaint();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        textTitle17.draw(graphics2D22, rectangle2D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = textTitle17.getPosition();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getBlue();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font4, (java.awt.Paint) color5);
        float[] floatArray7 = null;
        float[] floatArray8 = color5.getRGBComponents(floatArray7);
        try {
            float[] floatArray9 = color0.getComponents(colorSpace2, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        double double31 = numberAxis3D30.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, xYItemRenderer33);
        xYPlot5.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        numberAxis3D30.configure();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D30.setTickUnit(numberTickUnit37, true, true);
        numberAxis3D30.setTickMarkInsideLength((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit37);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle17.draw(graphics2D18, rectangle2D19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle17.getVerticalAlignment();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(verticalAlignment21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("RectangleEdge.LEFT", font2, (java.awt.Paint) color3);
        ringPlot0.setLabelFont(font2);
        ringPlot0.setIgnoreNullValues(true);
        ringPlot0.setLabelGap(90.0d);
        ringPlot0.setNoDataMessage("0,0,-2,-2,-2,2,-2,2");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle1.getMargin();
        double double7 = rectangleInsets5.trimWidth(600.0d);
        double double9 = rectangleInsets5.calculateBottomOutset(4.0d);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 600.0d + "'", double7 == 600.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        xYPlot5.setRangeCrosshairValue((double) '4', true);
        java.awt.geom.Point2D point2D9 = xYPlot5.getQuadrantOrigin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(point2D9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        xYPlot5.setDomainAxis((int) 'a', valueAxis26);
        java.awt.Color color28 = java.awt.Color.black;
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color28);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder();
        boolean boolean32 = plotOrientation30.equals((java.lang.Object) lineBorder31);
        java.awt.Stroke stroke33 = lineBorder31.getStroke();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        double double36 = numberAxis3D35.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer38);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        double double43 = numberAxis3D42.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, xYItemRenderer45);
        java.awt.Paint paint47 = numberAxis3D42.getLabelPaint();
        numberAxis3D42.setLabelToolTip("");
        xYPlot39.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, true);
        numberAxis3D42.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = numberAxis3D42.getLabelInsets();
        org.jfree.chart.block.LineBorder lineBorder55 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color28, stroke33, rectangleInsets54);
        java.awt.Stroke stroke56 = lineBorder55.getStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getPlotType();
        ringPlot0.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = ringPlot0.getLabelOutlineStroke();
        boolean boolean7 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie Plot" + "'", str1.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textBlock0.calculateDimensions(graphics2D3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock0.draw(graphics2D5, (float) (short) 1, 10.0f, textBlockAnchor8, (float) (byte) 0, (float) (short) 0, 101.0d);
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        int int13 = chartProgressEvent12.getType();
        int int14 = chartProgressEvent12.getPercent();
        org.jfree.chart.JFreeChart jFreeChart15 = chartProgressEvent12.getChart();
        int int16 = chartProgressEvent12.getType();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2, waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = waferMapPlot4.getDataset();
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        waferMapPlot4.setDataset(waferMapDataset6);
        boolean boolean8 = standardPieSectionLabelGenerator0.equals((java.lang.Object) waferMapPlot4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(waferMapDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        int int10 = pieSectionEntity9.getPieIndex();
        pieSectionEntity9.setURLText("java.awt.Color[r=255,g=255,b=64]");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint14 = xYPlot5.getRangeTickBandPaint();
        float float15 = xYPlot5.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot5.getDomainAxisForDataset(0);
        valueAxis17.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(valueAxis17);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getFixedAutoRange();
        java.awt.Shape shape2 = numberAxis3D0.getRightArrow();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) (byte) 10, (-16777216), (java.lang.Comparable) dateTickUnit6, "Pie Plot", "Pie Plot");
        java.lang.String str10 = pieSectionEntity9.getToolTipText();
        int int11 = pieSectionEntity9.getPieIndex();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        double double13 = numberAxis3D12.getFixedAutoRange();
        java.awt.Shape shape14 = numberAxis3D12.getRightArrow();
        pieSectionEntity9.setArea(shape14);
        java.lang.Object obj16 = pieSectionEntity9.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        polarPlot0.setDrawingSupplier(drawingSupplier1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        double double5 = numberAxis3D4.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, xYItemRenderer7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot8.rendererChanged(rendererChangeEvent9);
        boolean boolean11 = xYPlot8.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot8.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot8.getRangeAxisEdge((int) (short) 1);
        xYPlot8.setDomainCrosshairValue((double) 2);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelOutlineStroke();
        xYPlot8.setRangeCrosshairStroke(stroke25);
        polarPlot0.setAngleGridlineStroke(stroke25);
        boolean boolean28 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        polarPlot0.zoomDomainAxes(10.0d, (double) 10.0f, plotRenderingInfo31, point2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        double double36 = numberAxis3D35.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer38);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        xYPlot39.rendererChanged(rendererChangeEvent40);
        boolean boolean42 = xYPlot39.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot39.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        xYPlot39.setFixedRangeAxisSpace(axisSpace44);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot39.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint48 = xYPlot39.getRangeTickBandPaint();
        java.awt.Paint paint49 = xYPlot39.getDomainZeroBaselinePaint();
        java.awt.Paint paint50 = xYPlot39.getRangeGridlinePaint();
        polarPlot0.setRadiusGridlinePaint(paint50);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(valueAxis43);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 100L);
        java.awt.Font font4 = legendTitle1.getItemFont();
        legendTitle1.setWidth((double) 0.0f);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.title.Title title8 = titleChangeEvent7.getTitle();
        java.lang.String str9 = titleChangeEvent7.toString();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(title8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        java.awt.Paint paint10 = xYPlot5.getDomainTickBandPaint();
        xYPlot5.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot5.setRenderer(0, xYItemRenderer14, false);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str18 = ringPlot17.getPlotType();
        ringPlot17.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        ringPlot17.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = ringPlot17.getLabelLinkStroke();
        xYPlot5.setRangeGridlineStroke(stroke23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot5.setRangeAxisLocation((int) ' ', axisLocation26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot5.getRendererForDataset(xYDataset28);
        boolean boolean30 = xYPlot5.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pie Plot" + "'", str18.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint57 = categoryAxis3D55.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        float float58 = categoryAxis3D55.getTickMarkInsideLength();
        java.util.List list59 = categoryPlot54.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D55);
        categoryPlot54.zoom(100.0d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.0f + "'", float58 == 0.0f);
        org.junit.Assert.assertNotNull(list59);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot5.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot5);
        double double13 = legendTitle12.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle12.getItemLabelPadding();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.Object obj0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = xYPlot6.isRangeZoomable();
        java.awt.Image image10 = null;
        xYPlot6.setBackgroundImage(image10);
        java.lang.String str12 = xYPlot6.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot6);
        jFreeChart13.setBorderVisible(true);
        org.jfree.chart.plot.Plot plot16 = jFreeChart13.getPlot();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "XY Plot" + "'", str12.equals("XY Plot"));
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        int int13 = chartProgressEvent12.getType();
        int int14 = chartProgressEvent12.getPercent();
        org.jfree.chart.JFreeChart jFreeChart15 = chartProgressEvent12.getChart();
        java.lang.Object obj16 = chartProgressEvent12.getSource();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.plot.Plot plot12 = null;
        xYPlot5.setParent(plot12);
        java.awt.Stroke stroke14 = xYPlot5.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        double double17 = numberAxis3D16.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, xYItemRenderer19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYPlot20.rendererChanged(rendererChangeEvent21);
        boolean boolean23 = xYPlot20.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot20.getRangeAxis();
        java.awt.Paint paint25 = xYPlot20.getDomainTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = xYPlot20.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace27, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot20.setRenderer((int) 'a', xYItemRenderer31, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder34 = xYPlot20.getDatasetRenderingOrder();
        xYPlot5.setDatasetRenderingOrder(datasetRenderingOrder34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(datasetRenderingOrder34);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray12, numberArray17, numberArray22, numberArray27, numberArray32, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, true);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        double double44 = numberAxis3D43.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, xYItemRenderer46);
        org.jfree.data.Range range48 = numberAxis3D43.getDefaultAutoRange();
        org.jfree.data.Range range49 = org.jfree.data.Range.combine(range41, range48);
        numberAxis3D1.setRangeWithMargins(range49, true, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        ringPlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator2);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("Pie Plot");
        java.awt.Paint paint6 = textFragment5.getPaint();
        ringPlot1.setBaseSectionPaint(paint6);
        polarPlot0.setRadiusGridlinePaint(paint6);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str13 = ringPlot12.getPlotType();
        ringPlot12.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        ringPlot12.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = ringPlot12.getLabelOutlineStroke();
        xYPlot5.setRangeGridlineStroke(stroke18);
        xYPlot5.clearDomainMarkers((int) (byte) 100);
        java.awt.Stroke stroke22 = xYPlot5.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot7.getRangeAxis();
        java.awt.Paint paint12 = xYPlot7.getDomainTickBandPaint();
        xYPlot7.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot7.setRenderer(0, xYItemRenderer16, false);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelLinkStroke();
        xYPlot7.setRangeGridlineStroke(stroke25);
        valueMarker1.setStroke(stroke25);
        java.awt.Paint paint28 = valueMarker1.getOutlinePaint();
        java.awt.Stroke stroke29 = valueMarker1.getStroke();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        numberAxis3D44.setLabelToolTip("hi!");
        numberAxis3D44.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("LengthConstraintType.FIXED", "ChartChangeEventType.NEW_DATASET", "", image3, "RectangleConstraint[LengthConstraintType.FIXED: width=600.0, height=4.0]", "", "{0}");
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        double double3 = numberAxis3D2.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, xYItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot6.rendererChanged(rendererChangeEvent7);
        boolean boolean9 = xYPlot6.isRangeZoomable();
        boolean boolean10 = xYPlot6.isDomainZeroBaselineVisible();
        int int11 = xYPlot6.getDatasetCount();
        xYPlot6.setRangeCrosshairLockedOnData(false);
        int int14 = xYPlot6.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot6.getRangeAxisEdge();
        boolean boolean16 = objectList0.equals((java.lang.Object) xYPlot6);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        double double19 = numberAxis3D18.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, xYItemRenderer21);
        numberAxis3D20.setAxisLineVisible(false);
        boolean boolean25 = numberAxis3D20.isVerticalTickLabels();
        int int26 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D20);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) (short) 1);
        java.awt.Paint paint14 = xYPlot5.getRangeTickBandPaint();
        java.awt.Image image15 = xYPlot5.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) xYPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) strokeArray0, jFreeChart8, (int) (byte) 100, 128);
        jFreeChart8.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart8.addProgressListener(chartProgressListener15);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        textTitle17.draw(graphics2D18, rectangle2D19);
        java.awt.Font font21 = textTitle17.getFont();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) font21);
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        multiplePiePlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        double double6 = multiplePiePlot0.getLimit();
        java.lang.String str7 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Multiple Pie Plot" + "'", str7.equals("Multiple Pie Plot"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        int int10 = xYPlot5.getDatasetCount();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        xYPlot5.setDomainCrosshairValue(0.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        int int16 = xYPlot5.getIndexOf(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        paintMap0.put((java.lang.Comparable) (-8355712), (java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(4.0d, (-1.0d));
        size2D2.height = 1.05d;
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = numberAxis3D0.getTickUnit();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18, numberArray23, numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset35, true);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        double double40 = numberAxis3D39.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, xYItemRenderer42);
        org.jfree.data.Range range44 = numberAxis3D39.getDefaultAutoRange();
        org.jfree.data.Range range45 = org.jfree.data.Range.combine(range37, range44);
        numberAxis3D0.setRangeWithMargins(range37, true, false);
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18, numberArray23, numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset35, true);
        double double38 = range37.getLowerBound();
        double double39 = range37.getCentralValue();
        dateAxis1.setDefaultAutoRange(range37);
        boolean boolean41 = polarPlot0.equals((java.lang.Object) range37);
        boolean boolean42 = polarPlot0.isRangeZoomable();
        polarPlot0.clearCornerTextItems();
        polarPlot0.addCornerTextItem("java.awt.Color[r=0,g=128,b=128]");
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 49.5d + "'", double39 == 49.5d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray55 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot54.setRenderers(categoryItemRendererArray55);
        java.awt.Stroke stroke57 = categoryPlot54.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot54.getRangeAxisEdge();
        java.awt.Stroke stroke59 = categoryPlot54.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(categoryItemRendererArray55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.025d, (double) (-1.0f));
        size2D2.width = (-1.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D1.setPositiveArrowVisible(false);
        double double8 = numberAxis3D1.getUpperBound();
        numberAxis3D1.configure();
        org.jfree.data.RangeType rangeType10 = null;
        try {
            numberAxis3D1.setRangeType(rangeType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.05d + "'", double8 == 1.05d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        java.awt.Image image9 = null;
        xYPlot5.setBackgroundImage(image9);
        java.lang.String str11 = xYPlot5.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        jFreeChart12.setBorderPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str3 = ringPlot2.getPlotType();
        float float4 = ringPlot2.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint7 = categoryAxis3D5.getTickLabelPaint((java.lang.Comparable) (byte) 1);
        ringPlot2.setBaseSectionOutlinePaint(paint7);
        java.awt.Paint paint9 = ringPlot2.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("PieSection: 10, -16777216(DateTickUnit[DAY, 1])", font1, (org.jfree.chart.plot.Plot) ringPlot2, false);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        legendTitle13.setWidth((double) 100L);
        java.awt.Font font16 = legendTitle13.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle13.setLegendItemGraphicLocation(rectangleAnchor17);
        jFreeChart11.addLegend(legendTitle13);
        jFreeChart11.setBorderVisible(true);
        java.util.List list22 = jFreeChart11.getSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 500, range1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        numberAxis3D3.setAxisLineVisible(false);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str9 = ringPlot8.getPlotType();
        ringPlot8.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        ringPlot8.datasetChanged(datasetChangeEvent12);
        java.awt.Stroke stroke14 = ringPlot8.getLabelLinkStroke();
        java.awt.Paint paint15 = ringPlot8.getLabelShadowPaint();
        java.awt.Paint paint16 = ringPlot8.getSeparatorPaint();
        boolean boolean17 = ringPlot8.getIgnoreNullValues();
        boolean boolean18 = numberAxis3D3.hasListener((java.util.EventListener) ringPlot8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = null;
        ringPlot8.setLegendLabelURLGenerator(pieURLGenerator19);
        double double21 = ringPlot8.getStartAngle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie Plot" + "'", str9.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 97.0d + "'", double21 == 97.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) (short) 100, 1, rectangle2D39, rectangleEdge40);
        java.lang.String str42 = categoryAxis3D36.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D();
        double double45 = numberAxis3D44.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis3D46, xYItemRenderer47);
        numberAxis3D44.setPositiveArrowVisible(false);
        numberAxis3D44.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis3D44, categoryItemRenderer53);
        categoryPlot54.zoom((double) (-1));
        boolean boolean57 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        double double61 = numberAxis3D60.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, xYItemRenderer63);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent65 = null;
        xYPlot64.rendererChanged(rendererChangeEvent65);
        boolean boolean67 = xYPlot64.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot64.getRangeAxis();
        valueAxis68.centerRange((double) '#');
        categoryPlot54.setRangeAxis(0, valueAxis68, false);
        org.jfree.chart.plot.RingPlot ringPlot73 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str74 = ringPlot73.getPlotType();
        float float75 = ringPlot73.getBackgroundAlpha();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent76 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ringPlot73);
        java.awt.Stroke stroke77 = ringPlot73.getSeparatorStroke();
        categoryPlot54.setRangeGridlineStroke(stroke77);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = categoryPlot54.getDomainAxisEdge((int) (short) -1);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(valueAxis68);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Pie Plot" + "'", str74.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 1.0f + "'", float75 == 1.0f);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleEdge80);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textLine1.draw(graphics2D2, (float) (byte) 10, (float) (byte) 1, textAnchor5, 0.0f, (-1.0f), (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        dateAxis0.setLabel("ThreadContext");
        dateAxis0.centerRange((double) 3);
        org.junit.Assert.assertNotNull(dateTickUnit1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 0.8f, 2.0d, (double) 500);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        double double4 = numberAxis3D3.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot7.rendererChanged(rendererChangeEvent8);
        boolean boolean10 = xYPlot7.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot7.getRangeAxis();
        java.awt.Paint paint12 = xYPlot7.getDomainTickBandPaint();
        xYPlot7.setDomainCrosshairValue((double) 10.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot7.setRenderer(0, xYItemRenderer16, false);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str20 = ringPlot19.getPlotType();
        ringPlot19.setStartAngle((double) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot19.datasetChanged(datasetChangeEvent23);
        java.awt.Stroke stroke25 = ringPlot19.getLabelLinkStroke();
        xYPlot7.setRangeGridlineStroke(stroke25);
        valueMarker1.setStroke(stroke25);
        org.jfree.data.Range range28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range28, (double) (-1.0f));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint30.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint30.toUnconstrainedHeight();
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 0.0f, 100, (-1.0f), (-1.0d) };
        java.lang.Number[][] numberArray65 = new java.lang.Number[][] { numberArray39, numberArray44, numberArray49, numberArray54, numberArray59, numberArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray65);
        org.jfree.data.Range range68 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset66, true);
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D();
        double double71 = numberAxis3D70.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D72 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset69, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, (org.jfree.chart.axis.ValueAxis) numberAxis3D72, xYItemRenderer73);
        org.jfree.data.Range range75 = numberAxis3D70.getDefaultAutoRange();
        org.jfree.data.Range range76 = org.jfree.data.Range.combine(range68, range75);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = rectangleConstraint30.toRangeWidth(range68);
        boolean boolean78 = valueMarker1.equals((java.lang.Object) range68);
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxis11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleInsets79);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        double double2 = numberAxis3D1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, xYItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot5.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10);
        xYPlot5.setDomainCrosshairValue((double) (byte) 1);
        java.awt.Paint paint14 = xYPlot5.getOutlinePaint();
        xYPlot5.setDomainCrosshairLockedOnData(false);
        java.lang.Object obj17 = xYPlot5.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj17);
    }
}

