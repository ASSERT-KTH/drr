import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1558033199999L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1558033199999L + "'", long3 == 1558033199999L);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test2");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        java.lang.String str2 = timeSeries1.getRangeDescription();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setMaximumItemAge(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        boolean boolean10 = month8.equals((java.lang.Object) (byte) 10);
        java.lang.String str11 = month8.toString();
        long long12 = month8.getFirstMillisecond();
        int int14 = month8.compareTo((java.lang.Object) ' ');
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean17 = month15.equals((java.lang.Object) (byte) 10);
        java.lang.String str18 = month15.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 1.0f);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day20, (double) 1560184016008L, false);
        boolean boolean26 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

//    @Test
//    public void test3() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test3");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        java.lang.String str2 = timeSeries1.getRangeDescription();
//        java.lang.String str3 = timeSeries1.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
//        timeSeries1.removeAgedItems((long) 11, false);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        java.lang.String str11 = timeSeries10.getRangeDescription();
//        java.lang.String str12 = timeSeries10.getDomainDescription();
//        timeSeries10.setMaximumItemCount(2019);
//        timeSeries10.setNotify(false);
//        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.Number number19 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getSerialIndex();
//        boolean boolean22 = day18.equals((java.lang.Object) long21);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        java.lang.String str25 = timeSeries24.getRangeDescription();
//        java.lang.String str26 = timeSeries24.getDomainDescription();
//        timeSeries24.setMaximumItemCount(2019);
//        timeSeries24.setNotify(false);
//        java.lang.String str31 = timeSeries24.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries24);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
//        double double35 = timeSeries34.getMaxY();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) 10);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries24.addAndOrUpdate(timeSeries34);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        java.lang.String str42 = timeSeries41.getRangeDescription();
//        java.lang.String str43 = timeSeries41.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries41.removePropertyChangeListener(propertyChangeListener44);
//        timeSeries41.removeAgedItems((long) 11, false);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        java.lang.String str51 = timeSeries50.getRangeDescription();
//        java.lang.String str52 = timeSeries50.getDomainDescription();
//        timeSeries50.setMaximumItemCount(2019);
//        timeSeries50.setNotify(false);
//        java.util.Collection collection57 = timeSeries41.getTimePeriodsUniqueToOtherSeries(timeSeries50);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(1, (int) (short) 0);
//        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) month62, (java.lang.Number) 1.0d, false);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(1, (int) (short) 0);
//        int int69 = month68.getYearValue();
//        java.lang.Number number70 = timeSeries59.getValue((org.jfree.data.time.RegularTimePeriod) month68);
//        org.jfree.data.time.Year year71 = month68.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year71.next();
//        java.lang.Number number73 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) year71);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) year71);
//        int int75 = day18.compareTo((java.lang.Object) timeSeries24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day18.previous();
//        org.jfree.data.time.SerialDate serialDate77 = day18.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184083037L + "'", long21 == 1560184083037L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Value" + "'", str42.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Time" + "'", str43.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Value" + "'", str51.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 1.0d + "'", number70.equals(1.0d));
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNull(number73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(serialDate77);
//    }
//}

