import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0.0f, (java.lang.Object) (-1L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, (int) (byte) 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            timeSeries10.delete(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries10.getTimePeriod(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) '4', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        try {
            timeSeries10.update(0, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.previous();
        timeSeries10.add(regularTimePeriod20, (java.lang.Number) 1.0d);
        try {
            java.lang.Number number24 = timeSeries10.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.previous();
        timeSeries10.add(regularTimePeriod20, (java.lang.Number) 1.0d);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries10.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.util.Collection collection25 = timeSeries24.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean19 = timeSeries10.equals((java.lang.Object) (byte) 100);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries10.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year14.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries10.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "February" + "'", str2.equals("February"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        try {
            timeSeries23.update((int) '4', (java.lang.Number) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ClassContext");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class1);
        java.lang.Comparable comparable3 = null;
        try {
            timeSeries2.setKey(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate7.getDescription();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, (java.lang.Class) wildcardClass26);
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date29, timeZone30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 0, (java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        try {
            java.lang.Number number18 = timeSeries10.getValue(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year42.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.previous();
        java.lang.Class<?> wildcardClass47 = year42.getClass();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year42, (double) 7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeries10.getTimePeriod((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setMaximumItemAge((long) (short) 1);
        timeSeries10.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = timeSeries10.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        timeSeriesDataItem2.setValue((java.lang.Number) (short) 10);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        try {
            java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) fixedMillisecond1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2958465);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        try {
            timeSeries10.delete(2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate2.getFollowingDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 9999, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("February");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.previous();
        java.lang.Class<?> wildcardClass30 = year25.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.next();
        long long35 = fixedMillisecond33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond33.getMiddleMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) (-1));
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year43.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year43.previous();
        java.lang.Class<?> wildcardClass48 = year43.getClass();
        java.net.URL uRL49 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass48);
        int int50 = timeSeriesDataItem41.compareTo((java.lang.Object) wildcardClass48);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(uRL49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries10.getMaximumItemCount();
        boolean boolean19 = timeSeries10.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        try {
            timeSeries10.update(8, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries10.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        java.util.List list31 = timeSeries10.getItems();
        try {
            java.util.Collection collection32 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list31);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.lang.String str16 = timeSeries10.getDescription();
        try {
            timeSeries10.delete((int) (short) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeries timeSeries42 = null;
        try {
            java.util.Collection collection43 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("February");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries10.getDomainDescription();
        java.lang.Comparable comparable26 = timeSeries10.getKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str25.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertNotNull(comparable26);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        int int69 = year68.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year68.previous();
        try {
            timeSeries10.add(regularTimePeriod70, (java.lang.Number) 12, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2018 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 0);
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year19, (-1.0d), false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(inputStream13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean19 = timeSeries10.equals((java.lang.Object) (byte) 100);
        java.lang.Object obj20 = timeSeries10.clone();
        try {
            timeSeries10.update(0, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        try {
            java.lang.Number number12 = timeSeries10.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        try {
            java.lang.Number number12 = timeSeries10.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, (int) '#', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean19 = timeSeries10.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        java.lang.Class<?> wildcardClass29 = year24.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year20, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass29);
        timeSeries30.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int35 = year34.getYear();
        timeSeries30.setKey((java.lang.Comparable) year34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year41, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year41.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year41.previous();
        java.lang.Class<?> wildcardClass46 = year41.getClass();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number50 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        timeSeries47.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year53, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year53.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year53.previous();
        timeSeries47.add(regularTimePeriod57, (java.lang.Number) 1.0d);
        timeSeries30.add(regularTimePeriod57, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year62, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year62.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year62.previous();
        java.lang.Class<?> wildcardClass67 = year62.getClass();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) year62, (double) 7);
        long long70 = year62.getSerialIndex();
        long long71 = year62.getSerialIndex();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year62, (double) 52L, false);
        timeSeries10.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(number50);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2019L + "'", long71 == 2019L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        java.util.Calendar calendar13 = null;
        try {
            day11.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.setDescription("17-May-1927");
        try {
            timeSeries10.update(12, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries10.getDomainDescription();
        java.util.Collection collection26 = timeSeries10.getTimePeriods();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = year27.getYear();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year31.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
        java.lang.Class<?> wildcardClass36 = year31.getClass();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year27, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond39.next();
        long long41 = fixedMillisecond39.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 100);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond39.getMiddleMillisecond(calendar44);
        long long46 = fixedMillisecond39.getLastMillisecond();
        long long47 = fixedMillisecond39.getSerialIndex();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 10L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str25.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) 1L);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        boolean boolean9 = timeSeriesDataItem2.equals((java.lang.Object) serialDate7);
        java.lang.Object obj10 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) -1, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(classLoader6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        java.lang.Object obj60 = timeSeries10.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(obj60);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-May-1927", (java.lang.Class) wildcardClass11);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("June 2019", class14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(inputStream15);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.previous();
        java.lang.Class<?> wildcardClass30 = year25.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.next();
        long long35 = fixedMillisecond33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond33.getMiddleMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) (-1));
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener42);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, 1900, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year42.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.previous();
        java.lang.Class<?> wildcardClass47 = year42.getClass();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year42, (double) 7);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener50);
        java.lang.Class<?> wildcardClass52 = timeSeries10.getClass();
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(class53);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        java.lang.Class<?> wildcardClass14 = year9.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass14);
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-May-1927", (java.lang.Class) wildcardClass14);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.previous();
        java.lang.Class<?> wildcardClass23 = year18.getClass();
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", class17, (java.lang.Class) wildcardClass23);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass23);
        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass23);
        java.net.URL uRL27 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass23);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(inputStream16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(uRL27);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        long long32 = year30.getLastMillisecond();
        try {
            timeSeries10.update((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day11.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("31-May-1927");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2958465, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        int int4 = timeSeriesDataItem2.compareTo((java.lang.Object) 52L);
        timeSeriesDataItem2.setValue((java.lang.Number) 3);
        java.lang.Object obj7 = timeSeriesDataItem2.clone();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.previous();
        java.lang.Class<?> wildcardClass17 = year12.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year8, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass17);
        timeSeries18.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        timeSeries18.setKey((java.lang.Comparable) year22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.previous();
        java.lang.Class<?> wildcardClass34 = year29.getClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number38 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        timeSeries35.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year41, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year41.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year41.previous();
        timeSeries35.add(regularTimePeriod45, (java.lang.Number) 1.0d);
        timeSeries18.add(regularTimePeriod45, (java.lang.Number) (-1.0f));
        timeSeries18.setDomainDescription("");
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate57);
        java.lang.String str59 = serialDate57.toString();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate62);
        org.jfree.data.time.SerialDate serialDate64 = serialDate57.getEndOfCurrentMonth(serialDate62);
        java.lang.String str65 = serialDate57.getDescription();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(serialDate57);
        int int67 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day66);
        int int68 = timeSeriesDataItem2.compareTo((java.lang.Object) timeSeries18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "17-May-1927" + "'", str59.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("17-May-1927");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.lang.String str16 = timeSeries10.getDescription();
        timeSeries10.removeAgedItems(false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNotNull(classLoader0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.previous();
        java.lang.Class<?> wildcardClass30 = year25.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass30);
        timeSeries31.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        int int36 = year35.getYear();
        timeSeries31.setKey((java.lang.Comparable) year35);
        long long38 = year35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year35, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        java.lang.Class<?> wildcardClass60 = timeSeries10.getClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(wildcardClass60);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate4);
        java.lang.String str6 = serialDate4.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate4.getEndOfCurrentMonth(serialDate9);
        java.lang.String str12 = serialDate11.toString();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) '4', serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(2147483647, serialDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "17-May-1927" + "'", str6.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-May-1927" + "'", str12.equals("31-May-1927"));
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.previous();
        java.lang.Class<?> wildcardClass7 = year2.getClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(uRL8);
        org.junit.Assert.assertNotNull(inputStream9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9999L + "'", long3 == 9999L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = year3.getYear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.previous();
        java.lang.Class<?> wildcardClass12 = year7.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year3, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass12);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-May-1927", (java.lang.Class) wildcardClass12);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.previous();
        java.lang.Class<?> wildcardClass21 = year16.getClass();
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", class15, (java.lang.Class) wildcardClass21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertNotNull(uRL24);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 0);
        boolean boolean5 = timeSeriesDataItem3.equals((java.lang.Object) 1L);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("31-May-1927");
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeries23.equals(obj25);
        java.lang.Object obj27 = timeSeries23.clone();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 0);
        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) 1L);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate38);
        boolean boolean40 = timeSeriesDataItem33.equals((java.lang.Object) serialDate38);
        timeSeries10.setKey((java.lang.Comparable) serialDate38);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(uRL7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year28.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year28.previous();
        java.lang.Class<?> wildcardClass33 = year28.getClass();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass33);
        timeSeries34.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        int int39 = year38.getYear();
        timeSeries34.setKey((java.lang.Comparable) year38);
        long long41 = year38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.getDataItem(regularTimePeriod45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate7.getFollowingDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2147483647, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        boolean boolean68 = timeSeries65.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year73, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year73.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year73.previous();
        java.lang.Class<?> wildcardClass78 = year73.getClass();
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass78);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number82 = timeSeries79.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        java.lang.Number number83 = timeSeries65.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        java.lang.String str84 = timeSeries65.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(number82);
        org.junit.Assert.assertNull(number83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "hi!" + "'", str84.equals("hi!"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        java.lang.String str8 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year1.previous();
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(1900, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.previous();
        java.lang.Class<?> wildcardClass20 = year15.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year11, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.next();
        long long25 = fixedMillisecond23.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 100);
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, (java.lang.Class) wildcardClass26);
        java.util.Calendar calendar29 = null;
        try {
            year14.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        serialDate9.setDescription("17-May-1927");
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        int int4 = year0.getYear();
        int int5 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timeSeries10.getNotify();
        java.lang.Class class19 = timeSeries10.getTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        java.lang.String str11 = serialDate3.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        long long5 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        int int14 = timeSeries10.getItemCount();
        timeSeries10.setMaximumItemAge(0L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        timeSeries27.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        timeSeries27.setKey((java.lang.Comparable) year31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        timeSeriesDataItem36.setValue((java.lang.Number) 100L);
        timeSeries27.add(timeSeriesDataItem36, true);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
        java.lang.Class<?> wildcardClass50 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
        timeSeries51.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        timeSeries51.setKey((java.lang.Comparable) year55);
        long long58 = year55.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 1.0d);
        timeSeries10.add(timeSeriesDataItem61, false);
        int int64 = timeSeries10.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2147483647 + "'", int64 == 2147483647);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeries23.equals(obj25);
        java.lang.Object obj27 = timeSeries23.clone();
        java.lang.Comparable comparable28 = timeSeries23.getKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (byte) 100 + "'", comparable28.equals((byte) 100));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries10.getMaximumItemCount();
        boolean boolean19 = timeSeries10.isEmpty();
        java.lang.Class class20 = timeSeries10.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        int int60 = day58.getYear();
        int int61 = day58.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1927 + "'", int60 == 1927);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 17 + "'", int61 == 17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) 52L);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.previous();
        java.lang.Class<?> wildcardClass16 = year11.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year7, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass16);
        timeSeries17.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        timeSeries17.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        timeSeriesDataItem26.setValue((java.lang.Number) 100L);
        timeSeries17.add(timeSeriesDataItem26, true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year31.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) year31);
        java.lang.Class class37 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        int int39 = year38.getYear();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year42.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.previous();
        java.lang.Class<?> wildcardClass47 = year42.getClass();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year38, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass47);
        timeSeries48.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        int int53 = year52.getYear();
        timeSeries48.setKey((java.lang.Comparable) year52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number68 = timeSeries65.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
        timeSeries65.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year71, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year71.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year71.previous();
        timeSeries65.add(regularTimePeriod75, (java.lang.Number) 1.0d);
        timeSeries48.add(regularTimePeriod75, (java.lang.Number) (-1.0f));
        timeSeries48.setDomainDescription("");
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year82, (java.lang.Number) 11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = fixedMillisecond86.next();
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year82, regularTimePeriod87);
        boolean boolean89 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNull(number68);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNull(timeSeriesDataItem84);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        java.lang.String str17 = timeSeries10.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str17.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy(1, (int) (byte) 10);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.previous();
        java.lang.Class<?> wildcardClass21 = year16.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        java.lang.String str23 = year16.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1927);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond1.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1560409200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        serialDate8.setDescription("17-May-1927");
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-460), serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.previous();
        timeSeries10.add(regularTimePeriod20, (java.lang.Number) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = null;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year28.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year28.previous();
        java.lang.Class<?> wildcardClass33 = year28.getClass();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.next();
        long long38 = fixedMillisecond36.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 100);
        java.lang.String str41 = fixedMillisecond36.toString();
        try {
            org.jfree.data.time.TimeSeries timeSeries42 = timeSeries10.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str41.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        boolean boolean68 = timeSeries65.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year73, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year73.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year73.previous();
        java.lang.Class<?> wildcardClass78 = year73.getClass();
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass78);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number82 = timeSeries79.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        java.lang.Number number83 = timeSeries65.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        long long84 = fixedMillisecond81.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(number82);
        org.junit.Assert.assertNull(number83);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 100L + "'", long84 == 100L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getFirstMillisecond();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        timeSeries24.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2958465);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.lang.String str3 = regularTimePeriod2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str3.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean19 = timeSeries10.equals((java.lang.Object) (byte) 100);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries10.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries10.getMaximumItemCount();
        boolean boolean19 = timeSeries10.isEmpty();
        java.lang.Class class20 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
        long long24 = fixedMillisecond22.getMiddleMillisecond();
        long long25 = fixedMillisecond22.getLastMillisecond();
        java.util.Calendar calendar26 = null;
        fixedMillisecond22.peg(calendar26);
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 2958465);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9999);
        int int5 = day2.compareTo((java.lang.Object) serialDate4);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        java.lang.String str11 = serialDate3.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate3);
        serialDate12.setDescription("ThreadContext");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond1.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.previous();
        java.lang.Class<?> wildcardClass15 = year10.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass15);
        timeSeries16.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        timeSeries16.setKey((java.lang.Comparable) year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.previous();
        java.lang.Class<?> wildcardClass32 = year27.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number36 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        timeSeries33.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year39.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year39.previous();
        timeSeries33.add(regularTimePeriod43, (java.lang.Number) 1.0d);
        timeSeries16.add(regularTimePeriod43, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year48.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year48.previous();
        java.lang.Class<?> wildcardClass53 = year48.getClass();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year48, (double) 7);
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener56);
        boolean boolean58 = fixedMillisecond1.equals((java.lang.Object) timeSeries16);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        int int63 = timeSeriesDataItem61.compareTo((java.lang.Object) 52L);
        java.lang.Class<?> wildcardClass64 = timeSeriesDataItem61.getClass();
        java.lang.Number number65 = timeSeriesDataItem61.getValue();
        try {
            timeSeries16.add(timeSeriesDataItem61, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 0.0d + "'", number65.equals(0.0d));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        java.lang.String str11 = serialDate3.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate3);
        serialDate12.setDescription("ClassContext");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        int int13 = day11.getMonth();
        int int14 = day11.getMonth();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day11.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.previous();
        java.lang.Class<?> wildcardClass30 = year25.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.next();
        long long35 = fixedMillisecond33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond33.getMiddleMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) (-1));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        timeSeries52.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        int int57 = year56.getYear();
        timeSeries52.setKey((java.lang.Comparable) year56);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        timeSeriesDataItem61.setValue((java.lang.Number) 100L);
        timeSeries52.add(timeSeriesDataItem61, true);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year66, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year66.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year66.previous();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) year66);
        java.lang.Class class72 = timeSeries52.getTimePeriodClass();
        java.util.List list73 = timeSeries52.getItems();
        boolean boolean74 = timeSeriesDataItem41.equals((java.lang.Object) list73);
        timeSeriesDataItem41.setValue((java.lang.Number) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(class72);
        org.junit.Assert.assertNotNull(list73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 2958465);
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("2019");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        long long31 = timeSeries10.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            timeSeries23.update(regularTimePeriod25, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        java.lang.String str8 = year1.toString();
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        int int14 = timeSeries10.getItemCount();
        timeSeries10.setMaximumItemAge(0L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        timeSeries27.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        timeSeries27.setKey((java.lang.Comparable) year31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        timeSeriesDataItem36.setValue((java.lang.Number) 100L);
        timeSeries27.add(timeSeriesDataItem36, true);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
        java.lang.Class<?> wildcardClass50 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
        timeSeries51.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        timeSeries51.setKey((java.lang.Comparable) year55);
        long long58 = year55.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 1.0d);
        timeSeries10.add(timeSeriesDataItem61, false);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year64, (double) 2958465);
        boolean boolean68 = timeSeriesDataItem61.equals((java.lang.Object) 2958465);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass11);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("17-May-1927", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        boolean boolean68 = timeSeries65.getNotify();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries65.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        boolean boolean69 = timeSeries65.equals((java.lang.Object) (byte) 100);
        java.lang.Class<?> wildcardClass70 = timeSeries65.getClass();
        java.lang.String str71 = timeSeries65.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "hi!" + "'", str71.equals("hi!"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
        long long16 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries12.removeChangeListener(seriesChangeListener19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.previous();
        java.lang.Class<?> wildcardClass32 = year27.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year23, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.next();
        long long37 = fixedMillisecond35.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 100);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond35.getMiddleMillisecond(calendar40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) (-1));
        int int44 = year0.compareTo((java.lang.Object) timeSeriesDataItem43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (short) 1);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = year18.getYear();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.previous();
        java.lang.Class<?> wildcardClass27 = year22.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year18, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year35.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
        java.lang.Class<?> wildcardClass40 = year35.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries28.addAndOrUpdate(timeSeries41);
        java.lang.Object obj43 = null;
        boolean boolean44 = timeSeries41.equals(obj43);
        int int45 = fixedMillisecond12.compareTo((java.lang.Object) boolean44);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6, (int) (byte) -1, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        timeSeries11.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int16 = year15.getYear();
        timeSeries11.setKey((java.lang.Comparable) year15);
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.previous();
        java.lang.Class<?> wildcardClass15 = year10.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        long long20 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond18.getMiddleMillisecond(calendar23);
        long long25 = fixedMillisecond18.getLastMillisecond();
        long long26 = fixedMillisecond18.getSerialIndex();
        java.lang.String str27 = fixedMillisecond18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond18.next();
        java.util.Date date29 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year34.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year34.previous();
        java.lang.Class<?> wildcardClass39 = year34.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year30, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass39);
        timeSeries40.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        int int45 = year44.getYear();
        timeSeries40.setKey((java.lang.Comparable) year44);
        long long47 = year44.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year44.previous();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year44);
        java.util.Date date50 = year44.getStart();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date29, timeZone52);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date5, timeZone52);
        java.util.Calendar calendar56 = null;
        try {
            long long57 = month55.getFirstMillisecond(calendar56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str27.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone52);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.previous();
        java.lang.Class<?> wildcardClass12 = year7.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        timeSeries13.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timeSeries13.getMaximumItemCount();
        boolean boolean22 = timeSeries13.isEmpty();
        boolean boolean23 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries13);
        try {
            timeSeries13.update(0, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        int int4 = timeSeriesDataItem2.compareTo((java.lang.Object) 52L);
        timeSeriesDataItem2.setValue((java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day11.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries10.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        long long60 = day58.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9999L + "'", long60 == 9999L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        java.lang.String str13 = day11.toString();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "17-May-1927" + "'", str13.equals("17-May-1927"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        int int14 = timeSeries10.getItemCount();
        timeSeries10.setMaximumItemAge(0L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
        long long31 = fixedMillisecond29.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 100);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond29.getMiddleMillisecond(calendar34);
        long long36 = fixedMillisecond29.getLastMillisecond();
        long long37 = fixedMillisecond29.getSerialIndex();
        java.lang.String str38 = fixedMillisecond29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond29.next();
        java.util.Date date40 = fixedMillisecond29.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
        java.lang.Class<?> wildcardClass50 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
        timeSeries51.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        timeSeries51.setKey((java.lang.Comparable) year55);
        long long58 = year55.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.previous();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year55);
        java.util.Date date61 = year55.getStart();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date61, timeZone63);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date40, timeZone63);
        boolean boolean66 = timeSeries10.equals((java.lang.Object) year65);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str38.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        boolean boolean68 = timeSeries65.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year73, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year73.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year73.previous();
        java.lang.Class<?> wildcardClass78 = year73.getClass();
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass78);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number82 = timeSeries79.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        java.lang.Number number83 = timeSeries65.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = timeSeries65.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(number82);
        org.junit.Assert.assertNull(number83);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year35.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
        java.lang.Class<?> wildcardClass40 = year35.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass40);
        timeSeries41.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        int int46 = year45.getYear();
        timeSeries41.setKey((java.lang.Comparable) year45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year52.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year52.previous();
        java.lang.Class<?> wildcardClass57 = year52.getClass();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass57);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number61 = timeSeries58.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
        timeSeries58.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year64, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year64.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year64.previous();
        timeSeries58.add(regularTimePeriod68, (java.lang.Number) 1.0d);
        timeSeries41.add(regularTimePeriod68, (java.lang.Number) (-1.0f));
        timeSeries41.setDomainDescription("");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year75, (java.lang.Number) 11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = fixedMillisecond79.next();
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year75, regularTimePeriod80);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
        try {
            timeSeries81.update((org.jfree.data.time.RegularTimePeriod) day82, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(timeSeries81);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        java.lang.Object obj2 = null;
        boolean boolean3 = fixedMillisecond1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        timeSeries10.setNotify(true);
        java.lang.Class class62 = timeSeries10.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(class62);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-460) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        long long18 = fixedMillisecond12.getSerialIndex();
        java.util.Calendar calendar19 = null;
        fixedMillisecond12.peg(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond12.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) propertyChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("February");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate5);
        java.lang.String str7 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate10);
        java.lang.String str13 = serialDate12.toString();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) '4', serialDate12);
        java.lang.String str15 = serialDate14.getDescription();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9, serialDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-May-1927" + "'", str13.equals("31-May-1927"));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 12);
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.previous();
        java.lang.Class<?> wildcardClass15 = year10.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        long long20 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond18.getMiddleMillisecond(calendar23);
        long long25 = fixedMillisecond18.getLastMillisecond();
        long long26 = fixedMillisecond18.getSerialIndex();
        java.lang.String str27 = fixedMillisecond18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond18.next();
        java.util.Date date29 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year34.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year34.previous();
        java.lang.Class<?> wildcardClass39 = year34.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year30, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass39);
        timeSeries40.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        int int45 = year44.getYear();
        timeSeries40.setKey((java.lang.Comparable) year44);
        long long47 = year44.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year44.previous();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year44);
        java.util.Date date50 = year44.getStart();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date29, timeZone52);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date5, timeZone52);
        org.jfree.data.time.Year year56 = month55.getYear();
        java.util.Calendar calendar57 = null;
        try {
            long long58 = month55.getFirstMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str27.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(year56);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy(1, (int) (byte) 10);
        try {
            java.lang.Number number17 = timeSeries15.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        java.lang.Number number15 = null;
        try {
            timeSeries10.update((int) (byte) 1, number15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        timeSeries11.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int16 = year15.getYear();
        timeSeries11.setKey((java.lang.Comparable) year15);
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, year15);
        long long20 = year15.getMiddleMillisecond();
        java.lang.String str21 = year15.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        serialDate8.setDescription("17-May-1927");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(0, serialDate8);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate15);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10, 3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        long long18 = fixedMillisecond12.getSerialIndex();
        java.util.Calendar calendar19 = null;
        fixedMillisecond12.peg(calendar19);
        java.util.Date date21 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        long long18 = fixedMillisecond12.getSerialIndex();
        long long19 = fixedMillisecond12.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        int int14 = timeSeries10.getItemCount();
        timeSeries10.setMaximumItemAge(0L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        timeSeries27.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        timeSeries27.setKey((java.lang.Comparable) year31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        timeSeriesDataItem36.setValue((java.lang.Number) 100L);
        timeSeries27.add(timeSeriesDataItem36, true);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
        java.lang.Class<?> wildcardClass50 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
        timeSeries51.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        timeSeries51.setKey((java.lang.Comparable) year55);
        long long58 = year55.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 1.0d);
        timeSeries10.add(timeSeriesDataItem61, false);
        timeSeries10.setDomainDescription("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ClassContext" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ClassContext"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year42.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.previous();
        java.lang.Class<?> wildcardClass47 = year42.getClass();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year42, (double) 7);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener50);
        java.lang.Class<?> wildcardClass52 = timeSeries10.getClass();
        boolean boolean53 = timeSeries10.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries10.addChangeListener(seriesChangeListener54);
        java.util.List list56 = timeSeries10.getItems();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(list56);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        java.util.Date date20 = year14.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day23.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone22);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        java.lang.String str11 = serialDate3.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate14 = serialDate3.getNearestDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, 4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        java.lang.String str42 = timeSeries10.getDomainDescription();
        try {
            java.lang.Number number44 = timeSeries10.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str42.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        timeSeries10.setNotify(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year42.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year42.previous();
        java.lang.Class<?> wildcardClass47 = year42.getClass();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year42, (double) 7);
        long long50 = year42.getSerialIndex();
        long long51 = year42.getSerialIndex();
        java.lang.String str52 = year42.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019" + "'", str52.equals("2019"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 0, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("2019");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray8 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year28.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year28.previous();
        java.lang.Class<?> wildcardClass33 = year28.getClass();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass33);
        timeSeries34.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        int int39 = year38.getYear();
        timeSeries34.setKey((java.lang.Comparable) year38);
        long long41 = year38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 1.0d);
        java.util.Calendar calendar45 = null;
        try {
            long long46 = year38.getFirstMillisecond(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        java.util.Date date20 = year14.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        long long22 = day21.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43466L + "'", long22 == 43466L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, (java.lang.Class) wildcardClass26);
        timeSeries28.setRangeDescription("February");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries28.addChangeListener(seriesChangeListener31);
        try {
            timeSeries28.update(100, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        int int13 = day11.getMonth();
        java.lang.String str14 = day11.toString();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "17-May-1927" + "'", str14.equals("17-May-1927"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeries23.equals(obj25);
        java.lang.Object obj27 = timeSeries23.clone();
        boolean boolean29 = timeSeries23.equals((java.lang.Object) 4);
        try {
            timeSeries23.update((int) (byte) 100, (java.lang.Number) 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.setDomainDescription("2019");
        timeSeries10.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
        long long14 = day11.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9999L + "'", long14 == 9999L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) 9999);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.setRangeDescription("31-May-1927");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        java.util.Date date20 = year14.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        long long22 = day21.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546415999999L + "'", long22 == 1546415999999L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        long long7 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        timeSeries10.setDescription("hi!");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year23.previous();
        java.lang.Class<?> wildcardClass28 = year23.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass28);
        timeSeries29.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = year33.getYear();
        timeSeries29.setKey((java.lang.Comparable) year33);
        long long36 = year33.getFirstMillisecond();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, year33);
        long long38 = month37.getLastMillisecond();
        java.lang.Number number39 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month37);
        int int41 = month37.compareTo((java.lang.Object) "2019");
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1549007999999L + "'", long38 == 1549007999999L);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(classLoader11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        boolean boolean6 = spreadsheetDate2.isOnOrBefore(serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(12, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
        long long61 = regularTimePeriod60.getMiddleMillisecond();
        java.util.Date date62 = regularTimePeriod60.getStart();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-1345089600001L) + "'", long61 == (-1345089600001L));
        org.junit.Assert.assertNotNull(date62);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate2);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        java.lang.String str13 = seriesChangeEvent11.toString();
        java.lang.Object obj14 = seriesChangeEvent11.getSource();
        java.lang.Object obj15 = seriesChangeEvent11.getSource();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=17-May-1927]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source=17-May-1927]"));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate8);
        java.lang.String str10 = serialDate8.toString();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str16 = serialDate15.toString();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) '4', serialDate15);
        java.lang.String str18 = serialDate17.getDescription();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate17);
        int int20 = year0.compareTo((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-May-1927" + "'", str10.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-May-1927" + "'", str16.equals("31-May-1927"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = timeSeries10.getMaximumItemAge();
        try {
            timeSeries10.update(8, (java.lang.Number) 17);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        boolean boolean31 = timeSeries10.getNotify();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = timeSeries10.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        java.lang.Class<?> wildcardClass29 = year24.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year20, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        long long34 = fixedMillisecond32.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 100);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond32.getMiddleMillisecond(calendar37);
        long long39 = fixedMillisecond32.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-459));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries10.getTimePeriod(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.setDomainDescription("2019");
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy(9, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.previous();
        java.lang.Class<?> wildcardClass15 = year10.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        long long20 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond18.getMiddleMillisecond(calendar23);
        long long25 = fixedMillisecond18.getLastMillisecond();
        long long26 = fixedMillisecond18.getSerialIndex();
        java.lang.String str27 = fixedMillisecond18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond18.next();
        java.util.Date date29 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year34.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year34.previous();
        java.lang.Class<?> wildcardClass39 = year34.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year30, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass39);
        timeSeries40.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        int int45 = year44.getYear();
        timeSeries40.setKey((java.lang.Comparable) year44);
        long long47 = year44.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year44.previous();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year44);
        java.util.Date date50 = year44.getStart();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date29, timeZone52);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date5, timeZone52);
        java.util.Calendar calendar56 = null;
        try {
            month55.peg(calendar56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str27.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone52);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("17-May-1927");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year35.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
        java.lang.Class<?> wildcardClass40 = year35.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass40);
        timeSeries41.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        int int46 = year45.getYear();
        timeSeries41.setKey((java.lang.Comparable) year45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year52.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year52.previous();
        java.lang.Class<?> wildcardClass57 = year52.getClass();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass57);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number61 = timeSeries58.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
        timeSeries58.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year64, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year64.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year64.previous();
        timeSeries58.add(regularTimePeriod68, (java.lang.Number) 1.0d);
        timeSeries41.add(regularTimePeriod68, (java.lang.Number) (-1.0f));
        timeSeries41.setDomainDescription("");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year75, (java.lang.Number) 11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = fixedMillisecond79.next();
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year75, regularTimePeriod80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = year75.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        boolean boolean68 = timeSeries65.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year73, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year73.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year73.previous();
        java.lang.Class<?> wildcardClass78 = year73.getClass();
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass78);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number82 = timeSeries79.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        java.lang.Number number83 = timeSeries65.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81);
        timeSeries65.setNotify(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(number82);
        org.junit.Assert.assertNull(number83);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        long long18 = fixedMillisecond12.getSerialIndex();
        java.util.Calendar calendar19 = null;
        fixedMillisecond12.peg(calendar19);
        java.util.Date date21 = fixedMillisecond12.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year51, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year51.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year51.previous();
        java.lang.Class<?> wildcardClass56 = year51.getClass();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number60 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        timeSeries57.setDomainDescription("17-May-1927");
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, 0.0d);
        int int67 = year44.compareTo((java.lang.Object) fixedMillisecond64);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond64);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNull(number60);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        java.util.Collection collection42 = timeSeries10.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        int int4 = timeSeriesDataItem2.compareTo((java.lang.Object) 52L);
        java.lang.Class<?> wildcardClass5 = timeSeriesDataItem2.getClass();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getLastMillisecond();
        boolean boolean10 = timeSeriesDataItem2.equals((java.lang.Object) long9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        timeSeries12.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timeSeries12.getMaximumItemCount();
        boolean boolean21 = timeSeries12.isEmpty();
        java.lang.Class class22 = timeSeries12.getTimePeriodClass();
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("13-June-2019", class22);
        java.io.InputStream inputStream24 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("13-June-2019", class22);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNull(inputStream23);
        org.junit.Assert.assertNull(inputStream24);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate3);
        java.lang.String str5 = serialDate3.toString();
        serialDate3.setDescription("ERROR : Relative To String");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        timeSeries65.addChangeListener(seriesChangeListener68);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        int int12 = day11.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (byte) 0);
        timeSeriesDataItem16.setValue((java.lang.Number) 100L);
        boolean boolean19 = day11.equals((java.lang.Object) timeSeriesDataItem16);
        int int20 = day11.getYear();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 17 + "'", int12 == 17);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1927 + "'", int20 == 1927);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 0, serialDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        java.util.Date date20 = year14.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        java.lang.ClassLoader classLoader27 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass26);
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date28, timeZone29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date20, timeZone29);
        java.util.Calendar calendar32 = null;
        try {
            month31.peg(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(classLoader27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        int int6 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate7 = null;
        try {
            boolean boolean8 = spreadsheetDate1.isOnOrBefore(serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        int int14 = timeSeries10.getItemCount();
        timeSeries10.setMaximumItemAge(0L);
        timeSeries10.setDescription("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.previous();
        java.lang.Class<?> wildcardClass23 = year18.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass23);
        timeSeries24.removeAgedItems((long) 11, true);
        int int28 = timeSeries24.getItemCount();
        timeSeries24.setMaximumItemAge(0L);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year35.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
        java.lang.Class<?> wildcardClass40 = year35.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass40);
        timeSeries41.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        int int46 = year45.getYear();
        timeSeries41.setKey((java.lang.Comparable) year45);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (double) (byte) 0);
        timeSeriesDataItem50.setValue((java.lang.Number) 100L);
        timeSeries41.add(timeSeriesDataItem50, true);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year55, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        timeSeries65.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        int int70 = year69.getYear();
        timeSeries65.setKey((java.lang.Comparable) year69);
        long long72 = year69.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year69.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year69, (java.lang.Number) 1.0d);
        timeSeries24.add(timeSeriesDataItem75, false);
        timeSeries10.add(timeSeriesDataItem75, false);
        java.lang.Object obj80 = timeSeriesDataItem75.clone();
        java.lang.Object obj81 = timeSeriesDataItem75.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1546329600000L + "'", long72 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(timeSeriesDataItem75);
        org.junit.Assert.assertNotNull(obj80);
        org.junit.Assert.assertNotNull(obj81);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        long long18 = fixedMillisecond12.getSerialIndex();
        java.util.Calendar calendar19 = null;
        fixedMillisecond12.peg(calendar19);
        java.util.Date date21 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        long long26 = fixedMillisecond24.getMiddleMillisecond();
        long long27 = fixedMillisecond24.getLastMillisecond();
        long long28 = fixedMillisecond24.getLastMillisecond();
        boolean boolean29 = year22.equals((java.lang.Object) long28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        long long18 = fixedMillisecond12.getSerialIndex();
        java.util.Calendar calendar19 = null;
        fixedMillisecond12.peg(calendar19);
        java.util.Date date21 = fixedMillisecond12.getTime();
        java.lang.String str22 = fixedMillisecond12.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str22.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int3 = day0.compareTo((java.lang.Object) false);
//        java.lang.String str4 = day0.toString();
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        int int7 = year6.getYear();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.previous();
//        java.lang.Class<?> wildcardClass15 = year10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass15);
//        timeSeries16.removeAgedItems((long) 11, true);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        int int21 = year20.getYear();
//        timeSeries16.setKey((java.lang.Comparable) year20);
//        long long23 = year20.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.previous();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year20);
//        java.util.Date date26 = year20.getStart();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date5, timeZone28);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone28);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        long long19 = year14.getMiddleMillisecond();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year14.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.previous();
        java.lang.Class<?> wildcardClass30 = year25.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.next();
        long long35 = fixedMillisecond33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond33.getMiddleMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) (-1));
        java.lang.Number number42 = timeSeriesDataItem41.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 100.0d + "'", number42.equals(100.0d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries10.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.previous();
        timeSeries10.add(regularTimePeriod20, (java.lang.Number) 1.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int26 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.previous();
        java.lang.Class<?> wildcardClass34 = year29.getClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year25, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass34);
        timeSeries35.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = year39.getYear();
        timeSeries35.setKey((java.lang.Comparable) year39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number55 = timeSeries52.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
        timeSeries52.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year58, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year58.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year58.previous();
        timeSeries52.add(regularTimePeriod62, (java.lang.Number) 1.0d);
        timeSeries35.add(regularTimePeriod62, (java.lang.Number) (-1.0f));
        timeSeries35.setMaximumItemAge((long) (short) 1);
        timeSeries35.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, 0.0d);
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
        boolean boolean77 = timeSeries10.equals((java.lang.Object) 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        int int14 = timeSeries10.getItemCount();
        timeSeries10.setMaximumItemAge(0L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        timeSeries27.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        timeSeries27.setKey((java.lang.Comparable) year31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        timeSeriesDataItem36.setValue((java.lang.Number) 100L);
        timeSeries27.add(timeSeriesDataItem36, true);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
        java.lang.Class<?> wildcardClass50 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
        timeSeries51.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        timeSeries51.setKey((java.lang.Comparable) year55);
        long long58 = year55.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 1.0d);
        timeSeries10.add(timeSeriesDataItem61, false);
        boolean boolean65 = timeSeriesDataItem61.equals((java.lang.Object) (short) 1);
        java.lang.Object obj66 = timeSeriesDataItem61.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(obj66);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate14);
        java.lang.String str16 = serialDate14.toString();
        serialDate14.setDescription("ERROR : Relative To String");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate14);
        org.jfree.data.time.SerialDate serialDate20 = serialDate2.getEndOfCurrentMonth(serialDate14);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "17-May-1927" + "'", str16.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.lang.String str17 = fixedMillisecond12.toString();
        long long18 = fixedMillisecond12.getSerialIndex();
        long long19 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond12.next();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond12.getLastMillisecond(calendar21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("17-May-1927", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        timeSeriesDataItem19.setValue((java.lang.Number) 100L);
        timeSeries10.add(timeSeriesDataItem19, true);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class30 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.String str32 = month31.toString();
        int int33 = month31.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month31.previous();
        java.lang.Number number35 = timeSeries10.getValue(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNull(number35);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        int int14 = timeSeries10.getItemCount();
        timeSeries10.setMaximumItemAge(0L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        timeSeries27.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        timeSeries27.setKey((java.lang.Comparable) year31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 0);
        timeSeriesDataItem36.setValue((java.lang.Number) 100L);
        timeSeries27.add(timeSeriesDataItem36, true);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
        java.lang.Class<?> wildcardClass50 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
        timeSeries51.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int56 = year55.getYear();
        timeSeries51.setKey((java.lang.Comparable) year55);
        long long58 = year55.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 1.0d);
        timeSeries10.add(timeSeriesDataItem61, false);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        int int65 = year64.getYear();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year68, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
        java.lang.Class<?> wildcardClass73 = year68.getClass();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year64, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass73);
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond76.next();
        long long78 = fixedMillisecond76.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener81 = null;
        timeSeries74.removeChangeListener(seriesChangeListener81);
        java.util.Collection collection83 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries74);
        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar86 = null;
        long long87 = fixedMillisecond85.getMiddleMillisecond(calendar86);
        java.util.Calendar calendar88 = null;
        long long89 = fixedMillisecond85.getLastMillisecond(calendar88);
        try {
            timeSeries74.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond85, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 100L + "'", long78 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertNotNull(collection83);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 52L + "'", long87 == 52L);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 52L + "'", long89 == 52L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate5);
        java.lang.String str7 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate10);
        java.lang.String str13 = serialDate12.toString();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) '4', serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) '4', serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, serialDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-May-1927" + "'", str13.equals("31-May-1927"));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.previous();
        java.lang.Class<?> wildcardClass12 = year7.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        timeSeries13.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timeSeries13.getMaximumItemCount();
        boolean boolean22 = timeSeries13.isEmpty();
        boolean boolean23 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries13);
        timeSeries13.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("February");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: February" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: February"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate15);
        java.lang.String str17 = serialDate15.toString();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = serialDate15.getEndOfCurrentMonth(serialDate20);
        java.lang.String str23 = serialDate15.getDescription();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate15);
        org.jfree.data.time.SerialDate serialDate25 = serialDate12.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate15);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "17-May-1927" + "'", str17.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        java.util.Date date20 = year14.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.lang.String str22 = day21.toString();
        long long23 = day21.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1-January-2019" + "'", str22.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43466L + "'", long23 == 43466L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        java.lang.Class<?> wildcardClass14 = year9.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("17-May-1927", (java.lang.Class) wildcardClass14, (java.lang.Class) wildcardClass22);
        try {
            org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries(comparable0, "hi!", "June 2019", (java.lang.Class) wildcardClass22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
        long long16 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100);
        java.lang.String str19 = fixedMillisecond14.toString();
        long long20 = fixedMillisecond14.getSerialIndex();
        java.util.Calendar calendar21 = null;
        fixedMillisecond14.peg(calendar21);
        java.util.Date date23 = fixedMillisecond14.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        boolean boolean26 = spreadsheetDate1.isOn(serialDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate29);
        java.lang.String str31 = serialDate29.toString();
        int int32 = spreadsheetDate1.compare(serialDate29);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int34 = year33.getYear();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year37.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year37.previous();
        java.lang.Class<?> wildcardClass42 = year37.getClass();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year33, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass42);
        timeSeries43.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        int int48 = year47.getYear();
        timeSeries43.setKey((java.lang.Comparable) year47);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year50, (double) (byte) 0);
        timeSeriesDataItem52.setValue((java.lang.Number) 100L);
        timeSeries43.add(timeSeriesDataItem52, true);
        java.lang.Number number57 = timeSeriesDataItem52.getValue();
        boolean boolean58 = spreadsheetDate1.equals((java.lang.Object) number57);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str19.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "17-May-1927" + "'", str31.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-9899) + "'", int32 == (-9899));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 100L + "'", number57.equals(100L));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.previous();
        java.lang.Class<?> wildcardClass30 = year25.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.next();
        long long35 = fixedMillisecond33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond33.getMiddleMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) (-1));
        int int42 = timeSeries10.getItemCount();
        java.lang.Number number44 = timeSeries10.getValue(0);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        int int46 = year45.getYear();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year49.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year49.previous();
        java.lang.Class<?> wildcardClass54 = year49.getClass();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year45, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year56, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year56.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond61.next();
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond61.getLastMillisecond(calendar63);
        java.util.Date date65 = fixedMillisecond61.getTime();
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries55.createCopy(regularTimePeriod59, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        int int68 = year67.getYear();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year71, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year71.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year71.previous();
        java.lang.Class<?> wildcardClass76 = year71.getClass();
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year67, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass76);
        timeSeries77.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year();
        int int82 = year81.getYear();
        timeSeries77.setKey((java.lang.Comparable) year81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year84, (double) (byte) 0);
        timeSeriesDataItem86.setValue((java.lang.Number) 100L);
        timeSeries77.add(timeSeriesDataItem86, true);
        timeSeries55.add(timeSeriesDataItem86);
        try {
            org.jfree.data.time.TimeSeries timeSeries92 = timeSeries10.addAndOrUpdate(timeSeries55);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (-1) + "'", number44.equals((-1)));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 100L + "'", long64 == 100L);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2019 + "'", int82 == 2019);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        timeSeries11.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int16 = year15.getYear();
        timeSeries11.setKey((java.lang.Comparable) year15);
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, year15);
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = month19.getYearValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        java.lang.Object obj42 = timeSeries10.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        java.util.Date date20 = year14.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.previous();
        java.lang.Class<?> wildcardClass12 = year7.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        timeSeries13.setDomainDescription("17-May-1927");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timeSeries13.getMaximumItemCount();
        boolean boolean22 = timeSeries13.isEmpty();
        boolean boolean23 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int26 = year25.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.previous();
        java.lang.Class<?> wildcardClass34 = year29.getClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year25, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass34);
        timeSeries35.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = year39.getYear();
        timeSeries35.setKey((java.lang.Comparable) year39);
        long long42 = year39.getFirstMillisecond();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (short) 1, year39);
        long long44 = year39.getMiddleMillisecond();
        timeSeries13.setKey((java.lang.Comparable) year39);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1562097599999L + "'", long44 == 1562097599999L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate2.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        int int6 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.previous();
        java.lang.Class<?> wildcardClass18 = year13.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year9, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
        long long23 = fixedMillisecond21.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 100);
        java.lang.String str26 = fixedMillisecond21.toString();
        long long27 = fixedMillisecond21.getSerialIndex();
        java.util.Calendar calendar28 = null;
        fixedMillisecond21.peg(calendar28);
        java.util.Date date30 = fixedMillisecond21.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date30);
        boolean boolean33 = spreadsheetDate8.isOn(serialDate32);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate36);
        java.lang.String str38 = serialDate36.toString();
        int int39 = spreadsheetDate8.compare(serialDate36);
        int int40 = spreadsheetDate8.getMonth();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate43);
        java.lang.String str45 = serialDate43.toString();
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, serialDate43);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str26.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "17-May-1927" + "'", str38.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-9899) + "'", int39 == (-9899));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "17-May-1927" + "'", str45.equals("17-May-1927"));
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        java.lang.Class<?> wildcardClass14 = year9.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass14);
        timeSeries15.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        timeSeries15.setKey((java.lang.Comparable) year19);
        long long22 = year19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19);
        java.util.Date date25 = year19.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date4, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond12.getMiddleMillisecond(calendar17);
        long long19 = fixedMillisecond12.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond21.getLastMillisecond(calendar23);
        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) long24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) 100);
        long long8 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
//        java.lang.Class<?> wildcardClass9 = year4.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
//        timeSeries10.removeAgedItems((long) 11, true);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        int int15 = year14.getYear();
//        timeSeries10.setKey((java.lang.Comparable) year14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
//        java.lang.Class<?> wildcardClass26 = year21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries27.setDomainDescription("17-May-1927");
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
//        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
//        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        int int43 = year42.getYear();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
//        java.lang.Class<?> wildcardClass51 = year46.getClass();
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries52.addChangeListener(seriesChangeListener53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
//        java.lang.Class<?> wildcardClass64 = year59.getClass();
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
//        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(9999);
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate70);
//        java.lang.String str72 = serialDate70.toString();
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(9999);
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate75);
//        org.jfree.data.time.SerialDate serialDate77 = serialDate70.getEndOfCurrentMonth(serialDate75);
//        java.lang.String str78 = serialDate70.getDescription();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(serialDate70);
//        int int80 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day79);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        long long82 = day81.getSerialIndex();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day81);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(collection67);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "17-May-1927" + "'", str72.equals("17-May-1927"));
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNull(str78);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 43629L + "'", long82 == 43629L);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.lang.Class<?> wildcardClass6 = year1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        java.lang.String str8 = year1.toString();
        java.util.Date date9 = year1.getStart();
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((-459), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeries23.equals(obj25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = year28.getYear();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year32.previous();
        java.lang.Class<?> wildcardClass37 = year32.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year28, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass37);
        timeSeries38.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        timeSeries38.setKey((java.lang.Comparable) year42);
        long long45 = year42.getFirstMillisecond();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, year42);
        long long47 = year42.getMiddleMillisecond();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        int int51 = year50.getYear();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year54, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year54.previous();
        java.lang.Class<?> wildcardClass59 = year54.getClass();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year50, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass59);
        java.net.URL uRL61 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass59);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year62, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year62.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year62.previous();
        java.lang.Class<?> wildcardClass67 = year62.getClass();
        java.lang.Object obj68 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("17-May-1927", (java.lang.Class) wildcardClass59, (java.lang.Class) wildcardClass67);
        int int69 = year42.compareTo((java.lang.Object) wildcardClass59);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) (-1L), true);
        timeSeries23.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1562097599999L + "'", long47 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNull(uRL61);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNull(obj68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate5);
        java.lang.String str7 = serialDate5.toString();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate10);
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year46.previous();
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.addChangeListener(seriesChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year59.previous();
        java.lang.Class<?> wildcardClass64 = year59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries52.addAndOrUpdate(timeSeries65);
        java.util.Collection collection67 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries65);
        boolean boolean68 = timeSeries65.getNotify();
        try {
            timeSeries65.update(2, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((-1), serialDate2);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate6);
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = serialDate6.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate2.getEndOfCurrentMonth(serialDate11);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-May-1927" + "'", str8.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-May-1927", (java.lang.Class) wildcardClass11);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", class14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries23);
        java.lang.String str25 = timeSeries10.getDomainDescription();
        timeSeries10.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str25.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 100);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond12.getMiddleMillisecond(calendar17);
        long long19 = fixedMillisecond12.getLastMillisecond();
        long long20 = fixedMillisecond12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond12.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int2 = year1.getYear();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.previous();
//        java.lang.Class<?> wildcardClass10 = year5.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
//        timeSeries11.removeAgedItems((long) 11, true);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        timeSeries11.setKey((java.lang.Comparable) year15);
//        long long18 = year15.getFirstMillisecond();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, year15);
//        org.jfree.data.time.Year year20 = month19.getYear();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getSerialIndex();
//        boolean boolean23 = month19.equals((java.lang.Object) day21);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        int int25 = year24.getYear();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year28.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year28.previous();
//        java.lang.Class<?> wildcardClass33 = year28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.next();
//        long long38 = fixedMillisecond36.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 100);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond36.getMiddleMillisecond(calendar41);
//        long long43 = fixedMillisecond36.getLastMillisecond();
//        long long44 = fixedMillisecond36.getSerialIndex();
//        java.lang.String str45 = fixedMillisecond36.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond36.next();
//        java.util.Date date47 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        int int49 = year48.getYear();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (double) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year52.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year52.previous();
//        java.lang.Class<?> wildcardClass57 = year52.getClass();
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year48, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass57);
//        timeSeries58.removeAgedItems((long) 11, true);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
//        int int63 = year62.getYear();
//        timeSeries58.setKey((java.lang.Comparable) year62);
//        long long65 = year62.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year62.previous();
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year62);
//        java.util.Date date68 = year62.getStart();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date68, timeZone70);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date47, timeZone70);
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date47, timeZone73);
//        boolean boolean75 = month19.equals((java.lang.Object) day74);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43629L + "'", long22 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str45.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
        int int61 = day58.getMonth();
        java.lang.Object obj62 = null;
        int int63 = day58.compareTo(obj62);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day58.next();
        int int63 = day58.compareTo((java.lang.Object) "February");
        org.jfree.data.time.SerialDate serialDate64 = day58.getSerialDate();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(serialDate64);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(serialDate64);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        java.lang.String str5 = serialDate2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate2);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 2958465);
        try {
            timeSeries6.add(timeSeriesDataItem10, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
        long long16 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100);
        java.lang.String str19 = fixedMillisecond14.toString();
        long long20 = fixedMillisecond14.getSerialIndex();
        java.util.Calendar calendar21 = null;
        fixedMillisecond14.peg(calendar21);
        java.util.Date date23 = fixedMillisecond14.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        boolean boolean26 = spreadsheetDate1.isOn(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = null;
        try {
            boolean boolean28 = spreadsheetDate1.isOnOrBefore(serialDate27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str19.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-9899));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2860) + "'", int1 == (-2860));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        java.lang.Class<?> wildcardClass14 = year9.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries15.setDomainDescription("17-May-1927");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, 0.0d);
        int int25 = year0.compareTo((java.lang.Object) timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        long long17 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        boolean boolean21 = year14.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.previous();
        java.lang.Class<?> wildcardClass15 = year10.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass15);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-May-1927", (java.lang.Class) wildcardClass15);
        int int18 = fixedMillisecond1.compareTo((java.lang.Object) inputStream17);
        java.util.Date date19 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(inputStream17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        timeSeries10.setDomainDescription("");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate49);
        java.lang.String str51 = serialDate49.toString();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = serialDate49.getEndOfCurrentMonth(serialDate54);
        java.lang.String str57 = serialDate49.getDescription();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate49);
        int int59 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(9999);
        boolean boolean63 = day58.equals((java.lang.Object) 9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "SerialDate.weekInMonthToString(): invalid code.", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass9);
        timeSeries10.removeAgedItems((long) 11, true);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        timeSeries10.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.previous();
        java.lang.Class<?> wildcardClass26 = year21.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        timeSeries27.setDomainDescription("17-May-1927");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year33.previous();
        timeSeries27.add(regularTimePeriod37, (java.lang.Number) 1.0d);
        timeSeries10.add(regularTimePeriod37, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries10.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }
}

