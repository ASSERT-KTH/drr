import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.lang.Object obj7 = xYLineAndShapeRenderer2.clone();
        org.jfree.chart.LegendItem legendItem10 = xYLineAndShapeRenderer2.getLegendItem(1, 500);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis12);
        java.awt.Paint paint14 = combinedDomainXYPlot13.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot16.setDomainCrosshairPaint(paint17);
        org.jfree.chart.plot.Marker marker19 = null;
        boolean boolean20 = combinedDomainXYPlot16.removeDomainMarker(marker19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot16.setRangeAxisLocation(1, axisLocation22, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        xYBarRenderer26.setBaseToolTipGenerator(xYToolTipGenerator27, false);
        int int30 = combinedDomainXYPlot16.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer26);
        combinedDomainXYPlot13.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer26);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        combinedDomainXYPlot33.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo36, point2D37);
        combinedDomainXYPlot33.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        int int42 = combinedDomainXYPlot33.getDomainAxisIndex(valueAxis41);
        java.lang.String[] strArray47 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis48 = new org.jfree.chart.axis.SymbolAxis("", strArray47);
        java.lang.String str50 = symbolAxis48.valueToString(0.0d);
        int int51 = combinedDomainXYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis48);
        double double52 = symbolAxis48.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        try {
            xYLineAndShapeRenderer2.fillDomainGridBand(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.chart.axis.ValueAxis) symbolAxis48, rectangle2D53, (double) (-1), (double) 0.8f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0E-8d + "'", double52 == 1.0E-8d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection47 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double50 = xYBarRenderer49.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range52 = xYBarRenderer49.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        xYSeriesCollection47.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection51);
        int int54 = xYSeriesCollection51.getSeriesCount();
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        java.awt.Paint paint56 = null;
        polarPlot10.setRadiusGridlinePaint(paint56);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        boolean boolean6 = range2.intersects(range5);
        java.lang.String str7 = range5.toString();
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range5, (-1.0d));
        boolean boolean11 = range5.equals((java.lang.Object) (-2L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[9999.0,2958465.0]" + "'", str7.equals("Range[9999.0,2958465.0]"));
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        legendItem12.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker21.setStartValue(0.0d);
        float float24 = intervalMarker21.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = intervalMarker21.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, 1.0E-8d, 1.0E-8d, rectangleAnchor25);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D26);
        legendItem12.setLine((java.awt.Shape) rectangle2D26);
        boolean boolean29 = legendItem12.isShapeOutlineVisible();
        int int30 = legendItem12.getSeriesIndex();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.8f + "'", float24 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        try {
            xYBarRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine1);
        org.jfree.chart.text.TextLine textLine3 = null;
        textBlock0.addLine(textLine3);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textBlock0.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.text.DateFormat dateFormat8 = null;
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat8, dateFormat9);
        xYLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator10, true);
        boolean boolean13 = xYLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        double double5 = size2D0.width;
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("Range[9999.0,2958465.0]");
        basicProjectInfo0.addOptionalLibrary("UnitType.ABSOLUTE");
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.Object obj1 = combinedRangeXYPlot0.clone();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        java.awt.Color color18 = java.awt.Color.BLUE;
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color18);
        double double20 = symbolAxis8.getUpperBound();
        symbolAxis8.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation24 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Font font4 = xYLineAndShapeRenderer2.lookupLegendTextFont(0);
        org.junit.Assert.assertNull(font4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        symbolAxis5.setLowerMargin((double) (short) 1);
        symbolAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 10);
        java.lang.String str23 = numberTickUnit22.toString();
        symbolAxis5.setTickUnit(numberTickUnit22, false, true);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[size=10]" + "'", str23.equals("[size=10]"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.lang.String str1 = dateTickUnitType0.toString();
        java.lang.String str2 = dateTickUnitType0.toString();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) ' ');
        int int5 = dateTickUnit4.getMultiple();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.MINUTE" + "'", str1.equals("DateTickUnitType.MINUTE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickUnitType.MINUTE" + "'", str2.equals("DateTickUnitType.MINUTE"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        double double3 = dateRange0.constrain((double) (-2L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        ringPlot1.setInnerSeparatorExtension((double) (byte) -1);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        ringPlot8.setDrawingSupplier(drawingSupplier9, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = ringPlot8.getLegendLabelURLGenerator();
        boolean boolean13 = ringPlot8.isCircular();
        double double14 = ringPlot8.getOuterSeparatorExtension();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        ringPlot8.setBackgroundPaint((java.awt.Paint) color15);
        ringPlot1.setSeparatorPaint((java.awt.Paint) color15);
        ringPlot1.zoom(Double.NaN);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        jFreeChart14.handleClick((int) (byte) 0, 10, chartRenderingInfo19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color21);
        jFreeChart14.setBackgroundImageAlpha(100.0f);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        java.awt.Stroke stroke14 = xYLineAndShapeRenderer2.getSeriesStroke(1900);
        xYLineAndShapeRenderer2.setBaseShapesFilled(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, false);
        java.util.List list8 = categoryPlot0.getCategories();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers(layer9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double15 = xYBarRenderer14.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range17 = xYBarRenderer14.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        xYSeriesCollection12.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection16);
        java.util.List list19 = xYSeriesCollection16.getSeries();
        try {
            categoryPlot0.mapDatasetToRangeAxes(2, list19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("MAJOR", numberFormat1, numberFormat4);
        boolean boolean6 = numberFormat4.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Number number0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick(number0, "", textAnchor2, textAnchor3, (double) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart14.addProgressListener(chartProgressListener17);
        jFreeChart14.fireChartChanged();
        org.jfree.chart.event.ChartProgressListener chartProgressListener20 = null;
        jFreeChart14.addProgressListener(chartProgressListener20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setSeriesPaint(10, (java.awt.Paint) color5);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer16.setBaseCreateEntities(true);
        int int19 = xYLineAndShapeRenderer16.getPassCount();
        boolean boolean20 = xYLineAndShapeRenderer16.getUseFillPaint();
        java.text.DateFormat dateFormat22 = null;
        java.text.DateFormat dateFormat23 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator24 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat22, dateFormat23);
        xYLineAndShapeRenderer16.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator24, true);
        xYStepAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator24, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = xYStepAreaRenderer0.getToolTipGenerator(500, (-1), false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(xYToolTipGenerator32);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        boolean boolean13 = legendItem12.isLineVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter4 = xYBarRenderer1.getBarPainter();
        java.awt.Paint paint8 = xYBarRenderer1.getItemFillPaint(2147483647, (-1), false);
        xYBarRenderer1.setShadowVisible(false);
        org.junit.Assert.assertNotNull(xYBarPainter4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, dataset1, (java.lang.Comparable) 15);
        borderArrangement0.clear();
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (-1.0f), (java.lang.Number) 15);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        java.awt.Stroke stroke2 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color12);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        ringPlot22.setDrawingSupplier(drawingSupplier23, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        ringPlot22.markerChanged(markerChangeEvent26);
        ringPlot22.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = ringPlot22.getSimpleLabelOffset();
        standardChartTheme1.setAxisOffset(rectangleInsets30);
        double double33 = rectangleInsets30.extendHeight(10.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 15.625d + "'", double33 == 15.625d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        java.awt.Font font14 = combinedDomainXYPlot1.getNoDataMessageFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis24, polarItemRenderer26);
        boolean boolean28 = polarPlot27.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        polarPlot27.zoomRangeAxes((double) (byte) -1, plotRenderingInfo30, point2D31);
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (-1.0f), (double) 1L, rectangleAnchor38);
        java.awt.Point point40 = polarPlot27.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D39);
        try {
            combinedDomainXYPlot1.zoomRangeAxes((-1.0d), plotRenderingInfo16, (java.awt.geom.Point2D) point40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(point40);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        int int3 = xYSeries2.getMaximumItemCount();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean9 = xYStepAreaRenderer0.getShapesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine1);
        org.jfree.chart.text.TextLine textLine3 = null;
        textBlock0.addLine(textLine3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        try {
            textBlock0.draw(graphics2D5, (float) 9999, (float) 32, textBlockAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        combinedDomainXYPlot1.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot1);
        java.awt.Graphics2D graphics2D21 = null;
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis27 = new org.jfree.chart.axis.SymbolAxis("", strArray26);
        java.awt.Font font28 = symbolAxis27.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(rectangleInsets29, paint32);
        double double36 = rectangleInsets29.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker42.setStartValue(0.0d);
        float float45 = intervalMarker42.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = intervalMarker42.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 1.0E-8d, 1.0E-8d, rectangleAnchor46);
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets29.createInsetRectangle(rectangle2D47);
        symbolAxis27.setUpArrow((java.awt.Shape) rectangle2D47);
        org.jfree.chart.util.Size2D size2D51 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D51, (double) (-1.0f), (double) 1L, rectangleAnchor54);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D55);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        combinedDomainXYPlot58.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo61, point2D62);
        combinedDomainXYPlot58.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        int int67 = combinedDomainXYPlot58.getDomainAxisIndex(valueAxis66);
        java.lang.String[] strArray72 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis73 = new org.jfree.chart.axis.SymbolAxis("", strArray72);
        java.lang.String str75 = symbolAxis73.valueToString(0.0d);
        int int76 = combinedDomainXYPlot58.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis73);
        org.jfree.chart.util.Layer layer78 = null;
        java.util.Collection collection79 = combinedDomainXYPlot58.getDomainMarkers((-9999), layer78);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = combinedDomainXYPlot58.getDomainAxisEdge((int) (byte) 0);
        double double82 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D55, rectangleEdge81);
        try {
            java.lang.Object obj83 = legendTitle20.draw(graphics2D21, rectangle2D47, (java.lang.Object) rectangle2D55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.0d + "'", double36 == 3.0d);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.8f + "'", float45 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNull(collection79);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        java.awt.Color color14 = color5.brighter();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        combinedDomainXYPlot1.setFixedRangeAxisSpace(axisSpace33);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedDomainXYPlot1);
        java.awt.Paint paint36 = jFreeChart35.getBorderPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        java.awt.Font font14 = combinedDomainXYPlot1.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = combinedDomainXYPlot1.getDomainMarkers(layer15);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight((double) (short) 1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            timeSeriesCollection2.addSeries(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        piePlot3D1.setCircular(true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        double double10 = piePlot3D9.getLabelGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        piePlot3D9.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        java.lang.Object obj14 = standardPieSectionLabelGenerator12.clone();
        piePlot3D1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        try {
            piePlot3D1.setInteriorGap((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 9999, (int) (byte) 0, (int) '#');
        boolean boolean4 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline3.getBaseTimeline();
        java.lang.Object obj6 = segmentedTimeline3.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection47 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double50 = xYBarRenderer49.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range52 = xYBarRenderer49.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        xYSeriesCollection47.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection51);
        int int54 = xYSeriesCollection51.getSeriesCount();
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        polarPlot10.removeCornerTextItem("MAJOR");
        org.jfree.chart.axis.ValueAxis valueAxis58 = polarPlot10.getAxis();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(valueAxis58);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        int int33 = crosshairState31.getDatasetIndex();
        crosshairState31.setCrosshairX((double) 13);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2, (java.lang.Number) (short) 100);
        double double4 = xYDataItem3.getXValue();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem3, "LengthConstraintType.NONE");
        categoryAxis0.configure();
        categoryAxis0.setCategoryMargin((double) 3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("TimePeriodAnchor.START");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key TimePeriodAnchor.START");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, false);
        java.util.List list8 = categoryPlot0.getCategories();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot0.setDataset(categoryDataset10);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "white", false);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeZeroBaselineStroke(stroke15);
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.chart.axis.ValueAxis valueAxis13 = polarPlot10.getAxis();
        polarPlot10.removeCornerTextItem("Oct");
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis21 = new org.jfree.chart.axis.SymbolAxis("", strArray20);
        boolean boolean22 = symbolAxis21.getAutoRangeStickyZero();
        java.lang.String str24 = symbolAxis21.valueToString((double) (byte) 10);
        java.awt.Font font25 = symbolAxis21.getTickLabelFont();
        polarPlot10.setAngleLabelFont(font25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setRangePannable(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState36 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState36.updateCrosshairY(0.0d, (int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot45 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis44);
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = combinedDomainXYPlot45.getOrientation();
        crosshairState36.updateCrosshairPoint(12.0d, 0.0d, 0.0d, 3.0d, plotOrientation46);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection48 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection48);
        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis55 = new org.jfree.chart.axis.SymbolAxis("", strArray54);
        java.awt.Font font56 = symbolAxis55.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer57 = null;
        org.jfree.chart.plot.PolarPlot polarPlot58 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection48, (org.jfree.chart.axis.ValueAxis) symbolAxis55, polarItemRenderer57);
        boolean boolean59 = polarPlot58.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        polarPlot58.zoomRangeAxes((double) (byte) -1, plotRenderingInfo61, point2D62);
        org.jfree.chart.util.Size2D size2D66 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D70 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D66, (double) (-1.0f), (double) 1L, rectangleAnchor69);
        java.awt.Point point71 = polarPlot58.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D70);
        crosshairState36.setAnchor((java.awt.geom.Point2D) point71);
        categoryPlot29.zoomRangeAxes((double) 1900, (double) 0.0f, plotRenderingInfo34, (java.awt.geom.Point2D) point71);
        polarPlot10.zoomRangeAxes((double) 10L, plotRenderingInfo28, (java.awt.geom.Point2D) point71);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(point71);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        java.awt.Stroke stroke6 = null;
        try {
            categoryPlot0.setDomainCrosshairStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart14.addProgressListener(chartProgressListener17);
        jFreeChart14.fireChartChanged();
        java.awt.RenderingHints renderingHints20 = jFreeChart14.getRenderingHints();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(renderingHints20);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        boolean boolean5 = dateAxis0.isTickMarksVisible();
        dateAxis0.setVisible(true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Font font1 = null;
        xYStepAreaRenderer0.setBaseItemLabelFont(font1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 10);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        xYLineAndShapeRenderer2.setLegendShape(5, shape7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.entity.XYItemEntity xYItemEntity14 = new org.jfree.chart.entity.XYItemEntity(shape7, xYDataset9, (int) (byte) 1, 9999, "[size=1]", "Polar Plot");
        org.jfree.data.xy.XYDataset xYDataset15 = xYItemEntity14.getDataset();
        org.jfree.data.xy.XYDataset xYDataset16 = xYItemEntity14.getDataset();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNull(xYDataset16);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        polarPlot10.zoomRangeAxes((double) 0.8f, plotRenderingInfo48, point2D49);
        polarPlot10.zoom(1484232.0d);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis14 = new org.jfree.chart.axis.SymbolAxis("", strArray13);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer17.setBaseCreateEntities(true);
        xYLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYLineAndShapeRenderer17.getBaseURLGenerator();
        boolean boolean23 = symbolAxis14.equals((java.lang.Object) xYURLGenerator22);
        java.awt.Color color24 = java.awt.Color.BLUE;
        symbolAxis14.setTickMarkPaint((java.awt.Paint) color24);
        double double26 = symbolAxis14.getUpperBound();
        symbolAxis14.setAutoRange(true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double33 = xYBarRenderer32.getShadowYOffset();
        java.awt.Color color34 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.AffineTransform affineTransform38 = null;
        java.awt.RenderingHints renderingHints39 = null;
        java.awt.PaintContext paintContext40 = color34.createContext(colorModel35, rectangle36, rectangle2D37, affineTransform38, renderingHints39);
        xYBarRenderer32.setBasePaint((java.awt.Paint) color34);
        boolean boolean42 = combinedDomainXYPlot30.equals((java.lang.Object) color34);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier43 = null;
        combinedDomainXYPlot30.setDrawingSupplier(drawingSupplier43);
        combinedDomainXYPlot30.setDomainCrosshairValue((double) 2958465, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis54);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot55.setRangeAxisLocation(axisLocation56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot60 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis59);
        java.awt.Paint paint61 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot60.setDomainCrosshairPaint(paint61);
        org.jfree.chart.block.BlockBorder blockBorder63 = new org.jfree.chart.block.BlockBorder(rectangleInsets58, paint61);
        combinedDomainXYPlot55.setOutlinePaint(paint61);
        intervalMarker50.setOutlinePaint(paint61);
        boolean boolean66 = combinedDomainXYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker50);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer69 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double70 = xYBarRenderer69.getShadowYOffset();
        java.awt.Color color71 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel72 = null;
        java.awt.Rectangle rectangle73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        java.awt.geom.AffineTransform affineTransform75 = null;
        java.awt.RenderingHints renderingHints76 = null;
        java.awt.PaintContext paintContext77 = color71.createContext(colorModel72, rectangle73, rectangle2D74, affineTransform75, renderingHints76);
        xYBarRenderer69.setBasePaint((java.awt.Paint) color71);
        org.jfree.chart.LegendItem legendItem79 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color71);
        java.lang.Comparable comparable80 = legendItem79.getSeriesKey();
        legendItem79.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D83 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker88 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker88.setStartValue(0.0d);
        float float91 = intervalMarker88.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor92 = intervalMarker88.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D93 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D83, 1.0E-8d, 1.0E-8d, rectangleAnchor92);
        java.awt.Shape shape94 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D93);
        legendItem79.setLine((java.awt.Shape) rectangle2D93);
        barRenderer3D0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) symbolAxis14, (org.jfree.chart.plot.Marker) intervalMarker50, rectangle2D93);
        double double97 = barRenderer3D0.getItemMargin();
        java.awt.Paint paint99 = barRenderer3D0.getSeriesOutlinePaint(255);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintContext40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 4.0d + "'", double70 == 4.0d);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(paintContext77);
        org.junit.Assert.assertNull(comparable80);
        org.junit.Assert.assertTrue("'" + float91 + "' != '" + 0.8f + "'", float91 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor92);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertNotNull(shape94);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.2d + "'", double97 == 0.2d);
        org.junit.Assert.assertNull(paint99);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getShadowYOffset();
        org.jfree.chart.StandardChartTheme standardChartTheme9 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        standardChartTheme9.setTickLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = standardChartTheme9.getAxisOffset();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        standardChartTheme9.setChartBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer22.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer22.setBaseStroke(stroke25);
        xYStepAreaRenderer22.setOutline(true);
        java.awt.Font font29 = xYStepAreaRenderer22.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("", font29, (org.jfree.chart.plot.Plot) combinedDomainXYPlot31, false);
        standardChartTheme9.setExtraLargeFont(font29);
        ringPlot1.setLabelFont(font29);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getGridBandPaint();
        java.awt.Paint paint12 = standardChartTheme1.getPlotOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double14 = barRenderer3D13.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter18 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D13.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter18);
        java.awt.Paint paint20 = barRenderer3D13.getWallPaint();
        standardChartTheme1.setBaselinePaint(paint20);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            int[] intArray5 = timeSeriesCollection1.getSurroundingItems((-456), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-456).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection47 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double50 = xYBarRenderer49.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range52 = xYBarRenderer49.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        xYSeriesCollection47.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection51);
        int int54 = xYSeriesCollection51.getSeriesCount();
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        boolean boolean56 = polarPlot10.isDomainZoomable();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        xYBarRenderer1.setLegendBar(shape6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer1.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke10 = xYBarRenderer1.getSeriesStroke(0);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double14 = xYBarRenderer13.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range16 = xYBarRenderer13.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        xYSeriesCollection11.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.data.Range range19 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection31 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double34 = xYBarRenderer33.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection35 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range36 = xYBarRenderer33.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        xYSeriesCollection31.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection35);
        java.lang.Number number38 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis44 = new org.jfree.chart.axis.SymbolAxis("", strArray43);
        java.awt.Font font45 = symbolAxis44.getLabelFont();
        java.lang.String[] strArray50 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis51 = new org.jfree.chart.axis.SymbolAxis("", strArray50);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer54 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer54.setBaseCreateEntities(true);
        xYLineAndShapeRenderer54.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator59 = xYLineAndShapeRenderer54.getBaseURLGenerator();
        boolean boolean60 = symbolAxis51.equals((java.lang.Object) xYURLGenerator59);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean62 = xYStepAreaRenderer61.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection35, (org.jfree.chart.axis.ValueAxis) symbolAxis44, (org.jfree.chart.axis.ValueAxis) symbolAxis51, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer61);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer65 = new org.jfree.chart.text.G2TextMeasurer(graphics2D64);
        boolean boolean66 = xYPlot63.equals((java.lang.Object) graphics2D64);
        symbolAxis5.setPlot((org.jfree.chart.plot.Plot) xYPlot63);
        org.jfree.chart.axis.AxisLocation axisLocation68 = xYPlot63.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertEquals((double) number38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNull(xYURLGenerator59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(axisLocation68);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        barRenderer3D0.setItemMargin((double) 37);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer3D0.setSeriesToolTipGenerator(13, categoryToolTipGenerator10, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme18 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color19 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        standardChartTheme18.setTickLabelPaint((java.awt.Paint) color19);
        java.awt.Color color29 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color29);
        standardChartTheme18.setLegendBackgroundPaint((java.awt.Paint) color29);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot(pieDataset38);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = null;
        ringPlot39.setDrawingSupplier(drawingSupplier40, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = null;
        ringPlot39.markerChanged(markerChangeEvent43);
        ringPlot39.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = ringPlot39.getSimpleLabelOffset();
        standardChartTheme18.setAxisOffset(rectangleInsets47);
        org.jfree.chart.util.Size2D size2D49 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker54.setStartValue(0.0d);
        float float57 = intervalMarker54.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = intervalMarker54.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D59 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, 1.0E-8d, 1.0E-8d, rectangleAnchor58);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D59);
        java.lang.String[] strArray65 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis66 = new org.jfree.chart.axis.SymbolAxis("", strArray65);
        java.lang.String str68 = symbolAxis66.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity69 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D59, (org.jfree.chart.axis.Axis) symbolAxis66);
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets47.createInsetRectangle(rectangle2D59, false, false);
        java.awt.geom.Point2D point2D73 = null;
        org.jfree.chart.plot.PlotState plotState74 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        try {
            combinedRangeXYPlot11.draw(graphics2D16, rectangle2D59, point2D73, plotState74, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 0.8f + "'", float57 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hi!" + "'", str68.equals("hi!"));
        org.junit.Assert.assertNotNull(rectangle2D72);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        int int3 = xYSeries2.getMaximumItemCount();
        boolean boolean4 = xYSeries2.getAutoSort();
        double double5 = xYSeries2.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, false);
        java.util.List list8 = categoryPlot0.getCategories();
        boolean boolean9 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot2.getDataset();
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.text.DateFormat dateFormat1 = null;
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("UnitType.ABSOLUTE", dateFormat1, numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.chart.axis.ValueAxis valueAxis13 = polarPlot10.getAxis();
        polarPlot10.removeCornerTextItem("Oct");
        polarPlot10.setAngleLabelsVisible(true);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(valueAxis13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double7 = xYBarRenderer6.getShadowYOffset();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        xYBarRenderer6.setBasePaint((java.awt.Paint) color8);
        boolean boolean16 = combinedDomainXYPlot4.equals((java.lang.Object) color8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        combinedDomainXYPlot4.notifyListeners(plotChangeEvent17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("");
        labelBlock20.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot25.setDomainCrosshairPaint(paint26);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, paint26);
        double double30 = rectangleInsets23.calculateLeftOutset((double) (short) 100);
        labelBlock20.setMargin(rectangleInsets23);
        combinedDomainXYPlot4.setAxisOffset(rectangleInsets23);
        barRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator34 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator34, true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        categoryPlot0.setRangePannable(false);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo("", "", "MAJOR", "DateTickUnitType.MINUTE");
        boolean boolean12 = categoryPlot0.equals((java.lang.Object) "DateTickUnitType.MINUTE");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double10 = xYBarRenderer9.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYBarRenderer9.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYSeriesCollection7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection11);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        java.awt.Font font21 = symbolAxis20.getLabelFont();
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis27 = new org.jfree.chart.axis.SymbolAxis("", strArray26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer30.setBaseCreateEntities(true);
        xYLineAndShapeRenderer30.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYLineAndShapeRenderer30.getBaseURLGenerator();
        boolean boolean36 = symbolAxis27.equals((java.lang.Object) xYURLGenerator35);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean38 = xYStepAreaRenderer37.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.axis.ValueAxis) symbolAxis27, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer37);
        combinedDomainXYPlot1.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) symbolAxis27, false);
        org.jfree.chart.util.Size2D size2D43 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker48 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker48.setStartValue(0.0d);
        float float51 = intervalMarker48.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = intervalMarker48.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D53 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D43, 1.0E-8d, 1.0E-8d, rectangleAnchor52);
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double56 = symbolAxis27.java2DToValue((double) 10.0f, rectangle2D53, rectangleEdge55);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertEquals((double) number14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.8f + "'", float51 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        boolean boolean2 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        double double3 = combinedRangeXYPlot0.getGap();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        try {
            combinedRangeXYPlot0.rendererChanged(rendererChangeEvent4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        java.lang.String[] strArray37 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis38 = new org.jfree.chart.axis.SymbolAxis("", strArray37);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer41.setBaseCreateEntities(true);
        xYLineAndShapeRenderer41.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator46 = xYLineAndShapeRenderer41.getBaseURLGenerator();
        boolean boolean47 = symbolAxis38.equals((java.lang.Object) xYURLGenerator46);
        double double48 = symbolAxis38.getAutoRangeMinimumSize();
        java.awt.Paint paint49 = symbolAxis38.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer51 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double52 = xYBarRenderer51.getShadowYOffset();
        java.awt.Color color53 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel54 = null;
        java.awt.Rectangle rectangle55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = color53.createContext(colorModel54, rectangle55, rectangle2D56, affineTransform57, renderingHints58);
        xYBarRenderer51.setBasePaint((java.awt.Paint) color53);
        symbolAxis38.setTickMarkPaint((java.awt.Paint) color53);
        symbolAxis38.setUpperMargin((double) (-1.0f));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer65 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double66 = xYBarRenderer65.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection67 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range68 = xYBarRenderer65.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection67);
        double double70 = xYSeriesCollection67.getRangeUpperBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent71 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) symbolAxis38, (org.jfree.data.general.Dataset) xYSeriesCollection67);
        combinedDomainXYPlot1.datasetChanged(datasetChangeEvent71);
        org.jfree.data.general.DatasetGroup datasetGroup73 = combinedDomainXYPlot1.getDatasetGroup();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNull(xYURLGenerator46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0E-8d + "'", double48 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 4.0d + "'", double52 == 4.0d);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 4.0d + "'", double66 == 4.0d);
        org.junit.Assert.assertNull(range68);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNull(datasetGroup73);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getShadowYOffset();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        ringPlot1.setBackgroundPaint(paint8);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        combinedDomainXYPlot1.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle20.setPadding(rectangleInsets21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme25 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color26 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color26.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        standardChartTheme25.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Color color36 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel37 = null;
        java.awt.Rectangle rectangle38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.awt.geom.AffineTransform affineTransform40 = null;
        java.awt.RenderingHints renderingHints41 = null;
        java.awt.PaintContext paintContext42 = color36.createContext(colorModel37, rectangle38, rectangle2D39, affineTransform40, renderingHints41);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color36);
        standardChartTheme25.setLegendBackgroundPaint((java.awt.Paint) color36);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot(pieDataset45);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier47 = null;
        ringPlot46.setDrawingSupplier(drawingSupplier47, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        ringPlot46.markerChanged(markerChangeEvent50);
        ringPlot46.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = ringPlot46.getSimpleLabelOffset();
        standardChartTheme25.setAxisOffset(rectangleInsets54);
        org.jfree.chart.util.Size2D size2D56 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker61 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker61.setStartValue(0.0d);
        float float64 = intervalMarker61.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = intervalMarker61.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D66 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, 1.0E-8d, 1.0E-8d, rectangleAnchor65);
        java.awt.Shape shape67 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D66);
        java.lang.String[] strArray72 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis73 = new org.jfree.chart.axis.SymbolAxis("", strArray72);
        java.lang.String str75 = symbolAxis73.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity76 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D66, (org.jfree.chart.axis.Axis) symbolAxis73);
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets54.createInsetRectangle(rectangle2D66, false, false);
        org.jfree.chart.StandardChartTheme standardChartTheme81 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer82 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer82.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke85 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer82.setBaseStroke(stroke85);
        xYStepAreaRenderer82.setOutline(true);
        java.awt.Font font89 = xYStepAreaRenderer82.getBaseItemLabelFont();
        standardChartTheme81.setSmallFont(font89);
        java.awt.Paint paint91 = standardChartTheme81.getItemLabelPaint();
        java.awt.Paint paint92 = standardChartTheme81.getThermometerPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle93 = standardChartTheme81.getLabelLinkStyle();
        try {
            java.lang.Object obj94 = legendTitle20.draw(graphics2D23, rectangle2D79, (java.lang.Object) standardChartTheme81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paintContext42);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.8f + "'", float64 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(font89);
        org.junit.Assert.assertNotNull(paint91);
        org.junit.Assert.assertNotNull(paint92);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle93);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getOuterSeparatorExtension();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot9.setDomainCrosshairPaint(paint10);
        org.jfree.chart.plot.Marker marker12 = null;
        boolean boolean13 = combinedDomainXYPlot9.removeDomainMarker(marker12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot9.setRangeAxisLocation(1, axisLocation15, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = null;
        xYBarRenderer19.setBaseToolTipGenerator(xYToolTipGenerator20, false);
        int int23 = combinedDomainXYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer19);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker30.setStartValue(0.0d);
        float float33 = intervalMarker30.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = intervalMarker30.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, 1.0E-8d, 1.0E-8d, rectangleAnchor34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.CrosshairState crosshairState39 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean40 = combinedDomainXYPlot9.render(graphics2D24, rectangle2D35, (int) (short) 0, plotRenderingInfo37, crosshairState39);
        java.awt.Color color43 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel44 = null;
        java.awt.Rectangle rectangle45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.geom.AffineTransform affineTransform47 = null;
        java.awt.RenderingHints renderingHints48 = null;
        java.awt.PaintContext paintContext49 = color43.createContext(colorModel44, rectangle45, rectangle2D46, affineTransform47, renderingHints48);
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = combinedDomainXYPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker50, layer51);
        org.jfree.chart.block.LabelBlock labelBlock54 = new org.jfree.chart.block.LabelBlock("");
        labelBlock54.setURLText("hi!");
        java.awt.Paint paint57 = labelBlock54.getPaint();
        combinedDomainXYPlot9.setDomainMinorGridlinePaint(paint57);
        ringPlot1.setLabelPaint(paint57);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.8f + "'", float33 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paintContext49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        axisSpace0.add((double) (byte) 100, rectangleEdge3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Pie 3D Plot", graphics2D1, (float) (short) -1, (float) (-2L), textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        piePlot3D1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.text.NumberFormat numberFormat6 = standardPieSectionLabelGenerator4.getNumberFormat();
        numberFormat6.setMaximumIntegerDigits(2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color12);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color12);
        java.awt.Paint paint21 = standardChartTheme1.getChartBackgroundPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-1,1,0,2", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.awt.Font font17 = symbolAxis16.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, (org.jfree.chart.axis.ValueAxis) symbolAxis16, polarItemRenderer18);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection9);
        boolean boolean21 = xYSeries2.getAutoSort();
        try {
            xYSeries2.update((java.lang.Number) 1.0f, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 1.0");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection2);
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis9 = new org.jfree.chart.axis.SymbolAxis("", strArray8);
        java.awt.Font font10 = symbolAxis9.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, (org.jfree.chart.axis.ValueAxis) symbolAxis9, polarItemRenderer11);
        polarPlot12.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double18 = xYBarRenderer17.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range20 = xYBarRenderer17.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        xYSeriesCollection15.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection19);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis28 = new org.jfree.chart.axis.SymbolAxis("", strArray27);
        java.awt.Font font29 = symbolAxis28.getLabelFont();
        java.lang.String[] strArray34 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis35 = new org.jfree.chart.axis.SymbolAxis("", strArray34);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer38.setBaseCreateEntities(true);
        xYLineAndShapeRenderer38.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator43 = xYLineAndShapeRenderer38.getBaseURLGenerator();
        boolean boolean44 = symbolAxis35.equals((java.lang.Object) xYURLGenerator43);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer45 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean46 = xYStepAreaRenderer45.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection19, (org.jfree.chart.axis.ValueAxis) symbolAxis28, (org.jfree.chart.axis.ValueAxis) symbolAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer45);
        polarPlot12.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection49 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer51 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double52 = xYBarRenderer51.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range54 = xYBarRenderer51.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        xYSeriesCollection49.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection53);
        int int56 = xYSeriesCollection53.getSeriesCount();
        polarPlot12.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        java.awt.Paint paint58 = polarPlot12.getAngleLabelPaint();
        org.jfree.data.general.PieDataset pieDataset59 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D60 = new org.jfree.chart.plot.PiePlot3D(pieDataset59);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent61 = null;
        piePlot3D60.axisChanged(axisChangeEvent61);
        boolean boolean63 = piePlot3D60.getLabelLinksVisible();
        java.awt.Stroke stroke64 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot3D60.setLabelOutlineStroke(stroke64);
        java.awt.Paint paint66 = null;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker((double) 500, 1.0d, paint58, stroke64, paint66, stroke67, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertEquals((double) number22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNull(xYURLGenerator43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 4.0d + "'", double52 == 4.0d);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        boolean boolean3 = xYStepAreaRenderer0.isShapesFilled();
        boolean boolean4 = xYStepAreaRenderer0.isOutline();
        xYStepAreaRenderer0.setSeriesItemLabelsVisible(1900, (java.lang.Boolean) true, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = combinedDomainXYPlot1.getRangeAxis(9999);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = combinedDomainXYPlot1.getAxisOffset();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        double double7 = rectangleInsets0.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedDomainXYPlot9.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo12, point2D13);
        combinedDomainXYPlot9.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = combinedDomainXYPlot9.getDomainAxisIndex(valueAxis17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.lang.String str26 = symbolAxis24.valueToString(0.0d);
        int int27 = combinedDomainXYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        boolean boolean28 = rectangleInsets0.equals((java.lang.Object) combinedDomainXYPlot9);
        double double29 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 100L, (float) (short) 1, textAnchor4, (double) 1900, textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 10L, paint3);
        java.awt.Paint paint5 = piePlot1.getBaseSectionOutlinePaint();
        piePlot1.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            double double5 = timeSeriesCollection2.getEndYValue(255, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        combinedDomainXYPlot1.setFixedRangeAxisSpace(axisSpace33);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedDomainXYPlot1);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot37 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis36);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = combinedDomainXYPlot37.getOrientation();
        combinedDomainXYPlot1.setOrientation(plotOrientation38);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(plotOrientation38);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setOuterSeparatorExtension((double) 37);
        ringPlot1.setLabelGap((double) (-2208960000000L));
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = ringPlot1.getToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        java.awt.Paint paint2 = null;
        try {
            barRenderer3D0.setShadowPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.lang.Boolean boolean8 = xYLineAndShapeRenderer2.getSeriesVisibleInLegend((int) '#');
        java.awt.Font font10 = null;
        xYLineAndShapeRenderer2.setSeriesItemLabelFont((int) (byte) 10, font10);
        java.awt.Paint paint13 = null;
        try {
            xYLineAndShapeRenderer2.setSeriesItemLabelPaint((-9999), paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        combinedRangeXYPlot11.setRangePannable(false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = combinedRangeXYPlot11.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot22.setDomainCrosshairPaint(paint23);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, paint23);
        combinedRangeXYPlot11.setAxisOffset(rectangleInsets20);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setVersion("Range[9999.0,2958465.0]");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo3.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo6);
        java.util.List list8 = projectInfo6.getContributors();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        java.util.Date date10 = dateRange9.getLowerDate();
        try {
            org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list8, (org.jfree.data.Range) dateRange9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.ui.Contributor cannot be cast to java.lang.Comparable");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TimePeriodAnchor.START", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker5.setStartValue(0.0d);
        float float8 = intervalMarker5.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = intervalMarker5.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 1.0E-8d, 1.0E-8d, rectangleAnchor9);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D10);
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("", strArray16);
        java.lang.String str19 = symbolAxis17.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D10, (org.jfree.chart.axis.Axis) symbolAxis17);
        axisEntity20.setToolTipText("[size=10]");
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8f + "'", float8 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getGridBandPaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        standardChartTheme1.setThermometerPaint(paint12);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer15.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer15.setBaseStroke(stroke18);
        xYStepAreaRenderer15.setOutline(true);
        java.awt.Font font22 = xYStepAreaRenderer15.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis23);
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot24.setDomainCrosshairPaint(paint25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font22, (org.jfree.chart.plot.Plot) combinedDomainXYPlot24, false);
        java.lang.Object obj29 = jFreeChart28.clone();
        java.awt.RenderingHints renderingHints30 = jFreeChart28.getRenderingHints();
        standardChartTheme1.apply(jFreeChart28);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(renderingHints30);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        java.lang.String str35 = symbolAxis33.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity37 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D27, (org.jfree.chart.axis.Axis) symbolAxis33, "Pie 3D Plot");
        try {
            combinedRangeXYPlot11.drawOutline(graphics2D16, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) combinedDomainXYPlot11, false);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = labelBlock16.getPadding();
        java.awt.Paint paint18 = labelBlock16.getPaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis14 = new org.jfree.chart.axis.SymbolAxis("", strArray13);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer17.setBaseCreateEntities(true);
        xYLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYLineAndShapeRenderer17.getBaseURLGenerator();
        boolean boolean23 = symbolAxis14.equals((java.lang.Object) xYURLGenerator22);
        double double24 = symbolAxis14.getAutoRangeMinimumSize();
        java.awt.Paint paint25 = symbolAxis14.getLabelPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection26);
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        java.awt.Font font34 = symbolAxis33.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, polarItemRenderer35);
        boolean boolean37 = symbolAxis14.hasListener((java.util.EventListener) xYSeriesCollection26);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis38.setTickMarkPosition(dateTickMarkPosition39);
        java.text.DateFormat dateFormat41 = null;
        dateAxis38.setDateFormatOverride(dateFormat41);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition44 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis43.setTickMarkPosition(dateTickMarkPosition44);
        java.text.DateFormat dateFormat46 = null;
        dateAxis43.setDateFormatOverride(dateFormat46);
        boolean boolean48 = dateAxis43.isTickMarksVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { symbolAxis14, dateAxis38, dateAxis43 };
        combinedDomainXYPlot1.setRangeAxes(valueAxisArray49);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(dateTickMarkPosition44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(valueAxisArray49);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeriesCollection3.getSeries((java.lang.Comparable) 1900);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection3, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer3D0.getBarPainter();
        boolean boolean3 = barRenderer3D0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("MAJOR", numberFormat1, numberFormat4);
        numberFormat1.setParseIntegerOnly(true);
        numberFormat1.setMinimumFractionDigits(10);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "LengthConstraintType.NONE", "PlotOrientation.VERTICAL", image3, "Oct", "Pie 3D Plot", "ThreadContext");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        ringPlot1.setInnerSeparatorExtension((double) (byte) -1);
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis12 = new org.jfree.chart.axis.SymbolAxis("", strArray11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer15.setBaseCreateEntities(true);
        xYLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = xYLineAndShapeRenderer15.getBaseURLGenerator();
        boolean boolean21 = symbolAxis12.equals((java.lang.Object) xYURLGenerator20);
        double double22 = symbolAxis12.getAutoRangeMinimumSize();
        java.awt.Paint paint23 = symbolAxis12.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double26 = xYBarRenderer25.getShadowYOffset();
        java.awt.Color color27 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        xYBarRenderer25.setBasePaint((java.awt.Paint) color27);
        symbolAxis12.setTickMarkPaint((java.awt.Paint) color27);
        symbolAxis12.setUpperMargin((double) (-1.0f));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double40 = xYBarRenderer39.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection41 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range42 = xYBarRenderer39.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection41);
        double double44 = xYSeriesCollection41.getRangeUpperBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) symbolAxis12, (org.jfree.data.general.Dataset) xYSeriesCollection41);
        ringPlot1.datasetChanged(datasetChangeEvent45);
        double double47 = ringPlot1.getSectionDepth();
        boolean boolean48 = ringPlot1.isSubplot();
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNull(xYURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.2d + "'", double47 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) ' ', "LengthConstraintType.NONE");
        double double4 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        java.util.List list2 = timeSeriesCollection1.getSeries();
        try {
            double double5 = timeSeriesCollection1.getXValue(15, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Object obj3 = numberFormat0.parseObject("Polar Plot", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer29.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer29.setBaseStroke(stroke32);
        xYStepAreaRenderer29.setOutline(true);
        xYStepAreaRenderer29.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer39.setRangeBase((double) (short) 10);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot44 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        combinedDomainXYPlot44.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo47, point2D48);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = combinedDomainXYPlot44.getRangeMarkers(12, layer51);
        java.lang.String[] strArray57 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis58 = new org.jfree.chart.axis.SymbolAxis("", strArray57);
        boolean boolean59 = symbolAxis58.getAutoRangeStickyZero();
        java.lang.String str61 = symbolAxis58.valueToString((double) (byte) 10);
        java.awt.Font font62 = symbolAxis58.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer65 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double66 = xYBarRenderer65.getShadowYOffset();
        java.awt.Color color67 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel68 = null;
        java.awt.Rectangle rectangle69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.awt.geom.AffineTransform affineTransform71 = null;
        java.awt.RenderingHints renderingHints72 = null;
        java.awt.PaintContext paintContext73 = color67.createContext(colorModel68, rectangle69, rectangle2D70, affineTransform71, renderingHints72);
        xYBarRenderer65.setBasePaint((java.awt.Paint) color67);
        org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color67);
        java.lang.Comparable comparable76 = legendItem75.getSeriesKey();
        legendItem75.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D79 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker84 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker84.setStartValue(0.0d);
        float float87 = intervalMarker84.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = intervalMarker84.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D89 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D79, 1.0E-8d, 1.0E-8d, rectangleAnchor88);
        java.awt.Shape shape90 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D89);
        legendItem75.setLine((java.awt.Shape) rectangle2D89);
        xYStepAreaRenderer39.fillDomainGridBand(graphics2D42, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot44, (org.jfree.chart.axis.ValueAxis) symbolAxis58, rectangle2D89, 1.0d, (double) (-2208960000000L));
        xYStepAreaRenderer29.setSeriesShape(255, (java.awt.Shape) rectangle2D89);
        symbolAxis5.setDownArrow((java.awt.Shape) rectangle2D89);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 4.0d + "'", double66 == 4.0d);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(paintContext73);
        org.junit.Assert.assertNull(comparable76);
        org.junit.Assert.assertTrue("'" + float87 + "' != '" + 0.8f + "'", float87 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertNotNull(shape90);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double7 = xYBarRenderer6.getShadowYOffset();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        xYBarRenderer6.setBasePaint((java.awt.Paint) color8);
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color8);
        java.lang.Comparable comparable17 = legendItem16.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot19.setDomainCrosshairPaint(paint20);
        org.jfree.chart.plot.Marker marker22 = null;
        boolean boolean23 = combinedDomainXYPlot19.removeDomainMarker(marker22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot19.setRangeAxisLocation(1, axisLocation25, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator30 = null;
        xYBarRenderer29.setBaseToolTipGenerator(xYToolTipGenerator30, false);
        int int33 = combinedDomainXYPlot19.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer29);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker40.setStartValue(0.0d);
        float float43 = intervalMarker40.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = intervalMarker40.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, 1.0E-8d, 1.0E-8d, rectangleAnchor44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.chart.plot.CrosshairState crosshairState49 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean50 = combinedDomainXYPlot19.render(graphics2D34, rectangle2D45, (int) (short) 0, plotRenderingInfo47, crosshairState49);
        legendItem16.setShape((java.awt.Shape) rectangle2D45);
        barRenderer3D0.setBaseShape((java.awt.Shape) rectangle2D45, false);
        org.jfree.chart.renderer.category.BarPainter barPainter54 = barRenderer3D0.getBarPainter();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNull(comparable17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.8f + "'", float43 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(barPainter54);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        double double11 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        labelBlock1.setMargin(rectangleInsets4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = labelBlock1.getTextAnchor();
        org.jfree.chart.block.BlockFrame blockFrame14 = labelBlock1.getFrame();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toFixedHeight((double) (short) 1);
        try {
            org.jfree.chart.util.Size2D size2D19 = labelBlock1.arrange(graphics2D15, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(blockFrame14);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        xYLineAndShapeRenderer2.setLegendShape(5, shape7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.entity.XYItemEntity xYItemEntity14 = new org.jfree.chart.entity.XYItemEntity(shape7, xYDataset9, (int) (byte) 1, 9999, "[size=1]", "Polar Plot");
        org.jfree.data.xy.XYDataset xYDataset15 = xYItemEntity14.getDataset();
        xYItemEntity14.setItem(0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(xYDataset15);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        piePlot3D1.setCircular(false, false);
        double double9 = piePlot3D1.getLabelLinkMargin();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color10);
        java.awt.color.ColorSpace colorSpace12 = color10.getColorSpace();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace12);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        boolean boolean3 = combinedDomainXYPlot1.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis4 = combinedDomainXYPlot1.getRangeAxis();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double10 = xYBarRenderer9.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYBarRenderer9.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYSeriesCollection7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection11);
        java.util.List list14 = xYSeriesCollection11.getSeries();
        try {
            categoryPlot0.mapDatasetToRangeAxes(9999, list14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot7.setDomainCrosshairPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, paint8);
        xYLineAndShapeRenderer2.setBaseLegendTextPaint(paint8);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        xYLineAndShapeRenderer2.setSeriesShape(9999, shape14);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator16 = xYLineAndShapeRenderer2.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(xYItemLabelGenerator16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedDomainXYPlot6.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo9, point2D10);
        combinedDomainXYPlot6.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = combinedDomainXYPlot6.getDomainAxisIndex(valueAxis14);
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis21 = new org.jfree.chart.axis.SymbolAxis("", strArray20);
        java.lang.String str23 = symbolAxis21.valueToString(0.0d);
        int int24 = combinedDomainXYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis21);
        double double25 = symbolAxis21.getAutoRangeMinimumSize();
        categoryPlot0.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) symbolAxis21, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0E-8d + "'", double25 == 1.0E-8d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        xYLineAndShapeRenderer2.setDrawOutlines(true);
        boolean boolean17 = xYLineAndShapeRenderer2.getItemVisible((int) (short) -1, 13);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator22 = new org.jfree.chart.urls.StandardXYURLGenerator("-1,1,0,2", "MAJOR", "UnitType.ABSOLUTE");
        xYLineAndShapeRenderer2.setSeriesURLGenerator((int) (short) 100, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator22);
        boolean boolean24 = xYLineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        java.awt.geom.GeneralPath generalPath14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.RenderingSource renderingSource16 = null;
        combinedDomainXYPlot1.select(generalPath14, rectangle2D15, renderingSource16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setRangePannable(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState27.updateCrosshairY(0.0d, (int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot36 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis35);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = combinedDomainXYPlot36.getOrientation();
        crosshairState27.updateCrosshairPoint(12.0d, 0.0d, 0.0d, 3.0d, plotOrientation37);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection39 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection39);
        java.lang.String[] strArray45 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis46 = new org.jfree.chart.axis.SymbolAxis("", strArray45);
        java.awt.Font font47 = symbolAxis46.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer48 = null;
        org.jfree.chart.plot.PolarPlot polarPlot49 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection39, (org.jfree.chart.axis.ValueAxis) symbolAxis46, polarItemRenderer48);
        boolean boolean50 = polarPlot49.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        polarPlot49.zoomRangeAxes((double) (byte) -1, plotRenderingInfo52, point2D53);
        org.jfree.chart.util.Size2D size2D57 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D57, (double) (-1.0f), (double) 1L, rectangleAnchor60);
        java.awt.Point point62 = polarPlot49.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D61);
        crosshairState27.setAnchor((java.awt.geom.Point2D) point62);
        categoryPlot20.zoomRangeAxes((double) 1900, (double) 0.0f, plotRenderingInfo25, (java.awt.geom.Point2D) point62);
        combinedDomainXYPlot1.panDomainAxes((double) (byte) 1, plotRenderingInfo19, (java.awt.geom.Point2D) point62);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(point62);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        double double11 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        labelBlock1.setMargin(rectangleInsets4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = labelBlock1.getTextAnchor();
        org.jfree.chart.block.BlockFrame blockFrame14 = labelBlock1.getFrame();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = labelBlock1.getContentAlignmentPoint();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(blockFrame14);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        java.awt.Paint paint9 = combinedDomainXYPlot8.getRangeZeroBaselinePaint();
        boolean boolean10 = combinedDomainXYPlot8.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker13.setStartValue(0.0d);
        float float16 = intervalMarker13.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = intervalMarker13.getLabelOffsetType();
        boolean boolean18 = combinedDomainXYPlot8.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = categoryPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) intervalMarker13, layer19, false);
        categoryPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection27);
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis34 = new org.jfree.chart.axis.SymbolAxis("", strArray33);
        java.awt.Font font35 = symbolAxis34.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection27, (org.jfree.chart.axis.ValueAxis) symbolAxis34, polarItemRenderer36);
        boolean boolean38 = polarPlot37.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        polarPlot37.zoomRangeAxes((double) (byte) -1, plotRenderingInfo40, point2D41);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, (double) (-1.0f), (double) 1L, rectangleAnchor48);
        java.awt.Point point50 = polarPlot37.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D49);
        categoryPlot0.zoomRangeAxes((double) 2, (double) (-1), plotRenderingInfo26, (java.awt.geom.Point2D) point50);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.8f + "'", float16 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(point50);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.lang.Object obj15 = jFreeChart14.clone();
        java.awt.RenderingHints renderingHints16 = jFreeChart14.getRenderingHints();
        boolean boolean17 = jFreeChart14.isBorderVisible();
        boolean boolean18 = jFreeChart14.isNotify();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setAnchorValue((double) 4);
        int int5 = categoryPlot2.getRendererCount();
        boolean boolean6 = lineBorder0.equals((java.lang.Object) int5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        double double3 = blockParams0.getTranslateY();
        blockParams0.setTranslateX((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer3.setBaseCreateEntities(true);
        int int6 = xYLineAndShapeRenderer3.getPassCount();
        boolean boolean7 = xYLineAndShapeRenderer3.getUseFillPaint();
        java.lang.Boolean boolean9 = xYLineAndShapeRenderer3.getSeriesVisibleInLegend((int) '#');
        java.awt.Font font11 = null;
        xYLineAndShapeRenderer3.setSeriesItemLabelFont((int) (byte) 10, font11);
        boolean boolean13 = standardPieToolTipGenerator0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        symbolAxis5.setLowerMargin((double) (short) 1);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) symbolAxis5, (java.awt.Shape) rectangle2D21, "ThreadContext", "{0}: ({1}, {2})");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = standardChartTheme1.getAxisOffset();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        standardChartTheme1.setChartBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYBarRenderer14.notifyListeners(rendererChangeEvent15);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter17 = xYBarRenderer14.getBarPainter();
        boolean boolean18 = standardChartTheme1.equals((java.lang.Object) xYBarPainter17);
        org.jfree.chart.StandardChartTheme standardChartTheme20 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer21.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer21.setBaseStroke(stroke24);
        xYStepAreaRenderer21.setOutline(true);
        java.awt.Font font28 = xYStepAreaRenderer21.getBaseItemLabelFont();
        standardChartTheme20.setSmallFont(font28);
        java.awt.Paint paint30 = standardChartTheme20.getItemLabelPaint();
        java.awt.Paint paint31 = standardChartTheme20.getThermometerPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle32 = standardChartTheme20.getLabelLinkStyle();
        java.awt.Paint paint33 = standardChartTheme20.getCrosshairPaint();
        standardChartTheme1.setTickLabelPaint(paint33);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(xYBarPainter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2, (java.lang.Number) (short) 100);
        boolean boolean3 = xYDataItem2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        labelBlock2.setURLText("hi!");
        boolean boolean5 = itemLabelAnchor0.equals((java.lang.Object) "hi!");
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.util.List list7 = xYSeriesCollection4.getSeries();
        org.jfree.data.DomainOrder domainOrder8 = xYSeriesCollection4.getDomainOrder();
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertEquals((double) number9, Double.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 10L, paint3);
        java.awt.Paint paint5 = piePlot1.getBaseSectionOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        xYBarRenderer1.setLegendBar(shape6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer1.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke10 = xYBarRenderer1.getSeriesStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(itemLabelPosition11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.awt.Paint paint47 = polarPlot10.getAngleLabelPaint();
        java.lang.String str48 = polarPlot10.getPlotType();
        boolean boolean49 = polarPlot10.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        polarPlot10.zoomRangeAxes((double) 0.5f, (double) (byte) 10, plotRenderingInfo52, point2D53);
        polarPlot10.zoom(Double.NaN);
        java.awt.Paint paint57 = polarPlot10.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Polar Plot" + "'", str48.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        jFreeChart14.handleClick((int) (byte) 0, 10, chartRenderingInfo19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color21);
        jFreeChart14.setBorderVisible(false);
        org.jfree.chart.title.Title title25 = null;
        try {
            jFreeChart14.addSubtitle(title25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot59 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot59.setRangeAxisLocation(axisLocation60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot64 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis63);
        java.awt.Paint paint65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot64.setDomainCrosshairPaint(paint65);
        org.jfree.chart.block.BlockBorder blockBorder67 = new org.jfree.chart.block.BlockBorder(rectangleInsets62, paint65);
        combinedDomainXYPlot59.setOutlinePaint(paint65);
        org.jfree.chart.axis.ValueAxis valueAxis69 = combinedDomainXYPlot59.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation70 = combinedDomainXYPlot59.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation70, true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor73 = categoryPlot6.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(categoryAnchor73);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        double double7 = rectangleInsets0.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedDomainXYPlot9.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo12, point2D13);
        combinedDomainXYPlot9.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = combinedDomainXYPlot9.getDomainAxisIndex(valueAxis17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.lang.String str26 = symbolAxis24.valueToString(0.0d);
        int int27 = combinedDomainXYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        boolean boolean28 = rectangleInsets0.equals((java.lang.Object) combinedDomainXYPlot9);
        org.jfree.chart.util.UnitType unitType29 = rectangleInsets0.getUnitType();
        java.lang.String str30 = unitType29.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnitType.ABSOLUTE" + "'", str30.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        java.awt.Image image13 = null;
        combinedDomainXYPlot1.setBackgroundImage(image13);
        java.awt.Paint paint15 = combinedDomainXYPlot1.getBackgroundPaint();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        double double2 = axisSpace0.getRight();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace0.ensureAtLeast(100.0d, rectangleEdge4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.mapDatasetToRangeAxis(3, (-1));
        java.lang.Object obj10 = categoryPlot0.clone();
        int int11 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        try {
            int int3 = timeSeriesCollection1.getItemCount((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        double double4 = intervalXYDelegate2.getDomainUpperBound(false);
        try {
            java.lang.Number number7 = intervalXYDelegate2.getEndX(8, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter4 = xYBarRenderer1.getBarPainter();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter5 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        xYBarRenderer1.setBarPainter(xYBarPainter5);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer8.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer8.setBaseStroke(stroke11);
        try {
            xYBarRenderer1.setSeriesOutlineStroke((int) (byte) -1, stroke11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYBarPainter4);
        org.junit.Assert.assertNotNull(xYBarPainter5);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYLineAndShapeRenderer2.getBaseURLGenerator();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double12 = xYBarRenderer11.getShadowYOffset();
        java.awt.Color color13 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        xYBarRenderer11.setBasePaint((java.awt.Paint) color13);
        boolean boolean21 = combinedDomainXYPlot9.equals((java.lang.Object) color13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        combinedDomainXYPlot9.notifyListeners(plotChangeEvent22);
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("");
        labelBlock25.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis29);
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot30.setDomainCrosshairPaint(paint31);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder(rectangleInsets28, paint31);
        double double35 = rectangleInsets28.calculateLeftOutset((double) (short) 100);
        labelBlock25.setMargin(rectangleInsets28);
        combinedDomainXYPlot9.setAxisOffset(rectangleInsets28);
        int int38 = combinedDomainXYPlot9.getRangeAxisCount();
        boolean boolean39 = xYLineAndShapeRenderer2.equals((java.lang.Object) combinedDomainXYPlot9);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation40 = null;
        try {
            xYLineAndShapeRenderer2.addAnnotation(xYAnnotation40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        symbolAxis16.setGridBandsVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = xYBarRenderer1.getBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Color color2 = java.awt.Color.BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) (short) 100, (java.awt.Paint) color2);
        java.awt.Paint paint4 = intervalMarker3.getPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) combinedDomainXYPlot11, false);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("", font9);
        java.lang.String str17 = labelBlock16.getID();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        xYSeries2.clear();
        try {
            java.lang.Number number5 = xYSeries2.getX((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 10);
        java.lang.Object obj2 = null;
        int int3 = numberTickUnit1.compareTo(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.awt.Color color15 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color15.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        int int22 = color15.getBlue();
        jFreeChart14.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart14.removeChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        xYLineAndShapeRenderer2.setLegendShape(5, shape7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.entity.XYItemEntity xYItemEntity14 = new org.jfree.chart.entity.XYItemEntity(shape7, xYDataset9, (int) (byte) 1, 9999, "[size=1]", "Polar Plot");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double17 = xYBarRenderer16.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range19 = xYBarRenderer16.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18);
        xYItemEntity14.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection18);
        java.lang.String str21 = xYItemEntity14.toString();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem4 = xYSeries2.remove((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setAnchorValue((double) 4);
        categoryPlot3.setRangePannable(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            boolean boolean11 = xYPlot0.removeAnnotation(xYAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color2 = java.awt.Color.GRAY;
        xYStepAreaRenderer0.setBaseFillPaint((java.awt.Paint) color2, false);
        java.awt.Shape shape6 = xYStepAreaRenderer0.getLegendShape(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        blockParams0.setGenerateEntities(false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.awt.Paint paint47 = polarPlot10.getAngleLabelPaint();
        java.lang.String str48 = polarPlot10.getPlotType();
        boolean boolean49 = polarPlot10.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        polarPlot10.zoomRangeAxes((double) 0.5f, (double) (byte) 10, plotRenderingInfo52, point2D53);
        java.awt.Paint paint55 = polarPlot10.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = polarPlot10.getOrientation();
        java.awt.Font font57 = polarPlot10.getAngleLabelFont();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Polar Plot" + "'", str48.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(font57);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Paint paint6 = symbolAxis5.getGridBandAlternatePaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (-1.0f), (double) 1L, rectangleAnchor12);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        combinedDomainXYPlot16.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo19, point2D20);
        combinedDomainXYPlot16.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        int int25 = combinedDomainXYPlot16.getDomainAxisIndex(valueAxis24);
        java.lang.String[] strArray30 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis31 = new org.jfree.chart.axis.SymbolAxis("", strArray30);
        java.lang.String str33 = symbolAxis31.valueToString(0.0d);
        int int34 = combinedDomainXYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis31);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = combinedDomainXYPlot16.getDomainMarkers((-9999), layer36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedDomainXYPlot16.getDomainAxisEdge((int) (byte) 0);
        double double40 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D13, rectangleEdge39);
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D43 = labelBlock42.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            org.jfree.chart.axis.AxisState axisState46 = symbolAxis5.draw(graphics2D7, 1484232.0d, rectangle2D13, rectangle2D43, rectangleEdge44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        barRenderer3D0.setItemLabelAnchorOffset(1.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = barRenderer3D0.getPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation61 = null;
        org.jfree.chart.util.Layer layer62 = null;
        try {
            barRenderer3D0.addAnnotation(categoryAnnotation61, layer62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNull(categoryPlot60);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat2, dateFormat3);
        xYStepAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        int int11 = xYLineAndShapeRenderer8.getPassCount();
        boolean boolean12 = xYLineAndShapeRenderer8.getUseFillPaint();
        java.lang.Object obj13 = xYLineAndShapeRenderer8.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYBarRenderer15.setBaseToolTipGenerator(xYToolTipGenerator16, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        xYBarRenderer15.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition20, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYBarRenderer15.getBasePositiveItemLabelPosition();
        xYLineAndShapeRenderer8.setBaseNegativeItemLabelPosition(itemLabelPosition23, false);
        xYStepAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition23, false);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot(pieDataset28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = null;
        ringPlot29.setDrawingSupplier(drawingSupplier30, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        ringPlot29.markerChanged(markerChangeEvent33);
        ringPlot29.setLabelGap(0.0d);
        java.awt.Paint paint37 = ringPlot29.getBaseSectionPaint();
        ringPlot29.setSimpleLabels(false);
        boolean boolean40 = ringPlot29.getSeparatorsVisible();
        boolean boolean41 = itemLabelPosition23.equals((java.lang.Object) boolean40);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getItemLabelPaint();
        java.awt.Paint paint12 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint14 = standardChartTheme1.getCrosshairPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter15 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        standardChartTheme1.setXYBarPainter(xYBarPainter15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(xYBarPainter15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(255, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        categoryPlot0.clearDomainMarkers((-1));
        boolean boolean8 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        java.awt.Paint paint14 = combinedDomainXYPlot1.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYLineAndShapeRenderer2.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Color color1 = java.awt.Color.lightGray;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer10.setRangeBase((double) (short) 10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedDomainXYPlot15.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo18, point2D19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = combinedDomainXYPlot15.getRangeMarkers(12, layer22);
        java.lang.String[] strArray28 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis29 = new org.jfree.chart.axis.SymbolAxis("", strArray28);
        boolean boolean30 = symbolAxis29.getAutoRangeStickyZero();
        java.lang.String str32 = symbolAxis29.valueToString((double) (byte) 10);
        java.awt.Font font33 = symbolAxis29.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double37 = xYBarRenderer36.getShadowYOffset();
        java.awt.Color color38 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color38.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        xYBarRenderer36.setBasePaint((java.awt.Paint) color38);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color38);
        java.lang.Comparable comparable47 = legendItem46.getSeriesKey();
        legendItem46.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D50 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker55 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker55.setStartValue(0.0d);
        float float58 = intervalMarker55.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = intervalMarker55.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D50, 1.0E-8d, 1.0E-8d, rectangleAnchor59);
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D60);
        legendItem46.setLine((java.awt.Shape) rectangle2D60);
        xYStepAreaRenderer10.fillDomainGridBand(graphics2D13, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) symbolAxis29, rectangle2D60, 1.0d, (double) (-2208960000000L));
        xYStepAreaRenderer0.setSeriesShape(255, (java.awt.Shape) rectangle2D60);
        boolean boolean67 = xYStepAreaRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertNull(comparable47);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.8f + "'", float58 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis22 = new org.jfree.chart.axis.SymbolAxis("", strArray21);
        combinedRangeXYPlot11.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) symbolAxis22);
        int int24 = symbolAxis22.getMinorTickCount();
        org.jfree.data.Range range25 = symbolAxis22.getDefaultAutoRange();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.awt.Font font14 = symbolAxis13.getLabelFont();
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer23.setBaseCreateEntities(true);
        xYLineAndShapeRenderer23.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYLineAndShapeRenderer23.getBaseURLGenerator();
        boolean boolean29 = symbolAxis20.equals((java.lang.Object) xYURLGenerator28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean31 = xYStepAreaRenderer30.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer30);
        boolean boolean33 = xYPlot32.isDomainMinorGridlinesVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation34 = null;
        try {
            xYPlot32.addAnnotation(xYAnnotation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        combinedDomainXYPlot1.setOutlinePaint(paint7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = combinedDomainXYPlot1.getSeriesRenderingOrder();
        combinedDomainXYPlot1.clearSelection();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder();
        boolean boolean2 = datasetGroup0.equals((java.lang.Object) blockBorder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "{0}: ({1}, {2})", (java.lang.Number) 1900);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot4.setDomainCrosshairPaint(paint5);
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot4.setRangeAxisLocation(1, axisLocation10, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYBarRenderer14.setBaseToolTipGenerator(xYToolTipGenerator15, false);
        int int18 = combinedDomainXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        combinedDomainXYPlot1.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = combinedDomainXYPlot1.getDomainAxisLocation((int) (byte) 10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        combinedDomainXYPlot1.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle20.setPadding(rectangleInsets21);
        org.jfree.chart.block.BlockContainer blockContainer23 = legendTitle20.getWrapper();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot(pieDataset24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        ringPlot25.setDrawingSupplier(drawingSupplier26, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        ringPlot25.markerChanged(markerChangeEvent29);
        ringPlot25.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = ringPlot25.getSimpleLabelOffset();
        try {
            blockContainer23.setMargin(rectangleInsets33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(blockContainer23);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.notifyListeners(plotChangeEvent14);
        combinedDomainXYPlot1.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 0.5f, (double) 0.8f);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = combinedDomainXYPlot1.removeRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker21, layer22);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getShadowYOffset();
        boolean boolean8 = ringPlot1.getAutoPopulateSectionOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ringPlot1);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter4 = xYBarRenderer1.getBarPainter();
        java.awt.Paint paint8 = xYBarRenderer1.getItemFillPaint(2147483647, (-1), false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer12.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer12.setBaseStroke(stroke15);
        xYStepAreaRenderer12.setOutline(true);
        java.awt.Font font19 = xYStepAreaRenderer12.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis20);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot21.setDomainCrosshairPaint(paint22);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("", font19, (org.jfree.chart.plot.Plot) combinedDomainXYPlot21, false);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font19);
        xYBarRenderer1.setSeriesItemLabelFont(37, font19);
        org.junit.Assert.assertNotNull(xYBarPainter4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = combinedDomainXYPlot2.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation3);
        org.junit.Assert.assertNotNull(plotOrientation3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.lang.String str18 = symbolAxis16.valueToString(0.0d);
        int int19 = combinedDomainXYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis16);
        combinedDomainXYPlot1.configureRangeAxes();
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        standardChartTheme24.setTickLabelPaint((java.awt.Paint) color25);
        java.awt.color.ColorSpace colorSpace33 = color25.getColorSpace();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer34.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer34.setBaseStroke(stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 'a', (java.awt.Paint) color25, stroke37);
        org.jfree.chart.util.Layer layer40 = null;
        combinedDomainXYPlot1.addRangeMarker(5, (org.jfree.chart.plot.Marker) valueMarker39, layer40);
        boolean boolean42 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        double double18 = symbolAxis8.getAutoRangeMinimumSize();
        java.awt.Paint paint19 = symbolAxis8.getLabelPaint();
        int int20 = combinedDomainXYPlot1.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis8);
        symbolAxis8.setLowerMargin((double) 2);
        java.awt.Paint paint23 = symbolAxis8.getLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedDomainXYPlot3.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo6, point2D7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedDomainXYPlot3.getRangeMarkers(12, layer10);
        int int12 = combinedDomainXYPlot3.getDatasetCount();
        combinedDomainXYPlot3.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        combinedDomainXYPlot3.panRangeAxes((double) 1L, plotRenderingInfo17, point2D18);
        combinedDomainXYPlot3.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot3);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis23);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double27 = xYBarRenderer26.getShadowYOffset();
        java.awt.Color color28 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        xYBarRenderer26.setBasePaint((java.awt.Paint) color28);
        boolean boolean36 = combinedDomainXYPlot24.equals((java.lang.Object) color28);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent37 = null;
        combinedDomainXYPlot24.notifyListeners(plotChangeEvent37);
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("");
        labelBlock40.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot45 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis44);
        java.awt.Paint paint46 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot45.setDomainCrosshairPaint(paint46);
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder(rectangleInsets43, paint46);
        double double50 = rectangleInsets43.calculateLeftOutset((double) (short) 100);
        labelBlock40.setMargin(rectangleInsets43);
        combinedDomainXYPlot24.setAxisOffset(rectangleInsets43);
        double double53 = rectangleInsets43.getRight();
        legendTitle22.setItemLabelPadding(rectangleInsets43);
        org.jfree.chart.util.Size2D size2D55 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker60.setStartValue(0.0d);
        float float63 = intervalMarker60.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = intervalMarker60.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D65 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D55, 1.0E-8d, 1.0E-8d, rectangleAnchor64);
        java.awt.Shape shape66 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D65);
        try {
            blockContainer1.add((org.jfree.chart.block.Block) legendTitle22, (java.lang.Object) shape66);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.geom.Rectangle2D$Double cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 3.0d + "'", double50 == 3.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.0d + "'", double53 == 3.0d);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.8f + "'", float63 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(shape66);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        boolean boolean17 = symbolAxis16.getAutoRangeStickyZero();
        java.lang.String str19 = symbolAxis16.valueToString((double) (byte) 10);
        java.awt.Font font20 = symbolAxis16.getTickLabelFont();
        standardChartTheme1.setSmallFont(font20);
        java.awt.Paint paint22 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint23 = null;
        try {
            standardChartTheme1.setChartBackgroundPaint(paint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("-1,1,0,2", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        double double11 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        labelBlock1.setMargin(rectangleInsets4);
        double double14 = rectangleInsets4.calculateRightOutset((double) (short) 0);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection3);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis10 = new org.jfree.chart.axis.SymbolAxis("", strArray9);
        java.awt.Font font11 = symbolAxis10.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, (org.jfree.chart.axis.ValueAxis) symbolAxis10, polarItemRenderer12);
        boolean boolean14 = polarPlot13.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        polarPlot13.zoomRangeAxes((double) 2958465, 0.025d, plotRenderingInfo17, point2D18);
        boolean boolean20 = polarPlot13.isRangeZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker23.setStartValue(0.0d);
        float float26 = intervalMarker23.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = intervalMarker23.getLabelAnchor();
        java.awt.Font font28 = intervalMarker23.getLabelFont();
        polarPlot13.setAngleLabelFont(font28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        combinedDomainXYPlot33.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo36, point2D37);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = combinedDomainXYPlot33.getRangeMarkers(12, layer40);
        int int42 = combinedDomainXYPlot33.getDatasetCount();
        combinedDomainXYPlot33.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        combinedDomainXYPlot33.panRangeAxes((double) 1L, plotRenderingInfo47, point2D48);
        java.awt.geom.Point2D point2D50 = combinedDomainXYPlot33.getQuadrantOrigin();
        polarPlot13.zoomRangeAxes((double) (short) 1, plotRenderingInfo31, point2D50);
        try {
            combinedRangeXYPlot0.zoomDomainAxes(0.025d, plotRenderingInfo2, point2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.8f + "'", float26 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.awt.Font font14 = symbolAxis13.getLabelFont();
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer23.setBaseCreateEntities(true);
        xYLineAndShapeRenderer23.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYLineAndShapeRenderer23.getBaseURLGenerator();
        boolean boolean29 = symbolAxis20.equals((java.lang.Object) xYURLGenerator28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean31 = xYStepAreaRenderer30.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer30);
        boolean boolean33 = xYPlot32.isDomainMinorGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot32.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(legendItemCollection34);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        try {
            int int15 = xYSeriesCollection10.getItemCount((-456));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertEquals((double) number13, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        double double18 = symbolAxis8.getAutoRangeMinimumSize();
        java.awt.Paint paint19 = symbolAxis8.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double22 = xYBarRenderer21.getShadowYOffset();
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        xYBarRenderer21.setBasePaint((java.awt.Paint) color23);
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color23);
        symbolAxis8.setUpperMargin((double) (-1.0f));
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot35 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        combinedDomainXYPlot35.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo38, point2D39);
        combinedDomainXYPlot35.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint43 = combinedDomainXYPlot35.getRangeZeroBaselinePaint();
        symbolAxis8.setTickLabelPaint(paint43);
        org.jfree.data.Range range45 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis8);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = standardChartTheme1.getAxisOffset();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        standardChartTheme1.setChartBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYBarRenderer14.notifyListeners(rendererChangeEvent15);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter17 = xYBarRenderer14.getBarPainter();
        boolean boolean18 = standardChartTheme1.equals((java.lang.Object) xYBarPainter17);
        standardChartTheme1.setShadowVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(xYBarPainter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        xYBarRenderer2.notifyListeners(rendererChangeEvent3);
        boolean boolean7 = xYBarRenderer2.getItemVisible((int) (byte) 1, (int) (short) 0);
        java.awt.Font font9 = xYBarRenderer2.getSeriesItemLabelFont((int) 'a');
        java.awt.Font font11 = xYBarRenderer2.lookupLegendTextFont(2);
        xYBarRenderer2.setBarAlignmentFactor((double) 5);
        boolean boolean14 = datasetRenderingOrder0.equals((java.lang.Object) xYBarRenderer2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        double double5 = ringPlot1.getMinimumArcAngleToDraw();
        double double6 = ringPlot1.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        java.awt.Color color15 = java.awt.Color.BLUE;
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color15);
        symbolAxis5.setTickMarkInsideLength((float) 100L);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection47 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double50 = xYBarRenderer49.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range52 = xYBarRenderer49.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        xYSeriesCollection47.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection51);
        int int54 = xYSeriesCollection51.getSeriesCount();
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType56 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.lang.String str57 = dateTickUnitType56.toString();
        java.lang.String str58 = dateTickUnitType56.toString();
        org.jfree.chart.axis.DateTickUnit dateTickUnit60 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType56, (int) ' ');
        int int61 = dateTickUnit60.getCalendarField();
        int int62 = xYSeriesCollection51.indexOf((java.lang.Comparable) dateTickUnit60);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(dateTickUnitType56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "DateTickUnitType.MINUTE" + "'", str57.equals("DateTickUnitType.MINUTE"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "DateTickUnitType.MINUTE" + "'", str58.equals("DateTickUnitType.MINUTE"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double7 = xYBarRenderer6.getShadowYOffset();
        java.awt.Color color8 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        xYBarRenderer6.setBasePaint((java.awt.Paint) color8);
        boolean boolean16 = combinedDomainXYPlot4.equals((java.lang.Object) color8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        combinedDomainXYPlot4.notifyListeners(plotChangeEvent17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("");
        labelBlock20.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot25.setDomainCrosshairPaint(paint26);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, paint26);
        double double30 = rectangleInsets23.calculateLeftOutset((double) (short) 100);
        labelBlock20.setMargin(rectangleInsets23);
        combinedDomainXYPlot4.setAxisOffset(rectangleInsets23);
        barRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = barRenderer3D0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertNull(categoryURLGenerator34);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLowerMargin();
        double double2 = categoryAxis0.getUpperMargin();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        java.awt.Stroke stroke5 = ringPlot1.getBaseSectionOutlineStroke();
        ringPlot1.setSectionDepth(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY((double) (byte) 10);
        double double4 = crosshairState1.getCrosshairX();
        crosshairState1.updateCrosshairX(1.0E-8d, (int) 'a');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        try {
            java.util.Collection collection3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) strSet2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        long long6 = segmentedTimeline3.getExceptionSegmentCount((long) '#', (long) 37);
        long long7 = segmentedTimeline3.getSegmentsExcludedSize();
        int int8 = segmentedTimeline3.getSegmentsExcluded();
        long long9 = segmentedTimeline3.getSegmentsIncludedSize();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2L) + "'", long7 == (-2L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-35L) + "'", long9 == (-35L));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        int int6 = segmentedTimeline5.getGroupSegmentCount();
        objectList0.set(0, (java.lang.Object) int6);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 37 + "'", int6 == 37);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot15.setDomainCrosshairPaint(paint16);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = combinedDomainXYPlot15.removeDomainMarker(marker18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot15.setRangeAxisLocation(1, axisLocation21, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYBarRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        int int29 = combinedDomainXYPlot15.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker36.setStartValue(0.0d);
        float float39 = intervalMarker36.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = intervalMarker36.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 1.0E-8d, 1.0E-8d, rectangleAnchor40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean46 = combinedDomainXYPlot15.render(graphics2D30, rectangle2D41, (int) (short) 0, plotRenderingInfo43, crosshairState45);
        legendItem12.setShape((java.awt.Shape) rectangle2D41);
        legendItem12.setDatasetIndex(5);
        java.text.AttributedString attributedString50 = legendItem12.getAttributedLabel();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.8f + "'", float39 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(attributedString50);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(4.0d);
        double double2 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        barRenderer3D0.setIncludeBaseInRange(true);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        barRenderer3D0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot4.setDomainCrosshairPaint(paint5);
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot4.setRangeAxisLocation(1, axisLocation10, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYBarRenderer14.setBaseToolTipGenerator(xYToolTipGenerator15, false);
        int int18 = combinedDomainXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        java.awt.Paint paint20 = xYBarRenderer14.getBaseLegendTextPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        barRenderer3D0.setBase((double) '#');
        barRenderer3D0.setShadowYOffset((double) ' ');
        barRenderer3D0.removeAnnotations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range6 = new org.jfree.data.Range((double) (short) 100, 1484232.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range3, range6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 1546329600000L, range3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Color color0 = java.awt.Color.pink;
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        standardChartTheme2.setTickLabelPaint((java.awt.Paint) color3);
        java.awt.color.ColorSpace colorSpace11 = color3.getColorSpace();
        float[] floatArray13 = new float[] { 32 };
        try {
            float[] floatArray14 = color0.getComponents(colorSpace11, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        barRenderer3D0.setShadowVisible(false);
        java.awt.Font font12 = barRenderer3D0.getItemLabelFont(0, 9999, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        combinedDomainXYPlot1.setOutlinePaint(paint7);
        org.jfree.chart.axis.ValueAxis valueAxis11 = combinedDomainXYPlot1.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedDomainXYPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedDomainXYPlot15.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo18, point2D19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = combinedDomainXYPlot15.getRangeMarkers(12, layer22);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = combinedDomainXYPlot15.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection24, false);
        try {
            combinedDomainXYPlot1.setDataset((-456), (org.jfree.data.xy.XYDataset) xYSeriesCollection24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertEquals((double) number27, Double.NaN, 0);
        org.junit.Assert.assertNull(range29);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getShadowYOffset();
        boolean boolean8 = ringPlot1.getAutoPopulateSectionOutlineStroke();
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        ringPlot1.setSeparatorPaint(paint9);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.chart.axis.ValueAxis valueAxis13 = polarPlot10.getAxis();
        polarPlot10.removeCornerTextItem("Oct");
        int int16 = polarPlot10.getSeriesCount();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        boolean boolean3 = combinedDomainXYPlot1.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker6.setStartValue(0.0d);
        float float9 = intervalMarker6.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker6.getLabelOffsetType();
        boolean boolean11 = combinedDomainXYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker6);
        double double12 = intervalMarker6.getStartValue();
        java.awt.Font font13 = intervalMarker6.getLabelFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Shape shape0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot2.setRangeAxisLocation(axisLocation3);
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker7.setStartValue(0.0d);
        float float10 = intervalMarker7.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot12.setRangeAxisLocation(axisLocation13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis16);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, paint18);
        combinedDomainXYPlot12.setOutlinePaint(paint18);
        intervalMarker7.setOutlinePaint(paint18);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker7.setStroke(stroke23);
        boolean boolean25 = combinedDomainXYPlot2.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker7);
        combinedDomainXYPlot2.configureDomainAxes();
        try {
            org.jfree.chart.entity.PlotEntity plotEntity29 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedDomainXYPlot2, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.8f + "'", float10 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (-1.0f), (double) 1L, rectangleAnchor7);
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis14 = new org.jfree.chart.axis.SymbolAxis("", strArray13);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer17.setBaseCreateEntities(true);
        xYLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYLineAndShapeRenderer17.getBaseURLGenerator();
        boolean boolean23 = symbolAxis14.equals((java.lang.Object) xYURLGenerator22);
        double double24 = symbolAxis14.getAutoRangeMinimumSize();
        java.awt.Paint paint25 = symbolAxis14.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D8, (org.jfree.chart.axis.Axis) symbolAxis14, "PieLabelLinkStyle.STANDARD");
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        axisEntity27.setArea(shape28);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection30 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection30);
        java.lang.String[] strArray36 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis37 = new org.jfree.chart.axis.SymbolAxis("", strArray36);
        java.awt.Font font38 = symbolAxis37.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection30, (org.jfree.chart.axis.ValueAxis) symbolAxis37, polarItemRenderer39);
        polarPlot40.setForegroundAlpha((float) '4');
        java.awt.Paint paint43 = polarPlot40.getNoDataMessagePaint();
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color47 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel48 = null;
        java.awt.Rectangle rectangle49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        java.awt.geom.AffineTransform affineTransform51 = null;
        java.awt.RenderingHints renderingHints52 = null;
        java.awt.PaintContext paintContext53 = color47.createContext(colorModel48, rectangle49, rectangle2D50, affineTransform51, renderingHints52);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color47);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer55 = null;
        intervalMarker54.setGradientPaintTransformer(gradientPaintTransformer55);
        java.awt.Paint paint57 = intervalMarker54.getPaint();
        try {
            org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem(attributedString0, "ThreadContext", "PieLabelLinkStyle.STANDARD", "GradientPaintTransformType.CENTER_VERTICAL", shape28, paint43, stroke44, paint57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintContext53);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot11.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        combinedRangeXYPlot11.plotChanged(plotChangeEvent17);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Paint paint6 = symbolAxis5.getGridBandAlternatePaint();
        java.lang.String str7 = symbolAxis5.getLabelURL();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getGridBandPaint();
        java.awt.Paint paint12 = standardChartTheme1.getPlotOutlinePaint();
        java.awt.Font font13 = standardChartTheme1.getExtraLargeFont();
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) (short) 100, (java.awt.Paint) color16);
        java.awt.Color color18 = color16.brighter();
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color16);
        standardChartTheme1.setItemLabelPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        java.awt.geom.Point2D point2D18 = combinedDomainXYPlot1.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer20.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer20.setBaseStroke(stroke23);
        xYStepAreaRenderer20.setOutline(true);
        java.awt.Font font27 = xYStepAreaRenderer20.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis28);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot29.setDomainCrosshairPaint(paint30);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("", font27, (org.jfree.chart.plot.Plot) combinedDomainXYPlot29, false);
        boolean boolean34 = jFreeChart33.isBorderVisible();
        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) combinedDomainXYPlot1, (java.lang.Object) jFreeChart33);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        double double6 = piePlot3D1.getShadowYOffset();
        piePlot3D1.setBackgroundImageAlignment(0);
        piePlot3D1.setSimpleLabels(false);
        java.lang.String str11 = piePlot3D1.getPlotType();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str13 = pieLabelLinkStyle12.toString();
        piePlot3D1.setLabelLinkStyle(pieLabelLinkStyle12);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pie 3D Plot" + "'", str11.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str13.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Stroke stroke5 = piePlot4.getLabelLinkStroke();
        piePlot1.setLabelOutlineStroke(stroke5);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.String str7 = symbolAxis5.valueToString(0.0d);
        symbolAxis5.setMinorTickMarkOutsideLength((float) '4');
        symbolAxis5.pan((double) 1560495599999L);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        categoryPlot0.clearDomainMarkers((-1));
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double12 = xYBarRenderer11.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range14 = xYBarRenderer11.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        xYSeriesCollection9.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection13);
        java.util.List list16 = xYSeriesCollection13.getSeries();
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection13);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double21 = xYBarRenderer20.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection22 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range23 = xYBarRenderer20.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection22);
        xYSeriesCollection18.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection22);
        java.util.List list25 = xYSeriesCollection22.getSeries();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, list25, false);
        try {
            categoryPlot0.mapDatasetToDomainAxes(255, list25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertEquals((double) number17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.lang.Object obj7 = xYLineAndShapeRenderer2.clone();
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (-1.0f), (double) 1L, rectangleAnchor11);
        xYLineAndShapeRenderer2.setBaseLegendShape((java.awt.Shape) rectangle2D12);
        xYLineAndShapeRenderer2.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        int int2 = numberFormat1.getMaximumIntegerDigits();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getIntegerInstance();
        numberFormat3.setMinimumFractionDigits(0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PlotOrientation.VERTICAL", numberFormat1, numberFormat3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer9.setBaseCreateEntities(true);
        xYLineAndShapeRenderer9.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYLineAndShapeRenderer9.getBaseURLGenerator();
        boolean boolean15 = standardPieSectionLabelGenerator6.equals((java.lang.Object) xYURLGenerator14);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        combinedDomainXYPlot1.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle20.setPadding(rectangleInsets21);
        org.jfree.chart.block.BorderArrangement borderArrangement23 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement23, dataset24, (java.lang.Comparable) 15);
        org.jfree.chart.block.Arrangement arrangement27 = legendItemBlockContainer26.getArrangement();
        legendTitle20.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer26);
        legendItemBlockContainer26.setURLText("Range[9999.0,2958465.0]");
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(arrangement27);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangePannable(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState7.updateCrosshairY(0.0d, (int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = combinedDomainXYPlot16.getOrientation();
        crosshairState7.updateCrosshairPoint(12.0d, 0.0d, 0.0d, 3.0d, plotOrientation17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection19);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection19, (org.jfree.chart.axis.ValueAxis) symbolAxis26, polarItemRenderer28);
        boolean boolean30 = polarPlot29.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        polarPlot29.zoomRangeAxes((double) (byte) -1, plotRenderingInfo32, point2D33);
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) (-1.0f), (double) 1L, rectangleAnchor40);
        java.awt.Point point42 = polarPlot29.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D41);
        crosshairState7.setAnchor((java.awt.geom.Point2D) point42);
        categoryPlot0.zoomRangeAxes((double) 1900, (double) 0.0f, plotRenderingInfo5, (java.awt.geom.Point2D) point42);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(point42);
        org.junit.Assert.assertNotNull(legendItemCollection45);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot32.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo35, point2D36);
        combinedDomainXYPlot32.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint40 = combinedDomainXYPlot32.getRangeZeroBaselinePaint();
        symbolAxis5.setTickLabelPaint(paint40);
        float float42 = symbolAxis5.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie 3D Plot", "{0}: ({1}, {2})", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        piePlot3D1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        java.util.Date date8 = dateRange7.getLowerDate();
        boolean boolean9 = standardPieSectionLabelGenerator4.equals((java.lang.Object) date8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition11);
        boolean boolean13 = standardPieSectionLabelGenerator4.equals((java.lang.Object) dateAxis10);
        java.text.DateFormat dateFormat14 = dateAxis10.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(dateFormat14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis22 = new org.jfree.chart.axis.SymbolAxis("", strArray21);
        combinedRangeXYPlot11.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) symbolAxis22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        combinedDomainXYPlot28.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo31, point2D32);
        combinedDomainXYPlot28.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        int int37 = combinedDomainXYPlot28.getDomainAxisIndex(valueAxis36);
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis43 = new org.jfree.chart.axis.SymbolAxis("", strArray42);
        java.lang.String str45 = symbolAxis43.valueToString(0.0d);
        int int46 = combinedDomainXYPlot28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis43);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = combinedDomainXYPlot28.getDomainMarkers((-9999), layer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = combinedDomainXYPlot28.getDomainAxisEdge((int) (byte) 0);
        try {
            java.util.List list52 = symbolAxis22.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        xYBarRenderer1.setLegendBar(shape6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer1.getBasePositiveItemLabelPosition();
        xYBarRenderer1.setDrawBarOutline(false);
        boolean boolean11 = xYBarRenderer1.getAutoPopulateSeriesShape();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot14.setDomainCrosshairPaint(paint15);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, paint15);
        double double19 = rectangleInsets12.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker25.setStartValue(0.0d);
        float float28 = intervalMarker25.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = intervalMarker25.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 1.0E-8d, 1.0E-8d, rectangleAnchor29);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets12.createInsetRectangle(rectangle2D30);
        xYBarRenderer1.setLegendBar((java.awt.Shape) rectangle2D30);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot35 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        combinedDomainXYPlot35.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo38, point2D39);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = combinedDomainXYPlot35.getRangeMarkers(12, layer42);
        int int44 = combinedDomainXYPlot35.getDatasetCount();
        combinedDomainXYPlot35.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        combinedDomainXYPlot35.panRangeAxes((double) 1L, plotRenderingInfo49, point2D50);
        combinedDomainXYPlot35.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot35);
        boolean boolean55 = legendTitle54.isVisible();
        org.jfree.chart.entity.TitleEntity titleEntity57 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D30, (org.jfree.chart.title.Title) legendTitle54, "PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.8f + "'", float28 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = xYStepRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(drawingSupplier1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot59 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot59.setRangeAxisLocation(axisLocation60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot64 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis63);
        java.awt.Paint paint65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot64.setDomainCrosshairPaint(paint65);
        org.jfree.chart.block.BlockBorder blockBorder67 = new org.jfree.chart.block.BlockBorder(rectangleInsets62, paint65);
        combinedDomainXYPlot59.setOutlinePaint(paint65);
        org.jfree.chart.axis.ValueAxis valueAxis69 = combinedDomainXYPlot59.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation70 = combinedDomainXYPlot59.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation70, true);
        org.jfree.chart.axis.ValueAxis valueAxis73 = categoryPlot6.getRangeAxis();
        java.util.List list74 = categoryPlot6.getAnnotations();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation75 = null;
        try {
            boolean boolean77 = categoryPlot6.removeAnnotation(categoryAnnotation75, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(list74);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Font font6 = symbolAxis5.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot9.setDomainCrosshairPaint(paint10);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, paint10);
        double double14 = rectangleInsets7.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker20.setStartValue(0.0d);
        float float23 = intervalMarker20.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = intervalMarker20.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, 1.0E-8d, 1.0E-8d, rectangleAnchor24);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets7.createInsetRectangle(rectangle2D25);
        symbolAxis5.setUpArrow((java.awt.Shape) rectangle2D25);
        boolean boolean29 = symbolAxis5.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.8f + "'", float23 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis6 = new org.jfree.chart.axis.SymbolAxis("", strArray5);
        boolean boolean7 = symbolAxis6.getAutoRangeStickyZero();
        java.lang.String str9 = symbolAxis6.valueToString((double) (byte) 10);
        java.awt.Font font10 = symbolAxis6.getTickLabelFont();
        java.awt.Paint paint11 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("Range[9999.0,2958465.0]", font10, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setLabelGap(0.0d);
        java.awt.Paint paint9 = ringPlot1.getBaseSectionPaint();
        ringPlot1.setSimpleLabels(false);
        java.awt.Paint paint12 = ringPlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        legendItem12.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker21.setStartValue(0.0d);
        float float24 = intervalMarker21.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = intervalMarker21.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, 1.0E-8d, 1.0E-8d, rectangleAnchor25);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D26);
        legendItem12.setLine((java.awt.Shape) rectangle2D26);
        java.lang.String str29 = legendItem12.getLabel();
        java.awt.Font font30 = legendItem12.getLabelFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.8f + "'", float24 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Oct" + "'", str29.equals("Oct"));
        org.junit.Assert.assertNull(font30);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        double double9 = xYStepAreaRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker5.setStartValue(0.0d);
        float float8 = intervalMarker5.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = intervalMarker5.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 1.0E-8d, 1.0E-8d, rectangleAnchor9);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.text.NumberFormat numberFormat16 = java.text.NumberFormat.getPercentInstance();
        int int17 = numberFormat16.getMaximumIntegerDigits();
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getIntegerInstance();
        numberFormat18.setMinimumFractionDigits(0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PlotOrientation.VERTICAL", numberFormat16, numberFormat18);
        java.math.RoundingMode roundingMode22 = numberFormat16.getRoundingMode();
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity25 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, 100, 4, (java.lang.Comparable) roundingMode22, "-1,1,0,2", "{0}");
        org.jfree.data.general.PieDataset pieDataset26 = pieSectionEntity25.getDataset();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8f + "'", float8 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberFormat16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode22.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertNull(pieDataset26);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        java.awt.Paint paint9 = combinedDomainXYPlot8.getRangeZeroBaselinePaint();
        boolean boolean10 = combinedDomainXYPlot8.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker13.setStartValue(0.0d);
        float float16 = intervalMarker13.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = intervalMarker13.getLabelOffsetType();
        boolean boolean18 = combinedDomainXYPlot8.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = categoryPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) intervalMarker13, layer19, false);
        categoryPlot0.setDomainCrosshairVisible(true);
        java.awt.Paint paint24 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke25 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.8f + "'", float16 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        xYLineAndShapeRenderer5.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color7, false);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer5.getSeriesStroke(10);
        java.awt.Paint paint18 = xYLineAndShapeRenderer5.getBaseItemLabelPaint();
        piePlot3D1.setShadowPaint(paint18);
        boolean boolean20 = piePlot3D1.getDarkerSides();
        piePlot3D1.setDepthFactor((double) 255);
        java.awt.Paint paint23 = piePlot3D1.getLabelLinkPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator24 = piePlot3D1.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator24);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        try {
            java.lang.Number number3 = defaultKeyedValues0.getValue(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, dataset1, (java.lang.Comparable) 15);
        org.jfree.chart.block.Arrangement arrangement4 = legendItemBlockContainer3.getArrangement();
        legendItemBlockContainer3.setURLText("Oct");
        org.junit.Assert.assertNotNull(arrangement4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        borderArrangement0.clear();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double6 = xYBarRenderer5.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range8 = xYBarRenderer5.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection7);
        java.util.List list10 = xYSeriesCollection7.getSeries();
        org.jfree.data.DomainOrder domainOrder11 = xYSeriesCollection7.getDomainOrder();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, (org.jfree.data.general.Dataset) xYSeriesCollection7, (java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(domainOrder11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangePannable(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState7.updateCrosshairY(0.0d, (int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = combinedDomainXYPlot16.getOrientation();
        crosshairState7.updateCrosshairPoint(12.0d, 0.0d, 0.0d, 3.0d, plotOrientation17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection19);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection19, (org.jfree.chart.axis.ValueAxis) symbolAxis26, polarItemRenderer28);
        boolean boolean30 = polarPlot29.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        polarPlot29.zoomRangeAxes((double) (byte) -1, plotRenderingInfo32, point2D33);
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) (-1.0f), (double) 1L, rectangleAnchor40);
        java.awt.Point point42 = polarPlot29.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D41);
        crosshairState7.setAnchor((java.awt.geom.Point2D) point42);
        categoryPlot0.zoomRangeAxes((double) 1900, (double) 0.0f, plotRenderingInfo5, (java.awt.geom.Point2D) point42);
        java.awt.Paint paint45 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(point42);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 100L);
        org.jfree.data.Range range7 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range10 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range13 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        boolean boolean14 = range10.intersects(range13);
        boolean boolean15 = range7.intersects(range13);
        org.jfree.data.Range range16 = org.jfree.data.Range.combine(range4, range7);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        boolean boolean6 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.Object obj1 = combinedRangeXYPlot0.clone();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        java.awt.Color color18 = java.awt.Color.BLUE;
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color18);
        double double20 = symbolAxis8.getUpperBound();
        symbolAxis8.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection26);
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        java.awt.Font font34 = symbolAxis33.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, polarItemRenderer35);
        boolean boolean37 = polarPlot36.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        polarPlot36.zoomRangeAxes((double) 2958465, 0.025d, plotRenderingInfo40, point2D41);
        boolean boolean43 = polarPlot36.isRangeZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker46.setStartValue(0.0d);
        float float49 = intervalMarker46.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = intervalMarker46.getLabelAnchor();
        java.awt.Font font51 = intervalMarker46.getLabelFont();
        polarPlot36.setAngleLabelFont(font51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot56 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        combinedDomainXYPlot56.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo59, point2D60);
        org.jfree.chart.util.Layer layer63 = null;
        java.util.Collection collection64 = combinedDomainXYPlot56.getRangeMarkers(12, layer63);
        int int65 = combinedDomainXYPlot56.getDatasetCount();
        combinedDomainXYPlot56.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        java.awt.geom.Point2D point2D71 = null;
        combinedDomainXYPlot56.panRangeAxes((double) 1L, plotRenderingInfo70, point2D71);
        java.awt.geom.Point2D point2D73 = combinedDomainXYPlot56.getQuadrantOrigin();
        polarPlot36.zoomRangeAxes((double) (short) 1, plotRenderingInfo54, point2D73);
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo25, point2D73, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.8f + "'", float49 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(point2D73);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.lang.String str18 = symbolAxis16.valueToString(0.0d);
        int int19 = combinedDomainXYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis16);
        combinedDomainXYPlot1.configureRangeAxes();
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        standardChartTheme24.setTickLabelPaint((java.awt.Paint) color25);
        java.awt.color.ColorSpace colorSpace33 = color25.getColorSpace();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer34.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer34.setBaseStroke(stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 'a', (java.awt.Paint) color25, stroke37);
        org.jfree.chart.util.Layer layer40 = null;
        combinedDomainXYPlot1.addRangeMarker(5, (org.jfree.chart.plot.Marker) valueMarker39, layer40);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener42 = null;
        valueMarker39.addChangeListener(markerChangeListener42);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getOuterSeparatorExtension();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        ringPlot1.setBackgroundPaint((java.awt.Paint) color8);
        boolean boolean10 = ringPlot1.getSeparatorsVisible();
        ringPlot1.setIgnoreZeroValues(false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        ringPlot1.notifyListeners(plotChangeEvent13);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) '4', (double) (-2L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (-2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.text.DateFormat dateFormat8 = null;
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat8, dateFormat9);
        xYLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator10, true);
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker18.setStartValue(0.0d);
        float float21 = intervalMarker18.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = intervalMarker18.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 1.0E-8d, 1.0E-8d, rectangleAnchor22);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        java.text.NumberFormat numberFormat29 = java.text.NumberFormat.getPercentInstance();
        int int30 = numberFormat29.getMaximumIntegerDigits();
        java.text.NumberFormat numberFormat31 = java.text.NumberFormat.getIntegerInstance();
        numberFormat31.setMinimumFractionDigits(0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator34 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PlotOrientation.VERTICAL", numberFormat29, numberFormat31);
        java.math.RoundingMode roundingMode35 = numberFormat29.getRoundingMode();
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity38 = new org.jfree.chart.entity.PieSectionEntity(shape24, pieDataset25, 100, 4, (java.lang.Comparable) roundingMode35, "-1,1,0,2", "{0}");
        boolean boolean39 = standardXYToolTipGenerator10.equals((java.lang.Object) pieDataset25);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.8f + "'", float21 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(numberFormat29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat31);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode35.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        double double4 = intervalXYDelegate2.getDomainUpperBound(false);
        boolean boolean5 = intervalXYDelegate2.isAutoWidth();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection31 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double34 = xYBarRenderer33.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection35 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range36 = xYBarRenderer33.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        xYSeriesCollection31.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection35);
        java.lang.Number number38 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis44 = new org.jfree.chart.axis.SymbolAxis("", strArray43);
        java.awt.Font font45 = symbolAxis44.getLabelFont();
        java.lang.String[] strArray50 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis51 = new org.jfree.chart.axis.SymbolAxis("", strArray50);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer54 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer54.setBaseCreateEntities(true);
        xYLineAndShapeRenderer54.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator59 = xYLineAndShapeRenderer54.getBaseURLGenerator();
        boolean boolean60 = symbolAxis51.equals((java.lang.Object) xYURLGenerator59);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean62 = xYStepAreaRenderer61.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection35, (org.jfree.chart.axis.ValueAxis) symbolAxis44, (org.jfree.chart.axis.ValueAxis) symbolAxis51, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer61);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer65 = new org.jfree.chart.text.G2TextMeasurer(graphics2D64);
        boolean boolean66 = xYPlot63.equals((java.lang.Object) graphics2D64);
        symbolAxis5.setPlot((org.jfree.chart.plot.Plot) xYPlot63);
        xYPlot63.setDomainMinorGridlinesVisible(true);
        xYPlot63.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertEquals((double) number38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNull(xYURLGenerator59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getPlotOutlinePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) ' ', "LengthConstraintType.NONE");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(false);
        xYLineAndShapeRenderer2.setAutoPopulateSeriesStroke(false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        double double18 = symbolAxis8.getAutoRangeMinimumSize();
        java.awt.Paint paint19 = symbolAxis8.getLabelPaint();
        int int20 = combinedDomainXYPlot1.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.StandardChartTheme standardChartTheme23 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color24 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        standardChartTheme23.setTickLabelPaint((java.awt.Paint) color24);
        java.awt.color.ColorSpace colorSpace32 = color24.getColorSpace();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer33.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer33.setBaseStroke(stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 'a', (java.awt.Paint) color24, stroke36);
        boolean boolean39 = combinedDomainXYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker38);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        boolean boolean3 = intervalXYDelegate2.isAutoWidth();
        double double4 = intervalXYDelegate2.getIntervalPositionFactor();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        double double7 = rectangleInsets0.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedDomainXYPlot9.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo12, point2D13);
        combinedDomainXYPlot9.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = combinedDomainXYPlot9.getDomainAxisIndex(valueAxis17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.lang.String str26 = symbolAxis24.valueToString(0.0d);
        int int27 = combinedDomainXYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        boolean boolean28 = rectangleInsets0.equals((java.lang.Object) combinedDomainXYPlot9);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) '#', 3.0d);
        boolean boolean32 = combinedDomainXYPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        intervalMarker31.notifyListeners(markerChangeEvent33);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine1);
        org.jfree.chart.text.TextLine textLine3 = null;
        textBlock0.addLine(textLine3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor3 = timeSeriesCollection1.getXPosition();
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(timePeriodAnchor3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        xYLineAndShapeRenderer2.setDrawOutlines(true);
        boolean boolean17 = xYLineAndShapeRenderer2.getItemVisible((int) (short) -1, 13);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator22 = new org.jfree.chart.urls.StandardXYURLGenerator("-1,1,0,2", "MAJOR", "UnitType.ABSOLUTE");
        xYLineAndShapeRenderer2.setSeriesURLGenerator((int) (short) 100, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot(pieDataset24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        ringPlot25.setDrawingSupplier(drawingSupplier26, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator29 = ringPlot25.getLegendLabelURLGenerator();
        boolean boolean30 = ringPlot25.isCircular();
        boolean boolean31 = ringPlot25.getSimpleLabels();
        boolean boolean32 = standardXYURLGenerator22.equals((java.lang.Object) ringPlot25);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(pieURLGenerator29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getToolTipGenerator(0, (int) 'a', false);
        double double10 = xYBarRenderer1.getBarAlignmentFactor();
        xYBarRenderer1.setAutoPopulateSeriesFillPaint(true);
        xYBarRenderer1.setDefaultEntityRadius(1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        boolean boolean5 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer3D0.getBarPainter();
        barRenderer3D0.setMaximumBarWidth((double) 15);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer3D0.getBaseToolTipGenerator();
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer13.setBaseCreateEntities(true);
        boolean boolean16 = xYSeries10.equals((java.lang.Object) true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis24, polarItemRenderer26);
        xYSeries10.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection17);
        double[][] doubleArray29 = xYSeries10.toArray();
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("LengthConstraintType.NONE", "UnitType.ABSOLUTE", doubleArray29);
        org.jfree.data.Range range31 = barRenderer3D0.findRangeBounds(categoryDataset30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNull(range31);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setNotify(true);
        java.lang.Object obj3 = textTitle0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        boolean boolean3 = intervalXYDelegate2.isAutoWidth();
        double double5 = intervalXYDelegate2.getDomainUpperBound(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        java.awt.Shape shape4 = xYLineAndShapeRenderer2.getLegendLine();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        ringPlot1.setInnerSeparatorExtension((double) (byte) -1);
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis12 = new org.jfree.chart.axis.SymbolAxis("", strArray11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer15.setBaseCreateEntities(true);
        xYLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = xYLineAndShapeRenderer15.getBaseURLGenerator();
        boolean boolean21 = symbolAxis12.equals((java.lang.Object) xYURLGenerator20);
        double double22 = symbolAxis12.getAutoRangeMinimumSize();
        java.awt.Paint paint23 = symbolAxis12.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double26 = xYBarRenderer25.getShadowYOffset();
        java.awt.Color color27 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        xYBarRenderer25.setBasePaint((java.awt.Paint) color27);
        symbolAxis12.setTickMarkPaint((java.awt.Paint) color27);
        symbolAxis12.setUpperMargin((double) (-1.0f));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double40 = xYBarRenderer39.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection41 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range42 = xYBarRenderer39.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection41);
        double double44 = xYSeriesCollection41.getRangeUpperBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) symbolAxis12, (org.jfree.data.general.Dataset) xYSeriesCollection41);
        ringPlot1.datasetChanged(datasetChangeEvent45);
        java.lang.Object obj47 = datasetChangeEvent45.getSource();
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNull(xYURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer9.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer9.setBaseStroke(stroke12);
        xYStepAreaRenderer9.setOutline(true);
        java.awt.Font font16 = xYStepAreaRenderer9.getBaseItemLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double20 = xYBarRenderer19.getShadowYOffset();
        java.awt.Color color21 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color21.createContext(colorModel22, rectangle23, rectangle2D24, affineTransform25, renderingHints26);
        xYBarRenderer19.setBasePaint((java.awt.Paint) color21);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color21);
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("hi!", font16, (java.awt.Paint) color21);
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintContext27);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        boolean boolean3 = intervalXYDelegate2.isAutoWidth();
        try {
            double double6 = intervalXYDelegate2.getEndXValue((int) (byte) 1, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLowerMargin();
        double double2 = categoryAxis0.getUpperMargin();
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis10 = new org.jfree.chart.axis.SymbolAxis("", strArray9);
        java.awt.Font font11 = symbolAxis10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot14.setDomainCrosshairPaint(paint15);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, paint15);
        double double19 = rectangleInsets12.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker25.setStartValue(0.0d);
        float float28 = intervalMarker25.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = intervalMarker25.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 1.0E-8d, 1.0E-8d, rectangleAnchor29);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets12.createInsetRectangle(rectangle2D30);
        symbolAxis10.setUpArrow((java.awt.Shape) rectangle2D30);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge34);
        try {
            double double36 = categoryAxis0.getCategoryMiddle(1, (int) (byte) -1, rectangle2D30, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.8f + "'", float28 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        double double6 = piePlot3D1.getShadowYOffset();
        piePlot3D1.setBackgroundImageAlignment(0);
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer11.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer11.setBaseStroke(stroke14);
        xYStepAreaRenderer11.setOutline(true);
        java.awt.Font font18 = xYStepAreaRenderer11.getBaseItemLabelFont();
        standardChartTheme10.setSmallFont(font18);
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis25 = new org.jfree.chart.axis.SymbolAxis("", strArray24);
        boolean boolean26 = symbolAxis25.getAutoRangeStickyZero();
        java.lang.String str28 = symbolAxis25.valueToString((double) (byte) 10);
        java.awt.Font font29 = symbolAxis25.getTickLabelFont();
        standardChartTheme10.setSmallFont(font29);
        piePlot3D1.setLabelFont(font29);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator32 = null;
        piePlot3D1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator32);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        try {
            org.jfree.data.xy.XYSeries xYSeries8 = xYSeriesCollection0.getSeries(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = standardChartTheme1.getAxisOffset();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        standardChartTheme1.setChartBackgroundPaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = null;
        try {
            standardChartTheme1.setGridBandAlternatePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke8 = xYLineAndShapeRenderer2.lookupSeriesStroke((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(0, attributedString4);
        java.text.NumberFormat numberFormat6 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        try {
            java.text.AttributedString attributedString9 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset7, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot59 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot59.setRangeAxisLocation(axisLocation60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot64 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis63);
        java.awt.Paint paint65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot64.setDomainCrosshairPaint(paint65);
        org.jfree.chart.block.BlockBorder blockBorder67 = new org.jfree.chart.block.BlockBorder(rectangleInsets62, paint65);
        combinedDomainXYPlot59.setOutlinePaint(paint65);
        org.jfree.chart.axis.ValueAxis valueAxis69 = combinedDomainXYPlot59.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation70 = combinedDomainXYPlot59.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation70, true);
        java.awt.Paint paint73 = categoryPlot6.getRangeZeroBaselinePaint();
        java.awt.Graphics2D graphics2D74 = null;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection78 = chartRenderingInfo77.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = chartRenderingInfo77.getPlotInfo();
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState80 = null;
        boolean boolean81 = categoryPlot6.render(graphics2D74, rectangle2D75, 2147483647, plotRenderingInfo79, categoryCrosshairState80);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(entityCollection78);
        org.junit.Assert.assertNotNull(plotRenderingInfo79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
        try {
            dateAxis0.setRangeWithMargins(0.0d, (double) (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-9999.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis24, polarItemRenderer26);
        boolean boolean28 = symbolAxis5.hasListener((java.util.EventListener) xYSeriesCollection17);
        try {
            symbolAxis5.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        boolean boolean10 = combinedDomainXYPlot1.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot12.setDomainCrosshairPaint(paint13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = combinedDomainXYPlot12.removeDomainMarker(marker15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot12.setRangeAxisLocation(1, axisLocation18, false);
        combinedDomainXYPlot1.setRangeAxisLocation((int) (short) 100, axisLocation18, false);
        boolean boolean23 = combinedDomainXYPlot1.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        barRenderer3D0.setMinimumBarLength(8.0d);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer3D0.getToolTipGenerator((int) (short) 1, (-1), false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, dataset1, (java.lang.Comparable) 15);
        org.jfree.chart.block.Arrangement arrangement4 = legendItemBlockContainer3.getArrangement();
        java.lang.String str5 = legendItemBlockContainer3.getURLText();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker12.setStartValue(0.0d);
        float float15 = intervalMarker12.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = intervalMarker12.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, 1.0E-8d, 1.0E-8d, rectangleAnchor16);
        try {
            legendItemBlockContainer3.draw(graphics2D6, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.8f + "'", float15 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        java.awt.Paint paint8 = combinedDomainXYPlot7.getRangeZeroBaselinePaint();
        boolean boolean9 = combinedDomainXYPlot7.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker12.setStartValue(0.0d);
        float float15 = intervalMarker12.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = intervalMarker12.getLabelOffsetType();
        boolean boolean17 = combinedDomainXYPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        int int19 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.8f + "'", float15 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        boolean boolean17 = symbolAxis16.getAutoRangeStickyZero();
        java.lang.String str19 = symbolAxis16.valueToString((double) (byte) 10);
        java.awt.Font font20 = symbolAxis16.getTickLabelFont();
        standardChartTheme1.setSmallFont(font20);
        java.awt.Paint paint22 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle23 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle23);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle23);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("DateTickUnitType.MINUTE", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        boolean boolean2 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        java.lang.String str10 = symbolAxis8.valueToString(0.0d);
        org.jfree.data.Range range11 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis8);
        symbolAxis8.setMinorTickMarkOutsideLength((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-456), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -456");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        int int4 = segmentedTimeline3.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color2);
        java.lang.Object obj10 = intervalMarker9.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker13.setStartValue(0.0d);
        float float16 = intervalMarker13.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot18.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis22);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot23.setDomainCrosshairPaint(paint24);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, paint24);
        combinedDomainXYPlot18.setOutlinePaint(paint24);
        intervalMarker13.setOutlinePaint(paint24);
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker13.setStroke(stroke29);
        intervalMarker9.setOutlineStroke(stroke29);
        double double32 = intervalMarker9.getStartValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.8f + "'", float16 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.lang.String str18 = symbolAxis16.valueToString(0.0d);
        int int19 = combinedDomainXYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis16);
        combinedDomainXYPlot1.setRangeCrosshairValue(2.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("0", graphics2D1, (float) (byte) 10, 100.0f, (double) 0L, (float) (-2L), (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setSeriesPaint(10, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setSeriesItemLabelsVisible(35, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis10 = new org.jfree.chart.axis.SymbolAxis("", strArray9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer13.setBaseCreateEntities(true);
        xYLineAndShapeRenderer13.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYLineAndShapeRenderer13.getBaseURLGenerator();
        boolean boolean19 = symbolAxis10.equals((java.lang.Object) xYURLGenerator18);
        double double20 = symbolAxis10.getAutoRangeMinimumSize();
        java.awt.Paint paint21 = symbolAxis10.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity23 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D4, (org.jfree.chart.axis.Axis) symbolAxis10, "PieLabelLinkStyle.STANDARD");
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        axisEntity23.setArea(shape24);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D(pieDataset26);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = null;
        piePlot3D27.axisChanged(axisChangeEvent28);
        piePlot3D27.setLabelLinksVisible(true);
        piePlot3D27.setCircular(false, false);
        boolean boolean35 = axisEntity23.equals((java.lang.Object) false);
        java.lang.String str36 = axisEntity23.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-8d + "'", double20 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-4,-4,4,4" + "'", str36.equals("-4,-4,4,4"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "MAJOR", "GradientPaintTransformType.CENTER_VERTICAL", "PlotOrientation.VERTICAL");
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot59 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot59.setRangeAxisLocation(axisLocation60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot64 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis63);
        java.awt.Paint paint65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot64.setDomainCrosshairPaint(paint65);
        org.jfree.chart.block.BlockBorder blockBorder67 = new org.jfree.chart.block.BlockBorder(rectangleInsets62, paint65);
        combinedDomainXYPlot59.setOutlinePaint(paint65);
        org.jfree.chart.axis.ValueAxis valueAxis69 = combinedDomainXYPlot59.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation70 = combinedDomainXYPlot59.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation70, true);
        org.jfree.chart.axis.ValueAxis valueAxis73 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.ValueAxis valueAxis74 = categoryPlot6.getRangeAxis();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNull(valueAxis74);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        combinedDomainXYPlot7.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo10, point2D11);
        combinedDomainXYPlot7.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        int int16 = combinedDomainXYPlot7.getDomainAxisIndex(valueAxis15);
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis22 = new org.jfree.chart.axis.SymbolAxis("", strArray21);
        java.lang.String str24 = symbolAxis22.valueToString(0.0d);
        int int25 = combinedDomainXYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis22);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = combinedDomainXYPlot7.getDomainMarkers((-9999), layer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = combinedDomainXYPlot7.getDomainAxisEdge((int) (byte) 0);
        double double31 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D4, rectangleEdge30);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D(pieDataset32);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent34 = null;
        piePlot3D33.axisChanged(axisChangeEvent34);
        piePlot3D33.setLabelLinksVisible(true);
        piePlot3D33.setCircular(false, false);
        double double41 = piePlot3D33.getLabelLinkMargin();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot3D33);
        java.awt.Stroke stroke43 = piePlot3D33.getBaseSectionOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        piePlot3D33.setDataset(pieDataset44);
        org.jfree.chart.entity.PlotEntity plotEntity46 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D4, (org.jfree.chart.plot.Plot) piePlot3D33);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.025d + "'", double41 == 0.025d);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        java.lang.String[] strArray62 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis63 = new org.jfree.chart.axis.SymbolAxis("", strArray62);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer66 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer66.setBaseCreateEntities(true);
        xYLineAndShapeRenderer66.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator71 = xYLineAndShapeRenderer66.getBaseURLGenerator();
        boolean boolean72 = symbolAxis63.equals((java.lang.Object) xYURLGenerator71);
        double double73 = symbolAxis63.getAutoRangeMinimumSize();
        java.awt.Paint paint74 = symbolAxis63.getLabelPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection75 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent76 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection75);
        java.lang.String[] strArray81 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis82 = new org.jfree.chart.axis.SymbolAxis("", strArray81);
        java.awt.Font font83 = symbolAxis82.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer84 = null;
        org.jfree.chart.plot.PolarPlot polarPlot85 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection75, (org.jfree.chart.axis.ValueAxis) symbolAxis82, polarItemRenderer84);
        boolean boolean86 = symbolAxis63.hasListener((java.util.EventListener) xYSeriesCollection75);
        java.awt.Stroke stroke87 = symbolAxis63.getAxisLineStroke();
        barRenderer3D0.setBaseStroke(stroke87);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertNull(xYURLGenerator71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0E-8d + "'", double73 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("LengthConstraintType.NONE");
        periodAxis1.configure();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = periodAxis1.getLast();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getToolTipText();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedDomainXYPlot3.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo6, point2D7);
        combinedDomainXYPlot3.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = combinedDomainXYPlot3.getDomainAxisIndex(valueAxis11);
        boolean boolean13 = textTitle0.equals((java.lang.Object) int12);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        int int2 = crosshairState1.getRangeAxisIndex();
        crosshairState1.updateCrosshairX((-5.0d), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        combinedDomainXYPlot1.setOutlinePaint(paint7);
        org.jfree.chart.axis.ValueAxis valueAxis11 = combinedDomainXYPlot1.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedDomainXYPlot1.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        combinedDomainXYPlot1.setDataset(xYDataset13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedDomainXYPlot1.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getPercentInstance();
        int int3 = numberFormat2.getMaximumIntegerDigits();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getIntegerInstance();
        numberFormat4.setMinimumFractionDigits(0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PlotOrientation.VERTICAL", numberFormat2, numberFormat4);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(8.0d, numberFormat4);
        numberFormat4.setMinimumFractionDigits((int) 'a');
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 2.0d;
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat2, dateFormat3);
        xYStepAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4);
        java.text.DateFormat dateFormat6 = standardXYToolTipGenerator4.getYDateFormat();
        org.junit.Assert.assertNull(dateFormat6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis0.getTickUnit();
        int int6 = dateTickUnit5.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        xYBarRenderer1.setLegendBar(shape6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer1.getBasePositiveItemLabelPosition();
        xYBarRenderer1.setDrawBarOutline(false);
        boolean boolean11 = xYBarRenderer1.getAutoPopulateSeriesShape();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot14.setDomainCrosshairPaint(paint15);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, paint15);
        double double19 = rectangleInsets12.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker25.setStartValue(0.0d);
        float float28 = intervalMarker25.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = intervalMarker25.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 1.0E-8d, 1.0E-8d, rectangleAnchor29);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets12.createInsetRectangle(rectangle2D30);
        xYBarRenderer1.setLegendBar((java.awt.Shape) rectangle2D30);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator35 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator((int) (byte) 10, xYItemLabelGenerator35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.8f + "'", float28 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        timeSeries1.setMaximumItemAge((long) (short) 0);
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy(15, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setAnchorValue((double) 4);
        categoryPlot3.setRangePannable(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        int int10 = categoryPlot3.getIndexOf(categoryItemRenderer9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double15 = xYBarRenderer14.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range17 = xYBarRenderer14.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        xYSeriesCollection12.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection16);
        java.util.List list19 = xYSeriesCollection16.getSeries();
        try {
            categoryPlot3.mapDatasetToDomainAxes(37, list19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        xYBarRenderer1.setBasePaint((java.awt.Paint) color3);
        java.lang.Object obj11 = xYBarRenderer1.clone();
        xYBarRenderer1.setBarAlignmentFactor((double) 12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYBarRenderer1.setBaseStroke(stroke14, false);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double22 = xYBarRenderer21.getShadowYOffset();
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        xYBarRenderer21.setBasePaint((java.awt.Paint) color23);
        boolean boolean31 = combinedDomainXYPlot19.equals((java.lang.Object) color23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        combinedDomainXYPlot19.notifyListeners(plotChangeEvent32);
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis39 = new org.jfree.chart.axis.SymbolAxis("", strArray38);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer42.setBaseCreateEntities(true);
        xYLineAndShapeRenderer42.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator47 = xYLineAndShapeRenderer42.getBaseURLGenerator();
        boolean boolean48 = symbolAxis39.equals((java.lang.Object) xYURLGenerator47);
        double double49 = symbolAxis39.getAutoRangeMinimumSize();
        java.awt.Paint paint50 = symbolAxis39.getLabelPaint();
        symbolAxis39.setLowerMargin((double) (short) 1);
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        xYBarRenderer1.drawDomainGridLine(graphics2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19, (org.jfree.chart.axis.ValueAxis) symbolAxis39, rectangle2D53, Double.NaN);
        java.lang.String[] strArray60 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis61 = new org.jfree.chart.axis.SymbolAxis("", strArray60);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer64 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer64.setBaseCreateEntities(true);
        xYLineAndShapeRenderer64.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator69 = xYLineAndShapeRenderer64.getBaseURLGenerator();
        boolean boolean70 = symbolAxis61.equals((java.lang.Object) xYURLGenerator69);
        double double71 = symbolAxis61.getAutoRangeMinimumSize();
        java.awt.Paint paint72 = symbolAxis61.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer74 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double75 = xYBarRenderer74.getShadowYOffset();
        java.awt.Color color76 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel77 = null;
        java.awt.Rectangle rectangle78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color76.createContext(colorModel77, rectangle78, rectangle2D79, affineTransform80, renderingHints81);
        xYBarRenderer74.setBasePaint((java.awt.Paint) color76);
        symbolAxis61.setTickMarkPaint((java.awt.Paint) color76);
        symbolAxis61.setUpperMargin((double) (-1.0f));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer88 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double89 = xYBarRenderer88.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection90 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range91 = xYBarRenderer88.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection90);
        double double93 = xYSeriesCollection90.getRangeUpperBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent94 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) symbolAxis61, (org.jfree.data.general.Dataset) xYSeriesCollection90);
        org.jfree.data.Range range95 = xYBarRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection90);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNull(xYURLGenerator47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0E-8d + "'", double49 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNull(xYURLGenerator69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0E-8d + "'", double71 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 4.0d + "'", double75 == 4.0d);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 4.0d + "'", double89 == 4.0d);
        org.junit.Assert.assertNull(range91);
        org.junit.Assert.assertEquals((double) double93, Double.NaN, 0);
        org.junit.Assert.assertNull(range95);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.util.List list7 = xYSeriesCollection4.getSeries();
        java.lang.Object obj8 = xYSeriesCollection4.clone();
        java.util.List list9 = xYSeriesCollection4.getSeries();
        try {
            int int13 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (-1), 106.0d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getItemLabelPaint();
        java.awt.Paint paint12 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint14 = standardChartTheme1.getCrosshairPaint();
        java.awt.Paint paint15 = standardChartTheme1.getSubtitlePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean21 = chartRenderingInfo19.equals((java.lang.Object) (-1L));
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        chartRenderingInfo19.setEntityCollection(entityCollection22);
        org.jfree.chart.RenderingSource renderingSource24 = null;
        chartRenderingInfo19.setRenderingSource(renderingSource24);
        try {
            java.awt.image.BufferedImage bufferedImage26 = jFreeChart14.createBufferedImage(3, (int) 'a', chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        int int4 = segmentedTimeline3.getGroupSegmentCount();
        int int5 = segmentedTimeline3.getGroupSegmentCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 37 + "'", int4 == 37);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 37 + "'", int5 == 37);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint3);
        org.jfree.chart.plot.Marker marker5 = null;
        boolean boolean6 = combinedDomainXYPlot2.removeDomainMarker(marker5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot2.setRangeAxisLocation(1, axisLocation8, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYBarRenderer12.setBaseToolTipGenerator(xYToolTipGenerator13, false);
        int int16 = combinedDomainXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer12);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis24, polarItemRenderer26);
        polarPlot27.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection30 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double33 = xYBarRenderer32.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range35 = xYBarRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection34);
        xYSeriesCollection30.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection34);
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection34);
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis43 = new org.jfree.chart.axis.SymbolAxis("", strArray42);
        java.awt.Font font44 = symbolAxis43.getLabelFont();
        java.lang.String[] strArray49 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis50 = new org.jfree.chart.axis.SymbolAxis("", strArray49);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer53.setBaseCreateEntities(true);
        xYLineAndShapeRenderer53.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator58 = xYLineAndShapeRenderer53.getBaseURLGenerator();
        boolean boolean59 = symbolAxis50.equals((java.lang.Object) xYURLGenerator58);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer60 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean61 = xYStepAreaRenderer60.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection34, (org.jfree.chart.axis.ValueAxis) symbolAxis43, (org.jfree.chart.axis.ValueAxis) symbolAxis50, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer60);
        polarPlot27.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection34);
        java.awt.Paint paint64 = polarPlot27.getAngleLabelPaint();
        java.lang.String str65 = polarPlot27.getPlotType();
        boolean boolean66 = polarPlot27.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        java.awt.geom.Point2D point2D70 = null;
        polarPlot27.zoomRangeAxes((double) 0.5f, (double) (byte) 10, plotRenderingInfo69, point2D70);
        java.awt.Paint paint72 = polarPlot27.getRadiusGridlinePaint();
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint72);
        boolean boolean74 = itemLabelAnchor0.equals((java.lang.Object) combinedDomainXYPlot2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertEquals((double) number37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNull(xYURLGenerator58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Polar Plot" + "'", str65.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (short) -1);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        java.lang.Object obj16 = jFreeChart14.getTextAntiAlias();
        jFreeChart14.setBorderVisible(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer3.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer3.setBaseStroke(stroke6);
        xYStepAreaRenderer3.setOutline(true);
        java.awt.Font font10 = xYStepAreaRenderer3.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot12.setDomainCrosshairPaint(paint13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) combinedDomainXYPlot12, false);
        java.lang.Object obj17 = jFreeChart16.clone();
        java.awt.RenderingHints renderingHints18 = jFreeChart16.getRenderingHints();
        try {
            multiplePiePlot1.setPieChart(jFreeChart16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(renderingHints18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.Object obj1 = logFormat0.clone();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        java.lang.StringBuffer stringBuffer5 = logFormat0.format((double) 1577865599999L, stringBuffer3, fieldPosition4);
        try {
            java.lang.Object obj7 = logFormat0.parseObject("");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stringBuffer5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYBarRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2, false);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) (short) 100, (java.awt.Paint) color7);
        java.awt.Color color9 = color7.brighter();
        xYBarRenderer1.setBaseItemLabelPaint((java.awt.Paint) color9, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer14.setBaseCreateEntities(true);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        xYLineAndShapeRenderer14.setLegendShape(5, shape19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.entity.XYItemEntity xYItemEntity26 = new org.jfree.chart.entity.XYItemEntity(shape19, xYDataset21, (int) (byte) 1, 9999, "[size=1]", "Polar Plot");
        xYBarRenderer1.setLegendBar(shape19);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxisForDataset(35);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        barRenderer3D0.setMinimumBarLength(8.0d);
        boolean boolean7 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = barRenderer3D0.getDrawingSupplier();
        java.lang.Object obj9 = barRenderer3D0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.notifyListeners(plotChangeEvent14);
        combinedDomainXYPlot1.setDomainZeroBaselineVisible(false);
        combinedDomainXYPlot1.setDomainPannable(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setTextAlignment(horizontalAlignment2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        combinedDomainXYPlot1.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle20.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle20.setLegendItemGraphicLocation(rectangleAnchor22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double28 = xYBarRenderer27.getShadowYOffset();
        java.awt.Color color29 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        xYBarRenderer27.setBasePaint((java.awt.Paint) color29);
        boolean boolean37 = combinedDomainXYPlot25.equals((java.lang.Object) color29);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = null;
        combinedDomainXYPlot25.notifyListeners(plotChangeEvent38);
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("");
        labelBlock41.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis45);
        java.awt.Paint paint47 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot46.setDomainCrosshairPaint(paint47);
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder(rectangleInsets44, paint47);
        double double51 = rectangleInsets44.calculateLeftOutset((double) (short) 100);
        labelBlock41.setMargin(rectangleInsets44);
        combinedDomainXYPlot25.setAxisOffset(rectangleInsets44);
        legendTitle20.setItemLabelPadding(rectangleInsets44);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets44.createInsetRectangle(rectangle2D55, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        jFreeChart14.handleClick((int) (byte) 0, 10, chartRenderingInfo19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double26 = xYBarRenderer25.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range28 = xYBarRenderer25.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection27);
        xYSeriesCollection23.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection27);
        java.util.List list30 = xYSeriesCollection27.getSeries();
        jFreeChart14.setSubtitles(list30);
        jFreeChart14.removeLegend();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        double double6 = piePlot3D1.getShadowYOffset();
        piePlot3D1.setBackgroundImageAlignment(0);
        piePlot3D1.setDarkerSides(false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        combinedDomainXYPlot1.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        legendTitle20.setPadding(rectangleInsets21);
        org.jfree.chart.block.BorderArrangement borderArrangement23 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement23, dataset24, (java.lang.Comparable) 15);
        org.jfree.chart.block.Arrangement arrangement27 = legendItemBlockContainer26.getArrangement();
        legendTitle20.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer26);
        org.jfree.chart.StandardChartTheme standardChartTheme30 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color31 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel32 = null;
        java.awt.Rectangle rectangle33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.geom.AffineTransform affineTransform35 = null;
        java.awt.RenderingHints renderingHints36 = null;
        java.awt.PaintContext paintContext37 = color31.createContext(colorModel32, rectangle33, rectangle2D34, affineTransform35, renderingHints36);
        standardChartTheme30.setTickLabelPaint((java.awt.Paint) color31);
        java.awt.Color color41 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel42 = null;
        java.awt.Rectangle rectangle43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color41.createContext(colorModel42, rectangle43, rectangle2D44, affineTransform45, renderingHints46);
        org.jfree.chart.plot.IntervalMarker intervalMarker48 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color41);
        standardChartTheme30.setLegendBackgroundPaint((java.awt.Paint) color41);
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.RingPlot ringPlot51 = new org.jfree.chart.plot.RingPlot(pieDataset50);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier52 = null;
        ringPlot51.setDrawingSupplier(drawingSupplier52, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent55 = null;
        ringPlot51.markerChanged(markerChangeEvent55);
        ringPlot51.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = ringPlot51.getSimpleLabelOffset();
        standardChartTheme30.setAxisOffset(rectangleInsets59);
        org.jfree.chart.util.Size2D size2D61 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker66.setStartValue(0.0d);
        float float69 = intervalMarker66.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = intervalMarker66.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D71 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D61, 1.0E-8d, 1.0E-8d, rectangleAnchor70);
        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D71);
        java.lang.String[] strArray77 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis78 = new org.jfree.chart.axis.SymbolAxis("", strArray77);
        java.lang.String str80 = symbolAxis78.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity81 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D71, (org.jfree.chart.axis.Axis) symbolAxis78);
        java.awt.geom.Rectangle2D rectangle2D84 = rectangleInsets59.createInsetRectangle(rectangle2D71, false, false);
        legendTitle20.setPadding(rectangleInsets59);
        java.awt.Paint paint86 = legendTitle20.getItemPaint();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(arrangement27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintContext37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paintContext47);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + float69 + "' != '" + 0.8f + "'", float69 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(strArray77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "hi!" + "'", str80.equals("hi!"));
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(paint86);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Shape shape6 = xYLineAndShapeRenderer2.getSeriesShape(0);
        java.lang.Object obj7 = xYLineAndShapeRenderer2.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double11 = xYBarRenderer10.getShadowYOffset();
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        xYBarRenderer10.setBasePaint((java.awt.Paint) color12);
        java.lang.Object obj20 = xYBarRenderer10.clone();
        java.awt.Shape shape21 = xYBarRenderer10.getLegendBar();
        try {
            xYLineAndShapeRenderer2.setSeriesShape((-1), shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) 10L, paint5);
        java.awt.Paint paint7 = piePlot3.getBaseSectionOutlinePaint();
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color10);
        java.lang.Object obj18 = intervalMarker17.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker21.setStartValue(0.0d);
        float float24 = intervalMarker21.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot26.setRangeAxisLocation(axisLocation27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(rectangleInsets29, paint32);
        combinedDomainXYPlot26.setOutlinePaint(paint32);
        intervalMarker21.setOutlinePaint(paint32);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker21.setStroke(stroke37);
        intervalMarker17.setOutlineStroke(stroke37);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder(paint7, stroke37, rectangleInsets40);
        combinedRangeXYPlot0.setAxisOffset(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.8f + "'", float24 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("MAJOR", numberFormat1, numberFormat4);
        int int6 = numberFormat1.getMaximumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color12);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        ringPlot22.setDrawingSupplier(drawingSupplier23, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        ringPlot22.markerChanged(markerChangeEvent26);
        ringPlot22.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = ringPlot22.getSimpleLabelOffset();
        standardChartTheme1.setAxisOffset(rectangleInsets30);
        java.awt.Paint paint32 = standardChartTheme1.getSubtitlePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        org.jfree.chart.plot.Plot plot11 = symbolAxis7.getPlot();
        boolean boolean12 = symbolAxis7.isAutoRange();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue((double) 4);
        categoryPlot6.setRangePannable(false);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        symbolAxis16.setLowerMargin((double) (short) 1);
        symbolAxis16.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer36.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer36.setBaseStroke(stroke39);
        xYStepAreaRenderer36.setOutline(true);
        java.awt.Font font43 = xYStepAreaRenderer36.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis16, 100.0d, 0.0d, (double) 37, (double) 500, font43);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = intervalMarker50.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 1.0E-8d, 1.0E-8d, rectangleAnchor54);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) symbolAxis16, rectangle2D55, (double) (-2L));
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot59 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis58);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot59.setRangeAxisLocation(axisLocation60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot64 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis63);
        java.awt.Paint paint65 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot64.setDomainCrosshairPaint(paint65);
        org.jfree.chart.block.BlockBorder blockBorder67 = new org.jfree.chart.block.BlockBorder(rectangleInsets62, paint65);
        combinedDomainXYPlot59.setOutlinePaint(paint65);
        org.jfree.chart.axis.ValueAxis valueAxis69 = combinedDomainXYPlot59.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation70 = combinedDomainXYPlot59.getRangeAxisLocation();
        categoryPlot6.setRangeAxisLocation(axisLocation70, true);
        org.jfree.chart.axis.ValueAxis valueAxis73 = categoryPlot6.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation75 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot6.setDomainAxisLocation(12, axisLocation75);
        java.awt.Paint paint77 = categoryPlot6.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setSeriesPaint(10, (java.awt.Paint) color5);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer16.setBaseCreateEntities(true);
        int int19 = xYLineAndShapeRenderer16.getPassCount();
        boolean boolean20 = xYLineAndShapeRenderer16.getUseFillPaint();
        java.text.DateFormat dateFormat22 = null;
        java.text.DateFormat dateFormat23 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator24 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat22, dateFormat23);
        xYLineAndShapeRenderer16.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator24, true);
        xYStepAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator24, true);
        java.awt.Font font30 = xYStepAreaRenderer0.lookupLegendTextFont((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(font30);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot5.setRangeAxisLocation(axisLocation6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, paint11);
        combinedDomainXYPlot5.setOutlinePaint(paint11);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (short) 100, (double) (-1), 12.0d, (double) 10.0f, paint11);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        boolean boolean2 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        double double3 = combinedRangeXYPlot0.getGap();
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) (short) 100, (java.awt.Paint) color7);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean11 = combinedRangeXYPlot0.removeRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) intervalMarker8, layer9, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.plot.XYPlot xYPlot17 = jFreeChart14.getXYPlot();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(xYPlot17);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        double double7 = rectangleInsets0.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedDomainXYPlot9.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo12, point2D13);
        combinedDomainXYPlot9.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = combinedDomainXYPlot9.getDomainAxisIndex(valueAxis17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.lang.String str26 = symbolAxis24.valueToString(0.0d);
        int int27 = combinedDomainXYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        boolean boolean28 = rectangleInsets0.equals((java.lang.Object) combinedDomainXYPlot9);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) '#', 3.0d);
        boolean boolean32 = combinedDomainXYPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        double double33 = intervalMarker31.getEndValue();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        segmentedTimeline3.addException((long) 12, (long) 2147483647);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) (short) 10);
        long long11 = segment10.getMillisecond();
        long long12 = segment10.getMillisecond();
        long long13 = segment10.getSegmentNumber();
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Font font6 = symbolAxis5.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot9.setDomainCrosshairPaint(paint10);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, paint10);
        double double14 = rectangleInsets7.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker20.setStartValue(0.0d);
        float float23 = intervalMarker20.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = intervalMarker20.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, 1.0E-8d, 1.0E-8d, rectangleAnchor24);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets7.createInsetRectangle(rectangle2D25);
        symbolAxis5.setUpArrow((java.awt.Shape) rectangle2D25);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.entity.TitleEntity titleEntity30 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D25, (org.jfree.chart.title.Title) textTitle29);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.8f + "'", float23 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot8.setDomainCrosshairPaint(paint9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, paint9);
        double double13 = rectangleInsets6.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker19.setStartValue(0.0d);
        float float22 = intervalMarker19.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = intervalMarker19.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D24 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, 1.0E-8d, 1.0E-8d, rectangleAnchor23);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets6.createInsetRectangle(rectangle2D24);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis27);
        java.awt.Paint paint29 = combinedDomainXYPlot28.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = combinedDomainXYPlot28.getDomainAxisEdge();
        double double31 = categoryAxis2.getCategoryJava2DCoordinate(categoryAnchor3, 1, 100, rectangle2D24, rectangleEdge30);
        boolean boolean32 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) ' ', (double) 0.8f, rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.8f + "'", float22 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (short) 100, 1484232.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range2, range5);
        double double7 = range2.getLength();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2948466.0d + "'", double7 == 2948466.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textBlock0.calculateDimensions(graphics2D3);
        org.junit.Assert.assertNotNull(size2D4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        boolean boolean3 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("MAJOR");
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) '4');
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        barRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator3, true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer6.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer6.setBaseStroke(stroke9);
        xYStepAreaRenderer6.setOutline(true);
        java.awt.Font font13 = xYStepAreaRenderer6.getBaseItemLabelFont();
        barRenderer2.setBaseLegendTextFont(font13);
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("-1,1,0,2", font13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer17.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer17.setBaseStroke(stroke20);
        xYStepAreaRenderer17.setOutline(true);
        java.awt.Font font24 = xYStepAreaRenderer17.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        java.awt.Paint paint27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot26.setDomainCrosshairPaint(paint27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("", font24, (org.jfree.chart.plot.Plot) combinedDomainXYPlot26, false);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        boolean boolean32 = jFreeChart30.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        jFreeChart30.handleClick((int) (byte) 0, 10, chartRenderingInfo35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart30.setBackgroundPaint((java.awt.Paint) color37);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer41.setBaseCreateEntities(true);
        int int44 = xYLineAndShapeRenderer41.getPassCount();
        boolean boolean45 = xYLineAndShapeRenderer41.getUseFillPaint();
        java.lang.Object obj46 = xYLineAndShapeRenderer41.clone();
        boolean boolean47 = color37.equals((java.lang.Object) xYLineAndShapeRenderer41);
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("Range[9999.0,2958465.0]", font13, (java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getOuterSeparatorExtension();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        ringPlot1.setBackgroundPaint((java.awt.Paint) color8);
        boolean boolean10 = ringPlot1.getSeparatorsVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = ringPlot1.getURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(pieURLGenerator11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.notifyListeners(plotChangeEvent14);
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        labelBlock17.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot22.setDomainCrosshairPaint(paint23);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, paint23);
        double double27 = rectangleInsets20.calculateLeftOutset((double) (short) 100);
        labelBlock17.setMargin(rectangleInsets20);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets20);
        double double31 = rectangleInsets20.extendWidth(100.0d);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection32);
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis39 = new org.jfree.chart.axis.SymbolAxis("", strArray38);
        java.awt.Font font40 = symbolAxis39.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection32, (org.jfree.chart.axis.ValueAxis) symbolAxis39, polarItemRenderer41);
        polarPlot42.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection45 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double48 = xYBarRenderer47.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection49 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range50 = xYBarRenderer47.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection49);
        xYSeriesCollection45.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection49);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection49);
        java.lang.String[] strArray57 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis58 = new org.jfree.chart.axis.SymbolAxis("", strArray57);
        java.awt.Font font59 = symbolAxis58.getLabelFont();
        java.lang.String[] strArray64 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis65 = new org.jfree.chart.axis.SymbolAxis("", strArray64);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer68 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer68.setBaseCreateEntities(true);
        xYLineAndShapeRenderer68.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator73 = xYLineAndShapeRenderer68.getBaseURLGenerator();
        boolean boolean74 = symbolAxis65.equals((java.lang.Object) xYURLGenerator73);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer75 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean76 = xYStepAreaRenderer75.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection49, (org.jfree.chart.axis.ValueAxis) symbolAxis58, (org.jfree.chart.axis.ValueAxis) symbolAxis65, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer75);
        polarPlot42.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection49);
        java.awt.Paint paint79 = polarPlot42.getAngleLabelPaint();
        java.awt.Color color80 = org.jfree.chart.ChartColor.DARK_GREEN;
        polarPlot42.setRadiusGridlinePaint((java.awt.Paint) color80);
        polarPlot42.clearCornerTextItems();
        boolean boolean83 = rectangleInsets20.equals((java.lang.Object) polarPlot42);
        java.awt.Paint paint84 = polarPlot42.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 106.0d + "'", double31 == 106.0d);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 4.0d + "'", double48 == 4.0d);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(strArray64);
        org.junit.Assert.assertNull(xYURLGenerator73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(paint84);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.text.DateFormat dateFormat1 = null;
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        numberFormat2.setMinimumFractionDigits(0);
        numberFormat2.setMaximumFractionDigits(0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, numberFormat2);
        try {
            java.lang.Object obj9 = numberFormat2.parseObject("[size=1]");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.lang.String str18 = symbolAxis16.valueToString(0.0d);
        int int19 = combinedDomainXYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis16);
        combinedDomainXYPlot1.configureRangeAxes();
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        standardChartTheme24.setTickLabelPaint((java.awt.Paint) color25);
        java.awt.color.ColorSpace colorSpace33 = color25.getColorSpace();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer34.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer34.setBaseStroke(stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 'a', (java.awt.Paint) color25, stroke37);
        org.jfree.chart.util.Layer layer40 = null;
        combinedDomainXYPlot1.addRangeMarker(5, (org.jfree.chart.plot.Marker) valueMarker39, layer40);
        java.lang.String str42 = valueMarker39.getLabel();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        java.awt.Paint paint3 = piePlot3D1.getBaseSectionPaint();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot5.setDomainCrosshairPaint(paint6);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot5.removeDomainMarker(marker8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double14 = xYBarRenderer13.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range16 = xYBarRenderer13.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        xYSeriesCollection11.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection15);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        java.lang.String[] strArray30 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis31 = new org.jfree.chart.axis.SymbolAxis("", strArray30);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer34.setBaseCreateEntities(true);
        xYLineAndShapeRenderer34.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = xYLineAndShapeRenderer34.getBaseURLGenerator();
        boolean boolean40 = symbolAxis31.equals((java.lang.Object) xYURLGenerator39);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean42 = xYStepAreaRenderer41.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection15, (org.jfree.chart.axis.ValueAxis) symbolAxis24, (org.jfree.chart.axis.ValueAxis) symbolAxis31, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer41);
        combinedDomainXYPlot5.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) symbolAxis31, false);
        piePlot3D1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot5);
        boolean boolean47 = combinedDomainXYPlot5.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertEquals((double) number18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNull(xYURLGenerator39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.lang.Object obj3 = xYLineAndShapeRenderer2.clone();
        java.awt.Stroke stroke4 = xYLineAndShapeRenderer2.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        boolean boolean3 = combinedDomainXYPlot1.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker6.setStartValue(0.0d);
        float float9 = intervalMarker6.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker6.getLabelOffsetType();
        boolean boolean11 = combinedDomainXYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker6);
        java.awt.Stroke stroke12 = combinedDomainXYPlot1.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean14 = xYStepAreaRenderer13.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke16 = xYStepAreaRenderer13.lookupSeriesOutlineStroke((int) (byte) 100);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer18.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer18.setBaseStroke(stroke21);
        xYStepAreaRenderer18.setOutline(true);
        xYStepAreaRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        xYStepAreaRenderer18.clearSeriesPaints(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = null;
        xYBarRenderer31.setBaseToolTipGenerator(xYToolTipGenerator32, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        xYBarRenderer31.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition36, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = xYBarRenderer31.getBasePositiveItemLabelPosition();
        xYStepAreaRenderer18.setSeriesNegativeItemLabelPosition(4, itemLabelPosition39);
        xYStepAreaRenderer13.setBasePositiveItemLabelPosition(itemLabelPosition39);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        xYLineAndShapeRenderer2.setLegendShape(5, shape7);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = xYLineAndShapeRenderer2.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        java.util.Date date2 = dateRange1.getLowerDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = segmentedTimeline0.containsDomainRange(date2, date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine1.calculateDimensions(graphics2D3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = textLine1.calculateDimensions(graphics2D5);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(size2D6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        java.lang.String str2 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart" + "'", str2.equals("JFreeChart"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        segmentedTimeline3.addException((long) 12, (long) 2147483647);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) (short) 10);
        long long11 = segment10.getMillisecond();
        long long12 = segment10.getMillisecond();
        boolean boolean14 = segment10.contains((long) (-1));
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLowerMargin();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection2);
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis9 = new org.jfree.chart.axis.SymbolAxis("", strArray8);
        java.awt.Font font10 = symbolAxis9.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, (org.jfree.chart.axis.ValueAxis) symbolAxis9, polarItemRenderer11);
        polarPlot12.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double18 = xYBarRenderer17.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range20 = xYBarRenderer17.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        xYSeriesCollection15.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection19);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis28 = new org.jfree.chart.axis.SymbolAxis("", strArray27);
        java.awt.Font font29 = symbolAxis28.getLabelFont();
        java.lang.String[] strArray34 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis35 = new org.jfree.chart.axis.SymbolAxis("", strArray34);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer38.setBaseCreateEntities(true);
        xYLineAndShapeRenderer38.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator43 = xYLineAndShapeRenderer38.getBaseURLGenerator();
        boolean boolean44 = symbolAxis35.equals((java.lang.Object) xYURLGenerator43);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer45 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean46 = xYStepAreaRenderer45.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection19, (org.jfree.chart.axis.ValueAxis) symbolAxis28, (org.jfree.chart.axis.ValueAxis) symbolAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer45);
        polarPlot12.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        java.awt.Paint paint49 = polarPlot12.getAngleLabelPaint();
        java.lang.String str50 = polarPlot12.getPlotType();
        boolean boolean51 = polarPlot12.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        polarPlot12.zoomRangeAxes((double) 0.5f, (double) (byte) 10, plotRenderingInfo54, point2D55);
        java.awt.Paint paint57 = polarPlot12.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = polarPlot12.getOrientation();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection59 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent60 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection59);
        java.lang.String[] strArray65 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis66 = new org.jfree.chart.axis.SymbolAxis("", strArray65);
        java.awt.Font font67 = symbolAxis66.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer68 = null;
        org.jfree.chart.plot.PolarPlot polarPlot69 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection59, (org.jfree.chart.axis.ValueAxis) symbolAxis66, polarItemRenderer68);
        boolean boolean70 = polarPlot69.isRadiusGridlinesVisible();
        boolean boolean71 = polarPlot69.isAngleGridlinesVisible();
        java.lang.String[] strArray76 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis77 = new org.jfree.chart.axis.SymbolAxis("", strArray76);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer80 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer80.setBaseCreateEntities(true);
        xYLineAndShapeRenderer80.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator85 = xYLineAndShapeRenderer80.getBaseURLGenerator();
        boolean boolean86 = symbolAxis77.equals((java.lang.Object) xYURLGenerator85);
        double double87 = symbolAxis77.getAutoRangeMinimumSize();
        java.awt.Paint paint88 = symbolAxis77.getLabelPaint();
        symbolAxis77.setLowerMargin((double) (short) 1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit91 = symbolAxis77.getTickUnit();
        polarPlot69.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit91);
        polarPlot12.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit91);
        java.awt.Font font94 = categoryAxis0.getTickLabelFont((java.lang.Comparable) numberTickUnit91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertEquals((double) number22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNull(xYURLGenerator43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Polar Plot" + "'", str50.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertNull(xYURLGenerator85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.0E-8d + "'", double87 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(numberTickUnit91);
        org.junit.Assert.assertNotNull(font94);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setOuterSeparatorExtension((double) 37);
        ringPlot1.setLabelGap((double) (-2208960000000L));
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.awt.Font font17 = symbolAxis16.getLabelFont();
        ringPlot1.setLabelFont(font17);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        java.awt.Color color2 = java.awt.Color.GRAY;
        org.jfree.chart.title.LegendGraphic legendGraphic3 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker14.setStartValue(0.0d);
        float float17 = intervalMarker14.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = intervalMarker14.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, 1.0E-8d, 1.0E-8d, rectangleAnchor18);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection23);
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis30 = new org.jfree.chart.axis.SymbolAxis("", strArray29);
        java.awt.Font font31 = symbolAxis30.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection23, (org.jfree.chart.axis.ValueAxis) symbolAxis30, polarItemRenderer32);
        polarPlot33.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection36 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double39 = xYBarRenderer38.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection40 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range41 = xYBarRenderer38.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection40);
        xYSeriesCollection36.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection40);
        java.lang.Number number43 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection40);
        java.lang.String[] strArray48 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis49 = new org.jfree.chart.axis.SymbolAxis("", strArray48);
        java.awt.Font font50 = symbolAxis49.getLabelFont();
        java.lang.String[] strArray55 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis56 = new org.jfree.chart.axis.SymbolAxis("", strArray55);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer59 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer59.setBaseCreateEntities(true);
        xYLineAndShapeRenderer59.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator64 = xYLineAndShapeRenderer59.getBaseURLGenerator();
        boolean boolean65 = symbolAxis56.equals((java.lang.Object) xYURLGenerator64);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer66 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean67 = xYStepAreaRenderer66.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection40, (org.jfree.chart.axis.ValueAxis) symbolAxis49, (org.jfree.chart.axis.ValueAxis) symbolAxis56, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer66);
        polarPlot33.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection40);
        java.awt.Paint paint70 = polarPlot33.getAngleLabelPaint();
        java.awt.Color color71 = org.jfree.chart.ChartColor.DARK_GREEN;
        polarPlot33.setRadiusGridlinePaint((java.awt.Paint) color71);
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("DateTickUnitType.MINUTE", "PieLabelLinkStyle.STANDARD", "LengthConstraintType.NONE", "ThreadContext", (java.awt.Shape) rectangle2D19, (java.awt.Paint) color21, stroke22, (java.awt.Paint) color71);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot74.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot74.zoomRangeAxes(0.0d, plotRenderingInfo78, point2D79, false);
        java.util.List list82 = categoryPlot74.getCategories();
        org.jfree.chart.util.Layer layer83 = null;
        java.util.Collection collection84 = categoryPlot74.getDomainMarkers(layer83);
        try {
            java.lang.Object obj85 = legendGraphic3.draw(graphics2D4, rectangle2D19, (java.lang.Object) collection84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.8f + "'", float17 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertEquals((double) number43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNull(xYURLGenerator64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNull(list82);
        org.junit.Assert.assertNull(collection84);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DateTickUnitType.MINUTE", timeZone1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        standardChartTheme6.setTickLabelPaint((java.awt.Paint) color7);
        java.awt.Color color17 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color17);
        standardChartTheme6.setLegendBackgroundPaint((java.awt.Paint) color17);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot(pieDataset26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = null;
        ringPlot27.setDrawingSupplier(drawingSupplier28, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        ringPlot27.markerChanged(markerChangeEvent31);
        ringPlot27.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = ringPlot27.getSimpleLabelOffset();
        standardChartTheme6.setAxisOffset(rectangleInsets35);
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker42.setStartValue(0.0d);
        float float45 = intervalMarker42.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = intervalMarker42.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 1.0E-8d, 1.0E-8d, rectangleAnchor46);
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D47);
        java.lang.String[] strArray53 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis54 = new org.jfree.chart.axis.SymbolAxis("", strArray53);
        java.lang.String str56 = symbolAxis54.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity57 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D47, (org.jfree.chart.axis.Axis) symbolAxis54);
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets35.createInsetRectangle(rectangle2D47, false, false);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor63 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot68 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis67);
        java.awt.Paint paint69 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot68.setDomainCrosshairPaint(paint69);
        org.jfree.chart.block.BlockBorder blockBorder71 = new org.jfree.chart.block.BlockBorder(rectangleInsets66, paint69);
        double double73 = rectangleInsets66.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D74 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker79.setStartValue(0.0d);
        float float82 = intervalMarker79.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor83 = intervalMarker79.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D84 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D74, 1.0E-8d, 1.0E-8d, rectangleAnchor83);
        java.awt.Shape shape85 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D84);
        java.awt.geom.Rectangle2D rectangle2D86 = rectangleInsets66.createInsetRectangle(rectangle2D84);
        org.jfree.chart.axis.ValueAxis valueAxis87 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot88 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis87);
        java.awt.Paint paint89 = combinedDomainXYPlot88.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = combinedDomainXYPlot88.getDomainAxisEdge();
        double double91 = categoryAxis62.getCategoryJava2DCoordinate(categoryAnchor63, 1, 100, rectangle2D84, rectangleEdge90);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo92 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection93 = chartRenderingInfo92.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = chartRenderingInfo92.getPlotInfo();
        try {
            org.jfree.chart.axis.AxisState axisState95 = dateAxis2.draw(graphics2D3, 0.0d, rectangle2D47, rectangle2D61, rectangleEdge90, plotRenderingInfo94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.8f + "'", float45 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 3.0d + "'", double73 == 3.0d);
        org.junit.Assert.assertTrue("'" + float82 + "' != '" + 0.8f + "'", float82 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor83);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(rectangle2D86);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(rectangleEdge90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection93);
        org.junit.Assert.assertNotNull(plotRenderingInfo94);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setNotify(true);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle0.setVerticalAlignment(verticalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedDomainXYPlot1.getLegendItems();
        java.awt.Stroke stroke15 = combinedDomainXYPlot1.getDomainCrosshairStroke();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            combinedDomainXYPlot1.addRangeMarker((int) (short) -1, marker17, layer18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer18);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("0", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis22 = new org.jfree.chart.axis.SymbolAxis("", strArray21);
        combinedRangeXYPlot11.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) symbolAxis22);
        double double24 = symbolAxis22.getFixedDimension();
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis30 = new org.jfree.chart.axis.SymbolAxis("", strArray29);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer33.setBaseCreateEntities(true);
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = xYLineAndShapeRenderer33.getBaseURLGenerator();
        boolean boolean39 = symbolAxis30.equals((java.lang.Object) xYURLGenerator38);
        double double40 = symbolAxis30.getAutoRangeMinimumSize();
        java.awt.Paint paint41 = symbolAxis30.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer43 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double44 = xYBarRenderer43.getShadowYOffset();
        java.awt.Color color45 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel46 = null;
        java.awt.Rectangle rectangle47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color45.createContext(colorModel46, rectangle47, rectangle2D48, affineTransform49, renderingHints50);
        xYBarRenderer43.setBasePaint((java.awt.Paint) color45);
        symbolAxis30.setTickMarkPaint((java.awt.Paint) color45);
        org.jfree.data.Range range54 = symbolAxis30.getRange();
        symbolAxis22.setRangeWithMargins(range54, true, false);
        org.jfree.chart.axis.TickUnits tickUnits58 = new org.jfree.chart.axis.TickUnits();
        symbolAxis22.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits58);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNull(xYURLGenerator38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0E-8d + "'", double40 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paintContext51);
        org.junit.Assert.assertNotNull(range54);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot4.setDomainCrosshairPaint(paint5);
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot4.setRangeAxisLocation(1, axisLocation10, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYBarRenderer14.setBaseToolTipGenerator(xYToolTipGenerator15, false);
        int int18 = combinedDomainXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        combinedDomainXYPlot1.setRangeCrosshairVisible(false);
        java.awt.Stroke stroke22 = combinedDomainXYPlot1.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer3D0.getBarPainter();
        barRenderer3D0.setMaximumBarWidth((double) 15);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer3D0.getBaseToolTipGenerator();
        double double6 = barRenderer3D0.getItemMargin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        combinedDomainXYPlot10.setDrawingSupplier(drawingSupplier15, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer20.setBaseCreateEntities(true);
        java.awt.Shape shape24 = xYLineAndShapeRenderer20.getSeriesShape(0);
        java.lang.Object obj25 = xYLineAndShapeRenderer20.clone();
        combinedDomainXYPlot10.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(shape24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter4 = xYBarRenderer1.getBarPainter();
        java.awt.Paint paint8 = xYBarRenderer1.getItemFillPaint(2147483647, (-1), false);
        double double9 = xYBarRenderer1.getBase();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYBarRenderer1.setBaseToolTipGenerator(xYToolTipGenerator10);
        org.junit.Assert.assertNotNull(xYBarPainter4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getLastTextFragment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = textLine0.calculateDimensions(graphics2D2);
        org.junit.Assert.assertNull(textFragment1);
        org.junit.Assert.assertNotNull(size2D3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        size2D0.height = (-1L);
        java.lang.Object obj4 = size2D0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer10.setBaseCreateEntities(true);
        int int13 = xYLineAndShapeRenderer10.getPassCount();
        boolean boolean14 = xYLineAndShapeRenderer10.getUseFillPaint();
        java.text.DateFormat dateFormat16 = null;
        java.text.DateFormat dateFormat17 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator18 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat16, dateFormat17);
        xYLineAndShapeRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator18, true);
        xYLineAndShapeRenderer2.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator18);
        boolean boolean22 = xYLineAndShapeRenderer2.getDrawOutlines();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        combinedRangeXYPlot11.setRangePannable(false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = combinedRangeXYPlot11.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double24 = xYBarRenderer23.getShadowYOffset();
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        xYBarRenderer23.setBasePaint((java.awt.Paint) color25);
        boolean boolean33 = combinedDomainXYPlot21.equals((java.lang.Object) color25);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = null;
        combinedDomainXYPlot21.notifyListeners(plotChangeEvent34);
        combinedDomainXYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation39 = combinedDomainXYPlot21.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation41 = combinedDomainXYPlot21.getDomainAxisLocation(8);
        combinedRangeXYPlot11.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot21, (int) (short) 1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder44 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        combinedRangeXYPlot11.setSeriesRenderingOrder(seriesRenderingOrder44);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(seriesRenderingOrder44);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(100.0d, (double) 1L, (double) (byte) 10, 15.625d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        boolean boolean7 = ringPlot1.getSimpleLabels();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot1.getLegendLabelGenerator();
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        xYSeries2.add((double) 0.0f, (double) '#');
        double[][] doubleArray12 = xYSeries2.toArray();
        xYSeries2.add((java.lang.Number) 10.0d, (java.lang.Number) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        try {
            timeSeries1.delete(0, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer4.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer4.setBaseStroke(stroke7);
        xYStepAreaRenderer4.setOutline(true);
        java.awt.Font font11 = xYStepAreaRenderer4.getBaseItemLabelFont();
        barRenderer0.setBaseLegendTextFont(font11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.xy.XYSeries xYSeries20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer23.setBaseCreateEntities(true);
        boolean boolean26 = xYSeries20.equals((java.lang.Object) true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection27);
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis34 = new org.jfree.chart.axis.SymbolAxis("", strArray33);
        java.awt.Font font35 = symbolAxis34.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection27, (org.jfree.chart.axis.ValueAxis) symbolAxis34, polarItemRenderer36);
        xYSeries20.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection27);
        double[][] doubleArray39 = xYSeries20.toArray();
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie 3D Plot", "{0}: ({1}, {2})", doubleArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataItem xYDataItem44 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2, (java.lang.Number) (short) 100);
        double double45 = xYDataItem44.getXValue();
        categoryAxis41.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem44, "LengthConstraintType.NONE");
        org.jfree.chart.block.LabelBlock labelBlock49 = new org.jfree.chart.block.LabelBlock("");
        labelBlock49.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot54 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis53);
        java.awt.Paint paint55 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot54.setDomainCrosshairPaint(paint55);
        org.jfree.chart.block.BlockBorder blockBorder57 = new org.jfree.chart.block.BlockBorder(rectangleInsets52, paint55);
        double double59 = rectangleInsets52.calculateLeftOutset((double) (short) 100);
        labelBlock49.setMargin(rectangleInsets52);
        labelBlock49.setWidth((double) 255);
        java.awt.geom.Rectangle2D rectangle2D63 = labelBlock49.getBounds();
        org.jfree.chart.axis.AxisSpace axisSpace64 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.Size2D size2D65 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D69 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D65, (double) (-1.0f), (double) 1L, rectangleAnchor68);
        java.lang.String[] strArray74 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis75 = new org.jfree.chart.axis.SymbolAxis("", strArray74);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer78 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer78.setBaseCreateEntities(true);
        xYLineAndShapeRenderer78.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator83 = xYLineAndShapeRenderer78.getBaseURLGenerator();
        boolean boolean84 = symbolAxis75.equals((java.lang.Object) xYURLGenerator83);
        double double85 = symbolAxis75.getAutoRangeMinimumSize();
        java.awt.Paint paint86 = symbolAxis75.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity88 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D69, (org.jfree.chart.axis.Axis) symbolAxis75, "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.awt.geom.Rectangle2D rectangle2D90 = axisSpace64.reserved(rectangle2D69, rectangleEdge89);
        try {
            double double91 = barRenderer0.getItemMiddle((java.lang.Comparable) 100L, (java.lang.Comparable) year14, categoryDataset40, categoryAxis41, rectangle2D63, rectangleEdge89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.0d + "'", double59 == 3.0d);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(strArray74);
        org.junit.Assert.assertNull(xYURLGenerator83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.0E-8d + "'", double85 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertNotNull(rectangle2D90);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        java.awt.Paint paint8 = combinedDomainXYPlot7.getRangeZeroBaselinePaint();
        boolean boolean9 = combinedDomainXYPlot7.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker12.setStartValue(0.0d);
        float float15 = intervalMarker12.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = intervalMarker12.getLabelOffsetType();
        boolean boolean17 = combinedDomainXYPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        java.awt.Stroke stroke19 = intervalMarker12.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.8f + "'", float15 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        categoryPlot0.setBackgroundImageAlignment(12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        combinedDomainXYPlot1.setFixedRangeAxisSpace(axisSpace33);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedDomainXYPlot1);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot37 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis36);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double40 = xYBarRenderer39.getShadowYOffset();
        java.awt.Color color41 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel42 = null;
        java.awt.Rectangle rectangle43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color41.createContext(colorModel42, rectangle43, rectangle2D44, affineTransform45, renderingHints46);
        xYBarRenderer39.setBasePaint((java.awt.Paint) color41);
        boolean boolean49 = combinedDomainXYPlot37.equals((java.lang.Object) color41);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier50 = null;
        combinedDomainXYPlot37.setDrawingSupplier(drawingSupplier50);
        combinedDomainXYPlot37.setDomainCrosshairValue((double) 2958465, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker57 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker57.setStartValue(0.0d);
        float float60 = intervalMarker57.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot62 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis61);
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot62.setRangeAxisLocation(axisLocation63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot67 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis66);
        java.awt.Paint paint68 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot67.setDomainCrosshairPaint(paint68);
        org.jfree.chart.block.BlockBorder blockBorder70 = new org.jfree.chart.block.BlockBorder(rectangleInsets65, paint68);
        combinedDomainXYPlot62.setOutlinePaint(paint68);
        intervalMarker57.setOutlinePaint(paint68);
        boolean boolean73 = combinedDomainXYPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker57);
        java.awt.Stroke stroke74 = combinedDomainXYPlot37.getDomainMinorGridlineStroke();
        combinedDomainXYPlot1.setDomainMinorGridlineStroke(stroke74);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paintContext47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.8f + "'", float60 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter4 = xYBarRenderer1.getBarPainter();
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYBarRenderer1.setBaseStroke(stroke5);
        java.awt.Shape shape7 = xYBarRenderer1.getLegendBar();
        org.junit.Assert.assertNotNull(xYBarPainter4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Paint paint6 = symbolAxis5.getGridBandAlternatePaint();
        symbolAxis5.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        categoryPlot0.setRangePannable(false);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataItem xYDataItem12 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2, (java.lang.Number) (short) 100);
        double double13 = xYDataItem12.getXValue();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem12, "LengthConstraintType.NONE");
        categoryAxis9.configure();
        int int17 = categoryPlot0.getDomainAxisIndex(categoryAxis9);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("MAJOR", numberFormat1, numberFormat4);
        try {
            java.lang.Number number7 = numberFormat4.parse("[size=1]");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"[size=1]\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        long long3 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-57600000L) + "'", long3 == (-57600000L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        double double4 = barRenderer3D0.getXOffset();
        barRenderer3D0.setMinimumBarLength(8.0d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = barRenderer3D0.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.awt.Font font17 = symbolAxis16.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, (org.jfree.chart.axis.ValueAxis) symbolAxis16, polarItemRenderer18);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection9);
        boolean boolean21 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        double double3 = piePlot3D2.getLabelGap();
        java.awt.Paint paint4 = piePlot3D2.getBaseSectionPaint();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = combinedDomainXYPlot6.removeDomainMarker(marker9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double15 = xYBarRenderer14.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range17 = xYBarRenderer14.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        xYSeriesCollection12.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection16);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis25 = new org.jfree.chart.axis.SymbolAxis("", strArray24);
        java.awt.Font font26 = symbolAxis25.getLabelFont();
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis32 = new org.jfree.chart.axis.SymbolAxis("", strArray31);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer35.setBaseCreateEntities(true);
        xYLineAndShapeRenderer35.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator40 = xYLineAndShapeRenderer35.getBaseURLGenerator();
        boolean boolean41 = symbolAxis32.equals((java.lang.Object) xYURLGenerator40);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean43 = xYStepAreaRenderer42.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection16, (org.jfree.chart.axis.ValueAxis) symbolAxis25, (org.jfree.chart.axis.ValueAxis) symbolAxis32, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer42);
        combinedDomainXYPlot6.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) symbolAxis32, false);
        piePlot3D2.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot6);
        org.jfree.chart.StandardChartTheme standardChartTheme49 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color50 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel51 = null;
        java.awt.Rectangle rectangle52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.AffineTransform affineTransform54 = null;
        java.awt.RenderingHints renderingHints55 = null;
        java.awt.PaintContext paintContext56 = color50.createContext(colorModel51, rectangle52, rectangle2D53, affineTransform54, renderingHints55);
        standardChartTheme49.setTickLabelPaint((java.awt.Paint) color50);
        combinedDomainXYPlot6.setDomainGridlinePaint((java.awt.Paint) color50);
        java.awt.Stroke stroke59 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker(1.0E-8d, (java.awt.Paint) color50, stroke59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertEquals((double) number19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNull(xYURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintContext56);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.lang.Object obj15 = jFreeChart14.clone();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.lang.String str18 = textTitle17.getToolTipText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle17.setVerticalAlignment(verticalAlignment19);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int22 = barRenderer3D21.getRowCount();
        barRenderer3D21.setIncludeBaseInRange(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double28 = xYBarRenderer27.getShadowYOffset();
        java.awt.Color color29 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        xYBarRenderer27.setBasePaint((java.awt.Paint) color29);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color29);
        java.lang.Comparable comparable38 = legendItem37.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis39);
        java.awt.Paint paint41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot40.setDomainCrosshairPaint(paint41);
        org.jfree.chart.plot.Marker marker43 = null;
        boolean boolean44 = combinedDomainXYPlot40.removeDomainMarker(marker43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot40.setRangeAxisLocation(1, axisLocation46, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer50 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator51 = null;
        xYBarRenderer50.setBaseToolTipGenerator(xYToolTipGenerator51, false);
        int int54 = combinedDomainXYPlot40.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer50);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker61 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker61.setStartValue(0.0d);
        float float64 = intervalMarker61.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = intervalMarker61.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D66 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, 1.0E-8d, 1.0E-8d, rectangleAnchor65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.chart.plot.CrosshairState crosshairState70 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean71 = combinedDomainXYPlot40.render(graphics2D55, rectangle2D66, (int) (short) 0, plotRenderingInfo68, crosshairState70);
        legendItem37.setShape((java.awt.Shape) rectangle2D66);
        barRenderer3D21.setBaseShape((java.awt.Shape) rectangle2D66, false);
        textTitle17.setBounds(rectangle2D66);
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot77 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis76);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        java.awt.geom.Point2D point2D81 = null;
        combinedDomainXYPlot77.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo80, point2D81);
        org.jfree.chart.util.Layer layer84 = null;
        java.util.Collection collection85 = combinedDomainXYPlot77.getRangeMarkers(12, layer84);
        int int86 = combinedDomainXYPlot77.getDatasetCount();
        combinedDomainXYPlot77.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = null;
        java.awt.geom.Point2D point2D92 = null;
        combinedDomainXYPlot77.panRangeAxes((double) 1L, plotRenderingInfo91, point2D92);
        combinedDomainXYPlot77.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle96 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot77);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor97 = legendTitle96.getLegendItemGraphicLocation();
        org.jfree.chart.entity.TitleEntity titleEntity98 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D66, (org.jfree.chart.title.Title) legendTitle96);
        try {
            jFreeChart14.addSubtitle((int) (byte) -1, (org.jfree.chart.title.Title) legendTitle96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertNull(comparable38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.8f + "'", float64 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(collection85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor97);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        boolean boolean15 = symbolAxis5.isAxisLineVisible();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getGridBandPaint();
        java.lang.String str12 = standardChartTheme1.getName();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Oct" + "'", str12.equals("Oct"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        categoryPlot0.clearRangeMarkers();
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        barRenderer3D0.setItemMargin((double) 37);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator9, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d, (int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = combinedDomainXYPlot10.getOrientation();
        crosshairState1.updateCrosshairPoint(12.0d, 0.0d, 0.0d, 3.0d, plotOrientation11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection13);
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        java.awt.Font font21 = symbolAxis20.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, (org.jfree.chart.axis.ValueAxis) symbolAxis20, polarItemRenderer22);
        boolean boolean24 = polarPlot23.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        polarPlot23.zoomRangeAxes((double) (byte) -1, plotRenderingInfo26, point2D27);
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, (double) (-1.0f), (double) 1L, rectangleAnchor34);
        java.awt.Point point36 = polarPlot23.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D35);
        crosshairState1.setAnchor((java.awt.geom.Point2D) point36);
        crosshairState1.updateCrosshairY((double) 1L);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(point36);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        combinedRangeXYPlot11.setRangePannable(false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = combinedRangeXYPlot11.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double24 = xYBarRenderer23.getShadowYOffset();
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        xYBarRenderer23.setBasePaint((java.awt.Paint) color25);
        boolean boolean33 = combinedDomainXYPlot21.equals((java.lang.Object) color25);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = null;
        combinedDomainXYPlot21.notifyListeners(plotChangeEvent34);
        combinedDomainXYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation39 = combinedDomainXYPlot21.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation41 = combinedDomainXYPlot21.getDomainAxisLocation(8);
        combinedRangeXYPlot11.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot21, (int) (short) 1);
        java.awt.Stroke stroke44 = combinedDomainXYPlot21.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        timeSeries1.setMaximumItemAge((long) (short) 0);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        barRenderer3D0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double8 = barRenderer3D7.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter12 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D7.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter12);
        barRenderer3D7.setItemMargin((double) 37);
        double double16 = barRenderer3D7.getBase();
        java.awt.Stroke stroke20 = barRenderer3D7.getItemStroke(5, 10, false);
        barRenderer3D0.setSeriesStroke((int) 'a', stroke20, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.mapDatasetToRangeAxis(3, (-1));
        java.lang.Object obj10 = categoryPlot0.clone();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer12.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer12.setBaseStroke(stroke15);
        xYStepAreaRenderer12.setOutline(true);
        java.awt.Font font19 = xYStepAreaRenderer12.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis20);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot21.setDomainCrosshairPaint(paint22);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("", font19, (org.jfree.chart.plot.Plot) combinedDomainXYPlot21, false);
        categoryPlot0.setNoDataMessageFont(font19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        xYLineAndShapeRenderer2.removeAnnotations();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        boolean boolean7 = combinedDomainXYPlot1.canSelectByRegion();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2, (java.lang.Number) (short) 100);
        xYSeries2.add(xYDataItem5, false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        org.jfree.chart.axis.TickUnits tickUnits29 = new org.jfree.chart.axis.TickUnits();
        int int30 = tickUnits29.size();
        int int31 = tickUnits29.size();
        java.lang.Object obj32 = tickUnits29.clone();
        symbolAxis5.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits29);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("MAJOR");
        java.lang.Object obj3 = standardPieToolTipGenerator2.clone();
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) standardPieToolTipGenerator2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getToolTipText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int5 = barRenderer3D4.getRowCount();
        barRenderer3D4.setIncludeBaseInRange(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double11 = xYBarRenderer10.getShadowYOffset();
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        xYBarRenderer10.setBasePaint((java.awt.Paint) color12);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color12);
        java.lang.Comparable comparable21 = legendItem20.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis22);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot23.setDomainCrosshairPaint(paint24);
        org.jfree.chart.plot.Marker marker26 = null;
        boolean boolean27 = combinedDomainXYPlot23.removeDomainMarker(marker26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot23.setRangeAxisLocation(1, axisLocation29, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator34 = null;
        xYBarRenderer33.setBaseToolTipGenerator(xYToolTipGenerator34, false);
        int int37 = combinedDomainXYPlot23.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer33);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker44.setStartValue(0.0d);
        float float47 = intervalMarker44.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = intervalMarker44.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 1.0E-8d, 1.0E-8d, rectangleAnchor48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.chart.plot.CrosshairState crosshairState53 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean54 = combinedDomainXYPlot23.render(graphics2D38, rectangle2D49, (int) (short) 0, plotRenderingInfo51, crosshairState53);
        legendItem20.setShape((java.awt.Shape) rectangle2D49);
        barRenderer3D4.setBaseShape((java.awt.Shape) rectangle2D49, false);
        textTitle0.setBounds(rectangle2D49);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot60 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        java.awt.geom.Point2D point2D64 = null;
        combinedDomainXYPlot60.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo63, point2D64);
        org.jfree.chart.util.Layer layer67 = null;
        java.util.Collection collection68 = combinedDomainXYPlot60.getRangeMarkers(12, layer67);
        int int69 = combinedDomainXYPlot60.getDatasetCount();
        combinedDomainXYPlot60.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        java.awt.geom.Point2D point2D75 = null;
        combinedDomainXYPlot60.panRangeAxes((double) 1L, plotRenderingInfo74, point2D75);
        combinedDomainXYPlot60.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.title.LegendTitle legendTitle79 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor80 = legendTitle79.getLegendItemGraphicLocation();
        org.jfree.chart.entity.TitleEntity titleEntity81 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D49, (org.jfree.chart.title.Title) legendTitle79);
        java.lang.String str82 = titleEntity81.getToolTipText();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.8f + "'", float47 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(collection68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor80);
        org.junit.Assert.assertNull(str82);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities((int) (short) 0);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = xYLineAndShapeRenderer2.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setOuterSeparatorExtension((double) 37);
        ringPlot1.setLabelGap((double) (-2208960000000L));
        double double11 = ringPlot1.getShadowXOffset();
        ringPlot1.setAutoPopulateSectionOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.Object obj1 = combinedRangeXYPlot0.clone();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        java.awt.Color color18 = java.awt.Color.BLUE;
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color18);
        double double20 = symbolAxis8.getUpperBound();
        symbolAxis8.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        java.awt.Paint paint26 = combinedDomainXYPlot25.getRangeZeroBaselinePaint();
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis32 = new org.jfree.chart.axis.SymbolAxis("", strArray31);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer35.setBaseCreateEntities(true);
        xYLineAndShapeRenderer35.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator40 = xYLineAndShapeRenderer35.getBaseURLGenerator();
        boolean boolean41 = symbolAxis32.equals((java.lang.Object) xYURLGenerator40);
        double double42 = symbolAxis32.getAutoRangeMinimumSize();
        java.awt.Paint paint43 = symbolAxis32.getLabelPaint();
        int int44 = combinedDomainXYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis32);
        org.jfree.data.Range range45 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis32);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNull(xYURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0E-8d + "'", double42 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color12);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        ringPlot22.setDrawingSupplier(drawingSupplier23, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        ringPlot22.markerChanged(markerChangeEvent26);
        ringPlot22.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = ringPlot22.getSimpleLabelOffset();
        standardChartTheme1.setAxisOffset(rectangleInsets30);
        java.awt.Paint paint32 = standardChartTheme1.getSubtitlePaint();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D(pieDataset33);
        double double35 = piePlot3D34.getLabelGap();
        java.awt.Paint paint36 = piePlot3D34.getBaseSectionPaint();
        java.awt.Paint paint37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D(pieDataset38);
        double double40 = piePlot3D39.getLabelGap();
        java.awt.Color color41 = java.awt.Color.lightGray;
        piePlot3D39.setLabelShadowPaint((java.awt.Paint) color41);
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { paint32, paint36, paint37, color41 };
        java.awt.Paint[] paintArray44 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray45 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray43, paintArray44, strokeArray45, strokeArray46, shapeArray47);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.025d + "'", double35 == 0.025d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.025d + "'", double40 == 0.025d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(paintArray44);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        long long9 = segmentedTimeline6.getExceptionSegmentCount((long) '#', (long) 37);
        long long10 = segmentedTimeline6.getSegmentsExcludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        java.util.Date date14 = dateRange13.getLowerDate();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        boolean boolean18 = segmentedTimeline12.containsDomainRange(date14, date17);
        segmentedTimeline11.setBaseTimeline(segmentedTimeline12);
        java.util.Date date21 = segmentedTimeline12.getDate((long) 1);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment22 = segmentedTimeline6.getSegment(date21);
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date24 = dateTickUnit2.addToDate(date21, timeZone23);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2L) + "'", long10 == (-2L));
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(segment22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairVisible(false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        legendItem12.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker21.setStartValue(0.0d);
        float float24 = intervalMarker21.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = intervalMarker21.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, 1.0E-8d, 1.0E-8d, rectangleAnchor25);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D26);
        legendItem12.setLine((java.awt.Shape) rectangle2D26);
        java.lang.String str29 = legendItem12.getLabel();
        org.jfree.chart.StandardChartTheme standardChartTheme31 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color32 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel33 = null;
        java.awt.Rectangle rectangle34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.geom.AffineTransform affineTransform36 = null;
        java.awt.RenderingHints renderingHints37 = null;
        java.awt.PaintContext paintContext38 = color32.createContext(colorModel33, rectangle34, rectangle2D35, affineTransform36, renderingHints37);
        standardChartTheme31.setTickLabelPaint((java.awt.Paint) color32);
        java.awt.Color color42 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel43 = null;
        java.awt.Rectangle rectangle44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color42.createContext(colorModel43, rectangle44, rectangle2D45, affineTransform46, renderingHints47);
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color42);
        standardChartTheme31.setLegendBackgroundPaint((java.awt.Paint) color42);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D51 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int52 = barRenderer3D51.getRowCount();
        org.jfree.chart.renderer.category.BarPainter barPainter53 = barRenderer3D51.getBarPainter();
        standardChartTheme31.setBarPainter(barPainter53);
        java.awt.Font font55 = standardChartTheme31.getRegularFont();
        legendItem12.setLabelFont(font55);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.8f + "'", float24 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Oct" + "'", str29.equals("Oct"));
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintContext38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(barPainter53);
        org.junit.Assert.assertNotNull(font55);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        java.awt.Color color2 = java.awt.Color.GRAY;
        org.jfree.chart.title.LegendGraphic legendGraphic3 = new org.jfree.chart.title.LegendGraphic(shape1, (java.awt.Paint) color2);
        boolean boolean4 = legendGraphic3.isLineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (-1.0f), (double) 1L, rectangleAnchor9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer19.setBaseCreateEntities(true);
        xYLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYLineAndShapeRenderer19.getBaseURLGenerator();
        boolean boolean25 = symbolAxis16.equals((java.lang.Object) xYURLGenerator24);
        double double26 = symbolAxis16.getAutoRangeMinimumSize();
        java.awt.Paint paint27 = symbolAxis16.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity29 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D10, (org.jfree.chart.axis.Axis) symbolAxis16, "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.awt.geom.Rectangle2D rectangle2D31 = axisSpace5.reserved(rectangle2D10, rectangleEdge30);
        legendGraphic3.setLine((java.awt.Shape) rectangle2D31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = null;
        try {
            org.jfree.chart.util.Size2D size2D35 = legendGraphic3.arrange(graphics2D33, rectangleConstraint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.lang.Object obj16 = xYBarRenderer11.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color12);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        ringPlot22.setDrawingSupplier(drawingSupplier23, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        ringPlot22.markerChanged(markerChangeEvent26);
        ringPlot22.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = ringPlot22.getSimpleLabelOffset();
        standardChartTheme1.setAxisOffset(rectangleInsets30);
        double double33 = rectangleInsets30.calculateTopInset((double) 500);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.lang.String str18 = symbolAxis16.valueToString(0.0d);
        int int19 = combinedDomainXYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis16);
        combinedDomainXYPlot1.configureRangeAxes();
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color25 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        standardChartTheme24.setTickLabelPaint((java.awt.Paint) color25);
        java.awt.color.ColorSpace colorSpace33 = color25.getColorSpace();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer34.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer34.setBaseStroke(stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 'a', (java.awt.Paint) color25, stroke37);
        org.jfree.chart.util.Layer layer40 = null;
        combinedDomainXYPlot1.addRangeMarker(5, (org.jfree.chart.plot.Marker) valueMarker39, layer40);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer43 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double44 = xYBarRenderer43.getShadowYOffset();
        java.awt.Color color45 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel46 = null;
        java.awt.Rectangle rectangle47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color45.createContext(colorModel46, rectangle47, rectangle2D48, affineTransform49, renderingHints50);
        xYBarRenderer43.setBasePaint((java.awt.Paint) color45);
        java.lang.Object obj53 = xYBarRenderer43.clone();
        xYBarRenderer43.setBarAlignmentFactor((double) 12);
        java.awt.Stroke stroke56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYBarRenderer43.setBaseStroke(stroke56, false);
        combinedDomainXYPlot1.setDomainCrosshairStroke(stroke56);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paintContext51);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, (int) 'a', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        java.awt.Paint paint3 = piePlot3D1.getBaseSectionPaint();
        java.awt.Shape shape4 = piePlot3D1.getLegendItemShape();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        java.lang.Object obj7 = standardXYSeriesLabelGenerator6.clone();
        java.lang.Object obj8 = standardXYSeriesLabelGenerator6.clone();
        boolean boolean9 = piePlot3D1.equals(obj8);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = null;
        try {
            piePlot3D1.setLabelDistributor(abstractPieLabelDistributor10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        boolean boolean14 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        barRenderer0.setAutoPopulateSeriesPaint(true);
        int int9 = barRenderer0.getRowCount();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker2.setStartValue(0.0d);
        float float5 = intervalMarker2.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = intervalMarker2.getLabelAnchor();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        intervalMarker2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        java.awt.Paint paint9 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.setLicenceText("hi!");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis24, polarItemRenderer26);
        boolean boolean28 = symbolAxis5.hasListener((java.util.EventListener) xYSeriesCollection17);
        java.text.NumberFormat numberFormat29 = symbolAxis5.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(numberFormat29);
    }
}

