import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(xYDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Color color1 = java.awt.Color.lightGray;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.addFragment(textFragment1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = null;
        try {
            piePlot3D1.setLabelLinkStyle(pieLabelLinkStyle3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) axisChangeEvent2, jFreeChart4, chartChangeEventType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        boolean boolean7 = xYLineAndShapeRenderer2.getItemLineVisible((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.Title title1 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity3 = new org.jfree.chart.entity.TitleEntity(shape0, title1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 10, (-1.0f), textAnchor4, (double) 100.0f, textAnchor6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Color color1 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        try {
            org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.util.List list2 = null;
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list2, range3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        try {
            org.jfree.chart.entity.PlotEntity plotEntity3 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) piePlot3D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.GRAY;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2, (float) (short) 1, textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        org.jfree.data.xy.XYSeries xYSeries2 = null;
        try {
            xYSeriesCollection0.removeSeries(xYSeries2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', 12, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "", "DateTickUnitType.MINUTE", "hi!");
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        java.awt.Stroke stroke9 = null;
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 100.0f, (java.awt.Paint) color2, stroke9, (java.awt.Paint) color10, stroke11, (float) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) 1.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            combinedDomainXYPlot1.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Font font1 = null;
        xYStepAreaRenderer0.setBaseItemLabelFont(font1, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = combinedDomainXYPlot6.removeDomainMarker(marker9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color14 = java.awt.Color.GRAY;
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker17.setStartValue(0.0d);
        float float20 = intervalMarker17.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot22.setRangeAxisLocation(axisLocation23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis26);
        java.awt.Paint paint28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot27.setDomainCrosshairPaint(paint28);
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder(rectangleInsets25, paint28);
        combinedDomainXYPlot22.setOutlinePaint(paint28);
        intervalMarker17.setOutlinePaint(paint28);
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker17.setStroke(stroke33);
        try {
            xYStepAreaRenderer0.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, valueAxis11, rectangle2D12, (double) 9999, (java.awt.Paint) color14, stroke33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.8f + "'", float20 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = null;
        try {
            xYLineAndShapeRenderer2.setBaseItemLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            barRenderer3D0.drawAnnotations(graphics2D1, rectangle2D2, categoryAxis3, valueAxis4, layer5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setSeriesPaint(10, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setPlotArea(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oct" + "'", str2.equals("Oct"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("DateTickUnitType.MINUTE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        xYBarRenderer1.setBasePaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter11 = null;
        try {
            xYBarRenderer1.setBarPainter(xYBarPainter11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        try {
            barRenderer3D0.setLegendItemLabelGenerator(categorySeriesLabelGenerator1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker2.setStartValue(0.0d);
        float float5 = intervalMarker2.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot7.setRangeAxisLocation(axisLocation8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot12.setDomainCrosshairPaint(paint13);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, paint13);
        combinedDomainXYPlot7.setOutlinePaint(paint13);
        intervalMarker2.setOutlinePaint(paint13);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker2.setStroke(stroke18);
        java.lang.String str20 = intervalMarker2.getLabel();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        try {
            xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYLineAndShapeRenderer2.getBaseToolTipGenerator();
        java.lang.Boolean boolean5 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 0);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        java.awt.Paint paint9 = combinedDomainXYPlot8.getRangeZeroBaselinePaint();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("", strArray14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer18.setBaseCreateEntities(true);
        xYLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYLineAndShapeRenderer18.getBaseURLGenerator();
        boolean boolean24 = symbolAxis15.equals((java.lang.Object) xYURLGenerator23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot28.setRangeAxisLocation(axisLocation29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis32);
        java.awt.Paint paint34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot33.setDomainCrosshairPaint(paint34);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder(rectangleInsets31, paint34);
        combinedDomainXYPlot28.setOutlinePaint(paint34);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer38.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer38.setBaseStroke(stroke41);
        try {
            xYLineAndShapeRenderer2.drawDomainLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) symbolAxis15, rectangle2D25, 1.0d, paint34, stroke41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNull(xYURLGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.List list2 = null;
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxes((int) (short) -1, list2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation2, plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.awt.Shape shape3 = xYBarRenderer1.getBaseLegendShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("", strArray14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer18.setBaseCreateEntities(true);
        xYLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYLineAndShapeRenderer18.getBaseURLGenerator();
        boolean boolean24 = symbolAxis15.equals((java.lang.Object) xYURLGenerator23);
        double double25 = symbolAxis15.getAutoRangeMinimumSize();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            xYBarRenderer1.drawItem(graphics2D4, xYItemRendererState5, rectangle2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, valueAxis9, (org.jfree.chart.axis.ValueAxis) symbolAxis15, (org.jfree.data.xy.XYDataset) xYSeriesCollection26, (int) (short) 1, 5, false, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNull(xYURLGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0E-8d + "'", double25 == 1.0E-8d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("DateTickUnitType.MINUTE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultKeyedValues0.sortByKeys(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Font font6 = xYLineAndShapeRenderer2.getLegendTextFont((int) 'a');
        org.junit.Assert.assertNull(font6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        double double6 = piePlot3D1.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        double double6 = xYBarRenderer1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis9 = new org.jfree.chart.axis.SymbolAxis("", strArray8);
        java.awt.Font font10 = symbolAxis9.getLabelFont();
        xYBarRenderer2.setBaseLegendTextFont(font10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean15 = xYLineAndShapeRenderer14.getDrawOutlines();
        java.awt.Font font16 = xYLineAndShapeRenderer14.getBaseLegendTextFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot19.setDomainCrosshairPaint(paint20);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, paint20);
        xYLineAndShapeRenderer14.setBaseLegendTextPaint(paint20);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer26 = new org.jfree.chart.text.G2TextMeasurer(graphics2D25);
        try {
            org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("Oct", font10, paint20, (float) (short) 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            barRenderer3D0.drawDomainMarker(graphics2D2, categoryPlot3, categoryAxis4, categoryMarker5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        try {
            boolean boolean9 = xYSeriesCollection0.isSelected((int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        boolean boolean8 = xYStepAreaRenderer0.isSeriesVisible(100);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        try {
            int int5 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) xYSeriesCollection0, 255, (double) 100.0f, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        try {
            combinedRangeXYPlot11.zoomDomainAxes(10.0d, plotRenderingInfo15, point2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis11 = new org.jfree.chart.axis.SymbolAxis("", strArray10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer14.setBaseCreateEntities(true);
        xYLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = xYLineAndShapeRenderer14.getBaseURLGenerator();
        boolean boolean20 = symbolAxis11.equals((java.lang.Object) xYURLGenerator19);
        double double21 = symbolAxis11.getAutoRangeMinimumSize();
        java.awt.Paint paint22 = symbolAxis11.getLabelPaint();
        symbolAxis11.setLowerMargin((double) (short) 1);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis32 = new org.jfree.chart.axis.SymbolAxis("", strArray31);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer35.setBaseCreateEntities(true);
        xYLineAndShapeRenderer35.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator40 = xYLineAndShapeRenderer35.getBaseURLGenerator();
        boolean boolean41 = symbolAxis32.equals((java.lang.Object) xYURLGenerator40);
        double double42 = symbolAxis32.getAutoRangeMinimumSize();
        java.awt.Paint paint43 = symbolAxis32.getLabelPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer44 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer44.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer44.setBaseStroke(stroke47);
        try {
            barRenderer3D0.drawRangeLine(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) symbolAxis11, rectangle2D25, (double) 1L, paint43, stroke47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNull(xYURLGenerator19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-8d + "'", double21 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNull(xYURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0E-8d + "'", double42 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("MAJOR");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        try {
            combinedRangeXYPlot11.zoomDomainAxes((double) (short) 100, plotRenderingInfo15, point2D16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        try {
            combinedDomainXYPlot0.handleClick((int) (short) 0, 2, plotRenderingInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        try {
            standardChartTheme1.apply(jFreeChart2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.awt.Font font14 = symbolAxis13.getLabelFont();
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer23.setBaseCreateEntities(true);
        xYLineAndShapeRenderer23.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYLineAndShapeRenderer23.getBaseURLGenerator();
        boolean boolean29 = symbolAxis20.equals((java.lang.Object) xYURLGenerator28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean31 = xYStepAreaRenderer30.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer30);
        try {
            symbolAxis13.setRangeWithMargins((double) (byte) 100, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.2).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.String str2 = piePlot3D1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker2.setStartValue((-1.0d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        symbolAxis5.setLowerMargin((double) (short) 1);
        symbolAxis5.setTickMarkInsideLength((float) 'a');
        java.awt.Shape shape21 = null;
        try {
            symbolAxis5.setUpArrow(shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double8 = xYBarRenderer7.getShadowYOffset();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color9.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        xYBarRenderer7.setBasePaint((java.awt.Paint) color9);
        boolean boolean17 = combinedDomainXYPlot5.equals((java.lang.Object) color9);
        int int18 = combinedDomainXYPlot5.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot20.setDomainCrosshairPaint(paint21);
        org.jfree.chart.plot.Marker marker23 = null;
        boolean boolean24 = combinedDomainXYPlot20.removeDomainMarker(marker23);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double29 = xYBarRenderer28.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection30 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range31 = xYBarRenderer28.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection30);
        xYSeriesCollection26.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection30);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection30);
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis39 = new org.jfree.chart.axis.SymbolAxis("", strArray38);
        java.awt.Font font40 = symbolAxis39.getLabelFont();
        java.lang.String[] strArray45 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis46 = new org.jfree.chart.axis.SymbolAxis("", strArray45);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer49.setBaseCreateEntities(true);
        xYLineAndShapeRenderer49.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator54 = xYLineAndShapeRenderer49.getBaseURLGenerator();
        boolean boolean55 = symbolAxis46.equals((java.lang.Object) xYURLGenerator54);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer56 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean57 = xYStepAreaRenderer56.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection30, (org.jfree.chart.axis.ValueAxis) symbolAxis39, (org.jfree.chart.axis.ValueAxis) symbolAxis46, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer56);
        combinedDomainXYPlot20.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) symbolAxis46, false);
        boolean boolean61 = symbolAxis46.isPositiveArrowVisible();
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        try {
            xYStepAreaRenderer0.fillDomainGridBand(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5, (org.jfree.chart.axis.ValueAxis) symbolAxis46, rectangle2D62, 3.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertEquals((double) number33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNull(xYURLGenerator54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) shape0, (java.lang.Object) 5);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot12.setDomainCrosshairPaint(paint13);
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = combinedDomainXYPlot12.removeDomainMarker(marker15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot12.setRangeAxisLocation(1, axisLocation18, false);
        combinedDomainXYPlot1.setRangeAxisLocation((int) (short) 100, axisLocation18, false);
        combinedDomainXYPlot1.setBackgroundImageAlpha((float) 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = labelBlock1.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        double double7 = combinedDomainXYPlot1.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.awt.Font font14 = symbolAxis13.getLabelFont();
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer23.setBaseCreateEntities(true);
        xYLineAndShapeRenderer23.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYLineAndShapeRenderer23.getBaseURLGenerator();
        boolean boolean29 = symbolAxis20.equals((java.lang.Object) xYURLGenerator28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean31 = xYStepAreaRenderer30.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer30);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            org.jfree.chart.axis.AxisState axisState39 = symbolAxis13.draw(graphics2D33, (double) (short) 100, rectangle2D35, rectangle2D36, rectangleEdge37, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        try {
            symbolAxis5.setRange((double) 100.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        java.lang.String str4 = labelBlock1.getToolTipText();
        double double5 = labelBlock1.getContentXOffset();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        double double18 = symbolAxis8.getAutoRangeMinimumSize();
        java.awt.Paint paint19 = symbolAxis8.getLabelPaint();
        int int20 = combinedDomainXYPlot1.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            combinedDomainXYPlot1.addAnnotation(xYAnnotation21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (-1), (float) (byte) -1, 1.0d, (float) 15, (-1.0f));
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.removeValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color2);
        java.awt.Paint paint10 = null;
        try {
            intervalMarker9.setPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis9);
        java.awt.Paint paint11 = combinedDomainXYPlot1.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        try {
            double double7 = xYSeriesCollection3.getEndYValue(2958465, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        try {
            java.lang.Number number9 = xYSeriesCollection0.getStartY((-1), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        boolean boolean29 = symbolAxis5.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.awt.Font font14 = symbolAxis13.getLabelFont();
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer23.setBaseCreateEntities(true);
        xYLineAndShapeRenderer23.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYLineAndShapeRenderer23.getBaseURLGenerator();
        boolean boolean29 = symbolAxis20.equals((java.lang.Object) xYURLGenerator28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean31 = xYStepAreaRenderer30.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer30);
        symbolAxis20.setLabelURL("{0}: ({1}, {2})");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("{0}: ({1}, {2})", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        java.awt.Font font7 = xYStepAreaRenderer0.getBaseItemLabelFont();
        xYStepAreaRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYBarRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2, false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState6 = null;
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker12.setStartValue(0.0d);
        float float15 = intervalMarker12.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = intervalMarker12.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, 1.0E-8d, 1.0E-8d, rectangleAnchor16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double22 = xYBarRenderer21.getShadowYOffset();
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        xYBarRenderer21.setBasePaint((java.awt.Paint) color23);
        boolean boolean31 = combinedDomainXYPlot19.equals((java.lang.Object) color23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        combinedDomainXYPlot19.notifyListeners(plotChangeEvent32);
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("");
        labelBlock35.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis39);
        java.awt.Paint paint41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot40.setDomainCrosshairPaint(paint41);
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder(rectangleInsets38, paint41);
        double double45 = rectangleInsets38.calculateLeftOutset((double) (short) 100);
        labelBlock35.setMargin(rectangleInsets38);
        combinedDomainXYPlot19.setAxisOffset(rectangleInsets38);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot49 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis48);
        java.awt.Paint paint50 = combinedDomainXYPlot49.getRangeZeroBaselinePaint();
        java.lang.String[] strArray55 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis56 = new org.jfree.chart.axis.SymbolAxis("", strArray55);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer59 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer59.setBaseCreateEntities(true);
        xYLineAndShapeRenderer59.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator64 = xYLineAndShapeRenderer59.getBaseURLGenerator();
        boolean boolean65 = symbolAxis56.equals((java.lang.Object) xYURLGenerator64);
        double double66 = symbolAxis56.getAutoRangeMinimumSize();
        java.awt.Paint paint67 = symbolAxis56.getLabelPaint();
        int int68 = combinedDomainXYPlot49.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis56);
        java.lang.String[] strArray73 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis74 = new org.jfree.chart.axis.SymbolAxis("", strArray73);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer77 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer77.setBaseCreateEntities(true);
        xYLineAndShapeRenderer77.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator82 = xYLineAndShapeRenderer77.getBaseURLGenerator();
        boolean boolean83 = symbolAxis74.equals((java.lang.Object) xYURLGenerator82);
        double double84 = symbolAxis74.getAutoRangeMinimumSize();
        java.awt.Paint paint85 = symbolAxis74.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer87 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double88 = xYBarRenderer87.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection89 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range90 = xYBarRenderer87.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection89);
        double double92 = xYSeriesCollection89.getRangeUpperBound(false);
        try {
            xYBarRenderer1.drawItem(graphics2D5, xYItemRendererState6, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19, (org.jfree.chart.axis.ValueAxis) symbolAxis56, (org.jfree.chart.axis.ValueAxis) symbolAxis74, (org.jfree.data.xy.XYDataset) xYSeriesCollection89, (-1), 4, false, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.8f + "'", float15 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 3.0d + "'", double45 == 3.0d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNull(xYURLGenerator64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0E-8d + "'", double66 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNull(xYURLGenerator82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.0E-8d + "'", double84 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 4.0d + "'", double88 == 4.0d);
        org.junit.Assert.assertNull(range90);
        org.junit.Assert.assertEquals((double) double92, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Comparable comparable2 = null;
        try {
            defaultKeyedValues0.insertValue((int) '#', comparable2, (java.lang.Number) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        xYLineAndShapeRenderer5.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color7, false);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer5.getSeriesStroke(10);
        java.awt.Paint paint18 = xYLineAndShapeRenderer5.getBaseItemLabelPaint();
        piePlot3D1.setShadowPaint(paint18);
        piePlot3D1.setShadowYOffset((double) 12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.awt.Font font14 = symbolAxis13.getLabelFont();
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer23.setBaseCreateEntities(true);
        xYLineAndShapeRenderer23.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYLineAndShapeRenderer23.getBaseURLGenerator();
        boolean boolean29 = symbolAxis20.equals((java.lang.Object) xYURLGenerator28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean31 = xYStepAreaRenderer30.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot32.setBackgroundPaint((java.awt.Paint) color33);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        float[] floatArray4 = new float[] { 2958465 };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB(12, (-1), (-1), floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean9 = xYStepAreaRenderer0.isShapesFilled();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str3 = labelBlock2.getURLText();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot5.setDomainCrosshairPaint(paint6);
        labelBlock2.setPaint(paint6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter13 = xYBarRenderer10.getBarPainter();
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYBarRenderer10.setBaseStroke(stroke14);
        java.awt.Color color18 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color18);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 100, paint6, stroke14, (java.awt.Paint) color18, stroke26, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(xYBarPainter13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        try {
            barRenderer3D0.drawDomainLine(graphics2D6, categoryPlot7, rectangle2D8, (double) 1, (java.awt.Paint) color10, stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        double double11 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        labelBlock1.setMargin(rectangleInsets4);
        java.lang.Object obj13 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D0.getBaseURLGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        try {
            barRenderer3D0.setSeriesURLGenerator(2147483647, categoryURLGenerator9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNull(categoryURLGenerator7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.axis.TickUnit tickUnit2 = null;
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit(tickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getURLText();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot4.setDomainCrosshairPaint(paint5);
        labelBlock1.setPaint(paint5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker14.setStartValue(0.0d);
        float float17 = intervalMarker14.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = intervalMarker14.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, 1.0E-8d, 1.0E-8d, rectangleAnchor18);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D19);
        try {
            labelBlock1.draw(graphics2D8, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.8f + "'", float17 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-9999));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = null;
        try {
            java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        double double7 = ringPlot1.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot7.setDomainCrosshairPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, paint8);
        xYLineAndShapeRenderer2.setBaseLegendTextPaint(paint8);
        boolean boolean12 = xYLineAndShapeRenderer2.getDrawOutlines();
        xYLineAndShapeRenderer2.setSeriesVisible(5, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setOutlineVisible(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double7 = xYBarRenderer6.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range9 = xYBarRenderer6.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeriesCollection4.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection8);
        java.util.List list11 = xYSeriesCollection8.getSeries();
        try {
            xYPlot0.mapDatasetToDomainAxes(0, list11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color12);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color12);
        java.awt.Paint paint21 = standardChartTheme1.getWallPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("DateTickUnitType.MINUTE", graphics2D1, (float) 10, (float) (short) -1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean6 = ringPlot1.isCircular();
        double double7 = ringPlot1.getOuterSeparatorExtension();
        double double8 = ringPlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedDomainXYPlot1.setDrawingSupplier(drawingSupplier14);
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 2958465, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker21.setStartValue(0.0d);
        float float24 = intervalMarker21.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot26.setRangeAxisLocation(axisLocation27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(rectangleInsets29, paint32);
        combinedDomainXYPlot26.setOutlinePaint(paint32);
        intervalMarker21.setOutlinePaint(paint32);
        boolean boolean37 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker21);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = combinedDomainXYPlot1.getDomainMarkers(layer38);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.8f + "'", float24 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(collection39);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        combinedRangeXYPlot11.setRangePannable(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        try {
            combinedRangeXYPlot11.zoomDomainAxes(0.0d, (double) (short) 100, plotRenderingInfo18, point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        piePlot3D1.setCircular(false, false);
        double double9 = piePlot3D1.getLabelLinkMargin();
        piePlot3D1.setAutoPopulateSectionOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = null;
        try {
            ringPlot1.setLabelDistributor(abstractPieLabelDistributor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "MAJOR", "DateTickUnitType.MINUTE");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
        basicProjectInfo5.setCopyright("Polar Plot");
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            xYBarRenderer11.addAnnotation(xYAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        xYLineAndShapeRenderer2.setDrawOutlines(true);
        java.awt.Paint paint16 = xYLineAndShapeRenderer2.getSeriesFillPaint(1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        try {
            xYLineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((-1), itemLabelPosition18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultKeyedValues0.sortByValues(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        try {
            xYLineAndShapeRenderer2.setSeriesOutlineStroke((-1), stroke14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(12, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        piePlot3D1.setCircular(false, false);
        double double9 = piePlot3D1.getLabelLinkMargin();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot3D1);
        java.awt.Paint paint11 = piePlot3D1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        java.lang.String str2 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LengthConstraintType.NONE" + "'", str2.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        xYLineAndShapeRenderer5.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color7, false);
        java.lang.Boolean boolean17 = xYLineAndShapeRenderer5.getSeriesShapesFilled(1);
        boolean boolean18 = xYLineAndShapeRenderer5.getDrawSeriesLineAsPath();
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        try {
            java.lang.StringBuffer stringBuffer21 = numberFormat2.format((java.lang.Object) boolean18, stringBuffer19, fieldPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYBarRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2, false);
        java.awt.Font font5 = xYBarRenderer1.getBaseLegendTextFont();
        org.junit.Assert.assertNull(font5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        piePlot3D2.axisChanged(axisChangeEvent3);
        boolean boolean5 = piePlot3D2.getLabelLinksVisible();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot3D2.setLabelOutlineStroke(stroke6);
        boolean boolean8 = itemLabelAnchor0.equals((java.lang.Object) stroke6);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        combinedDomainXYPlot1.setFixedRangeAxisSpace(axisSpace7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        java.lang.String str2 = numberTickUnit0.toString();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=1]" + "'", str2.equals("[size=1]"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) (-1.0f), (double) 1L, rectangleAnchor8);
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("", strArray14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer18.setBaseCreateEntities(true);
        xYLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYLineAndShapeRenderer18.getBaseURLGenerator();
        boolean boolean24 = symbolAxis15.equals((java.lang.Object) xYURLGenerator23);
        double double25 = symbolAxis15.getAutoRangeMinimumSize();
        java.awt.Paint paint26 = symbolAxis15.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D9, (org.jfree.chart.axis.Axis) symbolAxis15, "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(rectangleInsets29, paint32);
        double double36 = rectangleInsets29.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker42.setStartValue(0.0d);
        float float45 = intervalMarker42.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = intervalMarker42.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D47 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 1.0E-8d, 1.0E-8d, rectangleAnchor46);
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets29.createInsetRectangle(rectangle2D47);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean51 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        try {
            org.jfree.chart.axis.AxisState axisState53 = dateAxis0.draw(graphics2D3, (double) '#', rectangle2D9, rectangle2D47, rectangleEdge50, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNull(xYURLGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0E-8d + "'", double25 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.0d + "'", double36 == 3.0d);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.8f + "'", float45 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) combinedDomainXYPlot11, false);
        java.lang.Object obj16 = jFreeChart15.clone();
        java.awt.RenderingHints renderingHints17 = jFreeChart15.getRenderingHints();
        java.util.List list18 = jFreeChart15.getSubtitles();
        try {
            org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(renderingHints17);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        size2D0.setHeight((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis10 = new org.jfree.chart.axis.SymbolAxis("", strArray9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer13.setBaseCreateEntities(true);
        xYLineAndShapeRenderer13.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYLineAndShapeRenderer13.getBaseURLGenerator();
        boolean boolean19 = symbolAxis10.equals((java.lang.Object) xYURLGenerator18);
        double double20 = symbolAxis10.getAutoRangeMinimumSize();
        java.awt.Paint paint21 = symbolAxis10.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity23 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D4, (org.jfree.chart.axis.Axis) symbolAxis10, "PieLabelLinkStyle.STANDARD");
        symbolAxis10.setMinorTickMarkInsideLength((float) 0L);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-8d + "'", double20 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYLineAndShapeRenderer2.setBaseURLGenerator(xYURLGenerator4, false);
        java.awt.Shape shape8 = xYLineAndShapeRenderer2.getSeriesShape(255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double15 = xYBarRenderer14.getShadowYOffset();
        java.awt.Color color16 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color16.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        xYBarRenderer14.setBasePaint((java.awt.Paint) color16);
        boolean boolean24 = combinedDomainXYPlot12.equals((java.lang.Object) color16);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        combinedDomainXYPlot12.notifyListeners(plotChangeEvent25);
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("");
        labelBlock28.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis32);
        java.awt.Paint paint34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot33.setDomainCrosshairPaint(paint34);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder(rectangleInsets31, paint34);
        double double38 = rectangleInsets31.calculateLeftOutset((double) (short) 100);
        labelBlock28.setMargin(rectangleInsets31);
        combinedDomainXYPlot12.setAxisOffset(rectangleInsets31);
        int int41 = combinedDomainXYPlot12.getRangeAxisCount();
        try {
            combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot12, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Require weight >= 1.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.0d + "'", double38 == 3.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        int int10 = combinedDomainXYPlot1.getDatasetCount();
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1L, plotRenderingInfo15, point2D16);
        combinedDomainXYPlot1.setRangePannable(false);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        symbolAxis5.setLabelInsets(rectangleInsets29, true);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        double double3 = range2.getCentralValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1484232.0d + "'", double3 == 1484232.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setLabelGap(0.0d);
        java.awt.Paint paint9 = ringPlot1.getBaseSectionPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = null;
        ringPlot1.setToolTipGenerator(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        ringPlot1.setInnerSeparatorExtension((double) (byte) -1);
        boolean boolean7 = ringPlot1.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        combinedDomainXYPlot1.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.START" + "'", str1.equals("TimePeriodAnchor.START"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedDomainXYPlot1.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot17.setRangeAxisLocation(axisLocation18);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot27.setRangeAxisLocation(axisLocation28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot32.setDomainCrosshairPaint(paint33);
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder(rectangleInsets30, paint33);
        combinedDomainXYPlot27.setOutlinePaint(paint33);
        intervalMarker22.setOutlinePaint(paint33);
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker22.setStroke(stroke38);
        boolean boolean40 = combinedDomainXYPlot17.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker22);
        org.jfree.chart.util.Layer layer41 = null;
        try {
            combinedDomainXYPlot1.addDomainMarker(0, (org.jfree.chart.plot.Marker) intervalMarker22, layer41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.lang.Object obj15 = jFreeChart14.clone();
        java.awt.RenderingHints renderingHints16 = jFreeChart14.getRenderingHints();
        java.util.List list17 = jFreeChart14.getSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle18 = null;
        try {
            jFreeChart14.addLegend(legendTitle18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        java.awt.Stroke stroke14 = xYLineAndShapeRenderer2.getSeriesStroke(10);
        java.awt.Paint paint15 = xYLineAndShapeRenderer2.getBaseItemLabelPaint();
        boolean boolean16 = xYLineAndShapeRenderer2.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        combinedDomainXYPlot19.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo22, point2D23);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = combinedDomainXYPlot19.getRangeMarkers(12, layer26);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection28 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection28);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = combinedDomainXYPlot19.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection28);
        boolean boolean31 = combinedDomainXYPlot19.isRangeZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = combinedDomainXYPlot19.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (-1.0f), (double) 1L, rectangleAnchor37);
        try {
            xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19, valueAxis33, rectangle2D38, (double) 0.8f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double10 = xYBarRenderer9.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYBarRenderer9.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYSeriesCollection7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection11);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        java.awt.Font font21 = symbolAxis20.getLabelFont();
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis27 = new org.jfree.chart.axis.SymbolAxis("", strArray26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer30.setBaseCreateEntities(true);
        xYLineAndShapeRenderer30.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYLineAndShapeRenderer30.getBaseURLGenerator();
        boolean boolean36 = symbolAxis27.equals((java.lang.Object) xYURLGenerator35);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean38 = xYStepAreaRenderer37.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.axis.ValueAxis) symbolAxis27, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer37);
        combinedDomainXYPlot1.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) symbolAxis27, false);
        try {
            symbolAxis27.setRange((double) 15, 0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (15.0) <= upper (0.025).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertEquals((double) number14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        xYBarRenderer1.setSeriesCreateEntities(0, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        java.awt.Stroke stroke14 = legendItem12.getLineStroke();
        java.lang.Object obj15 = legendItem12.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = ringPlot1.getSimpleLabelOffset();
        ringPlot1.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        int int1 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        piePlot3D2.axisChanged(axisChangeEvent3);
        piePlot3D2.setLabelLinksVisible(true);
        piePlot3D2.setCircular(false, false);
        double double10 = piePlot3D2.getLabelLinkMargin();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot3D2);
        java.awt.Stroke stroke12 = piePlot3D2.getBaseSectionOutlineStroke();
        xYStepAreaRenderer0.setBaseOutlineStroke(stroke12, true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("MAJOR", numberFormat1, numberFormat4);
        numberFormat4.setMaximumFractionDigits((int) (short) 0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis14 = new org.jfree.chart.axis.SymbolAxis("", strArray13);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer17.setBaseCreateEntities(true);
        xYLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYLineAndShapeRenderer17.getBaseURLGenerator();
        boolean boolean23 = symbolAxis14.equals((java.lang.Object) xYURLGenerator22);
        java.awt.Color color24 = java.awt.Color.BLUE;
        symbolAxis14.setTickMarkPaint((java.awt.Paint) color24);
        double double26 = symbolAxis14.getUpperBound();
        symbolAxis14.setAutoRange(true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double33 = xYBarRenderer32.getShadowYOffset();
        java.awt.Color color34 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.AffineTransform affineTransform38 = null;
        java.awt.RenderingHints renderingHints39 = null;
        java.awt.PaintContext paintContext40 = color34.createContext(colorModel35, rectangle36, rectangle2D37, affineTransform38, renderingHints39);
        xYBarRenderer32.setBasePaint((java.awt.Paint) color34);
        boolean boolean42 = combinedDomainXYPlot30.equals((java.lang.Object) color34);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier43 = null;
        combinedDomainXYPlot30.setDrawingSupplier(drawingSupplier43);
        combinedDomainXYPlot30.setDomainCrosshairValue((double) 2958465, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker50.setStartValue(0.0d);
        float float53 = intervalMarker50.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis54);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot55.setRangeAxisLocation(axisLocation56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot60 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis59);
        java.awt.Paint paint61 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot60.setDomainCrosshairPaint(paint61);
        org.jfree.chart.block.BlockBorder blockBorder63 = new org.jfree.chart.block.BlockBorder(rectangleInsets58, paint61);
        combinedDomainXYPlot55.setOutlinePaint(paint61);
        intervalMarker50.setOutlinePaint(paint61);
        boolean boolean66 = combinedDomainXYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker50);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer69 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double70 = xYBarRenderer69.getShadowYOffset();
        java.awt.Color color71 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel72 = null;
        java.awt.Rectangle rectangle73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        java.awt.geom.AffineTransform affineTransform75 = null;
        java.awt.RenderingHints renderingHints76 = null;
        java.awt.PaintContext paintContext77 = color71.createContext(colorModel72, rectangle73, rectangle2D74, affineTransform75, renderingHints76);
        xYBarRenderer69.setBasePaint((java.awt.Paint) color71);
        org.jfree.chart.LegendItem legendItem79 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color71);
        java.lang.Comparable comparable80 = legendItem79.getSeriesKey();
        legendItem79.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D83 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker88 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker88.setStartValue(0.0d);
        float float91 = intervalMarker88.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor92 = intervalMarker88.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D93 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D83, 1.0E-8d, 1.0E-8d, rectangleAnchor92);
        java.awt.Shape shape94 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D93);
        legendItem79.setLine((java.awt.Shape) rectangle2D93);
        barRenderer3D0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) symbolAxis14, (org.jfree.chart.plot.Marker) intervalMarker50, rectangle2D93);
        java.lang.String str98 = symbolAxis14.valueToString(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintContext40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.8f + "'", float53 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 4.0d + "'", double70 == 4.0d);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(paintContext77);
        org.junit.Assert.assertNull(comparable80);
        org.junit.Assert.assertTrue("'" + float91 + "' != '" + 0.8f + "'", float91 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor92);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertNotNull(shape94);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "hi!" + "'", str98.equals("hi!"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.removeValue((java.lang.Comparable) 106.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (106.0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint9 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        try {
            combinedDomainXYPlot1.mapDatasetToDomainAxis((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color2 = java.awt.Color.GRAY;
        xYStepAreaRenderer0.setBaseFillPaint((java.awt.Paint) color2, false);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        ringPlot7.setDrawingSupplier(drawingSupplier8, false);
        java.awt.Stroke stroke11 = ringPlot7.getBaseSectionOutlineStroke();
        xYStepAreaRenderer0.setSeriesStroke(0, stroke11);
        java.io.ObjectOutputStream objectOutputStream13 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke11, objectOutputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer2.getSeriesShapesFilled(1);
        xYLineAndShapeRenderer2.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        java.util.Date date4 = null;
        try {
            long long5 = segmentedTimeline3.toTimelineValue(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(false);
        xYLineAndShapeRenderer2.setSeriesShapesFilled((int) ' ', true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedDomainXYPlot1.setDrawingSupplier(drawingSupplier14);
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 2958465, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker21.setStartValue(0.0d);
        float float24 = intervalMarker21.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot26.setRangeAxisLocation(axisLocation27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(rectangleInsets29, paint32);
        combinedDomainXYPlot26.setOutlinePaint(paint32);
        intervalMarker21.setOutlinePaint(paint32);
        boolean boolean37 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        combinedDomainXYPlot1.zoomDomainAxes((double) 0.8f, plotRenderingInfo39, point2D40);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.8f + "'", float24 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        try {
            dateAxis0.setMaximumDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        double double7 = rectangleInsets0.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker13.setStartValue(0.0d);
        float float16 = intervalMarker13.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = intervalMarker13.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, 1.0E-8d, 1.0E-8d, rectangleAnchor17);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets0.createInsetRectangle(rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets0.createOutsetRectangle(rectangle2D21, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.8f + "'", float16 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        java.lang.String str3 = unitType2.toString();
        boolean boolean4 = chartChangeEventType0.equals((java.lang.Object) str3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UnitType.ABSOLUTE" + "'", str3.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        java.awt.Paint paint3 = piePlot3D1.getBaseSectionPaint();
        piePlot3D1.setAutoPopulateSectionOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit1.toString();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=1]" + "'", str2.equals("[size=1]"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter4 = xYBarRenderer1.getBarPainter();
        java.awt.Paint paint8 = xYBarRenderer1.getItemFillPaint(2147483647, (-1), false);
        java.awt.Paint paint9 = xYBarRenderer1.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(xYBarPainter4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        barRenderer3D0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 2147483647, 1.0E-5d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("MAJOR", graphics2D1, (float) (-1), (float) (-1), textAnchor4, (double) (-9999), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.lang.Object obj15 = jFreeChart14.clone();
        java.awt.RenderingHints renderingHints16 = jFreeChart14.getRenderingHints();
        java.util.List list17 = jFreeChart14.getSubtitles();
        int int18 = jFreeChart14.getSubtitleCount();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        symbolAxis5.setTickUnit(numberTickUnit17);
        boolean boolean19 = symbolAxis5.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        java.lang.Number number4 = null;
        try {
            defaultKeyedValues0.insertValue((int) '#', (java.lang.Comparable) '4', number4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getURLText();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot4.setDomainCrosshairPaint(paint5);
        labelBlock1.setPaint(paint5);
        java.lang.String str8 = labelBlock1.getURLText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (-1.0f), 0.0f, textAnchor4, (double) (-1.0f), (float) (short) 1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 1L, (float) 3, (float) (-2208960000000L));
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        xYBarRenderer1.setBasePaint((java.awt.Paint) color3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNull(itemLabelPosition11);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        standardChartTheme11.setTickLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = standardChartTheme11.getAxisOffset();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_GREEN;
        standardChartTheme11.setChartBackgroundPaint((java.awt.Paint) color21);
        standardChartTheme1.setBaselinePaint((java.awt.Paint) color21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        java.awt.Paint paint26 = combinedDomainXYPlot25.getRangeZeroBaselinePaint();
        standardChartTheme1.setChartBackgroundPaint(paint26);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        jFreeChart14.setPadding(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getRGBComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.lang.Object obj3 = xYLineAndShapeRenderer2.clone();
        boolean boolean4 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Shape shape6 = xYLineAndShapeRenderer2.getSeriesShape(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation7 = null;
        try {
            xYLineAndShapeRenderer2.addAnnotation(xYAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("GradientPaintTransformType.CENTER_VERTICAL", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYBarRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2, false);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) (short) 100, (java.awt.Paint) color7);
        java.awt.Color color9 = color7.brighter();
        xYBarRenderer1.setBaseItemLabelPaint((java.awt.Paint) color9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(itemLabelPosition12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis10 = new org.jfree.chart.axis.SymbolAxis("", strArray9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer13.setBaseCreateEntities(true);
        xYLineAndShapeRenderer13.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYLineAndShapeRenderer13.getBaseURLGenerator();
        boolean boolean19 = symbolAxis10.equals((java.lang.Object) xYURLGenerator18);
        double double20 = symbolAxis10.getAutoRangeMinimumSize();
        java.awt.Paint paint21 = symbolAxis10.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity23 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D4, (org.jfree.chart.axis.Axis) symbolAxis10, "PieLabelLinkStyle.STANDARD");
        java.lang.String str24 = axisEntity23.getShapeCoords();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator25 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator26 = null;
        try {
            java.lang.String str27 = axisEntity23.getImageMapAreaTag(toolTipTagFragmentGenerator25, uRLTagFragmentGenerator26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-8d + "'", double20 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-1,1,0,2" + "'", str24.equals("-1,1,0,2"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean4 = xYLineAndShapeRenderer3.getDrawOutlines();
        java.awt.Font font5 = xYLineAndShapeRenderer3.getBaseLegendTextFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot8.setDomainCrosshairPaint(paint9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, paint9);
        xYLineAndShapeRenderer3.setBaseLegendTextPaint(paint9);
        boolean boolean13 = blockBorder0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            double double5 = timeSeriesCollection2.getXValue(1900, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        double double11 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        labelBlock1.setMargin(rectangleInsets4);
        labelBlock1.setWidth((double) 255);
        double double15 = labelBlock1.getContentYOffset();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker6.setStartValue(0.0d);
        float float9 = intervalMarker6.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot11.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot16.setDomainCrosshairPaint(paint17);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets14, paint17);
        combinedDomainXYPlot11.setOutlinePaint(paint17);
        intervalMarker6.setOutlinePaint(paint17);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker6.setStroke(stroke22);
        boolean boolean24 = combinedDomainXYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker6);
        combinedDomainXYPlot1.configureDomainAxes();
        org.jfree.chart.plot.Plot plot26 = combinedDomainXYPlot1.getRootPlot();
        plot26.setBackgroundImageAlpha((float) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(plot26);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.notifyListeners(plotChangeEvent14);
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        labelBlock17.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot22.setDomainCrosshairPaint(paint23);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, paint23);
        double double27 = rectangleInsets20.calculateLeftOutset((double) (short) 100);
        labelBlock17.setMargin(rectangleInsets20);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets20);
        double double31 = rectangleInsets20.trimWidth((double) 1L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-5.0d) + "'", double31 == (-5.0d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Paint paint2 = null;
        try {
            standardChartTheme1.setGridBandPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        boolean boolean11 = polarPlot10.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot10.zoomRangeAxes((double) 2958465, 0.025d, plotRenderingInfo14, point2D15);
        boolean boolean17 = polarPlot10.isRangeZoomable();
        java.awt.Font font18 = null;
        try {
            polarPlot10.setAngleLabelFont(font18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYBarRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer1.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer1.getBasePositiveItemLabelPosition();
        double double10 = xYBarRenderer1.getShadowXOffset();
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.notifyListeners(plotChangeEvent14);
        java.lang.Object obj16 = combinedDomainXYPlot1.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot7.setDomainCrosshairPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, paint8);
        xYLineAndShapeRenderer2.setBaseLegendTextPaint(paint8);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        xYLineAndShapeRenderer2.setSeriesShape(9999, shape14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer18.setBaseCreateEntities(true);
        int int21 = xYLineAndShapeRenderer18.getPassCount();
        boolean boolean22 = xYLineAndShapeRenderer18.getUseFillPaint();
        java.lang.Object obj23 = xYLineAndShapeRenderer18.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYBarRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        xYBarRenderer25.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition30, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYBarRenderer25.getBasePositiveItemLabelPosition();
        xYLineAndShapeRenderer18.setBaseNegativeItemLabelPosition(itemLabelPosition33, false);
        xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition33, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage19 = jFreeChart14.createBufferedImage((int) '4', 1900, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        defaultKeyedValues0.addValue((java.lang.Comparable) "-1,1,0,2", 0.0d);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getToolTipText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        boolean boolean5 = textTitle0.equals((java.lang.Object) 4);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(255);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 255");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.lang.Object obj7 = xYLineAndShapeRenderer2.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYBarRenderer9.setBaseToolTipGenerator(xYToolTipGenerator10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        xYBarRenderer9.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition14, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYBarRenderer9.getBasePositiveItemLabelPosition();
        xYLineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition17, false);
        boolean boolean20 = xYLineAndShapeRenderer2.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.Object obj1 = combinedRangeXYPlot0.clone();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        java.awt.Color color18 = java.awt.Color.BLUE;
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color18);
        double double20 = symbolAxis8.getUpperBound();
        symbolAxis8.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double28 = xYBarRenderer27.getShadowYOffset();
        java.awt.Color color29 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        xYBarRenderer27.setBasePaint((java.awt.Paint) color29);
        boolean boolean37 = combinedDomainXYPlot25.equals((java.lang.Object) color29);
        java.awt.geom.GeneralPath generalPath38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.RenderingSource renderingSource40 = null;
        combinedDomainXYPlot25.select(generalPath38, rectangle2D39, renderingSource40);
        combinedRangeXYPlot0.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot25);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double16 = xYBarRenderer15.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range18 = xYBarRenderer15.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        xYSeriesCollection13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection17);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("", strArray25);
        java.awt.Font font27 = symbolAxis26.getLabelFont();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis33 = new org.jfree.chart.axis.SymbolAxis("", strArray32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer36.setBaseCreateEntities(true);
        xYLineAndShapeRenderer36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYLineAndShapeRenderer36.getBaseURLGenerator();
        boolean boolean42 = symbolAxis33.equals((java.lang.Object) xYURLGenerator41);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer43 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean44 = xYStepAreaRenderer43.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis33, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer43);
        polarPlot10.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection17);
        java.awt.Paint paint47 = polarPlot10.getAngleLabelPaint();
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_GREEN;
        polarPlot10.setRadiusGridlinePaint((java.awt.Paint) color48);
        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis55 = new org.jfree.chart.axis.SymbolAxis("", strArray54);
        java.lang.String str57 = symbolAxis55.valueToString(0.0d);
        polarPlot10.setAxis((org.jfree.chart.axis.ValueAxis) symbolAxis55);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertEquals((double) number20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[9999.0,2958465.0]", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D29 = null;
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis36 = new org.jfree.chart.axis.SymbolAxis("", strArray35);
        java.awt.Font font37 = symbolAxis36.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis39);
        java.awt.Paint paint41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot40.setDomainCrosshairPaint(paint41);
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder(rectangleInsets38, paint41);
        double double45 = rectangleInsets38.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D46 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker51.setStartValue(0.0d);
        float float54 = intervalMarker51.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = intervalMarker51.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D46, 1.0E-8d, 1.0E-8d, rectangleAnchor55);
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D56);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets38.createInsetRectangle(rectangle2D56);
        symbolAxis36.setUpArrow((java.awt.Shape) rectangle2D56);
        org.jfree.chart.util.Size2D size2D60 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker65 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker65.setStartValue(0.0d);
        float float68 = intervalMarker65.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = intervalMarker65.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D70 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D60, 1.0E-8d, 1.0E-8d, rectangleAnchor69);
        java.awt.Shape shape71 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D70);
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot73 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis72);
        java.awt.Paint paint74 = combinedDomainXYPlot73.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = combinedDomainXYPlot73.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        try {
            org.jfree.chart.axis.AxisState axisState77 = symbolAxis5.draw(graphics2D29, (double) 13, rectangle2D56, rectangle2D70, rectangleEdge75, plotRenderingInfo76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 3.0d + "'", double45 == 3.0d);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.8f + "'", float54 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 0.8f + "'", float68 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "MAJOR", "DateTickUnitType.MINUTE");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo5.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "MAJOR", "DateTickUnitType.MINUTE");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
        basicProjectInfo4.addOptionalLibrary("TimePeriodAnchor.START");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        xYBarRenderer1.setBasePaint((java.awt.Paint) color3);
        java.lang.String str11 = org.jfree.chart.util.PaintUtilities.colorToString(color3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "white" + "'", str11.equals("white"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        boolean boolean6 = symbolAxis5.getAutoRangeStickyZero();
        boolean boolean7 = symbolAxis5.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ThreadContext");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        org.jfree.chart.plot.Plot plot5 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D4, plot5, "PieLabelLinkStyle.STANDARD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot32.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo35, point2D36);
        combinedDomainXYPlot32.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint40 = combinedDomainXYPlot32.getRangeZeroBaselinePaint();
        symbolAxis5.setTickLabelPaint(paint40);
        try {
            symbolAxis5.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = legendItem12.getFillPaintTransformer();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 0.8f, (double) (-1), 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker3.setStartValue(0.0d);
        float float6 = intervalMarker3.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = intervalMarker3.getLabelAnchor();
        java.awt.Font font8 = intervalMarker3.getLabelFont();
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) (short) 100, (java.awt.Paint) color11);
        java.awt.Color color13 = color11.brighter();
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("-1,1,0,2", font8, (java.awt.Paint) color11, (float) ' ', (int) (short) 0, textMeasurer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.8f + "'", float6 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        int int2 = numberFormat1.getMaximumIntegerDigits();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getIntegerInstance();
        numberFormat3.setMinimumFractionDigits(0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PlotOrientation.VERTICAL", numberFormat1, numberFormat3);
        try {
            java.lang.Object obj8 = numberFormat3.parseObject("TimePeriodAnchor.START");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(1.0d, 106.0d, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        int int33 = crosshairState31.getDatasetIndex();
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = null;
        crosshairState31.updateCrosshairPoint(Double.NaN, (double) (byte) -1, 500, 0, (double) (byte) 1, (double) 100, plotOrientation40);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = null;
        crosshairState31.updateCrosshairPoint(4.0d, (double) 0L, 2147483647, 0, (double) (byte) 10, (double) 100L, plotOrientation48);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot32.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo35, point2D36);
        combinedDomainXYPlot32.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint40 = combinedDomainXYPlot32.getRangeZeroBaselinePaint();
        symbolAxis5.setTickLabelPaint(paint40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = symbolAxis5.getLabelInsets();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.data.Range range9 = xYSeriesCollection0.getDomainBounds(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.lang.Object obj15 = jFreeChart14.clone();
        java.awt.RenderingHints renderingHints16 = jFreeChart14.getRenderingHints();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double21 = xYBarRenderer20.getShadowYOffset();
        java.awt.Color color22 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.AffineTransform affineTransform26 = null;
        java.awt.RenderingHints renderingHints27 = null;
        java.awt.PaintContext paintContext28 = color22.createContext(colorModel23, rectangle24, rectangle2D25, affineTransform26, renderingHints27);
        xYBarRenderer20.setBasePaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color22);
        java.lang.Comparable comparable31 = legendItem30.getSeriesKey();
        legendItem30.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker39.setStartValue(0.0d);
        float float42 = intervalMarker39.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = intervalMarker39.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D44 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, 1.0E-8d, 1.0E-8d, rectangleAnchor43);
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D44);
        legendItem30.setLine((java.awt.Shape) rectangle2D44);
        try {
            jFreeChart14.draw(graphics2D17, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintContext28);
        org.junit.Assert.assertNull(comparable31);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.8f + "'", float42 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Paint paint1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        piePlot3D3.axisChanged(axisChangeEvent4);
        boolean boolean6 = piePlot3D3.getLabelLinksVisible();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot3D3.setLabelOutlineStroke(stroke7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Shape shape11 = piePlot10.getLegendItemShape();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        piePlot10.setDrawingSupplier(drawingSupplier12);
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot10.setShadowPaint(paint14);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color20);
        java.lang.Comparable comparable29 = legendItem28.getSeriesKey();
        java.awt.Stroke stroke30 = legendItem28.getLineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(1.0d, paint1, stroke7, paint14, stroke30, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        piePlot3D1.setCircular(false, false);
        double double9 = piePlot3D1.getLabelLinkMargin();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot3D1);
        boolean boolean11 = piePlot3D1.getAutoPopulateSectionPaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer4.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer4.setBaseStroke(stroke7);
        xYStepAreaRenderer4.setOutline(true);
        java.awt.Font font11 = xYStepAreaRenderer4.getBaseItemLabelFont();
        standardChartTheme3.setSmallFont(font11);
        java.awt.Paint paint13 = standardChartTheme3.getItemLabelPaint();
        java.awt.Paint paint14 = standardChartTheme3.getThermometerPaint();
        xYBarRenderer1.setBaseOutlinePaint(paint14);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, (double) (-1.0f), (double) 1L, rectangleAnchor7);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter15 = xYBarRenderer12.getBarPainter();
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYBarRenderer12.setBaseStroke(stroke16);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean21 = xYLineAndShapeRenderer20.getDrawOutlines();
        java.awt.Font font22 = xYLineAndShapeRenderer20.getBaseLegendTextFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot25.setDomainCrosshairPaint(paint26);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, paint26);
        xYLineAndShapeRenderer20.setBaseLegendTextPaint(paint26);
        try {
            org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem(attributedString0, "", "PlotOrientation.VERTICAL", "TimePeriodAnchor.START", (java.awt.Shape) rectangle2D8, paint10, stroke16, paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(xYBarPainter15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("MAJOR", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = xYBarRenderer2.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection4);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color2);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        intervalMarker9.setGradientPaintTransformer(gradientPaintTransformer10);
        java.awt.Paint paint12 = intervalMarker9.getPaint();
        java.awt.Paint paint13 = intervalMarker9.getOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color4, false);
        java.awt.Stroke stroke14 = xYLineAndShapeRenderer2.getSeriesStroke(1900);
        xYLineAndShapeRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint9 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) (-1.0f), (double) 1L, rectangleAnchor14);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        combinedDomainXYPlot18.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo21, point2D22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = combinedDomainXYPlot18.getRangeMarkers(12, layer25);
        int int27 = combinedDomainXYPlot18.getDatasetCount();
        combinedDomainXYPlot18.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        combinedDomainXYPlot18.panRangeAxes((double) 1L, plotRenderingInfo32, point2D33);
        java.awt.geom.Point2D point2D35 = combinedDomainXYPlot18.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState36 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            combinedDomainXYPlot1.draw(graphics2D10, rectangle2D15, point2D35, plotState36, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(point2D35);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedDomainXYPlot1.getLegendItems();
        java.awt.Stroke stroke15 = combinedDomainXYPlot1.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedDomainXYPlot20.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo23, point2D24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = combinedDomainXYPlot20.getRangeMarkers(12, layer27);
        int int29 = combinedDomainXYPlot20.getDatasetCount();
        combinedDomainXYPlot20.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        combinedDomainXYPlot20.panRangeAxes((double) 1L, plotRenderingInfo34, point2D35);
        java.awt.geom.Point2D point2D37 = combinedDomainXYPlot20.getQuadrantOrigin();
        try {
            combinedDomainXYPlot1.zoomRangeAxes(3.0d, 1.0E-5d, plotRenderingInfo18, point2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(point2D37);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        boolean boolean16 = jFreeChart14.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        jFreeChart14.handleClick((int) (byte) 0, 10, chartRenderingInfo19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer25.setBaseCreateEntities(true);
        int int28 = xYLineAndShapeRenderer25.getPassCount();
        boolean boolean29 = xYLineAndShapeRenderer25.getUseFillPaint();
        java.lang.Object obj30 = xYLineAndShapeRenderer25.clone();
        boolean boolean31 = color21.equals((java.lang.Object) xYLineAndShapeRenderer25);
        java.lang.Boolean boolean33 = xYLineAndShapeRenderer25.getSeriesCreateEntities((-9999));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(boolean33);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 2147483647, (double) (-9999), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        boolean boolean11 = polarPlot10.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        polarPlot10.zoomRangeAxes((double) (byte) -1, plotRenderingInfo13, point2D14);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        polarPlot10.setAngleLabelPaint(paint16);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        combinedDomainXYPlot1.setRangeCrosshairValue((double) 1900);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        combinedDomainXYPlot1.setDomainAxis(valueAxis18);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Color color1 = java.awt.Color.getColor("LengthConstraintType.NONE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        piePlot3D1.setMinimumArcAngleToDraw(10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        boolean boolean13 = combinedDomainXYPlot1.isRangeZoomable();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.plotChanged(plotChangeEvent14);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        combinedDomainXYPlot7.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo10, point2D11);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = combinedDomainXYPlot7.getRangeMarkers(12, layer14);
        int int16 = combinedDomainXYPlot7.getDatasetCount();
        combinedDomainXYPlot7.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        combinedDomainXYPlot7.panRangeAxes((double) 1L, plotRenderingInfo21, point2D22);
        java.awt.geom.Point2D point2D24 = combinedDomainXYPlot7.getQuadrantOrigin();
        try {
            combinedDomainXYPlot1.zoomRangeAxes((double) 10, (double) ' ', plotRenderingInfo5, point2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle0.setHorizontalAlignment(horizontalAlignment2);
        textTitle0.setToolTipText("Pie 3D Plot");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("PlotOrientation.VERTICAL");
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.text.DateFormat dateFormat8 = null;
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat8, dateFormat9);
        xYLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator10, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYBarRenderer14.notifyListeners(rendererChangeEvent15);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter17 = xYBarRenderer14.getBarPainter();
        java.awt.Paint paint21 = xYBarRenderer14.getItemFillPaint(2147483647, (-1), false);
        double double22 = xYBarRenderer14.getBase();
        boolean boolean23 = standardXYToolTipGenerator10.equals((java.lang.Object) double22);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(xYBarPainter17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        try {
            java.util.Collection collection3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) strSet2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        combinedRangeXYPlot11.setRangePannable(false);
        double double18 = combinedRangeXYPlot11.getGap();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getToolTipGenerator(0, (int) 'a', false);
        org.jfree.chart.plot.XYPlot xYPlot10 = xYBarRenderer1.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNull(xYPlot10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        boolean boolean2 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        java.lang.String str10 = symbolAxis8.valueToString(0.0d);
        org.jfree.data.Range range11 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = symbolAxis8.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(tickUnitSource12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis24, polarItemRenderer26);
        boolean boolean28 = symbolAxis5.hasListener((java.util.EventListener) xYSeriesCollection17);
        double double29 = symbolAxis5.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0E-8d + "'", double29 == 1.0E-8d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getPlotArea();
        int int2 = xYStepAreaRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        java.awt.Font font7 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Font font8 = xYStepAreaRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) combinedDomainXYPlot11, false);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = labelBlock16.getPadding();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection18);
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis25 = new org.jfree.chart.axis.SymbolAxis("", strArray24);
        java.awt.Font font26 = symbolAxis25.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection18, (org.jfree.chart.axis.ValueAxis) symbolAxis25, polarItemRenderer27);
        polarPlot28.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection31 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double34 = xYBarRenderer33.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection35 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range36 = xYBarRenderer33.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        xYSeriesCollection31.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection35);
        java.lang.Number number38 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis44 = new org.jfree.chart.axis.SymbolAxis("", strArray43);
        java.awt.Font font45 = symbolAxis44.getLabelFont();
        java.lang.String[] strArray50 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis51 = new org.jfree.chart.axis.SymbolAxis("", strArray50);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer54 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer54.setBaseCreateEntities(true);
        xYLineAndShapeRenderer54.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator59 = xYLineAndShapeRenderer54.getBaseURLGenerator();
        boolean boolean60 = symbolAxis51.equals((java.lang.Object) xYURLGenerator59);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean62 = xYStepAreaRenderer61.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection35, (org.jfree.chart.axis.ValueAxis) symbolAxis44, (org.jfree.chart.axis.ValueAxis) symbolAxis51, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer61);
        polarPlot28.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        boolean boolean65 = labelBlock16.equals((java.lang.Object) polarPlot28);
        polarPlot28.clearCornerTextItems();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertEquals((double) number38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNull(xYURLGenerator59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        combinedDomainXYPlot4.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo7, point2D8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedDomainXYPlot4.getRangeMarkers(12, layer11);
        int int13 = combinedDomainXYPlot4.getDatasetCount();
        combinedDomainXYPlot4.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedDomainXYPlot4.panRangeAxes((double) 1L, plotRenderingInfo18, point2D19);
        java.awt.geom.Point2D point2D21 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            waferMapPlot0.draw(graphics2D1, rectangle2D2, point2D21, plotState22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(point2D21);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot15.setDomainCrosshairPaint(paint16);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = combinedDomainXYPlot15.removeDomainMarker(marker18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot15.setRangeAxisLocation(1, axisLocation21, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYBarRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        int int29 = combinedDomainXYPlot15.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker36.setStartValue(0.0d);
        float float39 = intervalMarker36.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = intervalMarker36.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 1.0E-8d, 1.0E-8d, rectangleAnchor40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean46 = combinedDomainXYPlot15.render(graphics2D30, rectangle2D41, (int) (short) 0, plotRenderingInfo43, crosshairState45);
        legendItem12.setShape((java.awt.Shape) rectangle2D41);
        legendItem12.setDatasetIndex(5);
        java.awt.Paint paint50 = legendItem12.getLinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.8f + "'", float39 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYStepAreaRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        xYStepAreaRenderer0.setBaseShape(shape11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = labelBlock1.getMargin();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedDomainXYPlot5.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo8, point2D9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot5.getRangeMarkers(12, layer12);
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis19 = new org.jfree.chart.axis.SymbolAxis("", strArray18);
        boolean boolean20 = symbolAxis19.getAutoRangeStickyZero();
        java.lang.String str22 = symbolAxis19.valueToString((double) (byte) 10);
        java.awt.Font font23 = symbolAxis19.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double27 = xYBarRenderer26.getShadowYOffset();
        java.awt.Color color28 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        xYBarRenderer26.setBasePaint((java.awt.Paint) color28);
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color28);
        java.lang.Comparable comparable37 = legendItem36.getSeriesKey();
        legendItem36.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D40 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker45.setStartValue(0.0d);
        float float48 = intervalMarker45.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = intervalMarker45.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D40, 1.0E-8d, 1.0E-8d, rectangleAnchor49);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D50);
        legendItem36.setLine((java.awt.Shape) rectangle2D50);
        xYStepAreaRenderer0.fillDomainGridBand(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5, (org.jfree.chart.axis.ValueAxis) symbolAxis19, rectangle2D50, 1.0d, (double) (-2208960000000L));
        try {
            org.jfree.chart.axis.ValueAxis valueAxis57 = combinedDomainXYPlot5.getRangeAxisForDataset((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 52 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNull(comparable37);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.8f + "'", float48 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(shape51);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        ringPlot1.setInnerSeparatorExtension((double) (byte) -1);
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis12 = new org.jfree.chart.axis.SymbolAxis("", strArray11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer15.setBaseCreateEntities(true);
        xYLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = xYLineAndShapeRenderer15.getBaseURLGenerator();
        boolean boolean21 = symbolAxis12.equals((java.lang.Object) xYURLGenerator20);
        double double22 = symbolAxis12.getAutoRangeMinimumSize();
        java.awt.Paint paint23 = symbolAxis12.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double26 = xYBarRenderer25.getShadowYOffset();
        java.awt.Color color27 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color27.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        xYBarRenderer25.setBasePaint((java.awt.Paint) color27);
        symbolAxis12.setTickMarkPaint((java.awt.Paint) color27);
        symbolAxis12.setUpperMargin((double) (-1.0f));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double40 = xYBarRenderer39.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection41 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range42 = xYBarRenderer39.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection41);
        double double44 = xYSeriesCollection41.getRangeUpperBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) symbolAxis12, (org.jfree.data.general.Dataset) xYSeriesCollection41);
        ringPlot1.datasetChanged(datasetChangeEvent45);
        double double47 = ringPlot1.getSectionDepth();
        ringPlot1.setSectionDepth((double) (-2L));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNull(xYURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.2d + "'", double47 == 0.2d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.lang.Object obj15 = jFreeChart14.clone();
        java.awt.RenderingHints renderingHints16 = jFreeChart14.getRenderingHints();
        java.util.List list17 = jFreeChart14.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean24 = chartRenderingInfo22.equals((java.lang.Object) (-1L));
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart14.createBufferedImage((int) '#', (-9999), (double) (-1), (double) (-2208960000000L), chartRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (35) and height (-9999) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, (java.lang.Number) 500);
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            defaultKeyedValues0.sortByValues(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedDomainXYPlot32.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo35, point2D36);
        combinedDomainXYPlot32.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint40 = combinedDomainXYPlot32.getRangeZeroBaselinePaint();
        symbolAxis5.setTickLabelPaint(paint40);
        java.lang.String[] strArray42 = symbolAxis5.getSymbols();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(strArray42);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.String str7 = symbolAxis5.valueToString(0.0d);
        symbolAxis5.setMinorTickMarkOutsideLength((float) '4');
        symbolAxis5.resizeRange2(106.0d, (double) 1L);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double10 = xYBarRenderer9.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYBarRenderer9.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYSeriesCollection7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection11);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        java.awt.Font font21 = symbolAxis20.getLabelFont();
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis27 = new org.jfree.chart.axis.SymbolAxis("", strArray26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer30.setBaseCreateEntities(true);
        xYLineAndShapeRenderer30.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYLineAndShapeRenderer30.getBaseURLGenerator();
        boolean boolean36 = symbolAxis27.equals((java.lang.Object) xYURLGenerator35);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean38 = xYStepAreaRenderer37.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.axis.ValueAxis) symbolAxis27, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer37);
        combinedDomainXYPlot1.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) symbolAxis27, false);
        symbolAxis27.setAutoTickUnitSelection(false, true);
        java.lang.String[] strArray49 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis50 = new org.jfree.chart.axis.SymbolAxis("", strArray49);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer53.setBaseCreateEntities(true);
        xYLineAndShapeRenderer53.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator58 = xYLineAndShapeRenderer53.getBaseURLGenerator();
        boolean boolean59 = symbolAxis50.equals((java.lang.Object) xYURLGenerator58);
        double double60 = symbolAxis50.getAutoRangeMinimumSize();
        java.awt.Paint paint61 = symbolAxis50.getLabelPaint();
        symbolAxis50.setLowerMargin((double) (short) 1);
        symbolAxis50.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer70 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer70.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer70.setBaseStroke(stroke73);
        xYStepAreaRenderer70.setOutline(true);
        java.awt.Font font77 = xYStepAreaRenderer70.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand78 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis50, 100.0d, 0.0d, (double) 37, (double) 500, font77);
        symbolAxis27.setMarkerBand(markerAxisBand78);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertEquals((double) number14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNull(xYURLGenerator58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0E-8d + "'", double60 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(font77);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, false);
        java.util.List list8 = categoryPlot0.getCategories();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Font font6 = symbolAxis5.getLabelFont();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        symbolAxis5.setRightArrow(shape8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        java.math.RoundingMode roundingMode1 = null;
        try {
            numberFormat0.setRoundingMode(roundingMode1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot15.setDomainCrosshairPaint(paint16);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = combinedDomainXYPlot15.removeDomainMarker(marker18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot15.setRangeAxisLocation(1, axisLocation21, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYBarRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        int int29 = combinedDomainXYPlot15.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker36.setStartValue(0.0d);
        float float39 = intervalMarker36.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = intervalMarker36.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 1.0E-8d, 1.0E-8d, rectangleAnchor40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean46 = combinedDomainXYPlot15.render(graphics2D30, rectangle2D41, (int) (short) 0, plotRenderingInfo43, crosshairState45);
        legendItem12.setShape((java.awt.Shape) rectangle2D41);
        legendItem12.setDatasetIndex(5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer50 = null;
        try {
            legendItem12.setFillPaintTransformer(gradientPaintTransformer50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.8f + "'", float39 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 100, (double) 100L, 0.0d);
        barRenderer3D0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer3D0.setSeriesURLGenerator(10, categoryURLGenerator10, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        java.lang.String str3 = numberTickUnit0.valueToString(0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.text.NumberFormat numberFormat1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedDomainXYPlot3.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo6, point2D7);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedDomainXYPlot3.getRangeMarkers(12, layer10);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = combinedDomainXYPlot3.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        java.text.NumberFormat numberFormat15 = java.text.NumberFormat.getPercentInstance();
        java.math.RoundingMode roundingMode16 = numberFormat15.getRoundingMode();
        boolean boolean17 = xYSeriesCollection12.equals((java.lang.Object) numberFormat15);
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("0", numberFormat1, numberFormat15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode16.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        java.awt.Paint paint3 = piePlot3D1.getBaseSectionPaint();
        java.awt.Shape shape4 = piePlot3D1.getLegendItemShape();
        piePlot3D1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        try {
            xYSeries2.update((java.lang.Number) 500, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 500");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-456) + "'", int1 == (-456));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) 0.8f);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        xYLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYLineAndShapeRenderer2.setBaseToolTipGenerator(xYToolTipGenerator7);
        xYLineAndShapeRenderer2.setBaseSeriesVisible(false, false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        int int2 = numberFormat1.getMaximumIntegerDigits();
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getIntegerInstance();
        numberFormat3.setMinimumFractionDigits(0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PlotOrientation.VERTICAL", numberFormat1, numberFormat3);
        numberFormat3.setMaximumFractionDigits((-456));
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2, (java.lang.Number) (short) 100);
        xYDataItem2.setSelected(true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((-1));
        boolean boolean2 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        int int33 = crosshairState31.getDatasetIndex();
        double double34 = crosshairState31.getCrosshairY();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        org.jfree.chart.axis.AxisSpace axisSpace15 = combinedDomainXYPlot10.getFixedDomainAxisSpace();
        int int16 = combinedDomainXYPlot10.getWeight();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        polarPlot10.setForegroundAlpha((float) '4');
        org.jfree.chart.axis.ValueAxis valueAxis13 = polarPlot10.getAxis();
        polarPlot10.removeCornerTextItem("Oct");
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis21 = new org.jfree.chart.axis.SymbolAxis("", strArray20);
        boolean boolean22 = symbolAxis21.getAutoRangeStickyZero();
        java.lang.String str24 = symbolAxis21.valueToString((double) (byte) 10);
        java.awt.Font font25 = symbolAxis21.getTickLabelFont();
        polarPlot10.setAngleLabelFont(font25);
        java.awt.Image image27 = null;
        polarPlot10.setBackgroundImage(image27);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(valueAxis13);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        standardChartTheme6.setTickLabelPaint((java.awt.Paint) color7);
        java.awt.Color color17 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color17);
        standardChartTheme6.setLegendBackgroundPaint((java.awt.Paint) color17);
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "-1,1,0,2", "Pie 3D Plot", "PieLabelLinkStyle.STANDARD", shape4, (java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        java.awt.Stroke stroke9 = combinedDomainXYPlot1.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot4.setDomainCrosshairPaint(paint5);
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot4.setRangeAxisLocation(1, axisLocation10, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYBarRenderer14.setBaseToolTipGenerator(xYToolTipGenerator15, false);
        int int18 = combinedDomainXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer14);
        int int20 = combinedDomainXYPlot1.getRendererCount();
        java.lang.Object obj21 = combinedDomainXYPlot1.clone();
        org.jfree.data.xy.XYDataset xYDataset23 = combinedDomainXYPlot1.getDataset((int) ' ');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(xYDataset23);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker6.setStartValue(0.0d);
        float float9 = intervalMarker6.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot11.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot16.setDomainCrosshairPaint(paint17);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets14, paint17);
        combinedDomainXYPlot11.setOutlinePaint(paint17);
        intervalMarker6.setOutlinePaint(paint17);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker6.setStroke(stroke22);
        boolean boolean24 = combinedDomainXYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker6);
        try {
            java.awt.Paint paint26 = combinedDomainXYPlot1.getQuadrantPaint((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("[size=10]", (int) '4', 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.String str7 = symbolAxis5.valueToString(0.0d);
        symbolAxis5.setMinorTickMarkOutsideLength((float) '4');
        boolean boolean10 = symbolAxis5.isGridBandsVisible();
        org.jfree.data.RangeType rangeType11 = symbolAxis5.getRangeType();
        java.lang.String str12 = symbolAxis5.getLabel();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis0.getTickUnit();
        java.lang.Object obj6 = null;
        boolean boolean7 = dateAxis0.equals(obj6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Shape shape16 = symbolAxis5.getLeftArrow();
        boolean boolean17 = symbolAxis5.isGridBandsVisible();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        boolean boolean2 = timePeriodAnchor0.equals((java.lang.Object) dateRange1);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedDomainXYPlot1.setDrawingSupplier(drawingSupplier14);
        combinedDomainXYPlot1.setDomainCrosshairValue((double) 2958465, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker21.setStartValue(0.0d);
        float float24 = intervalMarker21.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot26.setRangeAxisLocation(axisLocation27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(rectangleInsets29, paint32);
        combinedDomainXYPlot26.setOutlinePaint(paint32);
        intervalMarker21.setOutlinePaint(paint32);
        boolean boolean37 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker21);
        java.awt.Stroke stroke38 = combinedDomainXYPlot1.getDomainMinorGridlineStroke();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color43 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel44 = null;
        java.awt.Rectangle rectangle45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.geom.AffineTransform affineTransform47 = null;
        java.awt.RenderingHints renderingHints48 = null;
        java.awt.PaintContext paintContext49 = color43.createContext(colorModel44, rectangle45, rectangle2D46, affineTransform47, renderingHints48);
        xYLineAndShapeRenderer41.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color43, false);
        java.awt.Stroke stroke53 = xYLineAndShapeRenderer41.getSeriesStroke(10);
        int int54 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer41);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = combinedDomainXYPlot1.getRenderer((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.8f + "'", float24 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paintContext49);
        org.junit.Assert.assertNull(stroke53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer56);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setSeriesPaint(10, (java.awt.Paint) color5);
        xYStepAreaRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        double double16 = xYStepAreaRenderer0.getRangeBase();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        int int2 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = piePlot3D1.getLegendItems();
        piePlot3D1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        ringPlot7.setDrawingSupplier(drawingSupplier8, false);
        java.awt.Stroke stroke11 = ringPlot7.getBaseSectionOutlineStroke();
        java.awt.Paint paint12 = null;
        try {
            org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "MAJOR", "", "Range[9999.0,2958465.0]", shape4, paint5, stroke11, paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.notifyListeners(plotChangeEvent14);
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        labelBlock17.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot22.setDomainCrosshairPaint(paint23);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, paint23);
        double double27 = rectangleInsets20.calculateLeftOutset((double) (short) 100);
        labelBlock17.setMargin(rectangleInsets20);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets20);
        double double30 = rectangleInsets20.getRight();
        double double32 = rectangleInsets20.calculateTopOutset(0.025d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection0);
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("", strArray6);
        java.awt.Font font8 = symbolAxis7.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) symbolAxis7, polarItemRenderer9);
        xYSeriesCollection0.validateObject();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("DateTickUnitType.MINUTE");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            float float4 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, dataset1, (java.lang.Comparable) 15);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer3D8.setBaseURLGenerator(categoryURLGenerator9);
        try {
            java.lang.Object obj11 = legendItemBlockContainer3.draw(graphics2D4, rectangle2D7, (java.lang.Object) categoryURLGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.Object obj1 = combinedRangeXYPlot0.clone();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        java.awt.Color color18 = java.awt.Color.BLUE;
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color18);
        double double20 = symbolAxis8.getUpperBound();
        symbolAxis8.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        combinedDomainXYPlot27.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo30, point2D31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = combinedDomainXYPlot27.getRangeMarkers(12, layer34);
        int int36 = combinedDomainXYPlot27.getDatasetCount();
        combinedDomainXYPlot27.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        combinedDomainXYPlot27.panRangeAxes((double) 1L, plotRenderingInfo41, point2D42);
        java.awt.geom.Point2D point2D44 = combinedDomainXYPlot27.getQuadrantOrigin();
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo25, point2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(point2D44);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieToolTipGenerator0.generateToolTip(pieDataset1, (java.lang.Comparable) "Oct");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        combinedRangeXYPlot11.setRangePannable(false);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot(pieDataset16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = null;
        ringPlot17.setDrawingSupplier(drawingSupplier18, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        ringPlot17.markerChanged(markerChangeEvent21);
        ringPlot17.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = ringPlot17.getSimpleLabelOffset();
        java.awt.Stroke stroke26 = ringPlot17.getBaseSectionOutlineStroke();
        combinedRangeXYPlot11.setDomainZeroBaselineStroke(stroke26);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (-456));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        double double11 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker17.setStartValue(0.0d);
        float float20 = intervalMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = intervalMarker17.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, 1.0E-8d, 1.0E-8d, rectangleAnchor21);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D22);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets4.createInsetRectangle(rectangle2D22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        java.awt.Paint paint27 = combinedDomainXYPlot26.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = combinedDomainXYPlot26.getDomainAxisEdge();
        double double29 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor1, 1, 100, rectangle2D22, rectangleEdge28);
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.8f + "'", float20 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.Object obj1 = combinedRangeXYPlot0.clone();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        java.awt.Color color18 = java.awt.Color.BLUE;
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color18);
        double double20 = symbolAxis8.getUpperBound();
        symbolAxis8.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection27);
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis34 = new org.jfree.chart.axis.SymbolAxis("", strArray33);
        java.awt.Font font35 = symbolAxis34.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection27, (org.jfree.chart.axis.ValueAxis) symbolAxis34, polarItemRenderer36);
        boolean boolean38 = polarPlot37.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        polarPlot37.zoomRangeAxes((double) (byte) -1, plotRenderingInfo40, point2D41);
        org.jfree.chart.util.Size2D size2D45 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, (double) (-1.0f), (double) 1L, rectangleAnchor48);
        java.awt.Point point50 = polarPlot37.translateValueThetaRadiusToJava2D((double) 0.5f, (double) (-1.0f), rectangle2D49);
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 10, (double) ' ', plotRenderingInfo26, (java.awt.geom.Point2D) point50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(point50);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker5.setStartValue(0.0d);
        float float8 = intervalMarker5.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = intervalMarker5.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 1.0E-8d, 1.0E-8d, rectangleAnchor9);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D10);
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("", strArray16);
        java.lang.String str19 = symbolAxis17.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D10, (org.jfree.chart.axis.Axis) symbolAxis17);
        java.lang.Object obj21 = axisEntity20.clone();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8f + "'", float8 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer3.setBaseCreateEntities(true);
        int int6 = xYLineAndShapeRenderer3.getPassCount();
        boolean boolean7 = xYLineAndShapeRenderer3.getUseFillPaint();
        java.lang.Object obj8 = xYLineAndShapeRenderer3.clone();
        org.jfree.chart.LegendItem legendItem11 = xYLineAndShapeRenderer3.getLegendItem(1, 500);
        boolean boolean12 = xYLineAndShapeRenderer3.getUseOutlinePaint();
        boolean boolean13 = dateTickMarkPosition0.equals((java.lang.Object) xYLineAndShapeRenderer3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        org.jfree.chart.plot.Marker marker16 = null;
        try {
            combinedDomainXYPlot1.addDomainMarker(marker16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, dataset1, (java.lang.Comparable) 15);
        org.jfree.chart.block.Arrangement arrangement4 = null;
        try {
            legendItemBlockContainer3.setArrangement(arrangement4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator4 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        boolean boolean5 = year0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        xYBarRenderer1.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        boolean boolean3 = combinedDomainXYPlot1.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double8 = xYBarRenderer7.getShadowYOffset();
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color9.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        xYBarRenderer7.setBasePaint((java.awt.Paint) color9);
        boolean boolean17 = combinedDomainXYPlot5.equals((java.lang.Object) color9);
        int int18 = combinedDomainXYPlot5.getRangeAxisCount();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5, 2147483647);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot15.setDomainCrosshairPaint(paint16);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = combinedDomainXYPlot15.removeDomainMarker(marker18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot15.setRangeAxisLocation(1, axisLocation21, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYBarRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        int int29 = combinedDomainXYPlot15.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker36.setStartValue(0.0d);
        float float39 = intervalMarker36.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = intervalMarker36.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 1.0E-8d, 1.0E-8d, rectangleAnchor40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean46 = combinedDomainXYPlot15.render(graphics2D30, rectangle2D41, (int) (short) 0, plotRenderingInfo43, crosshairState45);
        legendItem12.setShape((java.awt.Shape) rectangle2D41);
        java.awt.Paint paint48 = legendItem12.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.8f + "'", float39 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean4 = xYLineAndShapeRenderer3.getDrawOutlines();
        java.awt.Font font5 = xYLineAndShapeRenderer3.getBaseLegendTextFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot8.setDomainCrosshairPaint(paint9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, paint9);
        xYLineAndShapeRenderer3.setBaseLegendTextPaint(paint9);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        boolean boolean14 = xYLineAndShapeRenderer3.hasListener((java.util.EventListener) xYPlot13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot13.getRangeAxisLocation(0);
        combinedRangeXYPlot0.add(xYPlot13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle0.setHorizontalAlignment(horizontalAlignment2);
        textTitle0.setExpandToFitSpace(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        java.util.Date date6 = dateRange5.getLowerDate();
        try {
            dateAxis1.setRange(date4, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("[size=1]", "{0}: ({1}, {2})", "[size=1]", "PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot15.setDomainCrosshairPaint(paint16);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = combinedDomainXYPlot15.removeDomainMarker(marker18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot15.setRangeAxisLocation(1, axisLocation21, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYBarRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        int int29 = combinedDomainXYPlot15.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker36.setStartValue(0.0d);
        float float39 = intervalMarker36.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = intervalMarker36.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 1.0E-8d, 1.0E-8d, rectangleAnchor40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean46 = combinedDomainXYPlot15.render(graphics2D30, rectangle2D41, (int) (short) 0, plotRenderingInfo43, crosshairState45);
        legendItem12.setShape((java.awt.Shape) rectangle2D41);
        int int48 = legendItem12.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.8f + "'", float39 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = ringPlot1.getSimpleLabelOffset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = ringPlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) '#', (double) 0L, 5.0d, (double) (-2208960000000L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        double double3 = piePlot3D1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("white");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("GradientPaintTransformType.CENTER_VERTICAL");
        java.util.Date date2 = null;
        try {
            dateAxis1.setMaximumDate(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        java.lang.String str2 = numberFormat0.format(0.0d);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        java.util.Date date2 = dateRange1.getLowerDate();
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) date2, (double) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState1.getInfo();
        org.jfree.chart.entity.EntityCollection entityCollection4 = rendererState1.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection5 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertNull(entityCollection4);
        org.junit.Assert.assertNull(entityCollection5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        combinedDomainXYPlot1.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = combinedDomainXYPlot1.getDomainAxisIndex(valueAxis9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.lang.String str18 = symbolAxis16.valueToString(0.0d);
        int int19 = combinedDomainXYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis16);
        combinedDomainXYPlot1.configureRangeAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot1.getRenderer((int) (short) -1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        combinedDomainXYPlot1.axisChanged(axisChangeEvent23);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("Range[9999.0,2958465.0]");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        java.lang.String str5 = basicProjectInfo0.getLicenceName();
        java.lang.String str6 = basicProjectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, dataset1, (java.lang.Comparable) 15);
        boolean boolean4 = legendItemBlockContainer3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        boolean boolean6 = range2.intersects(range5);
        double double8 = range5.constrain((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9999.0d + "'", double8 == 9999.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        java.awt.Color color35 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color35.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color35);
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42, layer43);
        combinedDomainXYPlot1.clearRangeMarkers();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker2.setStartValue(0.0d);
        double double5 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYLineAndShapeRenderer2.setBaseLegendTextFont(font5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Paint paint2 = standardChartTheme1.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedDomainXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        try {
            java.lang.Number number16 = xYSeriesCollection10.getX((int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertEquals((double) number13, Double.NaN, 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.awt.Font font17 = symbolAxis16.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, (org.jfree.chart.axis.ValueAxis) symbolAxis16, polarItemRenderer18);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection9);
        try {
            xYSeriesCollection9.setSelected((int) ' ', (int) (short) 1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        xYBarRenderer1.setBasePaint((java.awt.Paint) color3);
        java.lang.Object obj11 = xYBarRenderer1.clone();
        xYBarRenderer1.setBarAlignmentFactor((double) 12);
        java.lang.Object obj14 = xYBarRenderer1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double33 = xYBarRenderer32.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range35 = xYBarRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection34);
        double double37 = xYSeriesCollection34.getRangeUpperBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) symbolAxis5, (org.jfree.data.general.Dataset) xYSeriesCollection34);
        double double39 = symbolAxis5.getUpperMargin();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker1, layer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        xYBarRenderer18.setBasePaint((java.awt.Paint) color20);
        symbolAxis5.setTickMarkPaint((java.awt.Paint) color20);
        symbolAxis5.setUpperMargin((double) (-1.0f));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double33 = xYBarRenderer32.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range35 = xYBarRenderer32.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection34);
        double double37 = xYSeriesCollection34.getRangeUpperBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) symbolAxis5, (org.jfree.data.general.Dataset) xYSeriesCollection34);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState39 = xYSeriesCollection34.getSelectionState();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState39);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        piePlot3D1.axisChanged(axisChangeEvent2);
        piePlot3D1.setLabelLinksVisible(true);
        piePlot3D1.setCircular(false, false);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        java.text.NumberFormat numberFormat13 = standardPieSectionLabelGenerator12.getNumberFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator14 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("MAJOR", numberFormat10, numberFormat13);
        piePlot3D1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat13);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot1.notifyListeners(plotChangeEvent14);
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("");
        labelBlock17.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot22.setDomainCrosshairPaint(paint23);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, paint23);
        double double27 = rectangleInsets20.calculateLeftOutset((double) (short) 100);
        labelBlock17.setMargin(rectangleInsets20);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets20);
        double double30 = rectangleInsets20.getRight();
        double double31 = rectangleInsets20.getTop();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color12);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color12);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        ringPlot22.setDrawingSupplier(drawingSupplier23, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        ringPlot22.markerChanged(markerChangeEvent26);
        ringPlot22.setLabelGap(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = ringPlot22.getSimpleLabelOffset();
        standardChartTheme1.setAxisOffset(rectangleInsets30);
        org.jfree.chart.util.Size2D size2D32 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker37.setStartValue(0.0d);
        float float40 = intervalMarker37.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = intervalMarker37.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 1.0E-8d, 1.0E-8d, rectangleAnchor41);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D42);
        java.lang.String[] strArray48 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis49 = new org.jfree.chart.axis.SymbolAxis("", strArray48);
        java.lang.String str51 = symbolAxis49.valueToString(0.0d);
        org.jfree.chart.entity.AxisEntity axisEntity52 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D42, (org.jfree.chart.axis.Axis) symbolAxis49);
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets30.createInsetRectangle(rectangle2D42, false, false);
        org.jfree.chart.entity.ChartEntity chartEntity57 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D55, "");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.8f + "'", float40 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        org.jfree.chart.LegendItem legendItem5 = xYBarRenderer1.getLegendItem((int) (short) 100, (int) (short) 1);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        xYBarRenderer1.setLegendBar(shape6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer1.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = itemLabelPosition8.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double10 = xYBarRenderer9.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYBarRenderer9.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYSeriesCollection7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection11);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis20 = new org.jfree.chart.axis.SymbolAxis("", strArray19);
        java.awt.Font font21 = symbolAxis20.getLabelFont();
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis27 = new org.jfree.chart.axis.SymbolAxis("", strArray26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer30.setBaseCreateEntities(true);
        xYLineAndShapeRenderer30.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYLineAndShapeRenderer30.getBaseURLGenerator();
        boolean boolean36 = symbolAxis27.equals((java.lang.Object) xYURLGenerator35);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean38 = xYStepAreaRenderer37.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) symbolAxis20, (org.jfree.chart.axis.ValueAxis) symbolAxis27, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer37);
        combinedDomainXYPlot1.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) symbolAxis27, false);
        boolean boolean42 = symbolAxis27.isPositiveArrowVisible();
        boolean boolean43 = symbolAxis27.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertEquals((double) number14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        xYLineAndShapeRenderer5.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color7, false);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer5.getSeriesStroke(10);
        java.awt.Paint paint18 = xYLineAndShapeRenderer5.getBaseItemLabelPaint();
        piePlot3D1.setShadowPaint(paint18);
        boolean boolean20 = piePlot3D1.getDarkerSides();
        java.awt.Paint paint21 = piePlot3D1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color2);
        java.lang.Object obj10 = intervalMarker9.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker13.setStartValue(0.0d);
        float float16 = intervalMarker13.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot18.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis22);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot23.setDomainCrosshairPaint(paint24);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, paint24);
        combinedDomainXYPlot18.setOutlinePaint(paint24);
        intervalMarker13.setOutlinePaint(paint24);
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker13.setStroke(stroke29);
        intervalMarker9.setOutlineStroke(stroke29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        try {
            intervalMarker9.setLabelOffsetType(lengthAdjustmentType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.8f + "'", float16 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        int int16 = legendItemCollection14.getItemCount();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        java.awt.Font font9 = symbolAxis8.getLabelFont();
        xYBarRenderer1.setBaseLegendTextFont(font9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot14.setDomainCrosshairPaint(paint15);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, paint15);
        double double19 = rectangleInsets12.calculateLeftOutset((double) (short) 100);
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker25.setStartValue(0.0d);
        float float28 = intervalMarker25.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = intervalMarker25.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 1.0E-8d, 1.0E-8d, rectangleAnchor29);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets12.createInsetRectangle(rectangle2D30);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot34.setRangeAxisLocation(axisLocation35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot39 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis38);
        java.awt.Paint paint40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot39.setDomainCrosshairPaint(paint40);
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder(rectangleInsets37, paint40);
        combinedDomainXYPlot34.setOutlinePaint(paint40);
        org.jfree.chart.axis.ValueAxis valueAxis44 = combinedDomainXYPlot34.getRangeAxis();
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = combinedDomainXYPlot34.getRangeMarkers((int) (short) 100, layer46);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection48 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection48);
        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis55 = new org.jfree.chart.axis.SymbolAxis("", strArray54);
        java.awt.Font font56 = symbolAxis55.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer57 = null;
        org.jfree.chart.plot.PolarPlot polarPlot58 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection48, (org.jfree.chart.axis.ValueAxis) symbolAxis55, polarItemRenderer57);
        polarPlot58.setForegroundAlpha((float) '4');
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection61 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer63 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double64 = xYBarRenderer63.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection65 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range66 = xYBarRenderer63.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection65);
        xYSeriesCollection61.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection65);
        java.lang.Number number68 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection65);
        java.lang.String[] strArray73 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis74 = new org.jfree.chart.axis.SymbolAxis("", strArray73);
        java.awt.Font font75 = symbolAxis74.getLabelFont();
        java.lang.String[] strArray80 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis81 = new org.jfree.chart.axis.SymbolAxis("", strArray80);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer84 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer84.setBaseCreateEntities(true);
        xYLineAndShapeRenderer84.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator89 = xYLineAndShapeRenderer84.getBaseURLGenerator();
        boolean boolean90 = symbolAxis81.equals((java.lang.Object) xYURLGenerator89);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer91 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean92 = xYStepAreaRenderer91.getPlotArea();
        org.jfree.chart.plot.XYPlot xYPlot93 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection65, (org.jfree.chart.axis.ValueAxis) symbolAxis74, (org.jfree.chart.axis.ValueAxis) symbolAxis81, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer91);
        polarPlot58.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo95 = null;
        try {
            org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState96 = xYBarRenderer1.initialise(graphics2D11, rectangle2D30, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot34, (org.jfree.data.xy.XYDataset) xYSeriesCollection65, plotRenderingInfo95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.8f + "'", float28 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 4.0d + "'", double64 == 4.0d);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertEquals((double) number68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertNull(xYURLGenerator89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        ringPlot1.setInnerSeparatorExtension((double) (byte) -1);
        try {
            ringPlot1.setInteriorGap(12.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (12.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        java.lang.Object obj15 = jFreeChart14.clone();
        java.awt.RenderingHints renderingHints16 = jFreeChart14.getRenderingHints();
        jFreeChart14.setAntiAlias(true);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        combinedDomainXYPlot22.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo25, point2D26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = combinedDomainXYPlot22.getRangeMarkers(12, layer29);
        int int31 = combinedDomainXYPlot22.getDatasetCount();
        combinedDomainXYPlot22.setDomainCrosshairValue((double) 10.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        combinedDomainXYPlot22.panRangeAxes((double) 1L, plotRenderingInfo36, point2D37);
        java.awt.geom.Point2D point2D39 = combinedDomainXYPlot22.getQuadrantOrigin();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean42 = chartRenderingInfo40.equals((java.lang.Object) (-1L));
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        chartRenderingInfo40.setEntityCollection(entityCollection43);
        try {
            jFreeChart14.draw(graphics2D19, rectangle2D20, point2D39, chartRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(point2D39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        boolean boolean2 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        piePlot3D1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        org.jfree.chart.util.Rotation rotation6 = piePlot3D1.getDirection();
        piePlot3D1.setStartAngle(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator4);
        barRenderer3D0.setShadowXOffset((double) 1);
        barRenderer3D0.setAutoPopulateSeriesStroke(true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        int int3 = categoryPlot0.getRendererCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis22 = new org.jfree.chart.axis.SymbolAxis("", strArray21);
        combinedRangeXYPlot11.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) symbolAxis22);
        java.awt.Font font24 = symbolAxis22.getTickLabelFont();
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis30 = new org.jfree.chart.axis.SymbolAxis("", strArray29);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer33.setBaseCreateEntities(true);
        xYLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = xYLineAndShapeRenderer33.getBaseURLGenerator();
        boolean boolean39 = symbolAxis30.equals((java.lang.Object) xYURLGenerator38);
        java.awt.Color color40 = java.awt.Color.BLUE;
        symbolAxis30.setTickMarkPaint((java.awt.Paint) color40);
        boolean boolean42 = symbolAxis22.equals((java.lang.Object) color40);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNull(xYURLGenerator38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        int int3 = xYSeries2.getMaximumItemCount();
        boolean boolean4 = xYSeries2.getAutoSort();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries2.remove((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        java.awt.Paint paint8 = combinedDomainXYPlot7.getRangeZeroBaselinePaint();
        boolean boolean9 = combinedDomainXYPlot7.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker12.setStartValue(0.0d);
        float float15 = intervalMarker12.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = intervalMarker12.getLabelOffsetType();
        boolean boolean17 = combinedDomainXYPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot0.getDomainAxisLocation(3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.8f + "'", float15 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection17);
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        java.awt.Font font25 = symbolAxis24.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, (org.jfree.chart.axis.ValueAxis) symbolAxis24, polarItemRenderer26);
        boolean boolean28 = symbolAxis5.hasListener((java.util.EventListener) xYSeriesCollection17);
        try {
            org.jfree.data.xy.XYSeries xYSeries30 = xYSeriesCollection17.getSeries((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection2.getSeries((java.lang.Comparable) 1900);
        java.util.List list5 = null;
        org.jfree.data.Range range8 = new org.jfree.data.Range((double) 9999, (double) 2958465);
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 100L);
        try {
            org.jfree.data.Range range12 = timeSeriesCollection2.getRangeBounds(list5, range8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeries4);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double4 = xYBarRenderer3.getShadowYOffset();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        xYBarRenderer3.setBasePaint((java.awt.Paint) color5);
        boolean boolean13 = combinedDomainXYPlot1.equals((java.lang.Object) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedDomainXYPlot1.setDrawingSupplier(drawingSupplier14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        try {
            combinedDomainXYPlot1.rendererChanged(rendererChangeEvent16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double3 = xYBarRenderer2.getShadowYOffset();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        xYBarRenderer2.setBasePaint((java.awt.Paint) color4);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color4);
        java.lang.Comparable comparable13 = legendItem12.getSeriesKey();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot15.setDomainCrosshairPaint(paint16);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = combinedDomainXYPlot15.removeDomainMarker(marker18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot15.setRangeAxisLocation(1, axisLocation21, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYBarRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26, false);
        int int29 = combinedDomainXYPlot15.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker36.setStartValue(0.0d);
        float float39 = intervalMarker36.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = intervalMarker36.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 1.0E-8d, 1.0E-8d, rectangleAnchor40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean46 = combinedDomainXYPlot15.render(graphics2D30, rectangle2D41, (int) (short) 0, plotRenderingInfo43, crosshairState45);
        legendItem12.setShape((java.awt.Shape) rectangle2D41);
        java.lang.Comparable comparable48 = legendItem12.getSeriesKey();
        boolean boolean49 = legendItem12.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.8f + "'", float39 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(comparable48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator4);
        boolean boolean6 = barRenderer3D0.getShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 9999, (java.awt.Paint) color7);
        java.lang.Object obj15 = intervalMarker14.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker18.setStartValue(0.0d);
        float float21 = intervalMarker18.getAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot23.setRangeAxisLocation(axisLocation24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis27);
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot28.setDomainCrosshairPaint(paint29);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(rectangleInsets26, paint29);
        combinedDomainXYPlot23.setOutlinePaint(paint29);
        intervalMarker18.setOutlinePaint(paint29);
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        intervalMarker18.setStroke(stroke34);
        intervalMarker14.setOutlineStroke(stroke34);
        xYLineAndShapeRenderer2.setBaseStroke(stroke34, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.8f + "'", float21 == 0.8f);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.DomainOrder domainOrder3 = timeSeriesCollection2.getDomainOrder();
        org.junit.Assert.assertNotNull(domainOrder3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            combinedDomainXYPlot1.handleClick((int) (short) -1, 1, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedDomainXYPlot5.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo8, point2D9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot5.getRangeMarkers(12, layer12);
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis19 = new org.jfree.chart.axis.SymbolAxis("", strArray18);
        boolean boolean20 = symbolAxis19.getAutoRangeStickyZero();
        java.lang.String str22 = symbolAxis19.valueToString((double) (byte) 10);
        java.awt.Font font23 = symbolAxis19.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double27 = xYBarRenderer26.getShadowYOffset();
        java.awt.Color color28 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        xYBarRenderer26.setBasePaint((java.awt.Paint) color28);
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("Oct", (java.awt.Paint) color28);
        java.lang.Comparable comparable37 = legendItem36.getSeriesKey();
        legendItem36.setSeriesKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Size2D size2D40 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker45.setStartValue(0.0d);
        float float48 = intervalMarker45.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = intervalMarker45.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D40, 1.0E-8d, 1.0E-8d, rectangleAnchor49);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D50);
        legendItem36.setLine((java.awt.Shape) rectangle2D50);
        xYStepAreaRenderer0.fillDomainGridBand(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5, (org.jfree.chart.axis.ValueAxis) symbolAxis19, rectangle2D50, 1.0d, (double) (-2208960000000L));
        symbolAxis19.resizeRange((double) 8);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNull(comparable37);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.8f + "'", float48 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(shape51);
    }
}

