import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo0.getPlotInfo();
        int int3 = plotRenderingInfo2.getSubplotCount();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        int int3 = xYSeries2.getMaximumItemCount();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.remove((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        int int3 = xYSeries2.getMaximumItemCount();
        boolean boolean4 = xYSeries2.getAutoSort();
        xYSeries2.add(100.0d, (double) (-2L));
        boolean boolean8 = xYSeries2.getAllowDuplicateXValues();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        combinedRangeXYPlot11.setRangePannable(false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedRangeXYPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = combinedRangeXYPlot11.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double22 = xYBarRenderer21.getShadowYOffset();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis28 = new org.jfree.chart.axis.SymbolAxis("", strArray27);
        java.awt.Font font29 = symbolAxis28.getLabelFont();
        xYBarRenderer21.setBaseLegendTextFont(font29);
        combinedRangeXYPlot11.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer21);
        java.awt.Shape shape33 = xYBarRenderer21.lookupSeriesShape(32);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color4, true);
        org.jfree.chart.LegendItem legendItem9 = xYLineAndShapeRenderer2.getLegendItem(0, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Shape shape2 = multiplePiePlot1.getLegendItemShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryDataset3);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, false);
        java.util.List list8 = categoryPlot0.getCategories();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot0.setDataset(categoryDataset10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double17 = xYBarRenderer16.getShadowYOffset();
        java.awt.Color color18 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        xYBarRenderer16.setBasePaint((java.awt.Paint) color18);
        boolean boolean26 = combinedDomainXYPlot14.equals((java.lang.Object) color18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        combinedDomainXYPlot14.notifyListeners(plotChangeEvent27);
        combinedDomainXYPlot14.setDomainZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation32 = combinedDomainXYPlot14.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedDomainXYPlot14.getDomainAxisLocation(8);
        try {
            categoryPlot0.setDomainAxisLocation((-1), axisLocation34, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine1.calculateDimensions(graphics2D3);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("DateTickUnitType.MINUTE");
        textLine1.addFragment(textFragment6);
        org.junit.Assert.assertNotNull(size2D4);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        combinedDomainXYPlot1.zoomDomainAxes(0.025d, (double) 9999, plotRenderingInfo4, point2D5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedDomainXYPlot1.getRangeMarkers(12, layer8);
        java.lang.Object obj10 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedDomainXYPlot1.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = new org.jfree.chart.LegendItemCollection();
        boolean boolean15 = combinedRangeXYPlot11.equals((java.lang.Object) legendItemCollection14);
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis22 = new org.jfree.chart.axis.SymbolAxis("", strArray21);
        combinedRangeXYPlot11.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) symbolAxis22);
        double double24 = combinedRangeXYPlot11.getGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        combinedRangeXYPlot11.plotChanged(plotChangeEvent25);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5.0d + "'", double24 == 5.0d);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5, false);
        java.util.List list8 = categoryPlot0.getCategories();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot0.setDataset(categoryDataset10);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "white", false);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 0);
        java.lang.Object obj2 = xYAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint7);
        combinedDomainXYPlot1.setOutlinePaint(paint7);
        org.jfree.chart.axis.ValueAxis valueAxis11 = combinedDomainXYPlot1.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        double double13 = axisSpace12.getBottom();
        combinedDomainXYPlot1.setFixedRangeAxisSpace(axisSpace12, true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        try {
            axisSpace12.ensureAtLeast(axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(5.0d, (double) 'a');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("MAJOR");
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean4 = standardPieToolTipGenerator1.equals((java.lang.Object) textAnchor3);
        java.lang.String str5 = standardPieToolTipGenerator1.getLabelFormat();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "MAJOR" + "'", str5.equals("MAJOR"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.Object obj1 = logFormat0.clone();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        java.lang.StringBuffer stringBuffer5 = logFormat0.format((double) 1577865599999L, stringBuffer3, fieldPosition4);
        int int6 = logFormat0.getMinimumFractionDigits();
        java.text.ParsePosition parsePosition8 = null;
        java.lang.Number number9 = logFormat0.parse("[size=1]", parsePosition8);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stringBuffer5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.util.Size2D size2D1 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D1, (double) (-1.0f), (double) 1L, rectangleAnchor4);
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis11 = new org.jfree.chart.axis.SymbolAxis("", strArray10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer14.setBaseCreateEntities(true);
        xYLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = xYLineAndShapeRenderer14.getBaseURLGenerator();
        boolean boolean20 = symbolAxis11.equals((java.lang.Object) xYURLGenerator19);
        double double21 = symbolAxis11.getAutoRangeMinimumSize();
        java.awt.Paint paint22 = symbolAxis11.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity24 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D5, (org.jfree.chart.axis.Axis) symbolAxis11, "PieLabelLinkStyle.STANDARD");
        java.lang.String str26 = symbolAxis11.valueToString((-5.0d));
        symbolAxis11.setUpperMargin((double) (-1.0f));
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker31.setStartValue(0.0d);
        float float34 = intervalMarker31.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = intervalMarker31.getLabelAnchor();
        java.awt.Font font36 = intervalMarker31.getLabelFont();
        symbolAxis11.setLabelFont(font36);
        org.jfree.chart.StandardChartTheme standardChartTheme39 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer40.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer40.setBaseStroke(stroke43);
        xYStepAreaRenderer40.setOutline(true);
        java.awt.Font font47 = xYStepAreaRenderer40.getBaseItemLabelFont();
        standardChartTheme39.setSmallFont(font47);
        java.awt.Paint paint49 = standardChartTheme39.getGridBandPaint();
        java.awt.Paint paint50 = standardChartTheme39.getPlotOutlinePaint();
        java.awt.Color color51 = java.awt.Color.WHITE;
        standardChartTheme39.setLegendBackgroundPaint((java.awt.Paint) color51);
        java.awt.Paint paint53 = standardChartTheme39.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer57 = new org.jfree.chart.text.G2TextMeasurer(graphics2D56);
        try {
            org.jfree.chart.text.TextBlock textBlock58 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie 3D Plot", font36, paint53, (float) (short) 100, 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNull(xYURLGenerator19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-8d + "'", double21 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.8f + "'", float34 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setVisible(true);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int[] intArray4 = org.jfree.chart.renderer.RendererUtilities.findLiveItems(xYDataset0, (int) 'a', (double) 2.0f, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection9);
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        java.awt.Font font17 = symbolAxis16.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, (org.jfree.chart.axis.ValueAxis) symbolAxis16, polarItemRenderer18);
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection9);
        boolean boolean21 = xYSeries2.getAutoSort();
        xYSeries2.add((double) (short) 10, (java.lang.Number) 2, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        java.util.List list2 = timeSeriesCollection1.getSeries();
        java.lang.Object obj3 = timeSeriesCollection1.clone();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot2.setDomainCrosshairPaint(paint3);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        double double6 = rectangleInsets0.getLeft();
        double double8 = rectangleInsets0.calculateTopOutset((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1900);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        int int6 = segmentedTimeline5.getGroupSegmentCount();
        objectList0.set(0, (java.lang.Object) int6);
        java.lang.Object obj9 = objectList0.get((int) 'a');
        java.lang.Object obj11 = objectList0.get(0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 37 + "'", int6 == 37);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + 37 + "'", obj11.equals(37));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (-1), (int) '#', 2);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        segmentedTimeline3.addException((long) 12, (long) 2147483647);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) (short) 10);
        segment10.inc(0L);
        long long13 = segment10.getSegmentCount();
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        timeSeries1.setMaximumItemAge((long) (short) 0);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.lang.Number number7 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer3D0.getBarPainter();
        barRenderer3D0.setMaximumBarWidth((double) 15);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer3D0.getBaseToolTipGenerator();
        barRenderer3D0.clearSeriesPaints(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int1 = barRenderer3D0.getRowCount();
        barRenderer3D0.setIncludeBaseInRange(true);
        barRenderer3D0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.text.DateFormat dateFormat9 = null;
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("PlotOrientation.VERTICAL", dateFormat9, dateFormat10);
        xYStepAreaRenderer7.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer15.setBaseCreateEntities(true);
        int int18 = xYLineAndShapeRenderer15.getPassCount();
        boolean boolean19 = xYLineAndShapeRenderer15.getUseFillPaint();
        java.lang.Object obj20 = xYLineAndShapeRenderer15.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        xYBarRenderer22.setBaseToolTipGenerator(xYToolTipGenerator23, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        xYBarRenderer22.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYBarRenderer22.getBasePositiveItemLabelPosition();
        xYLineAndShapeRenderer15.setBaseNegativeItemLabelPosition(itemLabelPosition30, false);
        xYStepAreaRenderer7.setBaseNegativeItemLabelPosition(itemLabelPosition30, false);
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        tickUnits0.add((org.jfree.chart.axis.TickUnit) numberTickUnit2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer8.setBaseCreateEntities(true);
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYLineAndShapeRenderer8.getBaseURLGenerator();
        boolean boolean14 = symbolAxis5.equals((java.lang.Object) xYURLGenerator13);
        double double15 = symbolAxis5.getAutoRangeMinimumSize();
        java.awt.Paint paint16 = symbolAxis5.getLabelPaint();
        symbolAxis5.setLowerMargin((double) (short) 1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 10);
        java.lang.String str21 = numberTickUnit20.toString();
        symbolAxis5.setTickUnit(numberTickUnit20);
        java.lang.String str24 = numberTickUnit20.valueToString(0.0d);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[size=10]" + "'", str21.equals("[size=10]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.Object obj1 = combinedRangeXYPlot0.clone();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer11.setBaseCreateEntities(true);
        xYLineAndShapeRenderer11.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYLineAndShapeRenderer11.getBaseURLGenerator();
        boolean boolean17 = symbolAxis8.equals((java.lang.Object) xYURLGenerator16);
        java.awt.Color color18 = java.awt.Color.BLUE;
        symbolAxis8.setTickMarkPaint((java.awt.Paint) color18);
        double double20 = symbolAxis8.getUpperBound();
        symbolAxis8.setAutoRange(true);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) symbolAxis8);
        java.lang.Object obj24 = combinedRangeXYPlot0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        xYBarRenderer2.notifyListeners(rendererChangeEvent3);
        boolean boolean7 = xYBarRenderer2.getItemVisible((int) (byte) 1, (int) (short) 0);
        java.awt.Font font9 = xYBarRenderer2.getSeriesItemLabelFont((int) 'a');
        boolean boolean10 = tickUnits0.equals((java.lang.Object) xYBarRenderer2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int4 = barRenderer3D3.getRowCount();
        org.jfree.chart.renderer.category.BarPainter barPainter5 = barRenderer3D3.getBarPainter();
        barRenderer3D0.setBarPainter(barPainter5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer3D0.setSeriesToolTipGenerator((int) 'a', categoryToolTipGenerator8);
        int int10 = barRenderer3D0.getRowCount();
        java.awt.Paint paint12 = barRenderer3D0.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(barPainter5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Paint paint6 = xYLineAndShapeRenderer2.getLegendTextPaint(255);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) 4);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), (double) 1L, rectangleAnchor3);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis10 = new org.jfree.chart.axis.SymbolAxis("", strArray9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer13.setBaseCreateEntities(true);
        xYLineAndShapeRenderer13.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYLineAndShapeRenderer13.getBaseURLGenerator();
        boolean boolean19 = symbolAxis10.equals((java.lang.Object) xYURLGenerator18);
        double double20 = symbolAxis10.getAutoRangeMinimumSize();
        java.awt.Paint paint21 = symbolAxis10.getLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity23 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D4, (org.jfree.chart.axis.Axis) symbolAxis10, "PieLabelLinkStyle.STANDARD");
        java.lang.String str25 = symbolAxis10.valueToString((-5.0d));
        symbolAxis10.setUpperMargin((double) (-1.0f));
        symbolAxis10.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-8d + "'", double20 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setLabelGap(0.0d);
        java.awt.Paint paint9 = ringPlot1.getBaseSectionPaint();
        ringPlot1.setSimpleLabels(false);
        boolean boolean12 = ringPlot1.getSeparatorsVisible();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot3D14.axisChanged(axisChangeEvent15);
        piePlot3D14.setLabelLinksVisible(true);
        double double19 = piePlot3D14.getShadowYOffset();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.StandardChartTheme standardChartTheme22 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        standardChartTheme22.setTickLabelPaint((java.awt.Paint) color23);
        piePlot3D14.setSectionOutlinePaint((java.lang.Comparable) numberTickUnit20, (java.awt.Paint) color23);
        ringPlot1.setLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor33 = null;
        try {
            ringPlot1.setLabelDistributor(abstractPieLabelDistributor33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double2 = xYBarRenderer1.getShadowYOffset();
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("", strArray7);
        java.awt.Font font9 = symbolAxis8.getLabelFont();
        xYBarRenderer1.setBaseLegendTextFont(font9);
        java.awt.Paint paint11 = xYBarRenderer1.getBaseLegendTextPaint();
        xYBarRenderer1.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        java.awt.Color color1 = java.awt.Color.red;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("-1,1,0,2", (java.awt.Paint) color1);
        int int3 = legendItem2.getDatasetIndex();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        xYLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition((int) (byte) 10, itemLabelPosition5, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(35);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer1.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer1.setBaseStroke(stroke4);
        xYStepAreaRenderer1.setOutline(true);
        java.awt.Font font8 = xYStepAreaRenderer1.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot10.setDomainCrosshairPaint(paint11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) combinedDomainXYPlot10, false);
        int int15 = jFreeChart14.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart14.addProgressListener(chartProgressListener16);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = combinedDomainXYPlot1.getOrientation();
        combinedDomainXYPlot1.clearAnnotations();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot1.getDomainAxisForDataset(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 12 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation2);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot1.setDomainCrosshairPaint(paint2);
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedDomainXYPlot1.removeDomainMarker(marker4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot1.setRangeAxisLocation(1, axisLocation7, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYBarRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12, false);
        int int15 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker22.setStartValue(0.0d);
        float float25 = intervalMarker22.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker22.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 1.0E-8d, 1.0E-8d, rectangleAnchor26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = new org.jfree.chart.plot.CrosshairState(true);
        boolean boolean32 = combinedDomainXYPlot1.render(graphics2D16, rectangle2D27, (int) (short) 0, plotRenderingInfo29, crosshairState31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        combinedDomainXYPlot1.setFixedRangeAxisSpace(axisSpace33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.NONE", graphics2D1, (float) 10, (float) 100L, (-1.0d), (float) 2147483647, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true);
        int int5 = xYLineAndShapeRenderer2.getPassCount();
        boolean boolean6 = xYLineAndShapeRenderer2.getUseFillPaint();
        java.lang.Boolean boolean8 = xYLineAndShapeRenderer2.getSeriesVisibleInLegend((int) '#');
        java.awt.Font font10 = null;
        xYLineAndShapeRenderer2.setSeriesItemLabelFont((int) (byte) 10, font10);
        xYLineAndShapeRenderer2.setBaseCreateEntities(true, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer0.setBaseStroke(stroke3);
        xYStepAreaRenderer0.setOutline(true);
        java.awt.Paint paint8 = xYStepAreaRenderer0.getSeriesFillPaint(12);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        java.awt.Color color3 = java.awt.Color.lightGray;
        piePlot3D1.setLabelShadowPaint((java.awt.Paint) color3);
        float[] floatArray13 = new float[] { 5, (-1L), 35, 5, (byte) 100 };
        float[] floatArray14 = java.awt.Color.RGBtoHSB(2147483647, (-9999), (int) (byte) -1, floatArray13);
        float[] floatArray15 = color3.getRGBComponents(floatArray13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("Range[9999.0,2958465.0]");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        java.util.List list5 = projectInfo3.getContributors();
        projectInfo3.setLicenceText("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer7.setBaseCreateEntities(true);
        boolean boolean10 = xYSeries4.equals((java.lang.Object) true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYSeriesCollection11);
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis18 = new org.jfree.chart.axis.SymbolAxis("", strArray17);
        java.awt.Font font19 = symbolAxis18.getLabelFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) symbolAxis18, polarItemRenderer20);
        xYSeries4.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection11);
        double[][] doubleArray23 = xYSeries4.toArray();
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("LengthConstraintType.NONE", "UnitType.ABSOLUTE", doubleArray23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(15.625d, 0.0d, (double) (short) 100);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        ringPlot1.setDrawingSupplier(drawingSupplier2, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        ringPlot1.markerChanged(markerChangeEvent5);
        ringPlot1.setLabelGap(0.0d);
        java.awt.Paint paint9 = ringPlot1.getBaseSectionPaint();
        ringPlot1.setOuterSeparatorExtension((double) (-1L));
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        double double1 = xYStepRenderer0.getStepPoint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        boolean boolean9 = xYSeries2.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.lang.Boolean boolean6 = xYLineAndShapeRenderer2.getSeriesCreateEntities((int) (short) 0);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        ringPlot9.setDrawingSupplier(drawingSupplier10, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = ringPlot9.getLegendLabelURLGenerator();
        boolean boolean14 = ringPlot9.isCircular();
        int int15 = day7.compareTo((java.lang.Object) ringPlot9);
        boolean boolean16 = xYLineAndShapeRenderer2.equals((java.lang.Object) int15);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLegendLabelGenerator();
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("Oct");
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        standardChartTheme5.setTickLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = standardChartTheme5.getAxisOffset();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        standardChartTheme5.setChartBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer18.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer18.setBaseStroke(stroke21);
        xYStepAreaRenderer18.setOutline(true);
        java.awt.Font font25 = xYStepAreaRenderer18.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis26);
        java.awt.Paint paint28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot27.setDomainCrosshairPaint(paint28);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("", font25, (org.jfree.chart.plot.Plot) combinedDomainXYPlot27, false);
        standardChartTheme5.setExtraLargeFont(font25);
        java.awt.Color color35 = java.awt.Color.BLUE;
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) (short) 100, (java.awt.Paint) color35);
        java.awt.Color color37 = color35.brighter();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color35);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer41 = new org.jfree.chart.text.G2TextMeasurer(graphics2D40);
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, (java.awt.Paint) color35, (float) 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer41);
        piePlot3D1.setLabelFont(font25);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(textBlock42);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double10 = xYBarRenderer9.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYBarRenderer9.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYSeriesCollection7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection11);
        java.util.List list14 = xYSeriesCollection11.getSeries();
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) ' ');
        double double19 = xYBarRenderer18.getShadowYOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range21 = xYBarRenderer18.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection20);
        xYSeriesCollection16.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection20);
        java.util.List list23 = xYSeriesCollection20.getSeries();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, list23, false);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, false);
        try {
            java.lang.String str29 = standardXYSeriesLabelGenerator5.generateLabel((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertEquals((double) number15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.util.Date date1 = dateRange0.getLowerDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Year year5 = month4.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getRangeZeroBaselinePaint();
        boolean boolean3 = combinedDomainXYPlot1.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker6.setStartValue(0.0d);
        float float9 = intervalMarker6.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker6.getLabelOffsetType();
        boolean boolean11 = combinedDomainXYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker6);
        java.awt.Stroke stroke12 = combinedDomainXYPlot1.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean14 = xYStepAreaRenderer13.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Stroke stroke16 = xYStepAreaRenderer13.lookupSeriesOutlineStroke((int) (byte) 100);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer13);
        xYStepAreaRenderer13.setPlotArea(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("JFreeChart", graphics2D1, 90.0d, (float) 500, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        boolean boolean5 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        int int7 = barRenderer3D6.getRowCount();
        barRenderer3D6.setIncludeBaseInRange(true);
        double double10 = barRenderer3D6.getXOffset();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue((double) 4);
        categoryPlot12.setRangePannable(false);
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis22 = new org.jfree.chart.axis.SymbolAxis("", strArray21);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer25.setBaseCreateEntities(true);
        xYLineAndShapeRenderer25.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = xYLineAndShapeRenderer25.getBaseURLGenerator();
        boolean boolean31 = symbolAxis22.equals((java.lang.Object) xYURLGenerator30);
        double double32 = symbolAxis22.getAutoRangeMinimumSize();
        java.awt.Paint paint33 = symbolAxis22.getLabelPaint();
        symbolAxis22.setLowerMargin((double) (short) 1);
        symbolAxis22.setTickMarksVisible(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer42 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer42.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer42.setBaseStroke(stroke45);
        xYStepAreaRenderer42.setOutline(true);
        java.awt.Font font49 = xYStepAreaRenderer42.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) symbolAxis22, 100.0d, 0.0d, (double) 37, (double) 500, font49);
        org.jfree.chart.util.Size2D size2D51 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker56.setStartValue(0.0d);
        float float59 = intervalMarker56.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = intervalMarker56.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D51, 1.0E-8d, 1.0E-8d, rectangleAnchor60);
        barRenderer3D6.drawRangeGridline(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) symbolAxis22, rectangle2D61, (double) (-2L));
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot65 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis64);
        org.jfree.chart.axis.AxisLocation axisLocation66 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        combinedDomainXYPlot65.setRangeAxisLocation(axisLocation66);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot70 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis69);
        java.awt.Paint paint71 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot70.setDomainCrosshairPaint(paint71);
        org.jfree.chart.block.BlockBorder blockBorder73 = new org.jfree.chart.block.BlockBorder(rectangleInsets68, paint71);
        combinedDomainXYPlot65.setOutlinePaint(paint71);
        org.jfree.chart.axis.ValueAxis valueAxis75 = combinedDomainXYPlot65.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation76 = combinedDomainXYPlot65.getRangeAxisLocation();
        categoryPlot12.setRangeAxisLocation(axisLocation76, true);
        org.jfree.chart.axis.ValueAxis valueAxis79 = categoryPlot12.getRangeAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor80 = categoryPlot12.getDomainGridlinePosition();
        categoryPlot0.setDomainGridlinePosition(categoryAnchor80);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 12.0d + "'", double10 == 12.0d);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNull(xYURLGenerator30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0E-8d + "'", double32 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.8f + "'", float59 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNull(valueAxis75);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNull(valueAxis79);
        org.junit.Assert.assertNotNull(categoryAnchor80);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getLabelGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Oct");
        piePlot3D1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.lang.Object obj6 = standardPieSectionLabelGenerator4.clone();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        java.util.Date date8 = dateRange7.getLowerDate();
        boolean boolean9 = standardPieSectionLabelGenerator4.equals((java.lang.Object) date8);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition11);
        boolean boolean13 = standardPieSectionLabelGenerator4.equals((java.lang.Object) dateAxis10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis10.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 4);
        categoryPlot0.setRangePannable(false);
        categoryPlot0.setDrawSharedDomainAxis(true);
        categoryPlot0.setDrawSharedDomainAxis(false);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        xYLineAndShapeRenderer5.setBaseCreateEntities(true);
        boolean boolean8 = xYSeries2.equals((java.lang.Object) true);
        double double9 = xYSeries2.getMinX();
        org.jfree.data.xy.XYDataItem xYDataItem12 = xYSeries2.addOrUpdate((java.lang.Number) 500, (java.lang.Number) 255);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem12);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle1.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, (double) 255, (double) (short) 10);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) dateTickUnitType7);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer3.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer3.setBaseStroke(stroke6);
        xYStepAreaRenderer3.setOutline(true);
        java.awt.Font font10 = xYStepAreaRenderer3.getBaseItemLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        combinedDomainXYPlot12.setDomainCrosshairPaint(paint13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) combinedDomainXYPlot12, false);
        float float17 = jFreeChart16.getBackgroundImageAlpha();
        boolean boolean18 = jFreeChart16.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        jFreeChart16.handleClick((int) (byte) 0, 10, chartRenderingInfo21);
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Oct");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer2.setRangeBase((double) (short) 10);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        xYStepAreaRenderer2.setBaseStroke(stroke5);
        xYStepAreaRenderer2.setOutline(true);
        java.awt.Font font9 = xYStepAreaRenderer2.getBaseItemLabelFont();
        standardChartTheme1.setSmallFont(font9);
        java.awt.Paint paint11 = standardChartTheme1.getItemLabelPaint();
        java.awt.Paint paint12 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Paint paint14 = standardChartTheme1.getCrosshairPaint();
        java.awt.Paint paint15 = standardChartTheme1.getLegendBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.util.Size2D size2D1 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, 0.0d);
        intervalMarker6.setStartValue(0.0d);
        float float9 = intervalMarker6.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = intervalMarker6.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D1, 1.0E-8d, 1.0E-8d, rectangleAnchor10);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setAnchorValue((double) 4);
        java.awt.Paint paint16 = categoryPlot13.getRangeGridlinePaint();
        java.awt.Stroke stroke17 = categoryPlot13.getRangeMinorGridlineStroke();
        java.awt.Paint paint18 = categoryPlot13.getRangeCrosshairPaint();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "Oct", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis24 = new org.jfree.chart.axis.SymbolAxis("", strArray23);
        int int25 = categoryPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis24);
        org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D11, (org.jfree.chart.plot.Plot) categoryPlot13);
        try {
            boolean boolean27 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine();
        textBlock1.addLine(textLine2);
        textBlock0.addLine(textLine2);
    }
}

