import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        java.awt.Paint paint5 = renderAttributes1.getItemPaint(192, (int) '4');
        java.awt.Font font7 = null;
        try {
            renderAttributes1.setSeriesLabelFont((int) ' ', font7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        boolean boolean3 = standardGradientPaintTransformer1.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot20.getDomainGridlinePosition();
        categoryPlot20.clearDomainMarkers();
        categoryPlot20.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryPlot20.equals(obj25);
        categoryPlot20.setRangeCrosshairValue((double) '#');
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        java.awt.Color color31 = java.awt.Color.YELLOW;
        barRenderer0.setSeriesOutlinePaint((int) (short) 1, (java.awt.Paint) color31);
        boolean boolean36 = barRenderer0.isItemLabelVisible(1, (int) (byte) 10, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Shape shape39 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = barRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(shape39);
        org.junit.Assert.assertNotNull(legendItemCollection40);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 1, (double) 192, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(valueAxisArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis16.setTickLabelFont(font17);
        boolean boolean19 = categoryAxis16.isVisible();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D14, rectangle2D15, categoryAxis16, valueAxis20, layer21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        float float9 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLowerMargin(0.0d);
        java.lang.String str12 = categoryAxis0.getLabel();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = categoryPlot4.getDatasetRenderingOrder();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot4.setDomainGridlineStroke(stroke7);
        java.awt.geom.GeneralPath generalPath9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.RenderingSource renderingSource11 = null;
        categoryPlot4.select(generalPath9, rectangle2D10, renderingSource11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color13);
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator8);
        boolean boolean12 = lineAndShapeRenderer2.getItemShapeFilled(3, 10);
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot19.getDomainGridlinePosition();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot19.setDomainGridlinePosition(categoryAnchor22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer30.setBaseItemLabelGenerator(categoryItemLabelGenerator41);
        boolean boolean43 = barRenderer30.isDrawBarOutline();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = categoryPlot46.getDatasetRenderingOrder();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot46.setDomainGridlineStroke(stroke49);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot46.select(generalPath51, rectangle2D52, renderingSource53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer30.initialise(graphics2D44, rectangle2D45, categoryPlot46, categoryDataset55, plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis25, categoryDataset26, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState57, rectangle2D58);
        org.jfree.chart.renderer.category.BarRenderer barRenderer60 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer61 = null;
        barRenderer60.setGradientPaintTransformer(gradientPaintTransformer61);
        java.awt.Paint paint66 = barRenderer60.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint68 = barRenderer60.getSeriesOutlinePaint(100);
        categoryPlot19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer60);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
        org.junit.Assert.assertNull(rectangle2D59);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNull(paint68);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (short) -1);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis8.setTickLabelFont(font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.setWeight(0);
        java.awt.Stroke stroke15 = categoryPlot11.getRangeMinorGridlineStroke();
        categoryAxis8.setTickMarkStroke(stroke15);
        float float17 = categoryAxis8.getTickMarkInsideLength();
        java.util.List list18 = categoryPlot0.getCategoriesForAxis(categoryAxis8);
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.lookupSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = barRenderer11.getSelectedItemAttributes();
        java.awt.Shape shape13 = null;
        barRenderer11.setBaseLegendShape(shape13);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer11.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = barRenderer18.getSelectedItemAttributes();
        java.awt.Shape shape21 = barRenderer18.lookupLegendShape((int) 'a');
        java.awt.Font font22 = barRenderer18.getBaseItemLabelFont();
        barRenderer11.setBaseItemLabelFont(font22, false);
        java.awt.Paint paint25 = barRenderer11.getBaseItemLabelPaint();
        java.awt.Paint paint27 = barRenderer11.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke29 = barRenderer11.lookupSeriesStroke(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes32 = barRenderer31.getSelectedItemAttributes();
        java.awt.Shape shape33 = null;
        barRenderer31.setBaseLegendShape(shape33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator36 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer31.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator36);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = barRenderer31.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = null;
        barRenderer31.setBaseItemLabelGenerator(categoryItemLabelGenerator42);
        boolean boolean44 = barRenderer31.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor46 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor46, textAnchor47);
        barRenderer31.setSeriesPositiveItemLabelPosition(2, itemLabelPosition48, true);
        barRenderer11.setSeriesNegativeItemLabelPosition(1, itemLabelPosition48, false);
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition(100, itemLabelPosition48);
        lineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean56 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(renderAttributes12);
        org.junit.Assert.assertNotNull(renderAttributes19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(renderAttributes32);
        org.junit.Assert.assertNull(categoryURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor46);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot2.setDataset(categoryDataset5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape10 = null;
        barRenderer8.setBaseLegendShape(shape10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        barRenderer8.setBaseItemLabelGenerator(categoryItemLabelGenerator12, true);
        barRenderer8.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape18 = barRenderer8.lookupLegendShape((int) (byte) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke21 = defaultDrawingSupplier20.getNextOutlineStroke();
        java.awt.Paint paint22 = defaultDrawingSupplier20.getNextPaint();
        barRenderer8.setLegendTextPaint(0, paint22);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8, false);
        java.awt.Color color27 = java.awt.Color.ORANGE;
        try {
            barRenderer8.setSeriesItemLabelPaint((-12517377), (java.awt.Paint) color27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer0.getToolTipGenerator((int) (short) 100, (int) '4', false);
        java.lang.Object obj16 = null;
        boolean boolean17 = barRenderer0.equals(obj16);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean30 = categoryPlot16.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        categoryPlot16.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.awt.Paint paint19 = barRenderer17.getBasePaint();
        barRenderer0.setSeriesPaint(10, paint19);
        barRenderer0.setItemLabelAnchorOffset((double) 0);
        barRenderer0.setShadowVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator26);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = barRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator28);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int3 = lineAndShapeRenderer2.getPassCount();
        boolean boolean4 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (byte) 0, categoryToolTipGenerator6, true);
        java.awt.Shape shape12 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 4, false);
        try {
            lineAndShapeRenderer2.setItemMargin(4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        int int5 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setUpperMargin((double) '4');
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot14.getDatasetRenderingOrder();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot14.setDomainGridlineStroke(stroke17);
        java.awt.geom.GeneralPath generalPath19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.RenderingSource renderingSource21 = null;
        categoryPlot14.select(generalPath19, rectangle2D20, renderingSource21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot14.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearRangeMarkers();
        boolean boolean27 = categoryPlot25.canSelectByPoint();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot25.removeDomainMarker(2, marker29, layer30);
        categoryPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        double double33 = categoryPlot14.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot14.getRangeAxisEdge((int) ' ');
        try {
            double double36 = categoryAxis0.getCategorySeriesMiddle(0, (int) (byte) 1, (int) (short) 1, 10, (double) '#', rectangle2D13, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3, chartChangeEventType4);
        java.util.List list6 = keyedObjects0.getKeys();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) itemLabelAnchor3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor5, textAnchor6, (double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor9 = itemLabelPosition8.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.ChartColor chartColor17 = new org.jfree.chart.ChartColor((int) ' ', (int) (short) 10, (int) (byte) 100);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            barRenderer0.drawRangeLine(graphics2D9, categoryPlot10, valueAxis11, rectangle2D12, (double) (-1), (java.awt.Paint) chartColor17, stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        java.awt.Font font17 = barRenderer2.getSeriesItemLabelFont(2);
        int int18 = objectList1.indexOf((java.lang.Object) barRenderer2);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(font17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = barRenderer5.getSelectedItemAttributes();
        java.awt.Shape shape7 = null;
        barRenderer5.setBaseLegendShape(shape7);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer5.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer5.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer5.setBaseItemLabelGenerator(categoryItemLabelGenerator16);
        boolean boolean18 = barRenderer5.isDrawBarOutline();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot21.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot21.getDatasetRenderingOrder();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot21.setDomainGridlineStroke(stroke24);
        java.awt.geom.GeneralPath generalPath26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.RenderingSource renderingSource28 = null;
        categoryPlot21.select(generalPath26, rectangle2D27, renderingSource28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = barRenderer5.initialise(graphics2D19, rectangle2D20, categoryPlot21, categoryDataset30, plotRenderingInfo31);
        categoryPlot21.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean35 = categoryPlot21.isRangeCrosshairLockedOnData();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        java.lang.String str37 = categoryAxis0.getLabelToolTip();
        java.lang.String str38 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(renderAttributes6);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(categoryItemRendererState32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke13);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.renderer.category.BarPainter barPainter11 = barRenderer0.getBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter11);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(barPainter11);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot20.getDomainGridlinePosition();
        categoryPlot20.clearDomainMarkers();
        categoryPlot20.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryPlot20.equals(obj25);
        categoryPlot20.setRangeCrosshairValue((double) '#');
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        java.awt.Shape shape31 = barRenderer0.getLegendShape(0);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(shape31);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("DatasetRenderingOrder.REVERSE");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("DatasetRenderingOrder.REVERSE");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.String str5 = unknownKeyException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: DatasetRenderingOrder.REVERSE" + "'", str5.equals("org.jfree.data.UnknownKeyException: DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        categoryPlot2.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot2.removeDomainMarker(marker7);
        java.util.List list10 = null;
        try {
            categoryPlot2.mapDatasetToRangeAxes(10, list10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot20.getDomainGridlinePosition();
        categoryPlot20.clearDomainMarkers();
        categoryPlot20.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryPlot20.equals(obj25);
        categoryPlot20.setRangeCrosshairValue((double) '#');
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        java.awt.Color color31 = java.awt.Color.YELLOW;
        barRenderer0.setSeriesOutlinePaint((int) (short) 1, (java.awt.Paint) color31);
        boolean boolean36 = barRenderer0.isItemLabelVisible(1, (int) (byte) 10, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes39 = barRenderer38.getSelectedItemAttributes();
        java.awt.Shape shape40 = null;
        barRenderer38.setBaseLegendShape(shape40);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator43 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer38.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator43);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator48 = barRenderer38.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator49 = null;
        barRenderer38.setBaseItemLabelGenerator(categoryItemLabelGenerator49);
        boolean boolean51 = barRenderer38.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor53 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor54 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor53, textAnchor54);
        barRenderer38.setSeriesPositiveItemLabelPosition(2, itemLabelPosition55, true);
        barRenderer0.setSeriesPositiveItemLabelPosition(192, itemLabelPosition55);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(renderAttributes39);
        org.junit.Assert.assertNull(categoryURLGenerator48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor53);
        org.junit.Assert.assertNotNull(textAnchor54);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        java.lang.String str9 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) 'a', (java.lang.Boolean) true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        categoryPlot16.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        boolean boolean9 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        java.lang.String str18 = legendItem17.getURLText();
        legendItem17.setShapeVisible(false);
        legendItem17.setSeriesIndex(0);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        double double19 = categoryPlot0.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot0.getRangeAxisEdge((int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot0.zoomDomainAxes((double) (byte) -1, (-35.0d), plotRenderingInfo24, point2D25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot0.panRangeAxes(4.0d, plotRenderingInfo28, point2D29);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        categoryPlot2.clearRangeAxes();
        java.awt.Stroke stroke7 = categoryPlot2.getRangeMinorGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        int int9 = categoryPlot2.indexOf(categoryDataset8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot2.getLegendItems();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint((int) (byte) 10);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        double double18 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.awt.Shape shape22 = null;
        barRenderer20.setBaseLegendShape(shape22);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator25 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer20.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape30 = barRenderer27.lookupLegendShape((int) 'a');
        java.awt.Font font31 = barRenderer27.getBaseItemLabelFont();
        barRenderer20.setBaseItemLabelFont(font31, false);
        java.awt.Paint paint34 = barRenderer20.getBaseItemLabelPaint();
        java.awt.Paint paint36 = barRenderer20.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke38 = barRenderer20.lookupSeriesStroke(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.awt.Shape shape42 = null;
        barRenderer40.setBaseLegendShape(shape42);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer40.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator45);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = barRenderer40.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator51 = null;
        barRenderer40.setBaseItemLabelGenerator(categoryItemLabelGenerator51);
        boolean boolean53 = barRenderer40.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor55 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor55, textAnchor56);
        barRenderer40.setSeriesPositiveItemLabelPosition(2, itemLabelPosition57, true);
        barRenderer20.setSeriesNegativeItemLabelPosition(1, itemLabelPosition57, false);
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 0, itemLabelPosition57, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator64 = null;
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator64);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(categoryURLGenerator50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor55);
        org.junit.Assert.assertNotNull(textAnchor56);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        barRenderer0.setBaseLegendShape(shape11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot15.getDomainGridlinePosition();
        categoryPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.util.ShadowGenerator shadowGenerator18 = null;
        categoryPlot13.setShadowGenerator(shadowGenerator18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot13.getRangeAxis((int) (short) 10);
        categoryPlot13.setRangeCrosshairVisible(false);
        categoryPlot13.setWeight((int) (byte) 1);
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) categoryPlot13, "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape11, "Category Plot", "Category Plot");
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getRowKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem((int) (byte) 0, 0);
        java.awt.Paint paint15 = barRenderer0.getBaseLegendTextPaint();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers();
        categoryPlot17.setAnchorValue((double) (-12517377), true);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        barRenderer0.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis22, marker23, rectangle2D24);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        barRenderer3.setBaseItemLabelFont(font25);
        renderAttributes1.setDefaultLabelFont(font25);
        try {
            java.lang.Boolean boolean31 = renderAttributes1.getSeriesCreateEntity((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        java.awt.Paint paint11 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        java.awt.Paint paint13 = barRenderer0.getLegendTextPaint(0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        java.awt.Stroke stroke18 = barRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarPainter barPainter19 = barRenderer0.getBarPainter();
        java.awt.Shape shape20 = barRenderer0.getBaseShape();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis23.setTickLabelFont(font24);
        double double26 = categoryAxis23.getUpperMargin();
        float float27 = categoryAxis23.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes29 = barRenderer28.getSelectedItemAttributes();
        java.awt.Shape shape30 = null;
        barRenderer28.setBaseLegendShape(shape30);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator33 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer28.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator33);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = barRenderer28.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator39 = null;
        barRenderer28.setBaseItemLabelGenerator(categoryItemLabelGenerator39);
        boolean boolean41 = barRenderer28.isDrawBarOutline();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = categoryPlot44.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder46 = categoryPlot44.getDatasetRenderingOrder();
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot44.setDomainGridlineStroke(stroke47);
        java.awt.geom.GeneralPath generalPath49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.RenderingSource renderingSource51 = null;
        categoryPlot44.select(generalPath49, rectangle2D50, renderingSource51);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = barRenderer28.initialise(graphics2D42, rectangle2D43, categoryPlot44, categoryDataset53, plotRenderingInfo54);
        categoryPlot44.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean58 = categoryPlot44.isRangeCrosshairLockedOnData();
        categoryAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot44);
        java.lang.String str60 = categoryAxis23.getLabelToolTip();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.util.Layer layer62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D21, rectangle2D22, categoryAxis23, valueAxis61, layer62, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(barPainter19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
        org.junit.Assert.assertNotNull(renderAttributes29);
        org.junit.Assert.assertNull(categoryURLGenerator38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categoryAnchor45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(categoryItemRendererState55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(str60);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getAxisOffset();
        double double6 = rectangleInsets4.calculateTopInset((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer0.getToolTipGenerator((int) (byte) 0, (int) ' ', false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        java.lang.Object obj9 = categoryAxis0.clone();
        java.awt.Stroke stroke10 = categoryAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getLabelPaint();
        java.awt.Paint paint19 = null;
        try {
            legendItem17.setFillPaint(paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        barRenderer0.setShadowVisible(true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers();
        categoryPlot17.setWeight(0);
        java.awt.Stroke stroke21 = categoryPlot17.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes25 = barRenderer24.getSelectedItemAttributes();
        java.lang.Boolean boolean27 = barRenderer24.getSeriesVisibleInLegend((-1));
        boolean boolean28 = defaultDrawingSupplier22.equals((java.lang.Object) boolean27);
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, false);
        float float31 = categoryPlot17.getForegroundAlpha();
        boolean boolean32 = categoryPlot17.isDomainPannable();
        categoryPlot17.clearDomainMarkers();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        try {
            barRenderer0.drawOutline(graphics2D16, categoryPlot17, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(renderAttributes25);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int3 = lineAndShapeRenderer2.getPassCount();
        boolean boolean4 = lineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        barRenderer2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint8 = barRenderer2.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint10 = barRenderer2.getSeriesOutlinePaint(100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer2.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color12, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray22 = new float[] { (-1L), 100.0f, (short) 1, (short) -1, 100L, 'a' };
        float[] floatArray23 = color15.getColorComponents(floatArray22);
        float[] floatArray24 = color12.getColorComponents(floatArray23);
        objectList0.set(0, (java.lang.Object) color12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer28.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) false);
        boolean boolean34 = lineAndShapeRenderer28.getItemLineVisible(1, 2);
        boolean boolean35 = lineAndShapeRenderer28.getUseOutlinePaint();
        boolean boolean36 = objectList0.equals((java.lang.Object) boolean35);
        java.lang.Object obj37 = objectList0.clone();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        java.text.AttributedString attributedString23 = legendItem17.getAttributedLabel();
        int int24 = legendItem17.getDatasetIndex();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(attributedString23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        java.awt.Stroke stroke18 = barRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarPainter barPainter19 = barRenderer0.getBarPainter();
        java.awt.Paint paint21 = barRenderer0.lookupLegendTextPaint((int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator22, false);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(barPainter19);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        int int5 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = barRenderer6.getSelectedItemAttributes();
        java.awt.Shape shape8 = null;
        barRenderer6.setBaseLegendShape(shape8);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer6.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator11);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer6.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint18 = barRenderer6.lookupSeriesPaint(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer20.removeAnnotations();
        java.awt.Stroke stroke25 = barRenderer20.getItemStroke(0, 0, true);
        barRenderer6.setSeriesStroke((int) (byte) 1, stroke25, true);
        categoryPlot0.setDomainGridlineStroke(stroke25);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(renderAttributes7);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) false);
        boolean boolean8 = lineAndShapeRenderer2.getItemLineVisible(1, 2);
        boolean boolean11 = lineAndShapeRenderer2.getItemLineVisible(3, (int) (short) 10);
        lineAndShapeRenderer2.setDrawOutlines(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getColumnKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryPlot0.equals(obj5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.panDomainAxes((double) 10, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        legendItem17.setOutlinePaint(paint21);
        java.awt.Stroke stroke23 = legendItem17.getOutlineStroke();
        java.lang.Object obj24 = legendItem17.clone();
        java.awt.Font font25 = legendItem17.getLabelFont();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(font25);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers();
        java.awt.Stroke stroke7 = categoryPlot5.getRangeZeroBaselineStroke();
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke7, false);
        boolean boolean11 = lineAndShapeRenderer2.isSeriesItemLabelsVisible((int) ' ');
        java.lang.Class<?> wildcardClass12 = lineAndShapeRenderer2.getClass();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3, chartChangeEventType4);
        java.lang.Object obj7 = null;
        keyedObjects0.addObject((java.lang.Comparable) (byte) 0, obj7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1L);
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) 10.0d, (java.lang.Comparable) "TextAnchor.HALF_ASCENT_LEFT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (10.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot16.getRangeAxisForDataset((int) ' ');
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot8.getDatasetRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setDomainGridlineStroke(stroke11);
        categoryPlot0.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getAxisOffset();
        double double16 = rectangleInsets14.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-8.0d) + "'", double16 == (-8.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray2);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (short) -1);
        categoryPlot0.configureDomainAxes();
        boolean boolean8 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape7, "java.awt.Color[r=64,g=64,b=64]", "DatasetRenderingOrder.REVERSE");
        java.lang.String str21 = chartEntity20.getURLText();
        java.lang.String str22 = chartEntity20.getShapeType();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str21.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "rect" + "'", str22.equals("rect"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        org.jfree.data.general.Dataset dataset18 = null;
        legendItem17.setDataset(dataset18);
        java.lang.String str20 = legendItem17.getDescription();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{0}" + "'", str20.equals("{0}"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = barRenderer10.getSelectedItemAttributes();
        java.awt.Shape shape13 = barRenderer10.lookupLegendShape((int) 'a');
        java.awt.Font font14 = barRenderer10.getBaseItemLabelFont();
        categoryPlot0.setNoDataMessageFont(font14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint19 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(renderAttributes11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer3.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint15 = barRenderer3.lookupSeriesPaint(0);
        renderAttributes1.setDefaultPaint(paint15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color18 = color17.brighter();
        java.awt.Color color19 = color17.brighter();
        java.awt.Color color20 = color19.brighter();
        renderAttributes1.setDefaultOutlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke4 = renderAttributes1.getSeriesStroke((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis10 };
        categoryPlot6.setDomainAxes(categoryAxisArray11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot6.zoomRangeAxes((double) 0, plotRenderingInfo14, point2D15, true);
        boolean boolean18 = categoryPlot6.isRangeGridlinesVisible();
        java.util.List list19 = categoryPlot6.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearRangeMarkers();
        java.awt.Stroke stroke22 = categoryPlot20.getRangeZeroBaselineStroke();
        categoryPlot6.setRangeMinorGridlineStroke(stroke22);
        renderAttributes1.setSeriesStroke((int) (byte) 1, stroke22);
        try {
            java.awt.Paint paint26 = renderAttributes1.getSeriesLabelPaint((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        float[] floatArray7 = new float[] { (-1.0f), 1.0f, '4' };
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) (short) 1, 1, (int) ' ', floatArray7);
        try {
            float[] floatArray9 = color0.getComponents(floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.lookupSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        barRenderer10.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator12, false);
        java.awt.Color color16 = java.awt.Color.pink;
        barRenderer10.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color16);
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(2, marker4, layer5);
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent7 = null;
        categoryPlot0.annotationChanged(annotationChangeEvent7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer9.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator15, false);
        java.awt.Stroke stroke18 = barRenderer9.getBaseStroke();
        renderAttributes1.setSeriesStroke((int) (short) 100, stroke18);
        java.awt.Stroke stroke20 = null;
        try {
            renderAttributes1.setDefaultStroke(stroke20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = plotChangeEvent4.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        int int5 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot0.handleClick((int) (short) 1, 0, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.ASCENDING" + "'", str2.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = barRenderer13.getSelectedItemAttributes();
        java.awt.Shape shape15 = null;
        barRenderer13.setBaseLegendShape(shape15);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer13.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.awt.Shape shape23 = barRenderer20.lookupLegendShape((int) 'a');
        java.awt.Font font24 = barRenderer20.getBaseItemLabelFont();
        barRenderer13.setBaseItemLabelFont(font24, false);
        java.awt.Paint paint27 = barRenderer13.getBaseItemLabelPaint();
        java.awt.Paint paint29 = barRenderer13.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke31 = barRenderer13.lookupSeriesStroke(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes34 = barRenderer33.getSelectedItemAttributes();
        java.awt.Shape shape35 = null;
        barRenderer33.setBaseLegendShape(shape35);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer33.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator43 = barRenderer33.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator44 = null;
        barRenderer33.setBaseItemLabelGenerator(categoryItemLabelGenerator44);
        boolean boolean46 = barRenderer33.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor48, textAnchor49);
        barRenderer33.setSeriesPositiveItemLabelPosition(2, itemLabelPosition50, true);
        barRenderer13.setSeriesNegativeItemLabelPosition(1, itemLabelPosition50, false);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition50);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(renderAttributes14);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(renderAttributes34);
        org.junit.Assert.assertNull(categoryURLGenerator43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
        org.junit.Assert.assertNotNull(textAnchor49);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        categoryAxis0.setMinorTickMarkOutsideLength((float) (byte) 10);
        boolean boolean11 = categoryAxis0.isTickLabelsVisible();
        java.lang.String str13 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "DatasetRenderingOrder.REVERSE");
        float float14 = categoryAxis0.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 10.0f + "'", float14 == 10.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.String str2 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str2.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation11);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        try {
            lineAndShapeRenderer2.setItemMargin((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot6.getDomainGridlinePosition();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape17 = barRenderer14.lookupLegendShape((int) 'a');
        java.awt.Font font18 = barRenderer14.getBaseItemLabelFont();
        categoryPlot4.setNoDataMessageFont(font18);
        barRenderer0.setBaseItemLabelFont(font18);
        double double21 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getAxisOffset();
        double double6 = rectangleInsets4.calculateTopOutset((double) (-20561));
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        double double18 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.awt.Shape shape22 = null;
        barRenderer20.setBaseLegendShape(shape22);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator25 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer20.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape30 = barRenderer27.lookupLegendShape((int) 'a');
        java.awt.Font font31 = barRenderer27.getBaseItemLabelFont();
        barRenderer20.setBaseItemLabelFont(font31, false);
        java.awt.Paint paint34 = barRenderer20.getBaseItemLabelPaint();
        java.awt.Paint paint36 = barRenderer20.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke38 = barRenderer20.lookupSeriesStroke(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.awt.Shape shape42 = null;
        barRenderer40.setBaseLegendShape(shape42);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer40.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator45);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = barRenderer40.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator51 = null;
        barRenderer40.setBaseItemLabelGenerator(categoryItemLabelGenerator51);
        boolean boolean53 = barRenderer40.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor55 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor55, textAnchor56);
        barRenderer40.setSeriesPositiveItemLabelPosition(2, itemLabelPosition57, true);
        barRenderer20.setSeriesNegativeItemLabelPosition(1, itemLabelPosition57, false);
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 0, itemLabelPosition57, false);
        org.jfree.chart.text.TextAnchor textAnchor64 = itemLabelPosition57.getTextAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor65 = itemLabelPosition57.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(categoryURLGenerator50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor55);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertNotNull(textAnchor64);
        org.junit.Assert.assertNotNull(itemLabelAnchor65);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) itemLabelAnchor3);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (0.2) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        categoryPlot0.setAnchorValue((-35.0d), true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int2 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getRowKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        legendItem17.setDescription("rect");
        java.awt.Shape shape25 = legendItem17.getLine();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearRangeMarkers();
        categoryPlot10.setWeight(0);
        java.awt.Stroke stroke14 = categoryPlot10.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.lang.Boolean boolean20 = barRenderer17.getSeriesVisibleInLegend((-1));
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) boolean20);
        categoryPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15, false);
        java.awt.Paint paint24 = defaultDrawingSupplier15.getNextPaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(collection27);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        int int13 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        int int6 = categoryPlot0.getRendererCount();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset();
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        boolean boolean10 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.removeAnnotations();
        java.awt.Stroke stroke19 = barRenderer14.getItemStroke(0, 0, true);
        barRenderer0.setSeriesStroke((int) (byte) 1, stroke19, true);
        java.awt.Paint paint25 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (short) 0, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        boolean boolean30 = barRenderer0.getItemVisible(100, (int) (short) 1);
        boolean boolean31 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem((int) (byte) 0, 0);
        java.awt.Shape shape16 = barRenderer0.lookupSeriesShape((int) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        categoryPlot17.clearDomainMarkers();
        categoryPlot17.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot17.getDomainAxis((int) (short) -1);
        categoryPlot17.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation28 = axisLocation27.getOpposite();
        categoryPlot17.setDomainAxisLocation((int) (short) 0, axisLocation28);
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) categoryPlot17);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke4 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        categoryAxis0.setMinorTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor11, (int) (byte) 10, 0, rectangle2D14, rectangleEdge15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers();
        categoryPlot1.setWeight(0);
        java.awt.Stroke stroke5 = categoryPlot1.getRangeMinorGridlineStroke();
        java.lang.String str6 = categoryPlot1.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot1.getRangeAxis();
        boolean boolean8 = defaultShadowGenerator0.equals((java.lang.Object) valueAxis7);
        int int9 = defaultShadowGenerator0.getShadowSize();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        java.awt.Image image6 = categoryPlot2.getBackgroundImage();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot2.addDomainMarker(192, categoryMarker8, layer9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        double double19 = categoryPlot0.getAnchorValue();
        double double20 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        barRenderer3.setBaseItemLabelFont(font25);
        renderAttributes1.setDefaultLabelFont(font25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint42 = barRenderer30.lookupSeriesPaint(0);
        java.awt.Stroke stroke46 = barRenderer30.getItemOutlineStroke(0, 0, false);
        renderAttributes1.setDefaultOutlineStroke(stroke46);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot19.getDomainGridlinePosition();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot19.setDomainGridlinePosition(categoryAnchor22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer30.setBaseItemLabelGenerator(categoryItemLabelGenerator41);
        boolean boolean43 = barRenderer30.isDrawBarOutline();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = categoryPlot46.getDatasetRenderingOrder();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot46.setDomainGridlineStroke(stroke49);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot46.select(generalPath51, rectangle2D52, renderingSource53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer30.initialise(graphics2D44, rectangle2D45, categoryPlot46, categoryDataset55, plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis25, categoryDataset26, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState57, rectangle2D58);
        org.jfree.chart.renderer.category.BarRenderer barRenderer61 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes62 = barRenderer61.getSelectedItemAttributes();
        java.awt.Shape shape63 = null;
        barRenderer61.setBaseLegendShape(shape63);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator66 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer61.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator66);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator71 = barRenderer61.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint73 = barRenderer61.lookupSeriesPaint(0);
        barRenderer0.setLegendTextPaint(100, paint73);
        java.awt.Color color75 = java.awt.Color.orange;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color75);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition77 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator81 = barRenderer0.getItemLabelGenerator((-20561), (int) ' ', true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
        org.junit.Assert.assertNull(rectangle2D59);
        org.junit.Assert.assertNotNull(renderAttributes62);
        org.junit.Assert.assertNull(categoryURLGenerator71);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(itemLabelPosition77);
        org.junit.Assert.assertNull(categoryItemLabelGenerator81);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        java.awt.Font font27 = barRenderer23.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        barRenderer23.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator29, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        barRenderer23.setBaseShape(shape35);
        legendItem17.setShape(shape35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.lang.Boolean boolean43 = barRenderer40.getSeriesVisibleInLegend((-1));
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) boolean43);
        java.awt.Paint paint45 = defaultDrawingSupplier38.getNextPaint();
        legendItem17.setFillPaint(paint45);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes48 = barRenderer47.getSelectedItemAttributes();
        java.lang.Boolean boolean49 = renderAttributes48.getDefaultCreateEntity();
        java.awt.Paint paint51 = renderAttributes48.getSeriesFillPaint(2);
        java.awt.Paint paint54 = renderAttributes48.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes57 = barRenderer56.getSelectedItemAttributes();
        java.awt.Shape shape59 = barRenderer56.lookupLegendShape((int) 'a');
        java.awt.Font font60 = barRenderer56.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        barRenderer56.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator62, false);
        java.awt.Stroke stroke65 = barRenderer56.getBaseStroke();
        renderAttributes48.setSeriesStroke((int) (short) 100, stroke65);
        boolean boolean67 = legendItem17.equals((java.lang.Object) (short) 100);
        org.jfree.chart.util.UnitType unitType68 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Shape shape69 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        boolean boolean70 = unitType68.equals((java.lang.Object) shape69);
        legendItem17.setLine(shape69);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer72 = legendItem17.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(renderAttributes48);
        org.junit.Assert.assertNull(boolean49);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(renderAttributes57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(unitType68);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer72);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        try {
            int int4 = categoryPlot0.getRangeAxisIndex(valueAxis3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot8.getDatasetRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setDomainGridlineStroke(stroke11);
        categoryPlot0.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getAxisOffset();
        java.lang.String str15 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean30 = categoryPlot16.isRangeCrosshairLockedOnData();
        categoryPlot16.setRangePannable(false);
        boolean boolean33 = categoryPlot16.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.data.general.DatasetGroup datasetGroup19 = categoryPlot11.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            categoryPlot11.setDomainAxisLocation((-12517377), axisLocation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(datasetGroup19);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot0.clearDomainMarkers();
        java.awt.Paint paint9 = categoryPlot0.getBackgroundPaint();
        int int10 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Paint paint15 = barRenderer12.getBasePaint();
        try {
            categoryPlot0.setRenderer((int) (byte) -1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        java.awt.Paint paint11 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        java.awt.Font font14 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 100, categoryURLGenerator16, true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot9.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator11 = null;
        categoryPlot9.setShadowGenerator(shadowGenerator11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getInsets();
        categoryAxis0.setLabelInsets(rectangleInsets13, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray22 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis21 };
        categoryPlot17.setDomainAxes(categoryAxisArray22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot17.zoomRangeAxes((double) 0, plotRenderingInfo25, point2D26, true);
        boolean boolean29 = categoryPlot17.isRangeGridlinesVisible();
        java.util.List list30 = categoryPlot17.getAnnotations();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.clearRangeMarkers();
        categoryPlot32.setAnchorValue((double) (-12517377), true);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot32.getRangeAxisEdge();
        try {
            double double38 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) 10L, list30, rectangle2D31, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(categoryAxisArray22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        java.lang.Boolean boolean6 = lineAndShapeRenderer2.getSeriesShapesFilled(1);
        java.lang.Boolean boolean8 = lineAndShapeRenderer2.getSeriesCreateEntities((int) (short) 0);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(datasetGroup6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        try {
            keyedObjects2D0.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation12, false);
        categoryPlot0.mapDatasetToDomainAxis((int) '#', (int) (short) 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer(2);
        java.lang.Object obj7 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot11.getDomainGridlinePosition();
        categoryPlot9.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo16, point2D17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = barRenderer19.getSelectedItemAttributes();
        java.awt.Shape shape22 = barRenderer19.lookupLegendShape((int) 'a');
        java.awt.Font font23 = barRenderer19.getBaseItemLabelFont();
        categoryPlot9.setNoDataMessageFont(font23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(axisLocation25, false);
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation25);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(renderAttributes20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Stroke stroke7 = barRenderer0.getItemOutlineStroke(0, (int) (short) -1, false);
        java.awt.Stroke stroke11 = barRenderer0.getItemOutlineStroke((int) (short) -1, (-1), false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        categoryPlot12.setWeight(0);
        java.awt.Stroke stroke16 = categoryPlot12.getRangeMinorGridlineStroke();
        categoryPlot12.setDomainCrosshairVisible(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot12.addChangeListener(plotChangeListener19);
        java.awt.Stroke stroke21 = categoryPlot12.getRangeCrosshairStroke();
        barRenderer0.setBaseOutlineStroke(stroke21);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        java.awt.Stroke stroke18 = barRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarPainter barPainter19 = barRenderer0.getBarPainter();
        java.awt.Paint paint21 = barRenderer0.lookupLegendTextPaint((int) (short) 10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor22, textAnchor23);
        double double25 = itemLabelPosition24.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor26 = itemLabelPosition24.getItemLabelAnchor();
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape29 = null;
        barRenderer27.setBaseLegendShape(shape29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor34 = categoryPlot33.getDomainGridlinePosition();
        categoryPlot31.setParent((org.jfree.chart.plot.Plot) categoryPlot33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot31.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo38, point2D39);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes42 = barRenderer41.getSelectedItemAttributes();
        java.awt.Shape shape44 = barRenderer41.lookupLegendShape((int) 'a');
        java.awt.Font font45 = barRenderer41.getBaseItemLabelFont();
        categoryPlot31.setNoDataMessageFont(font45);
        barRenderer27.setBaseItemLabelFont(font45);
        boolean boolean48 = itemLabelPosition24.equals((java.lang.Object) font45);
        barRenderer0.setBaseLegendTextFont(font45);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(barPainter19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor26);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(categoryAnchor34);
        org.junit.Assert.assertNotNull(renderAttributes42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        barRenderer3.setBaseItemLabelFont(font25);
        renderAttributes1.setDefaultLabelFont(font25);
        java.lang.Boolean boolean30 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint32 = renderAttributes1.getSeriesFillPaint((-20561));
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        java.awt.Font font9 = categoryAxis0.getLabelFont();
        boolean boolean10 = categoryAxis0.isTickMarksVisible();
        java.lang.String str11 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer9.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator15, false);
        java.awt.Stroke stroke18 = barRenderer9.getBaseStroke();
        renderAttributes1.setSeriesStroke((int) (short) 100, stroke18);
        java.awt.Shape shape20 = renderAttributes1.getDefaultShape();
        java.awt.Paint paint22 = renderAttributes1.getSeriesFillPaint(0);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryPlot0.equals(obj5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot0.setRangeAxis((int) '#', valueAxis12, false);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace1, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getAxisOffset();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape6 = null;
        barRenderer4.setBaseLegendShape(shape6);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = barRenderer11.getSelectedItemAttributes();
        java.awt.Shape shape14 = barRenderer11.lookupLegendShape((int) 'a');
        java.awt.Font font15 = barRenderer11.getBaseItemLabelFont();
        barRenderer4.setBaseItemLabelFont(font15, false);
        java.awt.Paint paint18 = barRenderer4.getBaseItemLabelPaint();
        barRenderer4.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Paint paint23 = barRenderer21.getBasePaint();
        barRenderer4.setSeriesPaint(10, paint23);
        barRenderer4.setItemLabelAnchorOffset((double) 0);
        java.awt.Paint paint30 = barRenderer4.getItemFillPaint((-12517377), (int) (short) -1, false);
        paintList0.setPaint(0, paint30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis32.setTickLabelFont(font33);
        double double35 = categoryAxis32.getUpperMargin();
        float float36 = categoryAxis32.getTickMarkOutsideLength();
        int int37 = categoryAxis32.getCategoryLabelPositionOffset();
        categoryAxis32.setUpperMargin((double) '4');
        boolean boolean40 = paintList0.equals((java.lang.Object) categoryAxis32);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(renderAttributes12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 2.0f + "'", float36 == 2.0f);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        java.util.List list3 = keyedObjects0.getKeys();
        java.util.List list4 = keyedObjects0.getKeys();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape9 = null;
        barRenderer7.setBaseLegendShape(shape9);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator12 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer7.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator12);
        java.awt.Color color15 = java.awt.Color.RED;
        barRenderer7.setSeriesFillPaint(0, (java.awt.Paint) color15);
        try {
            keyedObjects0.insertValue((int) (short) 10, (java.lang.Comparable) '4', (java.lang.Object) barRenderer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.data.UnknownKeyException: DatasetRenderingOrder.REVERSE", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.plot.Plot plot5 = categoryAxis0.getPlot();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = barRenderer6.getSelectedItemAttributes();
        java.awt.Shape shape8 = null;
        barRenderer6.setBaseLegendShape(shape8);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer6.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = barRenderer13.getSelectedItemAttributes();
        java.awt.Shape shape16 = barRenderer13.lookupLegendShape((int) 'a');
        java.awt.Font font17 = barRenderer13.getBaseItemLabelFont();
        barRenderer6.setBaseItemLabelFont(font17, false);
        barRenderer4.setLegendTextFont((int) '4', font17);
        java.awt.Stroke stroke22 = barRenderer4.getSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarPainter barPainter23 = barRenderer4.getBarPainter();
        java.awt.Shape shape24 = barRenderer4.getBaseShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes27 = barRenderer26.getSelectedItemAttributes();
        java.awt.Shape shape29 = barRenderer26.lookupLegendShape((int) 'a');
        java.awt.Font font30 = barRenderer26.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = null;
        barRenderer26.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator32, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes36 = barRenderer35.getSelectedItemAttributes();
        java.awt.Shape shape38 = barRenderer35.lookupLegendShape((int) 'a');
        barRenderer26.setBaseShape(shape38);
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity(shape38, "", "DatasetRenderingOrder.REVERSE");
        barRenderer4.setSeriesShape((int) (short) 100, shape38, true);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes47 = barRenderer46.getSelectedItemAttributes();
        java.lang.Boolean boolean48 = renderAttributes47.getDefaultCreateEntity();
        java.awt.Paint paint50 = renderAttributes47.getSeriesFillPaint(2);
        java.awt.Paint paint53 = renderAttributes47.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes56 = barRenderer55.getSelectedItemAttributes();
        java.awt.Font font57 = renderAttributes56.getDefaultLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes59 = barRenderer58.getSelectedItemAttributes();
        java.awt.Shape shape60 = null;
        barRenderer58.setBaseLegendShape(shape60);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator63 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer58.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator63);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator68 = barRenderer58.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint70 = barRenderer58.lookupSeriesPaint(0);
        renderAttributes56.setDefaultPaint(paint70);
        renderAttributes47.setSeriesPaint((int) '4', paint70);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot74.clearRangeMarkers();
        categoryPlot74.setWeight(0);
        java.awt.Stroke stroke78 = categoryPlot74.getRangeMinorGridlineStroke();
        java.awt.Stroke stroke79 = categoryPlot74.getRangeCrosshairStroke();
        renderAttributes47.setSeriesStroke(4, stroke79);
        java.awt.Paint paint81 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=64,g=64,b=64]", "UnitType.ABSOLUTE", "", shape38, (java.awt.Paint) color45, stroke79, paint81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes7);
        org.junit.Assert.assertNotNull(renderAttributes14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(barPainter23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(renderAttributes27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(renderAttributes36);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(renderAttributes47);
        org.junit.Assert.assertNull(boolean48);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(renderAttributes56);
        org.junit.Assert.assertNull(font57);
        org.junit.Assert.assertNotNull(renderAttributes59);
        org.junit.Assert.assertNull(categoryURLGenerator68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(paint81);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2);
        double double4 = itemLabelPosition3.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition3.getTextAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = barRenderer0.getURLGenerator((int) (byte) 100, (int) 'a', true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, (java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=64,b=64]");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape7, "java.awt.Color[r=64,g=64,b=64]", "DatasetRenderingOrder.REVERSE");
        chartEntity20.setURLText("hi!");
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (100) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(categoryAxis2);
        int int4 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = barRenderer6.getSelectedItemAttributes();
        java.awt.Shape shape9 = barRenderer6.lookupLegendShape((int) 'a');
        java.awt.Font font10 = barRenderer6.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        barRenderer6.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator12, false);
        java.awt.Stroke stroke15 = barRenderer6.getBaseStroke();
        boolean boolean16 = lineAndShapeRenderer2.equals((java.lang.Object) barRenderer6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(renderAttributes7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.lang.Boolean boolean10 = barRenderer7.getSeriesVisibleInLegend((-1));
        boolean boolean11 = defaultDrawingSupplier5.equals((java.lang.Object) boolean10);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier5, false);
        categoryPlot0.mapDatasetToRangeAxis(10, 5);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        categoryAxis0.setCategoryMargin((double) 100L);
        categoryAxis0.setVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers();
        categoryPlot13.setWeight(0);
        java.awt.Stroke stroke17 = categoryPlot13.getRangeMinorGridlineStroke();
        categoryPlot13.setNotify(false);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot13.setNoDataMessageFont(font20);
        categoryAxis0.setTickLabelFont(font20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        float float9 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLowerMargin(0.0d);
        int int12 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot6.setDomainGridlineStroke(stroke9);
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        categoryPlot6.select(generalPath11, rectangle2D12, renderingSource13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers();
        boolean boolean19 = categoryPlot17.canSelectByPoint();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot17.removeDomainMarker(2, marker21, layer22);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot17);
        double double25 = categoryPlot6.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot6.getRangeAxisEdge((int) ' ');
        try {
            double double28 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) ' ', (java.lang.Comparable) 1L, categoryDataset3, (-8.0d), rectangle2D5, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        boolean boolean7 = categoryPlot0.removeDomainMarker(1, marker5, layer6);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = barRenderer1.getSelectedItemAttributes();
        java.awt.Shape shape3 = null;
        barRenderer1.setBaseLegendShape(shape3);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer1.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        java.awt.Font font12 = barRenderer8.getBaseItemLabelFont();
        barRenderer1.setBaseItemLabelFont(font12, false);
        java.awt.Font font16 = barRenderer1.getSeriesItemLabelFont(2);
        boolean boolean17 = booleanList0.equals((java.lang.Object) font16);
        booleanList0.setBoolean(3, (java.lang.Boolean) false);
        java.lang.Boolean boolean22 = booleanList0.getBoolean(192);
        org.junit.Assert.assertNotNull(renderAttributes2);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(boolean22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesPaint(1);
        java.lang.Boolean boolean5 = renderAttributes1.getDefaultLabelVisible();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        int int6 = categoryPlot0.getRendererCount();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset();
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        barRenderer10.setGradientPaintTransformer(gradientPaintTransformer11);
        barRenderer10.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.awt.Shape shape23 = barRenderer20.lookupLegendShape((int) 'a');
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color25 = color24.brighter();
        java.awt.Color color26 = color25.darker();
        java.awt.Color color27 = color25.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.clearRangeMarkers();
        java.awt.Stroke stroke30 = categoryPlot28.getRangeZeroBaselineStroke();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color32 = color31.brighter();
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape23, (java.awt.Paint) color25, stroke30, (java.awt.Paint) color32);
        boolean boolean34 = legendItem33.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextOutlineStroke();
        java.awt.Paint paint37 = defaultDrawingSupplier35.getNextPaint();
        legendItem33.setOutlinePaint(paint37);
        barRenderer10.setBaseOutlinePaint(paint37);
        categoryPlot0.setNoDataMessagePaint(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.ShadowGenerator shadowGenerator13 = categoryPlot0.getShadowGenerator();
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.setNoDataMessage("");
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(shadowGenerator13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation11, true);
        boolean boolean14 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        legendItem17.setLineVisible(true);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        java.util.List list11 = categoryPlot0.getCategoriesForAxis(categoryAxis10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis13.setTickLabelFont(font14);
        double double16 = categoryAxis13.getUpperMargin();
        float float17 = categoryAxis13.getTickMarkOutsideLength();
        int int18 = categoryAxis13.getCategoryLabelPositionOffset();
        float float19 = categoryAxis13.getMinorTickMarkInsideLength();
        categoryPlot0.setDomainAxis(2, categoryAxis13, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot0.setRenderer(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        java.lang.String str5 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            categoryPlot0.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        boolean boolean12 = barRenderer0.getItemCreateEntity(3, (int) (byte) 1, true);
        try {
            barRenderer0.setSeriesCreateEntities((-1), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator8);
        boolean boolean12 = lineAndShapeRenderer2.getItemShapeFilled(3, 10);
        java.lang.Boolean boolean14 = lineAndShapeRenderer2.getSeriesShapesFilled(100);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot8.getDatasetRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setDomainGridlineStroke(stroke11);
        categoryPlot0.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getAxisOffset();
        double double16 = rectangleInsets14.extendHeight(1.0d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 9.0d + "'", double16 == 9.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesPaint(1);
        java.awt.Paint paint7 = renderAttributes1.getItemFillPaint((int) (byte) 1, (int) (byte) 100);
        java.awt.Paint paint8 = renderAttributes1.getDefaultFillPaint();
        java.awt.Font font10 = null;
        try {
            renderAttributes1.setSeriesLabelFont(2, font10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer11.setBaseShapesVisible(true);
        boolean boolean14 = lineAndShapeRenderer11.getDrawOutlines();
        lineAndShapeRenderer11.setBaseShapesVisible(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = barRenderer18.getSelectedItemAttributes();
        java.awt.Shape shape21 = barRenderer18.lookupLegendShape((int) 'a');
        java.awt.Font font22 = barRenderer18.getBaseItemLabelFont();
        lineAndShapeRenderer11.setSeriesItemLabelFont(0, font22, false);
        categoryAxis0.setLabelFont(font22);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(renderAttributes19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation(15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        java.awt.Image image6 = categoryPlot2.getBackgroundImage();
        float float7 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot2.panRangeAxes((double) 0, plotRenderingInfo9, point2D10);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot6.setDomainGridlineStroke(stroke9);
        lineAndShapeRenderer2.setSeriesOutlineStroke(0, stroke9);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str3 = plotOrientation2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation1, plotOrientation2);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str3.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = categoryPlot3.getDomainGridlinePosition();
        categoryPlot1.setParent((org.jfree.chart.plot.Plot) categoryPlot3);
        java.awt.Font font6 = categoryPlot1.getNoDataMessageFont();
        categoryPlot1.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot1.clearDomainMarkers();
        categoryPlot1.clearDomainAxes();
        categoryPlot1.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder13 = org.jfree.chart.util.SortOrder.ASCENDING;
        boolean boolean15 = sortOrder13.equals((java.lang.Object) 100);
        categoryPlot1.setColumnRenderingOrder(sortOrder13);
        boolean boolean17 = plotOrientation0.equals((java.lang.Object) categoryPlot1);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects0, jFreeChart3, chartChangeEventType4);
        java.lang.Object obj6 = chartChangeEvent5.getSource();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        chartChangeEvent5.setChart(jFreeChart7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean15 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = categoryPlot18.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator20 = null;
        categoryPlot18.setShadowGenerator(shadowGenerator20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot18.getInsets();
        java.awt.Paint paint23 = categoryPlot18.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = barRenderer0.initialise(graphics2D16, rectangle2D17, categoryPlot18, categoryDataset24, plotRenderingInfo25);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(categoryItemRendererState26);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color1 = defaultShadowGenerator0.getShadowColor();
        java.awt.Color color2 = defaultShadowGenerator0.getShadowColor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        categoryPlot0.setDomainCrosshairVisible(false);
        boolean boolean7 = categoryPlot0.isRangeMinorGridlinesVisible();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer0.getSeriesToolTipGenerator(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot15.getDatasetRenderingOrder();
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot15.setDomainGridlineStroke(stroke18);
        java.awt.geom.GeneralPath generalPath20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.RenderingSource renderingSource22 = null;
        categoryPlot15.select(generalPath20, rectangle2D21, renderingSource22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot15.setDomainGridlinePaint((java.awt.Paint) color24);
        int int26 = color24.getRGB();
        barRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-12517377) + "'", int26 == (-12517377));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        boolean boolean4 = categoryPlot0.isNotify();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        barRenderer0.setShadowVisible(false);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesStroke(15, stroke10, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        legendItem17.setOutlinePaint(paint21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendItem17.setLinePaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray7 = new float[] { (-1L), 100.0f, (short) 1, (short) -1, 100L, 'a' };
        float[] floatArray8 = color0.getColorComponents(floatArray7);
        java.awt.Color color9 = java.awt.Color.black;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = categoryPlot12.getDomainGridlinePosition();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Font font15 = categoryPlot10.getNoDataMessageFont();
        categoryPlot10.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot10.clearDomainMarkers();
        java.awt.Paint paint19 = categoryPlot10.getBackgroundPaint();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color21 = color20.brighter();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color0, color9, paint19, color21, color22, color23 };
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes27 = barRenderer26.getSelectedItemAttributes();
        java.awt.Font font28 = renderAttributes27.getDefaultLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes30 = barRenderer29.getSelectedItemAttributes();
        java.awt.Shape shape31 = null;
        barRenderer29.setBaseLegendShape(shape31);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer29.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator34);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator39 = barRenderer29.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint41 = barRenderer29.lookupSeriesPaint(0);
        renderAttributes27.setDefaultPaint(paint41);
        java.awt.Color color43 = java.awt.Color.orange;
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray52 = new float[] { (-1L), 100.0f, (short) 1, (short) -1, 100L, 'a' };
        float[] floatArray53 = color45.getColorComponents(floatArray52);
        java.awt.Paint[] paintArray54 = new java.awt.Paint[] { paint25, paint41, color43, color44, color45 };
        java.awt.Color color55 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes57 = barRenderer56.getSelectedItemAttributes();
        java.awt.Shape shape58 = null;
        barRenderer56.setBaseLegendShape(shape58);
        java.awt.Font font61 = barRenderer56.lookupLegendTextFont(0);
        boolean boolean65 = barRenderer56.getItemCreateEntity((int) '4', 10, false);
        java.awt.Paint paint67 = barRenderer56.lookupSeriesOutlinePaint((int) (short) 1);
        java.awt.Color color68 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color69 = java.awt.Color.YELLOW;
        java.awt.Color color70 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color71 = java.awt.Color.orange;
        java.awt.Paint[] paintArray72 = new java.awt.Paint[] { color55, paint67, color68, color69, color70, color71 };
        java.awt.Stroke[] strokeArray73 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray74 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray75 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier76 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray54, paintArray72, strokeArray73, strokeArray74, shapeArray75);
        java.awt.Paint paint77 = defaultDrawingSupplier76.getNextFillPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(renderAttributes27);
        org.junit.Assert.assertNull(font28);
        org.junit.Assert.assertNotNull(renderAttributes30);
        org.junit.Assert.assertNull(categoryURLGenerator39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(paintArray54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(renderAttributes57);
        org.junit.Assert.assertNull(font61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(paintArray72);
        org.junit.Assert.assertNotNull(strokeArray73);
        org.junit.Assert.assertNotNull(strokeArray74);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot9.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator11 = null;
        categoryPlot9.setShadowGenerator(shadowGenerator11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getInsets();
        categoryAxis0.setLabelInsets(rectangleInsets13, false);
        java.lang.String str17 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        double double18 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        keyedObjects2D0.setObject((java.lang.Object) stroke1, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 1L);
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) (byte) 100);
        java.lang.Object obj7 = keyedObjects2D0.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape10 = null;
        barRenderer8.setBaseLegendShape(shape10);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer8.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer8.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        barRenderer8.setBaseItemLabelGenerator(categoryItemLabelGenerator19);
        boolean boolean21 = barRenderer8.isDrawBarOutline();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot24.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot24.getDatasetRenderingOrder();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot24.setDomainGridlineStroke(stroke27);
        java.awt.geom.GeneralPath generalPath29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.RenderingSource renderingSource31 = null;
        categoryPlot24.select(generalPath29, rectangle2D30, renderingSource31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = barRenderer8.initialise(graphics2D22, rectangle2D23, categoryPlot24, categoryDataset33, plotRenderingInfo34);
        categoryPlot24.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean38 = categoryPlot24.isRangeCrosshairLockedOnData();
        categoryPlot24.setRangePannable(false);
        keyedObjects2D0.addObject((java.lang.Object) false, (java.lang.Comparable) 0.0f, (java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(categoryItemRendererState35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        barRenderer0.setBaseLegendShape(shape11);
        boolean boolean14 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = null;
        barRenderer15.setGradientPaintTransformer(gradientPaintTransformer16);
        barRenderer15.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer15.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator23 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        barRenderer15.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator23);
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer5.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator7, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer5.setBaseURLGenerator(categoryURLGenerator10, false);
        int int13 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        legendItem17.setOutlinePaint(paint21);
        legendItem17.setToolTipText("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray7 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis6 };
        categoryPlot0.setDomainAxes(categoryAxisArray7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.panDomainAxes((double) (-20561), plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(categoryAxisArray7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        java.util.List list2 = keyedObjects2D0.getRowKeys();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("rect");
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape11 = null;
        barRenderer9.setBaseLegendShape(shape11);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer9.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = barRenderer16.getSelectedItemAttributes();
        java.awt.Shape shape19 = barRenderer16.lookupLegendShape((int) 'a');
        java.awt.Font font20 = barRenderer16.getBaseItemLabelFont();
        barRenderer9.setBaseItemLabelFont(font20, false);
        java.awt.Paint paint23 = barRenderer9.getBaseItemLabelPaint();
        java.awt.Paint paint25 = barRenderer9.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke27 = barRenderer9.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer28 = null;
        barRenderer9.setGradientPaintTransformer(gradientPaintTransformer28);
        java.awt.Paint paint33 = barRenderer9.getItemFillPaint((int) (byte) 0, 0, false);
        java.awt.Shape shape35 = barRenderer9.getLegendShape((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer9.getPositiveItemLabelPositionFallback();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer9);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        int int39 = categoryPlot0.indexOf(categoryDataset38);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(renderAttributes17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(shape35);
        org.junit.Assert.assertNull(itemLabelPosition36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator6 = null;
        categoryPlot4.setShadowGenerator(shadowGenerator6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        java.awt.Paint paint9 = categoryPlot4.getDomainGridlinePaint();
        categoryPlot0.setRangeGridlinePaint(paint9);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint1 = renderAttributes0.getDefaultOutlinePaint();
        java.awt.Paint paint2 = renderAttributes0.getDefaultOutlinePaint();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int3 = lineAndShapeRenderer2.getPassCount();
        boolean boolean6 = lineAndShapeRenderer2.getItemLineVisible((int) (byte) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        categoryAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        legendItem17.setLineVisible(false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color21 = color20.brighter();
        java.awt.Color color22 = color20.brighter();
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.AffineTransform affineTransform26 = null;
        java.awt.RenderingHints renderingHints27 = null;
        java.awt.PaintContext paintContext28 = color20.createContext(colorModel23, rectangle24, rectangle2D25, affineTransform26, renderingHints27);
        legendItem17.setOutlinePaint((java.awt.Paint) color20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer32.setBaseShapesVisible(true);
        boolean boolean35 = lineAndShapeRenderer32.getDrawOutlines();
        lineAndShapeRenderer32.setBaseShapesVisible(false);
        boolean boolean38 = lineAndShapeRenderer32.getDrawOutlines();
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_YELLOW;
        lineAndShapeRenderer32.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color40);
        legendItem17.setFillPaint((java.awt.Paint) color40);
        int int43 = color40.getAlpha();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintContext28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        int int5 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setAnchorValue((double) 'a');
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
//        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
//        java.awt.Shape shape2 = null;
//        barRenderer0.setBaseLegendShape(shape2);
//        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
//        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
//        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
//        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
//        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
//        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
//        barRenderer0.setBaseItemLabelFont(font11, false);
//        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
//        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
//        barRenderer0.setBaseItemLabelPaint(paint15, true);
//        barRenderer0.setBaseSeriesVisible(true, true);
//        boolean boolean21 = barRenderer0.getShadowsVisible();
//        barRenderer0.setMinimumBarLength((double) 100);
//        org.junit.Assert.assertNotNull(renderAttributes1);
//        org.junit.Assert.assertNotNull(renderAttributes8);
//        org.junit.Assert.assertNotNull(shape10);
//        org.junit.Assert.assertNotNull(font11);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertNotNull(paint15);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        legendItem17.setSeriesKey((java.lang.Comparable) 0.5f);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation13);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace17, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator8);
        boolean boolean10 = lineAndShapeRenderer2.getDrawOutlines();
        boolean boolean11 = lineAndShapeRenderer2.getUseFillPaint();
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color13 = color12.brighter();
        java.awt.Color color14 = color13.darker();
        java.awt.Color color15 = color13.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearRangeMarkers();
        java.awt.Stroke stroke18 = categoryPlot16.getRangeZeroBaselineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color20 = color19.brighter();
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape11, (java.awt.Paint) color13, stroke18, (java.awt.Paint) color20);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape11, "java.awt.Color[r=64,g=64,b=64]", "DatasetRenderingOrder.REVERSE");
        objectList2.set((int) (byte) 10, (java.lang.Object) shape11);
        java.lang.Comparable comparable26 = null;
        try {
            keyedObjects2D0.addObject((java.lang.Object) (byte) 10, comparable26, (java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color1 = defaultShadowGenerator0.getShadowColor();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot4.getDomainGridlinePosition();
        categoryPlot2.setParent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Font font7 = categoryPlot2.getNoDataMessageFont();
        categoryPlot2.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        categoryPlot2.setFixedLegendItems(legendItemCollection10);
        boolean boolean12 = defaultShadowGenerator0.equals((java.lang.Object) legendItemCollection10);
        java.awt.Color color13 = defaultShadowGenerator0.getShadowColor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        boolean boolean9 = barRenderer0.getItemCreateEntity((int) '4', 10, false);
        java.awt.Paint paint11 = barRenderer0.lookupSeriesOutlinePaint((int) (short) 1);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis15, marker16, rectangle2D17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes23 = barRenderer22.getSelectedItemAttributes();
        java.lang.Boolean boolean25 = barRenderer22.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextOutlineStroke();
        barRenderer22.setSeriesOutlineStroke((int) 'a', stroke28, true);
        java.awt.Paint paint31 = barRenderer22.getBaseFillPaint();
        boolean boolean32 = axisLocation20.equals((java.lang.Object) barRenderer22);
        categoryPlot13.setDomainAxisLocation((int) 'a', axisLocation20, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot13.getAxisOffset();
        java.awt.Stroke stroke36 = categoryPlot13.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot13.zoomRangeAxes((double) (-20561), 0.0d, plotRenderingInfo39, point2D40);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(renderAttributes23);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((-35.0d), plotRenderingInfo11, point2D12, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = barRenderer11.getSelectedItemAttributes();
        java.awt.Shape shape13 = null;
        barRenderer11.setBaseLegendShape(shape13);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer11.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = barRenderer18.getSelectedItemAttributes();
        java.awt.Shape shape21 = barRenderer18.lookupLegendShape((int) 'a');
        java.awt.Font font22 = barRenderer18.getBaseItemLabelFont();
        barRenderer11.setBaseItemLabelFont(font22, false);
        barRenderer0.setBaseItemLabelFont(font22);
        double double26 = barRenderer0.getShadowXOffset();
        java.awt.Shape shape28 = barRenderer0.lookupSeriesShape(3);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(renderAttributes12);
        org.junit.Assert.assertNotNull(renderAttributes19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes((double) 3, plotRenderingInfo4, point2D5);
        java.awt.Image image7 = null;
        categoryPlot0.setBackgroundImage(image7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        java.awt.Paint paint16 = barRenderer2.getBaseItemLabelPaint();
        java.awt.Paint paint18 = barRenderer2.getSeriesItemLabelPaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = barRenderer19.getSelectedItemAttributes();
        java.awt.Shape shape21 = null;
        barRenderer19.setBaseLegendShape(shape21);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator24 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer19.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes27 = barRenderer26.getSelectedItemAttributes();
        java.awt.Shape shape29 = barRenderer26.lookupLegendShape((int) 'a');
        java.awt.Font font30 = barRenderer26.getBaseItemLabelFont();
        barRenderer19.setBaseItemLabelFont(font30, false);
        java.awt.Paint paint33 = barRenderer19.getBaseItemLabelPaint();
        java.awt.Paint paint34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer19.setBaseItemLabelPaint(paint34, true);
        barRenderer2.setBasePaint(paint34, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = barRenderer2.getLegendItemURLGenerator();
        boolean boolean40 = gradientPaintTransformType0.equals((java.lang.Object) barRenderer2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(renderAttributes20);
        org.junit.Assert.assertNotNull(renderAttributes27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Font font22 = barRenderer0.getLegendTextFont((int) '#');
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape25 = null;
        barRenderer23.setBaseLegendShape(shape25);
        java.awt.Font font28 = barRenderer23.lookupLegendTextFont(0);
        boolean boolean32 = barRenderer23.getItemCreateEntity((int) '4', 10, false);
        java.awt.Paint paint34 = barRenderer23.lookupSeriesOutlinePaint((int) (short) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer37 = null;
        barRenderer36.setGradientPaintTransformer(gradientPaintTransformer37);
        barRenderer36.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = barRenderer36.getBasePositiveItemLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes45 = barRenderer44.getSelectedItemAttributes();
        java.awt.Shape shape46 = null;
        barRenderer44.setBaseLegendShape(shape46);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator49 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer44.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator49);
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes52 = barRenderer51.getSelectedItemAttributes();
        java.awt.Shape shape54 = barRenderer51.lookupLegendShape((int) 'a');
        java.awt.Font font55 = barRenderer51.getBaseItemLabelFont();
        barRenderer44.setBaseItemLabelFont(font55, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes59 = barRenderer58.getSelectedItemAttributes();
        java.awt.Shape shape60 = null;
        barRenderer58.setBaseLegendShape(shape60);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator63 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer58.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator63);
        org.jfree.chart.renderer.category.BarRenderer barRenderer65 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes66 = barRenderer65.getSelectedItemAttributes();
        java.awt.Shape shape68 = barRenderer65.lookupLegendShape((int) 'a');
        java.awt.Font font69 = barRenderer65.getBaseItemLabelFont();
        barRenderer58.setBaseItemLabelFont(font69, false);
        java.awt.Shape shape75 = barRenderer58.getItemShape((int) (byte) 10, 3, false);
        org.jfree.chart.entity.ChartEntity chartEntity78 = new org.jfree.chart.entity.ChartEntity(shape75, "hi!", "java.awt.Color[r=64,g=64,b=64]");
        barRenderer44.setBaseShape(shape75, false);
        barRenderer36.setSeriesShape((int) '4', shape75);
        barRenderer23.setSeriesShape(192, shape75, false);
        barRenderer0.setBaseShape(shape75, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNull(font28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(renderAttributes45);
        org.junit.Assert.assertNotNull(renderAttributes52);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(renderAttributes59);
        org.junit.Assert.assertNotNull(renderAttributes66);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(shape75);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition17);
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22, false);
        java.awt.Font font25 = barRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(font25);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator8);
        boolean boolean10 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint6 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint1 = renderAttributes0.getDefaultOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape5 = barRenderer2.lookupLegendShape((int) 'a');
        java.awt.Font font6 = barRenderer2.getBaseItemLabelFont();
        renderAttributes0.setDefaultLabelFont(font6);
        java.awt.Paint paint8 = renderAttributes0.getDefaultOutlinePaint();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) false);
        boolean boolean8 = lineAndShapeRenderer2.getItemLineVisible(1, 2);
        boolean boolean11 = lineAndShapeRenderer2.getItemLineVisible(3, (int) (short) 10);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        double double19 = categoryPlot0.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot0.getRangeAxisEdge((int) ' ');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        categoryPlot0.axisChanged(axisChangeEvent22);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Category Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean5 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setBaseShapesVisible(false);
        boolean boolean8 = lineAndShapeRenderer2.getDrawOutlines();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color10);
        java.awt.Color color12 = color10.brighter();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearRangeMarkers();
        java.awt.Stroke stroke22 = categoryPlot20.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot20.getDomainAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D18, rectangle2D19, categoryPlot20, categoryDataset25, plotRenderingInfo26);
        categoryPlot20.setNoDataMessage("");
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) '#', (double) 0L, (double) (byte) 0);
        double double7 = rectangleInsets5.calculateLeftOutset((double) 10.0f);
        double double8 = rectangleInsets5.getRight();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        java.awt.Font font27 = barRenderer23.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        barRenderer23.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator29, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        barRenderer23.setBaseShape(shape35);
        legendItem17.setShape(shape35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.lang.Boolean boolean43 = barRenderer40.getSeriesVisibleInLegend((-1));
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) boolean43);
        java.awt.Paint paint45 = defaultDrawingSupplier38.getNextPaint();
        legendItem17.setFillPaint(paint45);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes48 = barRenderer47.getSelectedItemAttributes();
        java.lang.Boolean boolean49 = renderAttributes48.getDefaultCreateEntity();
        java.awt.Paint paint51 = renderAttributes48.getSeriesFillPaint(2);
        java.awt.Paint paint54 = renderAttributes48.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes57 = barRenderer56.getSelectedItemAttributes();
        java.awt.Shape shape59 = barRenderer56.lookupLegendShape((int) 'a');
        java.awt.Font font60 = barRenderer56.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        barRenderer56.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator62, false);
        java.awt.Stroke stroke65 = barRenderer56.getBaseStroke();
        renderAttributes48.setSeriesStroke((int) (short) 100, stroke65);
        boolean boolean67 = legendItem17.equals((java.lang.Object) (short) 100);
        java.lang.Comparable comparable68 = legendItem17.getSeriesKey();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(renderAttributes48);
        org.junit.Assert.assertNull(boolean49);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(renderAttributes57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(comparable68);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean5 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean10 = lineAndShapeRenderer2.getItemShapeVisible((int) (byte) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Shape shape17 = barRenderer0.getItemShape((int) (byte) 10, 3, false);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape17, "hi!", "java.awt.Color[r=64,g=64,b=64]");
        java.lang.String str21 = chartEntity20.getURLText();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str21.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = barRenderer10.getSelectedItemAttributes();
        java.awt.Shape shape13 = barRenderer10.lookupLegendShape((int) 'a');
        java.awt.Font font14 = barRenderer10.getBaseItemLabelFont();
        categoryPlot0.setNoDataMessageFont(font14);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = new org.jfree.chart.LegendItemCollection();
        categoryPlot0.setFixedLegendItems(legendItemCollection16);
        categoryPlot0.clearRangeMarkers((int) (byte) 1);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(renderAttributes11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        double double5 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator8);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (short) -1, (double) 100.0f, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis14.setTickLabelFont(font15);
        double double17 = categoryAxis14.getUpperMargin();
        float float18 = categoryAxis14.getTickMarkOutsideLength();
        int int19 = categoryAxis14.getCategoryLabelPositionOffset();
        float float20 = categoryAxis14.getMinorTickMarkInsideLength();
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis14, false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot28.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot28.getDatasetRenderingOrder();
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot28.setDomainGridlineStroke(stroke31);
        java.awt.geom.GeneralPath generalPath33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        categoryPlot28.select(generalPath33, rectangle2D34, renderingSource35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot28.setDomainGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot39.clearRangeMarkers();
        boolean boolean41 = categoryPlot39.canSelectByPoint();
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = categoryPlot39.removeDomainMarker(2, marker43, layer44);
        categoryPlot28.setParent((org.jfree.chart.plot.Plot) categoryPlot39);
        double double47 = categoryPlot28.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot28.getRangeAxisEdge((int) ' ');
        try {
            double double50 = categoryAxis14.getCategorySeriesMiddle((java.lang.Comparable) 1.0d, (java.lang.Comparable) (-34.0d), categoryDataset25, (double) (-12517377), rectangle2D27, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        categoryPlot2.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot2.setRangeAxisLocation(0, axisLocation8);
        categoryPlot2.setCrosshairDatasetIndex((-1), true);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("Category Plot");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: Category Plot" + "'", str2.equals("org.jfree.data.UnknownKeyException: Category Plot"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        categoryPlot2.setRangeCrosshairValue((double) (short) 10);
        categoryPlot2.configureDomainAxes();
        boolean boolean8 = categoryPlot2.isRangePannable();
        boolean boolean9 = categoryPlot2.isOutlineVisible();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        categoryPlot2.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        barRenderer0.setBasePaint((java.awt.Paint) color5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        barRenderer0.setSeriesURLGenerator((int) (byte) 100, categoryURLGenerator14, false);
        barRenderer0.setShadowYOffset((double) (-20561));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        int int28 = barRenderer0.getDefaultEntityRadius();
        java.awt.Paint paint29 = barRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.lang.Boolean boolean5 = barRenderer2.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        barRenderer2.setSeriesOutlineStroke((int) 'a', stroke8, true);
        java.awt.Paint paint11 = barRenderer2.getBaseFillPaint();
        boolean boolean12 = axisLocation0.equals((java.lang.Object) barRenderer2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer2.getBaseURLGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.Range range15 = barRenderer2.findRangeBounds(categoryDataset14);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        double double3 = itemLabelPosition2.getAngle();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color13 = color12.brighter();
        java.awt.Color color14 = color13.darker();
        java.awt.Color color15 = color13.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearRangeMarkers();
        java.awt.Stroke stroke18 = categoryPlot16.getRangeZeroBaselineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color20 = color19.brighter();
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape11, (java.awt.Paint) color13, stroke18, (java.awt.Paint) color20);
        java.awt.Paint paint22 = legendItem21.getLabelPaint();
        legendItem21.setSeriesKey((java.lang.Comparable) true);
        java.awt.Paint paint25 = legendItem21.getLabelPaint();
        boolean boolean26 = itemLabelPosition2.equals((java.lang.Object) paint25);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        barRenderer0.setBaseCreateEntities(true, false);
        java.lang.Boolean boolean25 = barRenderer0.getSeriesVisibleInLegend(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        barRenderer0.setSeriesURLGenerator(192, categoryURLGenerator27, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(boolean25);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        java.text.AttributedString attributedString23 = legendItem17.getAttributedLabel();
        java.lang.String str24 = legendItem17.getLabel();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(attributedString23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator6, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        barRenderer0.setBaseShape(shape12);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape12, "", "DatasetRenderingOrder.REVERSE");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator19 = null;
        categoryPlot17.setShadowGenerator(shadowGenerator19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot17.getInsets();
        boolean boolean22 = chartEntity16.equals((java.lang.Object) categoryPlot17);
        java.awt.Shape shape23 = chartEntity16.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape23, "java.awt.Color[r=64,g=64,b=64]", "TextAnchor.HALF_ASCENT_LEFT");
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getLabelPaint();
        legendItem17.setSeriesKey((java.lang.Comparable) true);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke21);
        legendItem17.setDescription("AxisLocation.TOP_OR_RIGHT");
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        barRenderer0.setBaseLegendShape(shape11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot15.getDomainGridlinePosition();
        categoryPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.util.ShadowGenerator shadowGenerator18 = null;
        categoryPlot13.setShadowGenerator(shadowGenerator18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot13.getRangeAxis((int) (short) 10);
        categoryPlot13.setRangeCrosshairVisible(false);
        categoryPlot13.setWeight((int) (byte) 1);
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) categoryPlot13, "hi!");
        java.lang.String str28 = plotEntity27.getShapeType();
        java.lang.String str29 = plotEntity27.toString();
        org.jfree.chart.plot.Plot plot30 = plotEntity27.getPlot();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "rect" + "'", str28.equals("rect"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PlotEntity: tooltip = hi!" + "'", str29.equals("PlotEntity: tooltip = hi!"));
        org.junit.Assert.assertNotNull(plot30);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesVisibleInLegend((-1));
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Shape shape6 = null;
        barRenderer0.setSeriesShape((int) (byte) 10, shape6, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot20.getDomainGridlinePosition();
        categoryPlot20.clearDomainMarkers();
        categoryPlot20.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryPlot20.equals(obj25);
        categoryPlot20.setRangeCrosshairValue((double) '#');
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        java.awt.Color color31 = java.awt.Color.YELLOW;
        barRenderer0.setSeriesOutlinePaint((int) (short) 1, (java.awt.Paint) color31);
        org.jfree.chart.renderer.category.BarPainter barPainter33 = barRenderer0.getBarPainter();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(barPainter33);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean8 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        boolean boolean3 = categoryAxis0.isVisible();
        java.lang.Object obj4 = categoryAxis0.clone();
        java.lang.String str5 = categoryAxis0.getLabelURL();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = barRenderer6.getSelectedItemAttributes();
        java.awt.Shape shape8 = null;
        barRenderer6.setBaseLegendShape(shape8);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer6.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator11);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = barRenderer6.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        barRenderer6.setBaseItemLabelGenerator(categoryItemLabelGenerator17);
        boolean boolean19 = barRenderer6.isDrawBarOutline();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = categoryPlot22.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = categoryPlot22.getDatasetRenderingOrder();
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot22.setDomainGridlineStroke(stroke25);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot22.select(generalPath27, rectangle2D28, renderingSource29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = barRenderer6.initialise(graphics2D20, rectangle2D21, categoryPlot22, categoryDataset31, plotRenderingInfo32);
        categoryPlot22.setBackgroundImageAlpha((float) (byte) 1);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 9.0d, (java.awt.Paint) color38);
        categoryAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(renderAttributes7);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(categoryItemRendererState33);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Paint paint3 = barRenderer0.getSeriesItemLabelPaint((int) (short) -1);
        barRenderer0.setMaximumBarWidth((double) '4');
        barRenderer0.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape11 = null;
        barRenderer9.setBaseLegendShape(shape11);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer9.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = barRenderer16.getSelectedItemAttributes();
        java.awt.Shape shape19 = barRenderer16.lookupLegendShape((int) 'a');
        java.awt.Font font20 = barRenderer16.getBaseItemLabelFont();
        barRenderer9.setBaseItemLabelFont(font20, false);
        java.awt.Paint paint23 = barRenderer9.getBaseItemLabelPaint();
        java.awt.Paint paint25 = barRenderer9.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot28.getDomainGridlinePosition();
        categoryPlot28.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot28.setDomainGridlinePosition(categoryAnchor31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes40 = barRenderer39.getSelectedItemAttributes();
        java.awt.Shape shape41 = null;
        barRenderer39.setBaseLegendShape(shape41);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator44 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer39.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator44);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator49 = barRenderer39.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator50 = null;
        barRenderer39.setBaseItemLabelGenerator(categoryItemLabelGenerator50);
        boolean boolean52 = barRenderer39.isDrawBarOutline();
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor56 = categoryPlot55.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder57 = categoryPlot55.getDatasetRenderingOrder();
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot55.setDomainGridlineStroke(stroke58);
        java.awt.geom.GeneralPath generalPath60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.RenderingSource renderingSource62 = null;
        categoryPlot55.select(generalPath60, rectangle2D61, renderingSource62);
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState66 = barRenderer39.initialise(graphics2D53, rectangle2D54, categoryPlot55, categoryDataset64, plotRenderingInfo65);
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = barRenderer9.createHotSpotBounds(graphics2D26, rectangle2D27, categoryPlot28, categoryAxis33, valueAxis34, categoryDataset35, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState66, rectangle2D67);
        categoryPlot28.mapDatasetToDomainAxis((int) (byte) 100, (-12517377));
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot72.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor75 = categoryPlot74.getDomainGridlinePosition();
        categoryPlot72.setParent((org.jfree.chart.plot.Plot) categoryPlot74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        java.awt.geom.Point2D point2D80 = null;
        categoryPlot72.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo79, point2D80);
        org.jfree.chart.renderer.category.BarRenderer barRenderer82 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes83 = barRenderer82.getSelectedItemAttributes();
        java.awt.Shape shape85 = barRenderer82.lookupLegendShape((int) 'a');
        java.awt.Font font86 = barRenderer82.getBaseItemLabelFont();
        categoryPlot72.setNoDataMessageFont(font86);
        boolean boolean88 = categoryPlot28.equals((java.lang.Object) font86);
        barRenderer0.setBaseLegendTextFont(font86);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(renderAttributes17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(renderAttributes40);
        org.junit.Assert.assertNull(categoryURLGenerator49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(categoryAnchor56);
        org.junit.Assert.assertNotNull(datasetRenderingOrder57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(categoryItemRendererState66);
        org.junit.Assert.assertNull(rectangle2D68);
        org.junit.Assert.assertNotNull(categoryAnchor75);
        org.junit.Assert.assertNotNull(renderAttributes83);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(font86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }
}

