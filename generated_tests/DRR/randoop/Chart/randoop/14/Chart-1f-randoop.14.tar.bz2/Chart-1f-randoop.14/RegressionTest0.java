import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "", categoryDataset3, (java.lang.Comparable) "", (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo0 = new org.jfree.chart.event.DatasetChangeInfo();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), (int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color1 = color0.brighter();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color1 = color0.brighter();
        boolean boolean3 = color0.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color1 = null;
        try {
            org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 0, color1, (float) (byte) -1, 0, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'color' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray3 = new float[] { (byte) 0, 'a' };
        try {
            float[] floatArray4 = color0.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeMarkers();
        try {
            org.jfree.chart.entity.PlotEntity plotEntity3 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        try {
            keyedObjects0.removeValue(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        boolean boolean3 = categoryAnchor1.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot6.getDomainGridlinePosition();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot4.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D3, categoryPlot4, categoryAxis14, categoryMarker15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot9.getDomainGridlinePosition();
        categoryPlot7.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        try {
            barRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D6, categoryPlot9, categoryAxis12, valueAxis13, categoryDataset14, 1, (int) ' ', false, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(categoryAnchor10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list2 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) (byte) 1, list2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        try {
            categoryPlot0.setDomainAxisLocation((int) (byte) -1, axisLocation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str1.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            java.lang.String str5 = standardCategorySeriesLabelGenerator1.generateLabel(categoryDataset3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray5 = new float[] { 10, 100.0f, (byte) 10 };
        try {
            float[] floatArray6 = color0.getComponents(colorSpace1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("{0}", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        try {
            barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (-1) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            categoryPlot0.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = null;
        strokeList0.setStroke((int) (byte) 100, stroke2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        try {
            categoryPlot0.setDomainAxisLocation((-1), axisLocation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Paint paint11 = barRenderer8.getSeriesItemLabelPaint((int) (short) -1);
        java.awt.Paint paint15 = barRenderer8.getItemPaint((int) (short) -1, (int) (byte) -1, false);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint17 = null;
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", "Category Plot", "{0}", "", shape7, paint15, stroke16, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            categoryPlot0.addRangeMarker(marker2, layer3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot15.zoomRangeAxes((double) 0, plotRenderingInfo23, point2D24, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = null;
        try {
            boolean boolean34 = barRenderer0.hitTest(10.0d, (double) (-1), graphics2D13, rectangle2D14, categoryPlot15, categoryAxis27, valueAxis28, categoryDataset29, 3, (int) (short) 0, false, categoryItemRendererState33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint1 = null;
        try {
            renderAttributes0.setDefaultLabelPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(false);
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) ' ', (int) (short) 10, (int) (byte) 100);
        try {
            barRenderer0.setSeriesFillPaint((int) (byte) -1, (java.awt.Paint) chartColor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addRangeMarker((int) (short) 10, marker14, layer15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) itemLabelAnchor3);
        try {
            keyedObjects0.removeValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearRangeMarkers();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeZeroBaselineStroke();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) ' ', (int) (short) 10, (int) (byte) 100);
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "", shape7, stroke10, (java.awt.Paint) chartColor14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) itemLabelAnchor3);
        try {
            java.lang.Comparable comparable6 = keyedObjects0.getKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot7.getDomainGridlinePosition();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.util.ShadowGenerator shadowGenerator10 = categoryPlot7.getShadowGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D4, categoryPlot7, categoryAxis11, categoryMarker12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(shadowGenerator10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(categoryAxis19);
        boolean boolean21 = barRenderer0.hasListener((java.util.EventListener) categoryPlot17);
        java.awt.Paint paint25 = barRenderer0.getItemOutlinePaint(0, 0, false);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) (short) 10);
        categoryPlot0.setBackgroundAlpha(100.0f);
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            categoryPlot0.addRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        try {
            categoryPlot2.setBackgroundImageAlpha((float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = barRenderer10.getSelectedItemAttributes();
        java.lang.Boolean boolean13 = barRenderer10.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        barRenderer10.setSeriesOutlineStroke((int) 'a', stroke16, true);
        java.lang.Boolean boolean20 = barRenderer10.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke21 = barRenderer10.getBaseStroke();
        try {
            barRenderer0.setSeriesOutlineStroke((int) (byte) -1, stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(renderAttributes11);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.cyan;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot6.getDatasetRenderingOrder();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot6.setDomainGridlineStroke(stroke9);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(0, (int) (byte) 0, (int) (byte) 1);
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "Category Plot", "", shape4, (java.awt.Paint) color5, stroke9, (java.awt.Paint) chartColor14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent10 = null;
        categoryPlot0.annotationChanged(annotationChangeEvent10);
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double11 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator12);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray24 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot19.setDomainAxes(categoryAxisArray24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot19.zoomRangeAxes((double) 0, plotRenderingInfo27, point2D28, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot19.getRangeAxisEdge();
        try {
            double double32 = barRenderer0.getItemMiddle((java.lang.Comparable) 100.0d, (java.lang.Comparable) 0.0d, categoryDataset16, categoryAxis17, rectangle2D18, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(categoryAxisArray24);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryPlot0.equals(obj5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation7, false);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean7 = categoryPlot2.removeRangeMarker(marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("DatasetRenderingOrder.REVERSE");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot0.clearDomainMarkers();
        java.awt.Paint paint9 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) -1, categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        categoryPlot2.setRangeCrosshairValue((double) (short) 10);
        categoryPlot2.clearRangeAxes();
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Font font5 = renderAttributes4.getDefaultLabelFont();
        java.awt.Paint paint7 = renderAttributes4.getSeriesFillPaint((int) '4');
        boolean boolean8 = itemLabelAnchor0.equals((java.lang.Object) paint7);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation13.getOpposite();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = barRenderer1.getSelectedItemAttributes();
        java.awt.Shape shape3 = null;
        barRenderer1.setBaseLegendShape(shape3);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer1.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        barRenderer1.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer1.getNegativeItemLabelPositionFallback();
        boolean boolean12 = booleanList0.equals((java.lang.Object) itemLabelPosition11);
        org.junit.Assert.assertNotNull(renderAttributes2);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        float float4 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        boolean boolean6 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 100.0f, (-1.0f));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 1, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent3.getChart();
        org.junit.Assert.assertNull(chartChangeEventType4);
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.awt.Shape shape19 = null;
        barRenderer17.setBaseLegendShape(shape19);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator22 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer17.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator22);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes25 = barRenderer24.getSelectedItemAttributes();
        java.awt.Shape shape27 = barRenderer24.lookupLegendShape((int) 'a');
        java.awt.Font font28 = barRenderer24.getBaseItemLabelFont();
        barRenderer17.setBaseItemLabelFont(font28, false);
        java.awt.Paint paint31 = barRenderer17.getBaseItemLabelPaint();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer17.setBaseItemLabelPaint(paint32, true);
        barRenderer0.setBasePaint(paint32, false);
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNotNull(renderAttributes25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation11, plotOrientation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double11 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator12);
        barRenderer0.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator6, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        barRenderer0.setBaseShape(shape12);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape12, "", "DatasetRenderingOrder.REVERSE");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator19 = null;
        categoryPlot17.setShadowGenerator(shadowGenerator19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot17.getInsets();
        boolean boolean22 = chartEntity16.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        try {
            int int24 = categoryPlot17.getDomainAxisIndex(categoryAxis23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator6, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        barRenderer0.setBaseShape(shape12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        categoryPlot15.setParent((org.jfree.chart.plot.Plot) categoryPlot17);
        java.awt.Font font20 = categoryPlot15.getNoDataMessageFont();
        try {
            barRenderer0.setSeriesItemLabelFont((int) (short) -1, font20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        categoryPlot0.setRangeCrosshairValue((double) 3, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            categoryPlot2.setColumnRenderingOrder(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = categoryPlot1.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator3 = null;
        categoryPlot1.setShadowGenerator(shadowGenerator3);
        boolean boolean5 = unitType0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot1.setDomainAxisLocation(0, axisLocation7);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            java.lang.String str5 = standardCategorySeriesLabelGenerator1.generateLabel(categoryDataset3, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer(2);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNull(categoryItemRenderer6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) '#', (double) 0L, (double) (byte) 0);
        double double7 = rectangleInsets5.trimWidth((double) 1);
        double double9 = rectangleInsets5.trimHeight((-34.0d));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-34.0d) + "'", double7 == (-34.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-35.0d) + "'", double9 == (-35.0d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        java.lang.String str2 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str2.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer3.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint15 = barRenderer3.lookupSeriesPaint(0);
        renderAttributes1.setDefaultPaint(paint15);
        try {
            java.awt.Paint paint19 = renderAttributes1.getItemLabelPaint((int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) '#', (double) 0L, (double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets5.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot2.clearDomainMarkers();
        categoryPlot2.setCrosshairDatasetIndex((int) (short) -1);
        boolean boolean7 = categoryAnchor1.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot15.getDatasetRenderingOrder();
        java.lang.String str18 = datasetRenderingOrder17.toString();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder17);
        java.lang.String str20 = datasetRenderingOrder17.toString();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str18.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str20.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.awt.Paint paint9 = barRenderer0.getBaseFillPaint();
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        barRenderer0.setAutoPopulateSeriesPaint(true);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        java.awt.Font font27 = barRenderer23.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        barRenderer23.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator29, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        barRenderer23.setBaseShape(shape35);
        legendItem17.setShape(shape35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.lang.Boolean boolean43 = barRenderer40.getSeriesVisibleInLegend((-1));
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) boolean43);
        java.awt.Paint paint45 = defaultDrawingSupplier38.getNextPaint();
        legendItem17.setFillPaint(paint45);
        java.awt.Shape shape47 = legendItem17.getShape();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        java.awt.Image image3 = null;
        categoryPlot0.setBackgroundImage(image3);
        try {
            categoryPlot0.mapDatasetToDomainAxis((int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            boolean boolean10 = categoryPlot2.removeRangeMarker(2, marker7, layer8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) 'a', 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot11.getDomainGridlinePosition();
        categoryPlot9.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        java.awt.Font font14 = categoryPlot9.getNoDataMessageFont();
        categoryPlot9.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot9.clearDomainMarkers();
        java.awt.Paint paint18 = categoryPlot9.getBackgroundPaint();
        renderAttributes1.setSeriesPaint((int) '4', paint18);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Font font11 = renderAttributes10.getDefaultLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes13 = barRenderer12.getSelectedItemAttributes();
        java.awt.Shape shape14 = null;
        barRenderer12.setBaseLegendShape(shape14);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer12.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer12.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint24 = barRenderer12.lookupSeriesPaint(0);
        renderAttributes10.setDefaultPaint(paint24);
        renderAttributes1.setSeriesPaint((int) '4', paint24);
        java.awt.Stroke stroke27 = null;
        try {
            renderAttributes1.setDefaultStroke(stroke27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNotNull(renderAttributes13);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation5, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            boolean boolean9 = categoryPlot0.removeAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double11 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator12);
        boolean boolean14 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) '#', (double) 0L, (double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets5.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        barRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean17 = barRenderer0.getSeriesCreateEntities((int) (byte) 0);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition17);
        java.awt.Shape shape20 = barRenderer0.getSeriesShape((int) '#');
        barRenderer0.setSeriesVisibleInLegend((int) 'a', (java.lang.Boolean) true, true);
        barRenderer0.setItemMargin((double) 0L);
        int int27 = barRenderer0.getColumnCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = barRenderer0.getToolTipGenerator((int) 'a', (int) '4', true);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot20.getDomainGridlinePosition();
        categoryPlot20.clearDomainMarkers();
        categoryPlot20.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryPlot20.equals(obj25);
        categoryPlot20.setRangeCrosshairValue((double) '#');
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        java.awt.Font font30 = barRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(font30);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis10 };
        categoryPlot6.setDomainAxes(categoryAxisArray11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot6.zoomRangeAxes((double) 0, plotRenderingInfo14, point2D15, true);
        boolean boolean18 = categoryPlot6.isRangeGridlinesVisible();
        java.util.List list19 = categoryPlot6.getAnnotations();
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) ' ', list19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) '#', (double) 0L, (double) (byte) 0);
        double double7 = rectangleInsets5.trimWidth((double) 1);
        double double9 = rectangleInsets5.extendHeight((double) 100.0f);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-34.0d) + "'", double7 == (-34.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 101.0d + "'", double9 == 101.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        categoryPlot17.clearDomainMarkers();
        categoryPlot17.setCrosshairDatasetIndex((int) (short) -1);
        barRenderer0.setPlot(categoryPlot17);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        try {
            barRenderer0.setSeriesItemLabelsVisible((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(categoryAnchor18);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        int int5 = barRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        org.jfree.chart.util.SortOrder sortOrder2 = null;
        try {
            keyedObjects0.sortByKeys(sortOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        boolean boolean12 = barRenderer0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            barRenderer0.drawBackground(graphics2D13, categoryPlot14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer0.getToolTipGenerator((int) (short) 100, (int) '4', false);
        boolean boolean16 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder7);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        java.lang.String str2 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        java.awt.Image image3 = null;
        categoryPlot0.setBackgroundImage(image3);
        java.awt.Paint paint5 = categoryPlot0.getRangeZeroBaselinePaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot0.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        org.jfree.data.general.Dataset dataset18 = null;
        legendItem17.setDataset(dataset18);
        java.awt.Paint paint20 = legendItem17.getLabelPaint();
        legendItem17.setDatasetIndex(100);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint24 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        java.awt.Paint paint25 = barRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        categoryPlot17.clearDomainMarkers();
        categoryPlot17.setCrosshairDatasetIndex((int) (short) -1);
        barRenderer0.setPlot(categoryPlot17);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        barRenderer0.setBaseCreateEntities(false);
        barRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(categoryAnchor18);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer9.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator15, false);
        java.awt.Stroke stroke18 = barRenderer9.getBaseStroke();
        renderAttributes1.setSeriesStroke((int) (short) 100, stroke18);
        java.awt.Shape shape20 = renderAttributes1.getDefaultShape();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot24.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot24.getDatasetRenderingOrder();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot24.setDomainGridlineStroke(stroke27);
        categoryPlot22.setOutlineStroke(stroke27);
        try {
            renderAttributes1.setSeriesOutlineStroke(2, stroke27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.awt.Shape shape22 = null;
        barRenderer20.setBaseLegendShape(shape22);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator25 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer20.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape30 = barRenderer27.lookupLegendShape((int) 'a');
        java.awt.Font font31 = barRenderer27.getBaseItemLabelFont();
        barRenderer20.setBaseItemLabelFont(font31, false);
        java.awt.Shape shape37 = barRenderer20.getItemShape((int) (byte) 10, 3, false);
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity(shape37, "hi!", "java.awt.Color[r=64,g=64,b=64]");
        barRenderer0.setLegendShape(3, shape37);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), (double) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot13.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator15 = null;
        categoryPlot13.setShadowGenerator(shadowGenerator15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = categoryPlot13.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier17);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNotNull(drawingSupplier17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        renderAttributes1.setSeriesPaint((int) (byte) 1, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        java.awt.Font font27 = barRenderer23.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        barRenderer23.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator29, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        barRenderer23.setBaseShape(shape35);
        legendItem17.setShape(shape35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.lang.Boolean boolean43 = barRenderer40.getSeriesVisibleInLegend((-1));
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) boolean43);
        java.awt.Paint paint45 = defaultDrawingSupplier38.getNextPaint();
        legendItem17.setFillPaint(paint45);
        java.lang.Object obj47 = null;
        boolean boolean48 = legendItem17.equals(obj47);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.setCrosshairDatasetIndex(10, true);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearRangeMarkers();
        categoryPlot10.setWeight(0);
        java.awt.Stroke stroke14 = categoryPlot10.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.lang.Boolean boolean20 = barRenderer17.getSeriesVisibleInLegend((-1));
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) boolean20);
        categoryPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15, false);
        java.awt.Paint paint24 = defaultDrawingSupplier15.getNextPaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        double double26 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = barRenderer0.getSelectedItemAttributes();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(renderAttributes14);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        java.lang.String str3 = textAnchor1.toString();
        java.lang.String str4 = textAnchor1.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str3.equals("TextAnchor.HALF_ASCENT_LEFT"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str4.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot8.getDatasetRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setDomainGridlineStroke(stroke11);
        categoryPlot0.setRangeCrosshairStroke(stroke11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        try {
            categoryPlot0.setDataset((-1), categoryDataset15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation13);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = null;
        barRenderer11.setGradientPaintTransformer(gradientPaintTransformer12);
        java.awt.Font font15 = null;
        barRenderer11.setLegendTextFont(10, font15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        barRenderer11.setBaseURLGenerator(categoryURLGenerator17, true);
        org.jfree.chart.LegendItem legendItem22 = barRenderer11.getLegendItem((int) (short) 100, 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot26.getDomainGridlinePosition();
        categoryPlot24.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        java.awt.Font font29 = categoryPlot24.getNoDataMessageFont();
        categoryPlot24.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot32.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder34 = categoryPlot32.getDatasetRenderingOrder();
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot32.setDomainGridlineStroke(stroke35);
        categoryPlot24.setRangeCrosshairStroke(stroke35);
        barRenderer11.setSeriesStroke((int) (short) 1, stroke35);
        try {
            barRenderer0.setSeriesStroke((int) (byte) -1, stroke35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertNotNull(datasetRenderingOrder34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = categoryPlot0.removeRangeMarker(marker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Comparable comparable3 = null;
        java.lang.Object obj4 = null;
        try {
            keyedObjects0.insertValue(0, comparable3, obj4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        barRenderer0.setBaseLegendShape(shape11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        java.awt.Color color6 = java.awt.Color.pink;
        barRenderer0.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color6);
        int int8 = color6.getRGB();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-20561) + "'", int8 == (-20561));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot19.getDomainGridlinePosition();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot19.setDomainGridlinePosition(categoryAnchor22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer30.setBaseItemLabelGenerator(categoryItemLabelGenerator41);
        boolean boolean43 = barRenderer30.isDrawBarOutline();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = categoryPlot46.getDatasetRenderingOrder();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot46.setDomainGridlineStroke(stroke49);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot46.select(generalPath51, rectangle2D52, renderingSource53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer30.initialise(graphics2D44, rectangle2D45, categoryPlot46, categoryDataset55, plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis25, categoryDataset26, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState57, rectangle2D58);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation60 = null;
        try {
            boolean boolean62 = categoryPlot19.removeAnnotation(categoryAnnotation60, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
        org.junit.Assert.assertNull(rectangle2D59);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis8, true);
        java.lang.Object obj11 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.lang.Boolean boolean5 = barRenderer2.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        barRenderer2.setSeriesOutlineStroke((int) 'a', stroke8, true);
        java.awt.Paint paint11 = barRenderer2.getBaseFillPaint();
        boolean boolean12 = axisLocation0.equals((java.lang.Object) barRenderer2);
        barRenderer2.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation2 = axisLocation1.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation2, plotOrientation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("Category Plot");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            boolean boolean8 = categoryPlot0.removeAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        java.awt.Paint paint5 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((-35.0d), plotRenderingInfo7, point2D8, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        barRenderer0.setBaseCreateEntities(true, false);
        java.awt.Paint paint27 = barRenderer0.getItemPaint((int) 'a', (int) (byte) -1, false);
        org.jfree.chart.renderer.category.BarPainter barPainter28 = barRenderer0.getBarPainter();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(barPainter28);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        categoryPlot0.setDomainCrosshairVisible(false);
        java.lang.Comparable comparable7 = categoryPlot0.getDomainCrosshairRowKey();
        boolean boolean8 = categoryPlot0.isRangePannable();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        java.lang.String str21 = legendItem17.getDescription();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{0}" + "'", str21.equals("{0}"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj6 = standardCategorySeriesLabelGenerator5.clone();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) (short) 10);
        categoryPlot0.setBackgroundAlpha(100.0f);
        categoryPlot0.setRangePannable(true);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.String str3 = datasetRenderingOrder2.toString();
        java.lang.String str4 = datasetRenderingOrder2.toString();
        java.lang.Object obj5 = null;
        boolean boolean6 = datasetRenderingOrder2.equals(obj5);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str4.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.lang.Boolean boolean8 = barRenderer0.getSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarPainter barPainter9 = barRenderer0.getBarPainter();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset10);
        java.awt.Font font13 = barRenderer0.getLegendTextFont(0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(barPainter9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.awt.Paint paint9 = barRenderer0.getBaseFillPaint();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        double double18 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.awt.Shape shape22 = null;
        barRenderer20.setBaseLegendShape(shape22);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator25 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer20.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape30 = barRenderer27.lookupLegendShape((int) 'a');
        java.awt.Font font31 = barRenderer27.getBaseItemLabelFont();
        barRenderer20.setBaseItemLabelFont(font31, false);
        java.awt.Paint paint34 = barRenderer20.getBaseItemLabelPaint();
        java.awt.Paint paint36 = barRenderer20.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke38 = barRenderer20.lookupSeriesStroke(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.awt.Shape shape42 = null;
        barRenderer40.setBaseLegendShape(shape42);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer40.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator45);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = barRenderer40.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator51 = null;
        barRenderer40.setBaseItemLabelGenerator(categoryItemLabelGenerator51);
        boolean boolean53 = barRenderer40.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor55 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor55, textAnchor56);
        barRenderer40.setSeriesPositiveItemLabelPosition(2, itemLabelPosition57, true);
        barRenderer20.setSeriesNegativeItemLabelPosition(1, itemLabelPosition57, false);
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 0, itemLabelPosition57, false);
        double double64 = itemLabelPosition57.getAngle();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(categoryURLGenerator50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor55);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = barRenderer1.getSelectedItemAttributes();
        java.awt.Font font3 = renderAttributes2.getDefaultLabelFont();
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) font3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot7.getDomainGridlinePosition();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot7);
        java.awt.Font font10 = categoryPlot5.getNoDataMessageFont();
        boolean boolean11 = rectangleInsets0.equals((java.lang.Object) categoryPlot5);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            rectangleInsets0.trim(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(renderAttributes2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        categoryPlot2.clearRangeAxes();
        java.awt.Stroke stroke7 = categoryPlot2.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot2.setDomainAxis(0, categoryAxis9);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        java.awt.Stroke stroke18 = barRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearRangeMarkers();
        boolean boolean23 = categoryPlot21.canSelectByPoint();
        java.awt.Image image24 = null;
        categoryPlot21.setBackgroundImage(image24);
        java.awt.Paint paint26 = categoryPlot21.getRangeZeroBaselinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = barRenderer0.initialise(graphics2D19, rectangle2D20, categoryPlot21, categoryDataset27, plotRenderingInfo28);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(categoryItemRendererState29);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.lang.Boolean boolean10 = barRenderer7.getSeriesVisibleInLegend((-1));
        boolean boolean11 = defaultDrawingSupplier5.equals((java.lang.Object) boolean10);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier5, false);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        try {
            categoryPlot0.addRangeMarker((int) (short) 1, marker15, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        boolean boolean9 = barRenderer0.getItemCreateEntity((int) '4', 10, false);
        java.awt.Paint paint11 = barRenderer0.lookupSeriesOutlinePaint((int) (short) 1);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        barRenderer0.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis15, marker16, rectangle2D17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot13.addDomainMarker(100, categoryMarker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        categoryPlot2.setRangeCrosshairValue((double) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        int int8 = categoryPlot2.indexOf(categoryDataset7);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        java.awt.Image image5 = null;
        categoryPlot0.setBackgroundImage(image5);
        org.junit.Assert.assertNotNull(categoryAnchor1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        int int1 = strokeList0.size();
        java.lang.Object obj2 = strokeList0.clone();
        java.awt.Stroke stroke4 = strokeList0.getStroke((int) (byte) 0);
        java.lang.Object obj5 = strokeList0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        float float2 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        float[] floatArray6 = null;
        float[] floatArray7 = java.awt.Color.RGBtoHSB(3, (int) (short) -1, (int) (byte) -1, floatArray6);
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) (byte) -1, (-1), 0, floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        boolean boolean9 = barRenderer0.getItemCreateEntity((int) '4', 10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        categoryPlot17.clearDomainMarkers();
        categoryPlot17.setCrosshairDatasetIndex((int) (short) -1);
        barRenderer0.setPlot(categoryPlot17);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearRangeMarkers();
        boolean boolean28 = categoryPlot26.canSelectByPoint();
        java.awt.Image image29 = null;
        categoryPlot26.setBackgroundImage(image29);
        java.awt.Paint paint31 = categoryPlot26.getRangeZeroBaselinePaint();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            barRenderer0.drawOutline(graphics2D25, categoryPlot26, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = itemLabelPosition6.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(categoryAxis19);
        boolean boolean21 = barRenderer0.hasListener((java.util.EventListener) categoryPlot17);
        double double22 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        boolean boolean6 = unitType4.equals((java.lang.Object) shape5);
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        barRenderer9.setGradientPaintTransformer(gradientPaintTransformer10);
        java.awt.Paint paint15 = barRenderer9.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint17 = barRenderer9.getSeriesOutlinePaint(100);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer9.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color19, false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray29 = new float[] { (-1L), 100.0f, (short) 1, (short) -1, 100L, 'a' };
        float[] floatArray30 = color22.getColorComponents(floatArray29);
        float[] floatArray31 = color19.getColorComponents(floatArray30);
        objectList7.set(0, (java.lang.Object) color19);
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = null;
        barRenderer34.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator36, false);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color39.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        barRenderer34.setBasePaint((java.awt.Paint) color39);
        try {
            org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem(attributedString0, "AxisLocation.TOP_OR_RIGHT", "{0}", "AxisLocation.TOP_OR_RIGHT", shape5, (java.awt.Paint) color19, stroke33, (java.awt.Paint) color39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintContext45);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke4 = renderAttributes1.getSeriesStroke((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape9 = null;
        barRenderer7.setBaseLegendShape(shape9);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator12 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer7.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape17 = barRenderer14.lookupLegendShape((int) 'a');
        java.awt.Font font18 = barRenderer14.getBaseItemLabelFont();
        barRenderer7.setBaseItemLabelFont(font18, false);
        barRenderer5.setLegendTextFont((int) '4', font18);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        barRenderer5.setBaseItemLabelPaint(paint22);
        renderAttributes1.setDefaultPaint(paint22);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearRangeMarkers();
        categoryPlot13.setWeight(0);
        java.awt.Stroke stroke17 = categoryPlot13.getRangeMinorGridlineStroke();
        java.lang.String str18 = categoryPlot13.getPlotType();
        java.awt.Image image19 = categoryPlot13.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        int int21 = categoryPlot13.indexOf(categoryDataset20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot13);
        categoryPlot0.notifyListeners(plotChangeEvent22);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        int int2 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            categoryPlot0.addDomainMarker((-12517377), categoryMarker4, layer5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        double double5 = rectangleInsets4.getBottom();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets4.createOutsetRectangle(rectangle2D6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Font font4 = null;
        barRenderer0.setLegendTextFont(10, font4);
        java.awt.Paint paint7 = barRenderer0.lookupSeriesPaint((int) (short) 1);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (short) -1, (double) 100.0f, plotRenderingInfo10, point2D11);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        int int1 = strokeList0.size();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.lang.Boolean boolean4 = renderAttributes3.getDefaultCreateEntity();
        java.awt.Paint paint6 = renderAttributes3.getSeriesPaint(1);
        boolean boolean7 = strokeList0.equals((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(legendItemCollection7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator19);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot20.getDomainGridlinePosition();
        categoryPlot20.clearDomainMarkers();
        categoryPlot20.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryPlot20.equals(obj25);
        categoryPlot20.setRangeCrosshairValue((double) '#');
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            categoryPlot20.drawBackground(graphics2D30, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean5 = barRenderer0.isSeriesVisible((int) (byte) 10);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        java.awt.Font font3 = null;
        try {
            categoryAxis0.setTickLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        legendItem17.setOutlinePaint(paint21);
        legendItem17.setDatasetIndex((int) (short) -1);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint(100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color10, false);
        java.awt.Paint paint14 = barRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot2.handleClick(1, 10, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        categoryPlot2.clearRangeAxes();
        java.awt.Stroke stroke7 = categoryPlot2.getRangeMinorGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        int int9 = categoryPlot2.indexOf(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot2.getDataset((int) 'a');
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(categoryDataset11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = keyedObjects2D0.getRowIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=192,b=192]" + "'", str1.equals("java.awt.Color[r=0,g=192,b=192]"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        barRenderer3.setBaseItemLabelFont(font25);
        renderAttributes1.setDefaultLabelFont(font25);
        java.awt.Color color30 = java.awt.Color.cyan;
        renderAttributes1.setDefaultPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation13);
        int int15 = categoryPlot0.getRendererCount();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRendererForDataset(categoryDataset13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers();
        categoryPlot15.setWeight(0);
        java.awt.Stroke stroke19 = categoryPlot15.getRangeMinorGridlineStroke();
        java.lang.String str20 = categoryPlot15.getPlotType();
        java.awt.Image image21 = categoryPlot15.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        int int23 = categoryPlot15.indexOf(categoryDataset22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot0.notifyListeners(plotChangeEvent24);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Category Plot" + "'", str20.equals("Category Plot"));
        org.junit.Assert.assertNull(image21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        java.lang.Object obj28 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot2.getDatasetRenderingOrder();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot2.setDomainGridlineStroke(stroke5);
        categoryPlot0.setOutlineStroke(stroke5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearRangeMarkers();
        java.awt.Stroke stroke11 = categoryPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot9.getDomainAxisLocation(0);
        categoryPlot0.setDomainAxisLocation((int) (short) 100, axisLocation13);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        org.jfree.data.general.Dataset dataset18 = null;
        legendItem17.setDataset(dataset18);
        java.lang.Comparable comparable20 = legendItem17.getSeriesKey();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(comparable20);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean30 = categoryPlot16.isRangeCrosshairLockedOnData();
        categoryPlot16.configureRangeAxes();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (SortOrder.ASCENDING) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes1.setDefaultStroke(stroke3);
        java.awt.Paint paint6 = renderAttributes1.getSeriesOutlinePaint(100);
        java.awt.Stroke stroke8 = null;
        try {
            renderAttributes1.setSeriesStroke((-1), stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        java.util.List list13 = categoryPlot0.getAnnotations();
        categoryPlot0.configureRangeAxes();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            categoryPlot0.drawBackground(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape10 = null;
        barRenderer8.setBaseLegendShape(shape10);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer8.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes16 = barRenderer15.getSelectedItemAttributes();
        java.awt.Shape shape18 = barRenderer15.lookupLegendShape((int) 'a');
        java.awt.Font font19 = barRenderer15.getBaseItemLabelFont();
        barRenderer8.setBaseItemLabelFont(font19, false);
        barRenderer6.setLegendTextFont((int) '4', font19);
        try {
            renderAttributes1.setSeriesLabelFont((int) (short) 1, font19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(renderAttributes16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.awt.Paint paint19 = barRenderer17.getBasePaint();
        barRenderer0.setSeriesPaint(10, paint19);
        barRenderer0.setItemLabelAnchorOffset((double) 0);
        barRenderer0.setSeriesVisible((int) (short) 10, (java.lang.Boolean) true);
        barRenderer0.clearSeriesStrokes(false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers((int) '4', layer6);
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            categoryPlot0.addRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint3 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint4 = null;
        try {
            renderAttributes1.setDefaultLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(8.0d, (double) 0, (double) (short) 0, (double) '#');
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Color color1 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean14 = barRenderer0.isSeriesVisibleInLegend((int) (short) 100);
        barRenderer0.setShadowXOffset((double) 1L);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot4.getDomainGridlinePosition();
        categoryPlot4.clearDomainMarkers();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot8.getDatasetRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setDomainGridlineStroke(stroke11);
        java.awt.geom.GeneralPath generalPath13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.RenderingSource renderingSource15 = null;
        categoryPlot8.select(generalPath13, rectangle2D14, renderingSource15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot8.setDomainGridlinePaint((java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearRangeMarkers();
        boolean boolean21 = categoryPlot19.canSelectByPoint();
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot19.removeDomainMarker(2, marker23, layer24);
        categoryPlot8.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        double double27 = categoryPlot8.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot8.getRangeAxisEdge((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) categoryPlot4, rectangle2D7, rectangleEdge29, axisSpace30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        java.awt.Font font5 = barRenderer0.getSeriesItemLabelFont(2);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        barRenderer0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color7, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean30 = categoryPlot16.isRangeCrosshairLockedOnData();
        categoryPlot16.setRangePannable(false);
        boolean boolean33 = categoryPlot16.canSelectByRegion();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearRangeMarkers();
        int int10 = categoryPlot8.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot11.getDomainGridlinePosition();
        categoryPlot11.clearDomainMarkers();
        categoryPlot11.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot11.getDomainAxis((int) (short) -1);
        categoryPlot11.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis19.setTickLabelFont(font20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearRangeMarkers();
        categoryPlot22.setWeight(0);
        java.awt.Stroke stroke26 = categoryPlot22.getRangeMinorGridlineStroke();
        categoryAxis19.setTickMarkStroke(stroke26);
        float float28 = categoryAxis19.getTickMarkInsideLength();
        java.util.List list29 = categoryPlot11.getCategoriesForAxis(categoryAxis19);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D7, categoryPlot8, categoryAxis19, categoryMarker30, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        barRenderer0.setSeriesCreateEntities(10, (java.lang.Boolean) true);
        barRenderer0.setBaseItemLabelsVisible(true, true);
        java.awt.Stroke stroke28 = barRenderer0.getItemOutlineStroke(0, (int) (short) 0, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(sortOrder4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        java.awt.Font font27 = barRenderer23.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        barRenderer23.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator29, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        barRenderer23.setBaseShape(shape35);
        legendItem17.setShape(shape35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.lang.Boolean boolean43 = barRenderer40.getSeriesVisibleInLegend((-1));
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) boolean43);
        java.awt.Paint paint45 = defaultDrawingSupplier38.getNextPaint();
        legendItem17.setFillPaint(paint45);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes48 = barRenderer47.getSelectedItemAttributes();
        java.awt.Shape shape49 = null;
        barRenderer47.setBaseLegendShape(shape49);
        java.awt.Font font52 = barRenderer47.lookupLegendTextFont(0);
        barRenderer47.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes56 = barRenderer55.getSelectedItemAttributes();
        java.awt.Shape shape58 = barRenderer55.lookupLegendShape((int) 'a');
        barRenderer47.setBaseLegendShape(shape58);
        legendItem17.setShape(shape58);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(renderAttributes48);
        org.junit.Assert.assertNull(font52);
        org.junit.Assert.assertNotNull(renderAttributes56);
        org.junit.Assert.assertNotNull(shape58);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        double double19 = categoryPlot0.getAnchorValue();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 0.05d, true);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Font font4 = null;
        barRenderer0.setLegendTextFont(10, font4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator6, true);
        java.awt.Paint paint12 = barRenderer0.getItemOutlinePaint((int) ' ', 0, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearRangeMarkers();
        java.awt.Stroke stroke18 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis19.setTickLabelFont(font20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape29 = null;
        barRenderer27.setBaseLegendShape(shape29);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator32 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer27.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator32);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = barRenderer34.getSelectedItemAttributes();
        java.awt.Shape shape37 = barRenderer34.lookupLegendShape((int) 'a');
        java.awt.Font font38 = barRenderer34.getBaseItemLabelFont();
        barRenderer27.setBaseItemLabelFont(font38, false);
        java.awt.Paint paint41 = barRenderer27.getBaseItemLabelPaint();
        java.awt.Paint paint43 = barRenderer27.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        categoryPlot46.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor49 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot46.setDomainGridlinePosition(categoryAnchor49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer57 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes58 = barRenderer57.getSelectedItemAttributes();
        java.awt.Shape shape59 = null;
        barRenderer57.setBaseLegendShape(shape59);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator62 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer57.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator62);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator67 = barRenderer57.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator68 = null;
        barRenderer57.setBaseItemLabelGenerator(categoryItemLabelGenerator68);
        boolean boolean70 = barRenderer57.isDrawBarOutline();
        java.awt.Graphics2D graphics2D71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor74 = categoryPlot73.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder75 = categoryPlot73.getDatasetRenderingOrder();
        java.awt.Stroke stroke76 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot73.setDomainGridlineStroke(stroke76);
        java.awt.geom.GeneralPath generalPath78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.RenderingSource renderingSource80 = null;
        categoryPlot73.select(generalPath78, rectangle2D79, renderingSource80);
        org.jfree.data.category.CategoryDataset categoryDataset82 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState84 = barRenderer57.initialise(graphics2D71, rectangle2D72, categoryPlot73, categoryDataset82, plotRenderingInfo83);
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = barRenderer27.createHotSpotBounds(graphics2D44, rectangle2D45, categoryPlot46, categoryAxis51, valueAxis52, categoryDataset53, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState84, rectangle2D85);
        try {
            java.awt.Shape shape87 = barRenderer0.createHotSpotShape(graphics2D14, rectangle2D15, categoryPlot16, categoryAxis19, valueAxis22, categoryDataset23, 0, (int) 'a', false, categoryItemRendererState84);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(renderAttributes35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(categoryAnchor49);
        org.junit.Assert.assertNotNull(renderAttributes58);
        org.junit.Assert.assertNull(categoryURLGenerator67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(categoryAnchor74);
        org.junit.Assert.assertNotNull(datasetRenderingOrder75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(categoryItemRendererState84);
        org.junit.Assert.assertNull(rectangle2D86);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = categoryPlot7.getDatasetRenderingOrder();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot7.setDomainGridlineStroke(stroke10);
        categoryPlot0.setOutlineStroke(stroke10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = barRenderer14.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = null;
        barRenderer14.setBaseItemLabelGenerator(categoryItemLabelGenerator25);
        boolean boolean27 = barRenderer14.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        barRenderer14.setSeriesPositiveItemLabelPosition(2, itemLabelPosition31, true);
        try {
            categoryPlot0.setRenderer((int) (byte) -1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNull(categoryURLGenerator24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        barRenderer0.setBaseCreateEntities(true, false);
        java.awt.Paint paint27 = barRenderer0.getItemPaint((int) 'a', (int) (byte) -1, false);
        double double28 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        try {
            barRenderer0.setSeriesToolTipGenerator((int) (short) -1, categoryToolTipGenerator30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        java.awt.Paint paint11 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator(2, color1, (float) ' ', (-20561), (double) 0.0f);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        int int7 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 192 + "'", int7 == 192);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) 0.0f, (java.lang.Comparable) "TextAnchor.HALF_ASCENT_LEFT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (0.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        legendItem17.setOutlinePaint(paint21);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        barRenderer23.setGradientPaintTransformer(gradientPaintTransformer24);
        barRenderer23.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.lang.Boolean boolean32 = renderAttributes31.getDefaultCreateEntity();
        java.awt.Paint paint34 = renderAttributes31.getSeriesFillPaint(2);
        java.awt.Paint paint37 = renderAttributes31.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes40 = barRenderer39.getSelectedItemAttributes();
        java.awt.Shape shape42 = barRenderer39.lookupLegendShape((int) 'a');
        java.awt.Font font43 = barRenderer39.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator45 = null;
        barRenderer39.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator45, false);
        java.awt.Stroke stroke48 = barRenderer39.getBaseStroke();
        renderAttributes31.setSeriesStroke((int) (short) 100, stroke48);
        barRenderer23.setSeriesOutlineStroke((int) 'a', stroke48, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator52 = null;
        barRenderer23.setBaseURLGenerator(categoryURLGenerator52);
        boolean boolean54 = legendItem17.equals((java.lang.Object) categoryURLGenerator52);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(renderAttributes40);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        java.awt.Stroke stroke18 = barRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarPainter barPainter19 = barRenderer0.getBarPainter();
        java.awt.Stroke stroke20 = null;
        try {
            barRenderer0.setBaseOutlineStroke(stroke20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(barPainter19);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        barRenderer0.clearSeriesStrokes(true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint24 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        java.awt.Shape shape26 = barRenderer0.getLegendShape((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = categoryPlot31.getDomainGridlinePosition();
        categoryPlot29.setParent((org.jfree.chart.plot.Plot) categoryPlot31);
        java.awt.Font font34 = categoryPlot29.getNoDataMessageFont();
        categoryPlot29.clearDomainMarkers();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        try {
            barRenderer0.drawBackground(graphics2D28, categoryPlot29, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(shape26);
        org.junit.Assert.assertNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(categoryAnchor32);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        categoryPlot0.setNotify(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.lang.Boolean boolean11 = barRenderer8.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        barRenderer8.setSeriesOutlineStroke((int) 'a', stroke14, true);
        java.awt.Paint paint17 = barRenderer8.getBaseFillPaint();
        try {
            categoryPlot0.setRenderer((-12517377), (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        java.awt.Font font5 = barRenderer0.getSeriesItemLabelFont(2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(font5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        java.lang.String str5 = categoryPlot0.getPlotType();
        java.awt.Paint paint6 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean5 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setBaseShapesVisible(false);
        boolean boolean8 = lineAndShapeRenderer2.getDrawOutlines();
        boolean boolean11 = lineAndShapeRenderer2.getItemLineVisible((int) (byte) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Font font15 = barRenderer0.getSeriesItemLabelFont(2);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Paint paint19 = barRenderer0.lookupSeriesPaint((int) (short) 100);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot0.clearDomainMarkers();
        java.awt.Paint paint9 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("java.awt.Color[r=0,g=192,b=192]");
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem((int) (byte) 0, 0);
        java.awt.Paint paint15 = barRenderer0.getBaseLegendTextPaint();
        java.awt.Font font16 = barRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(font16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = barRenderer11.getSelectedItemAttributes();
        java.lang.Boolean boolean13 = renderAttributes12.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer14.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer14.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes26 = barRenderer25.getSelectedItemAttributes();
        java.awt.Shape shape27 = null;
        barRenderer25.setBaseLegendShape(shape27);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator30 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer25.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator30);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        java.awt.Font font36 = barRenderer32.getBaseItemLabelFont();
        barRenderer25.setBaseItemLabelFont(font36, false);
        barRenderer14.setBaseItemLabelFont(font36);
        renderAttributes12.setDefaultLabelFont(font36);
        categoryPlot0.setNoDataMessageFont(font36);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(renderAttributes12);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(renderAttributes26);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        java.awt.Shape shape20 = barRenderer0.lookupLegendShape(0);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Paint paint3 = barRenderer0.getSeriesItemLabelPaint((int) (short) -1);
        barRenderer0.setMaximumBarWidth((double) '4');
        barRenderer0.setBaseItemLabelsVisible(false, true);
        java.awt.Paint paint12 = barRenderer0.getItemPaint(0, (int) (short) 0, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setSeriesOutlinePaint(192, paint15, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Color color17 = java.awt.Color.red;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) itemLabelAnchor3);
        try {
            java.lang.Object obj6 = keyedObjects0.getObject((java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key () is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        int int3 = lineAndShapeRenderer2.getPassCount();
        boolean boolean4 = lineAndShapeRenderer2.getBaseLinesVisible();
        int int5 = lineAndShapeRenderer2.getColumnCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        java.lang.String str5 = categoryPlot0.getPlotType();
        java.awt.Image image6 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "hi!");
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = java.awt.Color.black;
        float[] floatArray7 = new float[] { (short) 1, 100, 2, 100, 'a', '#' };
        float[] floatArray8 = color0.getComponents(floatArray7);
        java.awt.Color color9 = color0.brighter();
        java.awt.Color color10 = color9.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(0);
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.data.general.DatasetGroup datasetGroup19 = categoryPlot11.getDatasetGroup();
        java.lang.Comparable comparable20 = null;
        categoryPlot11.setDomainCrosshairRowKey(comparable20);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(datasetGroup19);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        lineAndShapeRenderer2.setBaseShapesFilled(true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        barRenderer2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint8 = barRenderer2.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint10 = barRenderer2.getSeriesOutlinePaint(100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer2.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color12, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray22 = new float[] { (-1L), 100.0f, (short) 1, (short) -1, 100L, 'a' };
        float[] floatArray23 = color15.getColorComponents(floatArray22);
        float[] floatArray24 = color12.getColorComponents(floatArray23);
        objectList0.set(0, (java.lang.Object) color12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes27 = barRenderer26.getSelectedItemAttributes();
        java.awt.Shape shape28 = null;
        barRenderer26.setBaseLegendShape(shape28);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator31 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer26.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator31);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes34 = barRenderer33.getSelectedItemAttributes();
        java.awt.Shape shape36 = barRenderer33.lookupLegendShape((int) 'a');
        java.awt.Font font37 = barRenderer33.getBaseItemLabelFont();
        barRenderer26.setBaseItemLabelFont(font37, false);
        java.awt.Paint paint40 = barRenderer26.getBaseItemLabelPaint();
        java.awt.Paint paint42 = barRenderer26.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke44 = barRenderer26.lookupSeriesStroke(10);
        int int45 = objectList0.indexOf((java.lang.Object) barRenderer26);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(renderAttributes27);
        org.junit.Assert.assertNotNull(renderAttributes34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer(2);
        java.lang.Object obj7 = categoryPlot0.clone();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 4);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = barRenderer1.getSelectedItemAttributes();
        java.awt.Font font3 = renderAttributes2.getDefaultLabelFont();
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) font3);
        double double5 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(renderAttributes2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        barRenderer0.setBaseLegendShape(shape11);
        boolean boolean14 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes16 = barRenderer15.getSelectedItemAttributes();
        java.awt.Shape shape17 = null;
        barRenderer15.setBaseLegendShape(shape17);
        java.awt.Font font20 = barRenderer15.lookupLegendTextFont(0);
        barRenderer15.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        barRenderer15.setBaseLegendShape(shape26);
        barRenderer0.setBaseShape(shape26, false);
        try {
            barRenderer0.setSeriesVisibleInLegend((-12517377), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(renderAttributes16);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint(100);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = categoryPlot12.getDomainGridlinePosition();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot12);
        categoryPlot12.setRangeCrosshairValue((double) (short) 10);
        categoryPlot12.configureDomainAxes();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.lang.Boolean boolean22 = renderAttributes21.getDefaultCreateEntity();
        java.awt.Paint paint24 = renderAttributes21.getSeriesPaint(1);
        java.awt.Paint paint27 = renderAttributes21.getItemFillPaint((int) (byte) 1, (int) (byte) 100);
        java.awt.Paint paint28 = renderAttributes21.getDefaultFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes30 = barRenderer29.getSelectedItemAttributes();
        java.lang.Boolean boolean32 = barRenderer29.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        barRenderer29.setSeriesOutlineStroke((int) 'a', stroke35, true);
        try {
            barRenderer0.drawDomainLine(graphics2D9, categoryPlot12, rectangle2D18, (double) 'a', paint28, stroke35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(renderAttributes30);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer9.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator15, false);
        java.awt.Stroke stroke18 = barRenderer9.getBaseStroke();
        renderAttributes1.setSeriesStroke((int) (short) 100, stroke18);
        try {
            renderAttributes1.setSeriesCreateEntity((-20561), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = barRenderer5.getSelectedItemAttributes();
        java.awt.Shape shape7 = null;
        barRenderer5.setBaseLegendShape(shape7);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer5.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer5.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer5.setBaseItemLabelGenerator(categoryItemLabelGenerator16);
        boolean boolean18 = barRenderer5.isDrawBarOutline();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot21.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot21.getDatasetRenderingOrder();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot21.setDomainGridlineStroke(stroke24);
        java.awt.geom.GeneralPath generalPath26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.RenderingSource renderingSource28 = null;
        categoryPlot21.select(generalPath26, rectangle2D27, renderingSource28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = barRenderer5.initialise(graphics2D19, rectangle2D20, categoryPlot21, categoryDataset30, plotRenderingInfo31);
        categoryPlot21.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean35 = categoryPlot21.isRangeCrosshairLockedOnData();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        java.lang.Comparable comparable37 = null;
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = categoryPlot42.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = categoryPlot42.getDatasetRenderingOrder();
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot42.setDomainGridlineStroke(stroke45);
        java.awt.geom.GeneralPath generalPath47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.RenderingSource renderingSource49 = null;
        categoryPlot42.select(generalPath47, rectangle2D48, renderingSource49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot42.setDomainGridlinePaint((java.awt.Paint) color51);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot53.clearRangeMarkers();
        boolean boolean55 = categoryPlot53.canSelectByPoint();
        org.jfree.chart.plot.Marker marker57 = null;
        org.jfree.chart.util.Layer layer58 = null;
        boolean boolean59 = categoryPlot53.removeDomainMarker(2, marker57, layer58);
        categoryPlot42.setParent((org.jfree.chart.plot.Plot) categoryPlot53);
        double double61 = categoryPlot42.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot42.getRangeAxisEdge((int) ' ');
        try {
            double double64 = categoryAxis0.getCategorySeriesMiddle(comparable37, (java.lang.Comparable) true, categoryDataset39, (double) 0, rectangle2D41, rectangleEdge63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(renderAttributes6);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(categoryItemRendererState32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(categoryAnchor43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer0.getSeriesToolTipGenerator(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getSeriesNegativeItemLabelPosition((int) 'a');
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Color color1 = java.awt.Color.getColor("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        java.awt.Font font5 = barRenderer0.getSeriesItemLabelFont(2);
        boolean boolean6 = barRenderer0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot8.getDatasetRenderingOrder();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setDomainGridlineStroke(stroke11);
        java.awt.geom.GeneralPath generalPath13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.RenderingSource renderingSource15 = null;
        categoryPlot8.select(generalPath13, rectangle2D14, renderingSource15);
        boolean boolean17 = categoryPlot8.getDrawSharedDomainAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            barRenderer0.drawOutline(graphics2D7, categoryPlot8, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setCategoryLabelPositionOffset(192);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Paint paint2 = barRenderer0.getBasePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(100, categoryURLGenerator4);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean30 = categoryPlot16.isRangeCrosshairLockedOnData();
        java.lang.Comparable comparable31 = null;
        categoryPlot16.setDomainCrosshairRowKey(comparable31, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        try {
            keyedObjects0.removeValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getToolTipGenerator(10, (int) '#', true);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator19);
        java.awt.Stroke stroke22 = barRenderer0.getSeriesOutlineStroke((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis23.setTickLabelFont(font24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearRangeMarkers();
        categoryPlot26.setWeight(0);
        java.awt.Stroke stroke30 = categoryPlot26.getRangeMinorGridlineStroke();
        categoryAxis23.setTickMarkStroke(stroke30);
        barRenderer0.setBaseOutlineStroke(stroke30);
        barRenderer0.setSeriesVisible((int) 'a', (java.lang.Boolean) false);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        categoryPlot17.clearDomainMarkers();
        categoryPlot17.setCrosshairDatasetIndex((int) (short) -1);
        barRenderer0.setPlot(categoryPlot17);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        barRenderer0.setBaseCreateEntities(false);
        barRenderer0.setBaseSeriesVisible(true, false);
        boolean boolean33 = barRenderer0.isItemLabelVisible((int) (short) 10, (int) (short) 1, false);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        double double19 = categoryPlot0.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot0.getRangeAxisEdge((int) ' ');
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) 100, categoryMarker23, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) '#', (double) 0L, (double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType7, lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition17);
        java.awt.Shape shape20 = barRenderer0.getSeriesShape((int) '#');
        barRenderer0.setSeriesVisibleInLegend((int) 'a', (java.lang.Boolean) true, true);
        barRenderer0.setItemMargin((double) 0L);
        int int27 = barRenderer0.getColumnCount();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes29 = barRenderer28.getSelectedItemAttributes();
        java.awt.Shape shape30 = null;
        barRenderer28.setBaseLegendShape(shape30);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator33 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer28.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator33);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = null;
        barRenderer28.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator36);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer28.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes40 = barRenderer39.getSelectedItemAttributes();
        java.awt.Shape shape41 = null;
        barRenderer39.setBaseLegendShape(shape41);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator44 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer39.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator44);
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes47 = barRenderer46.getSelectedItemAttributes();
        java.awt.Shape shape49 = barRenderer46.lookupLegendShape((int) 'a');
        java.awt.Font font50 = barRenderer46.getBaseItemLabelFont();
        barRenderer39.setBaseItemLabelFont(font50, false);
        barRenderer28.setBaseItemLabelFont(font50);
        barRenderer0.setBaseLegendTextFont(font50);
        java.awt.Paint paint58 = barRenderer0.getItemLabelPaint((int) (byte) 1, (int) (byte) 10, false);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(renderAttributes29);
        org.junit.Assert.assertNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(renderAttributes40);
        org.junit.Assert.assertNotNull(renderAttributes47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.lang.Boolean boolean5 = barRenderer2.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        barRenderer2.setSeriesOutlineStroke((int) 'a', stroke8, true);
        java.awt.Paint paint11 = barRenderer2.getBaseFillPaint();
        boolean boolean12 = axisLocation0.equals((java.lang.Object) barRenderer2);
        java.lang.String str13 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str13.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers();
        java.awt.Stroke stroke7 = categoryPlot5.getRangeZeroBaselineStroke();
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke7, false);
        boolean boolean12 = lineAndShapeRenderer2.getItemShapeVisible((int) (byte) 1, 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        java.awt.Paint paint11 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        java.awt.Paint paint15 = barRenderer0.getItemFillPaint((int) '#', (int) (byte) 0, false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=64,b=64]" + "'", str1.equals("java.awt.Color[r=255,g=64,b=64]"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = categoryPlot7.getDatasetRenderingOrder();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot7.setDomainGridlineStroke(stroke10);
        categoryPlot0.setOutlineStroke(stroke10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot13.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator15 = null;
        categoryPlot13.setShadowGenerator(shadowGenerator15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = categoryPlot13.getDrawingSupplier();
        java.awt.Paint paint18 = categoryPlot13.getDomainGridlinePaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint18);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor3);
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNull(comparable5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot19.getDomainGridlinePosition();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot19.setDomainGridlinePosition(categoryAnchor22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer30.setBaseItemLabelGenerator(categoryItemLabelGenerator41);
        boolean boolean43 = barRenderer30.isDrawBarOutline();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = categoryPlot46.getDatasetRenderingOrder();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot46.setDomainGridlineStroke(stroke49);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot46.select(generalPath51, rectangle2D52, renderingSource53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer30.initialise(graphics2D44, rectangle2D45, categoryPlot46, categoryDataset55, plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis25, categoryDataset26, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState57, rectangle2D58);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator61 = null;
        try {
            barRenderer0.setSeriesURLGenerator((-12517377), categoryURLGenerator61, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
        org.junit.Assert.assertNull(rectangle2D59);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Paint paint3 = barRenderer0.getSeriesItemLabelPaint((int) (short) -1);
        barRenderer0.setMaximumBarWidth((double) '4');
        barRenderer0.setBaseItemLabelsVisible(false, true);
        java.awt.Stroke stroke12 = barRenderer0.getItemStroke((int) (byte) 0, (int) (short) 1, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot19.getDomainGridlinePosition();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot19.setDomainGridlinePosition(categoryAnchor22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer30.setBaseItemLabelGenerator(categoryItemLabelGenerator41);
        boolean boolean43 = barRenderer30.isDrawBarOutline();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = categoryPlot46.getDatasetRenderingOrder();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot46.setDomainGridlineStroke(stroke49);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot46.select(generalPath51, rectangle2D52, renderingSource53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer30.initialise(graphics2D44, rectangle2D45, categoryPlot46, categoryDataset55, plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis25, categoryDataset26, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState57, rectangle2D58);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = categoryPlot19.getRenderer();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
        org.junit.Assert.assertNull(rectangle2D59);
        org.junit.Assert.assertNull(categoryItemRenderer60);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        java.awt.Color color5 = java.awt.Color.black;
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        double double6 = rectangleInsets4.calculateTopInset(0.0d);
        double double8 = rectangleInsets4.calculateLeftOutset((double) (-1.0f));
        double double9 = rectangleInsets4.getLeft();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        try {
            barRenderer0.setPlot(categoryPlot4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint1 = renderAttributes0.getDefaultFillPaint();
        org.junit.Assert.assertNull(paint1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator6, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        barRenderer0.setBaseShape(shape12);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape12, "", "DatasetRenderingOrder.REVERSE");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator19 = null;
        categoryPlot17.setShadowGenerator(shadowGenerator19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot17.getInsets();
        boolean boolean22 = chartEntity16.equals((java.lang.Object) categoryPlot17);
        chartEntity16.setURLText("hi!");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator25 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator26 = null;
        try {
            java.lang.String str27 = chartEntity16.getImageMapAreaTag(toolTipTagFragmentGenerator25, uRLTagFragmentGenerator26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        barRenderer3.setBaseItemLabelFont(font25);
        renderAttributes1.setDefaultLabelFont(font25);
        java.awt.Paint paint30 = renderAttributes1.getDefaultLabelPaint();
        try {
            java.lang.Boolean boolean33 = renderAttributes1.getCreateEntity((-20561), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        int int5 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        java.awt.Paint paint7 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot19.getDomainGridlinePosition();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot19.setDomainGridlinePosition(categoryAnchor22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer30.setBaseItemLabelGenerator(categoryItemLabelGenerator41);
        boolean boolean43 = barRenderer30.isDrawBarOutline();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = categoryPlot46.getDatasetRenderingOrder();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot46.setDomainGridlineStroke(stroke49);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot46.select(generalPath51, rectangle2D52, renderingSource53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer30.initialise(graphics2D44, rectangle2D45, categoryPlot46, categoryDataset55, plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis25, categoryDataset26, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState57, rectangle2D58);
        categoryPlot19.mapDatasetToDomainAxis((int) (byte) 100, (-12517377));
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        try {
            categoryPlot19.drawBackground(graphics2D63, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
        org.junit.Assert.assertNull(rectangle2D59);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Font font15 = barRenderer0.getSeriesItemLabelFont(2);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) false);
        boolean boolean8 = lineAndShapeRenderer2.getItemLineVisible(1, 2);
        boolean boolean11 = lineAndShapeRenderer2.getItemLineVisible(3, (int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator12, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        int int5 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6);
        java.awt.Shape shape8 = defaultDrawingSupplier6.getNextShape();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke4 = renderAttributes1.getSeriesStroke((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis10 };
        categoryPlot6.setDomainAxes(categoryAxisArray11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot6.zoomRangeAxes((double) 0, plotRenderingInfo14, point2D15, true);
        boolean boolean18 = categoryPlot6.isRangeGridlinesVisible();
        java.util.List list19 = categoryPlot6.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearRangeMarkers();
        java.awt.Stroke stroke22 = categoryPlot20.getRangeZeroBaselineStroke();
        categoryPlot6.setRangeMinorGridlineStroke(stroke22);
        renderAttributes1.setSeriesStroke((int) (byte) 1, stroke22);
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        try {
            keyedObjects2D0.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        keyedObjects2D0.setObject((java.lang.Object) stroke1, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 1L);
        try {
            java.lang.Object obj7 = keyedObjects2D0.getObject(1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 192, (double) 100L, (double) (short) 10, 0.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        categoryAxis0.setMinorTickMarkOutsideLength((float) (byte) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot15.zoomRangeAxes((double) 0, plotRenderingInfo23, point2D24, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot15.getRangeAxisEdge();
        try {
            double double28 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor11, 2, (int) ' ', rectangle2D14, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        int int30 = categoryPlot16.getWeight();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.Point2D point2D33 = null;
        org.jfree.chart.plot.PlotState plotState34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            categoryPlot16.draw(graphics2D31, rectangle2D32, point2D33, plotState34, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setRangeCrosshairValue((double) 1, true);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (short) -1);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis8.setTickLabelFont(font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.setWeight(0);
        java.awt.Stroke stroke15 = categoryPlot11.getRangeMinorGridlineStroke();
        categoryAxis8.setTickMarkStroke(stroke15);
        float float17 = categoryAxis8.getTickMarkInsideLength();
        java.util.List list18 = categoryPlot0.getCategoriesForAxis(categoryAxis8);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            categoryAxis8.setLabelInsets(rectangleInsets19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke15, false);
        boolean boolean21 = barRenderer0.isItemLabelVisible((int) (byte) 0, (int) (short) 0, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        barRenderer0.setItemMargin((double) 1);
        barRenderer0.setShadowYOffset(101.0d);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint((int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = null;
        barRenderer6.setGradientPaintTransformer(gradientPaintTransformer7);
        barRenderer6.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer6.getBasePositiveItemLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes29 = barRenderer28.getSelectedItemAttributes();
        java.awt.Shape shape30 = null;
        barRenderer28.setBaseLegendShape(shape30);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator33 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer28.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes36 = barRenderer35.getSelectedItemAttributes();
        java.awt.Shape shape38 = barRenderer35.lookupLegendShape((int) 'a');
        java.awt.Font font39 = barRenderer35.getBaseItemLabelFont();
        barRenderer28.setBaseItemLabelFont(font39, false);
        java.awt.Shape shape45 = barRenderer28.getItemShape((int) (byte) 10, 3, false);
        org.jfree.chart.entity.ChartEntity chartEntity48 = new org.jfree.chart.entity.ChartEntity(shape45, "hi!", "java.awt.Color[r=64,g=64,b=64]");
        barRenderer14.setBaseShape(shape45, false);
        barRenderer6.setSeriesShape((int) '4', shape45);
        renderAttributes1.setSeriesShape((int) (short) 10, shape45);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(renderAttributes29);
        org.junit.Assert.assertNotNull(renderAttributes36);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator6, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        barRenderer0.setBaseShape(shape12);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape12, "", "DatasetRenderingOrder.REVERSE");
        java.lang.Object obj17 = chartEntity16.clone();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator18 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator19 = null;
        try {
            java.lang.String str20 = chartEntity16.getImageMapAreaTag(toolTipTagFragmentGenerator18, uRLTagFragmentGenerator19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (-20561), true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        boolean boolean12 = barRenderer0.isSeriesVisibleInLegend((-20561));
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        double double5 = rectangleInsets4.getBottom();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets4.createInsetRectangle(rectangle2D6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator2, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        java.awt.Paint paint11 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = null;
        barRenderer14.setGradientPaintTransformer(gradientPaintTransformer15);
        barRenderer14.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer14.getBasePositiveItemLabelPosition();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition20);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator8);
        boolean boolean12 = lineAndShapeRenderer2.getItemLineVisible(4, 10);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot0.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        lineAndShapeRenderer2.setItemLabelAnchorOffset((double) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer2.getBaseURLGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        java.awt.Shape shape4 = lineAndShapeRenderer2.lookupSeriesShape(1);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        barRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot20.getDomainGridlinePosition();
        categoryPlot20.clearDomainMarkers();
        categoryPlot20.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryPlot20.equals(obj25);
        categoryPlot20.setRangeCrosshairValue((double) '#');
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        categoryPlot20.setRangeCrosshairValue((double) (byte) -1, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.setWeight((int) (byte) 1);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addRangeMarker((-1), marker14, layer15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            java.awt.Color color1 = java.awt.Color.decode("SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SortOrder.ASCENDING\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = barRenderer0.getURLGenerator((int) (byte) 100, (int) 'a', true);
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryURLGenerator12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = barRenderer20.getSelectedItemAttributes();
        java.lang.Boolean boolean22 = renderAttributes21.getDefaultCreateEntity();
        java.awt.Paint paint24 = renderAttributes21.getSeriesPaint(1);
        java.awt.Paint paint27 = renderAttributes21.getItemFillPaint((int) (byte) 1, (int) (byte) 100);
        try {
            barRenderer0.setSeriesItemLabelPaint((int) (byte) -1, paint27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(renderAttributes21);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint(100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color10, false);
        java.awt.Paint paint14 = barRenderer0.lookupSeriesFillPaint(0);
        barRenderer0.removeAnnotations();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot21.getDomainGridlinePosition();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.chart.util.ShadowGenerator shadowGenerator24 = null;
        categoryPlot19.setShadowGenerator(shadowGenerator24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot26.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = categoryPlot26.getDatasetRenderingOrder();
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot26.setDomainGridlineStroke(stroke29);
        categoryPlot19.setOutlineStroke(stroke29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        try {
            barRenderer0.drawItem(graphics2D16, categoryItemRendererState17, rectangle2D18, categoryPlot19, categoryAxis32, valueAxis33, categoryDataset34, (int) (byte) -1, (int) (byte) 1, false, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        java.lang.String str5 = categoryPlot0.getPlotType();
        java.awt.Image image6 = categoryPlot0.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        int int8 = categoryPlot0.indexOf(categoryDataset7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        java.lang.String str10 = plotChangeEvent9.toString();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape11 = barRenderer8.lookupLegendShape((int) 'a');
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color13 = color12.brighter();
        java.awt.Color color14 = color13.darker();
        java.awt.Color color15 = color13.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearRangeMarkers();
        java.awt.Stroke stroke18 = categoryPlot16.getRangeZeroBaselineStroke();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color20 = color19.brighter();
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape11, (java.awt.Paint) color13, stroke18, (java.awt.Paint) color20);
        boolean boolean22 = legendItem21.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextOutlineStroke();
        java.awt.Paint paint25 = defaultDrawingSupplier23.getNextPaint();
        legendItem21.setOutlinePaint(paint25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape30 = barRenderer27.lookupLegendShape((int) 'a');
        legendItem21.setShape(shape30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.clearRangeMarkers();
        categoryPlot33.setWeight(0);
        java.awt.Stroke stroke37 = categoryPlot33.getRangeMinorGridlineStroke();
        java.awt.Color color38 = java.awt.Color.yellow;
        try {
            org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem(attributedString0, "AxisLocation.TOP_OR_RIGHT", "", "", shape30, (java.awt.Paint) color32, stroke37, (java.awt.Paint) color38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = barRenderer0.getPlot();
        barRenderer0.clearSeriesStrokes(false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot18);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        float float9 = categoryAxis0.getTickMarkInsideLength();
        boolean boolean10 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot19.getDomainGridlinePosition();
        categoryPlot19.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot19.setDomainGridlinePosition(categoryAnchor22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = barRenderer30.getSelectedItemAttributes();
        java.awt.Shape shape32 = null;
        barRenderer30.setBaseLegendShape(shape32);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer30.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator35);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = barRenderer30.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer30.setBaseItemLabelGenerator(categoryItemLabelGenerator41);
        boolean boolean43 = barRenderer30.isDrawBarOutline();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = categoryPlot46.getDatasetRenderingOrder();
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot46.setDomainGridlineStroke(stroke49);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot46.select(generalPath51, rectangle2D52, renderingSource53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer30.initialise(graphics2D44, rectangle2D45, categoryPlot46, categoryDataset55, plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = barRenderer0.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis25, categoryDataset26, (int) (byte) 10, (int) (byte) 10, false, categoryItemRendererState57, rectangle2D58);
        org.jfree.chart.renderer.category.BarRenderer barRenderer61 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes62 = barRenderer61.getSelectedItemAttributes();
        java.awt.Shape shape63 = null;
        barRenderer61.setBaseLegendShape(shape63);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator66 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer61.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator66);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator71 = barRenderer61.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint73 = barRenderer61.lookupSeriesPaint(0);
        barRenderer0.setLegendTextPaint(100, paint73);
        java.awt.Color color75 = java.awt.Color.orange;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color75);
        java.awt.Paint paint80 = barRenderer0.getItemFillPaint(0, 0, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(renderAttributes31);
        org.junit.Assert.assertNull(categoryURLGenerator40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
        org.junit.Assert.assertNull(rectangle2D59);
        org.junit.Assert.assertNotNull(renderAttributes62);
        org.junit.Assert.assertNull(categoryURLGenerator71);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(paint80);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(4, (int) (short) 100, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = barRenderer5.getSelectedItemAttributes();
        java.awt.Shape shape7 = null;
        barRenderer5.setBaseLegendShape(shape7);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer5.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer5.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer5.setBaseItemLabelGenerator(categoryItemLabelGenerator16);
        boolean boolean18 = barRenderer5.isDrawBarOutline();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot21.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot21.getDatasetRenderingOrder();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot21.setDomainGridlineStroke(stroke24);
        java.awt.geom.GeneralPath generalPath26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.RenderingSource renderingSource28 = null;
        categoryPlot21.select(generalPath26, rectangle2D27, renderingSource28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = barRenderer5.initialise(graphics2D19, rectangle2D20, categoryPlot21, categoryDataset30, plotRenderingInfo31);
        categoryPlot21.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean35 = categoryPlot21.isRangeCrosshairLockedOnData();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        categoryPlot21.setDomainCrosshairRowKey((java.lang.Comparable) 0, true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(renderAttributes6);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(categoryItemRendererState32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.awt.Paint paint19 = barRenderer17.getBasePaint();
        barRenderer0.setSeriesPaint(10, paint19);
        barRenderer0.setItemLabelAnchorOffset((double) 0);
        barRenderer0.setShadowVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = null;
        barRenderer26.setGradientPaintTransformer(gradientPaintTransformer27);
        java.awt.Paint paint32 = barRenderer26.getItemPaint((int) (short) 1, (int) (short) 0, true);
        barRenderer0.setSeriesFillPaint(0, paint32);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double11 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = barRenderer13.getSelectedItemAttributes();
        java.lang.Boolean boolean16 = barRenderer13.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        barRenderer13.setSeriesOutlineStroke((int) 'a', stroke19, true);
        java.awt.Paint paint22 = barRenderer13.getBaseFillPaint();
        barRenderer0.setSeriesFillPaint((int) ' ', paint22, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(renderAttributes14);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        barRenderer0.setSeriesToolTipGenerator(4, categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint(100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color10, false);
        java.awt.Paint paint14 = barRenderer0.lookupSeriesFillPaint(0);
        boolean boolean15 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getLabelPaint();
        java.awt.Stroke stroke19 = legendItem17.getOutlineStroke();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getColumnKey((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        java.util.List list3 = keyedObjects0.getKeys();
        java.lang.Comparable comparable4 = null;
        java.lang.Object obj5 = null;
        try {
            keyedObjects0.addObject(comparable4, obj5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Object obj6 = lineAndShapeRenderer2.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer2.setBasePaint(paint7, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape6 = null;
        barRenderer4.setBaseLegendShape(shape6);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = barRenderer11.getSelectedItemAttributes();
        java.awt.Shape shape14 = barRenderer11.lookupLegendShape((int) 'a');
        java.awt.Font font15 = barRenderer11.getBaseItemLabelFont();
        barRenderer4.setBaseItemLabelFont(font15, false);
        java.awt.Paint paint18 = barRenderer4.getBaseItemLabelPaint();
        barRenderer4.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Paint paint23 = barRenderer21.getBasePaint();
        barRenderer4.setSeriesPaint(10, paint23);
        barRenderer4.setItemLabelAnchorOffset((double) 0);
        java.awt.Paint paint30 = barRenderer4.getItemFillPaint((-12517377), (int) (short) -1, false);
        paintList0.setPaint(0, paint30);
        java.awt.Paint paint33 = paintList0.getPaint((int) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = barRenderer34.getSelectedItemAttributes();
        java.awt.Shape shape36 = null;
        barRenderer34.setBaseLegendShape(shape36);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator39 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer34.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator39);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes42 = barRenderer41.getSelectedItemAttributes();
        java.awt.Shape shape44 = barRenderer41.lookupLegendShape((int) 'a');
        java.awt.Font font45 = barRenderer41.getBaseItemLabelFont();
        barRenderer34.setBaseItemLabelFont(font45, false);
        java.awt.Paint paint48 = barRenderer34.getBaseItemLabelPaint();
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer34.setBaseOutlineStroke(stroke49, false);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        barRenderer34.setSeriesOutlineStroke((int) (byte) 0, stroke53);
        boolean boolean55 = paintList0.equals((java.lang.Object) barRenderer34);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(renderAttributes12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(renderAttributes35);
        org.junit.Assert.assertNotNull(renderAttributes42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.awt.Paint paint19 = barRenderer17.getBasePaint();
        barRenderer0.setSeriesPaint(10, paint19);
        barRenderer0.setItemLabelAnchorOffset((double) 0);
        java.awt.Paint paint26 = barRenderer0.getItemFillPaint((-12517377), (int) (short) -1, false);
        java.awt.Paint paint28 = barRenderer0.getSeriesPaint(1);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot8.getDomainGridlinePosition();
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        categoryPlot8.setRangeCrosshairValue((double) (short) 10);
        try {
            keyedObjects0.insertValue((int) (byte) 10, (java.lang.Comparable) 0, (java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setShapeVisible(true);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_RED;
        legendItem17.setOutlinePaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem((int) (byte) 0, 0);
        java.awt.Paint paint15 = barRenderer0.getBaseLegendTextPaint();
        java.awt.Paint paint19 = barRenderer0.getItemLabelPaint(0, (int) (byte) -1, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot0.addRangeMarker(marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        boolean boolean7 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke15, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = barRenderer18.getSelectedItemAttributes();
        java.awt.Shape shape20 = null;
        barRenderer18.setBaseLegendShape(shape20);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator23 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer18.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes26 = barRenderer25.getSelectedItemAttributes();
        java.awt.Shape shape28 = barRenderer25.lookupLegendShape((int) 'a');
        java.awt.Font font29 = barRenderer25.getBaseItemLabelFont();
        barRenderer18.setBaseItemLabelFont(font29, false);
        java.awt.Paint paint32 = barRenderer18.getBaseItemLabelPaint();
        barRenderer18.removeAnnotations();
        java.awt.Color color34 = java.awt.Color.black;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color34, false);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color34, true);
        java.lang.Boolean boolean40 = barRenderer0.getSeriesVisibleInLegend(2);
        barRenderer0.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Shape shape45 = barRenderer0.lookupSeriesShape((-20561));
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(renderAttributes19);
        org.junit.Assert.assertNotNull(renderAttributes26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(boolean40);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Shape shape11 = barRenderer0.getBaseShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.awt.Shape shape20 = barRenderer17.lookupLegendShape((int) 'a');
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color22 = color21.brighter();
        java.awt.Color color23 = color22.darker();
        java.awt.Color color24 = color22.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearRangeMarkers();
        java.awt.Stroke stroke27 = categoryPlot25.getRangeZeroBaselineStroke();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color29 = color28.brighter();
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape20, (java.awt.Paint) color22, stroke27, (java.awt.Paint) color29);
        boolean boolean31 = legendItem30.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke33 = defaultDrawingSupplier32.getNextOutlineStroke();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextPaint();
        legendItem30.setOutlinePaint(paint34);
        java.awt.Stroke stroke36 = legendItem30.getOutlineStroke();
        java.awt.Shape shape37 = legendItem30.getShape();
        barRenderer0.setLegendShape(1, shape37);
        java.awt.Shape shape40 = barRenderer0.getLegendShape((int) (short) -1);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(shape40);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint6 = barRenderer0.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint(100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color10, false);
        java.awt.Paint paint14 = barRenderer0.lookupSeriesFillPaint(0);
        barRenderer0.setBaseItemLabelsVisible(false, false);
        barRenderer0.setSeriesItemLabelsVisible((int) ' ', (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        int int6 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        lineAndShapeRenderer2.setDrawOutlines(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        int int28 = barRenderer0.getDefaultEntityRadius();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer29);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        int int1 = strokeList0.size();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        barRenderer2.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator10);
        boolean boolean12 = strokeList0.equals((java.lang.Object) 0);
        java.awt.Stroke stroke14 = strokeList0.getStroke((int) (short) 1);
        int int15 = strokeList0.size();
        java.awt.Stroke stroke17 = strokeList0.getStroke((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(stroke17);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        java.awt.Font font5 = barRenderer0.getSeriesItemLabelFont(2);
        boolean boolean6 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.util.PaintList paintList8 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint10 = paintList8.getPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes13 = barRenderer12.getSelectedItemAttributes();
        java.awt.Shape shape14 = null;
        barRenderer12.setBaseLegendShape(shape14);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer12.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = barRenderer19.getSelectedItemAttributes();
        java.awt.Shape shape22 = barRenderer19.lookupLegendShape((int) 'a');
        java.awt.Font font23 = barRenderer19.getBaseItemLabelFont();
        barRenderer12.setBaseItemLabelFont(font23, false);
        java.awt.Paint paint26 = barRenderer12.getBaseItemLabelPaint();
        barRenderer12.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes30 = barRenderer29.getSelectedItemAttributes();
        java.awt.Paint paint31 = barRenderer29.getBasePaint();
        barRenderer12.setSeriesPaint(10, paint31);
        barRenderer12.setItemLabelAnchorOffset((double) 0);
        java.awt.Paint paint38 = barRenderer12.getItemFillPaint((-12517377), (int) (short) -1, false);
        paintList8.setPaint(0, paint38);
        try {
            barRenderer0.setSeriesOutlinePaint((int) (short) -1, paint38, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(renderAttributes13);
        org.junit.Assert.assertNotNull(renderAttributes20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(renderAttributes30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        java.awt.Font font27 = barRenderer23.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        barRenderer23.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator29, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        barRenderer23.setBaseShape(shape35);
        legendItem17.setShape(shape35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.lang.Boolean boolean43 = barRenderer40.getSeriesVisibleInLegend((-1));
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) boolean43);
        java.awt.Paint paint45 = defaultDrawingSupplier38.getNextPaint();
        legendItem17.setFillPaint(paint45);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes48 = barRenderer47.getSelectedItemAttributes();
        java.lang.Boolean boolean49 = renderAttributes48.getDefaultCreateEntity();
        java.awt.Paint paint51 = renderAttributes48.getSeriesFillPaint(2);
        java.awt.Paint paint54 = renderAttributes48.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes57 = barRenderer56.getSelectedItemAttributes();
        java.awt.Shape shape59 = barRenderer56.lookupLegendShape((int) 'a');
        java.awt.Font font60 = barRenderer56.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        barRenderer56.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator62, false);
        java.awt.Stroke stroke65 = barRenderer56.getBaseStroke();
        renderAttributes48.setSeriesStroke((int) (short) 100, stroke65);
        boolean boolean67 = legendItem17.equals((java.lang.Object) (short) 100);
        org.jfree.chart.util.UnitType unitType68 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Shape shape69 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        boolean boolean70 = unitType68.equals((java.lang.Object) shape69);
        legendItem17.setLine(shape69);
        boolean boolean72 = legendItem17.isShapeVisible();
        int int73 = legendItem17.getSeriesIndex();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(renderAttributes48);
        org.junit.Assert.assertNull(boolean49);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(renderAttributes57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(unitType68);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint3 = barRenderer0.getBasePaint();
        double double4 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        barRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape10 = barRenderer0.lookupLegendShape((int) (byte) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        java.awt.Paint paint14 = defaultDrawingSupplier12.getNextPaint();
        barRenderer0.setLegendTextPaint(0, paint14);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator16, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryPlot0.equals(obj5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        categoryPlot0.setRangeCrosshairValue((double) '#');
        java.lang.String str11 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint15, true);
        boolean boolean20 = barRenderer0.getItemVisible((int) (byte) 0, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes28 = barRenderer27.getSelectedItemAttributes();
        java.awt.Shape shape30 = barRenderer27.lookupLegendShape((int) 'a');
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color32 = color31.brighter();
        java.awt.Color color33 = color32.darker();
        java.awt.Color color34 = color32.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot35.clearRangeMarkers();
        java.awt.Stroke stroke37 = categoryPlot35.getRangeZeroBaselineStroke();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color39 = color38.brighter();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape30, (java.awt.Paint) color32, stroke37, (java.awt.Paint) color39);
        boolean boolean41 = legendItem40.isShapeVisible();
        java.awt.Stroke stroke42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem40.setOutlineStroke(stroke42);
        legendItem40.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes47 = barRenderer46.getSelectedItemAttributes();
        java.awt.Shape shape49 = barRenderer46.lookupLegendShape((int) 'a');
        java.awt.Font font50 = barRenderer46.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator52 = null;
        barRenderer46.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator52, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes56 = barRenderer55.getSelectedItemAttributes();
        java.awt.Shape shape58 = barRenderer55.lookupLegendShape((int) 'a');
        barRenderer46.setBaseShape(shape58);
        legendItem40.setShape(shape58);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke62 = defaultDrawingSupplier61.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes64 = barRenderer63.getSelectedItemAttributes();
        java.lang.Boolean boolean66 = barRenderer63.getSeriesVisibleInLegend((-1));
        boolean boolean67 = defaultDrawingSupplier61.equals((java.lang.Object) boolean66);
        java.awt.Paint paint68 = defaultDrawingSupplier61.getNextPaint();
        legendItem40.setFillPaint(paint68);
        try {
            barRenderer0.setSeriesPaint((-12517377), paint68, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(renderAttributes28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(renderAttributes47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(renderAttributes56);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(renderAttributes64);
        org.junit.Assert.assertNull(boolean66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(paint68);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        boolean boolean24 = legendItem17.equals((java.lang.Object) (-34.0d));
        java.lang.Object obj25 = legendItem17.clone();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        categoryPlot0.setDomainCrosshairVisible(false);
        java.lang.Comparable comparable7 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot0.handleClick((int) 'a', (int) (short) 10, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(comparable7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11);
        boolean boolean13 = barRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot16.setDomainGridlineStroke(stroke19);
        java.awt.geom.GeneralPath generalPath21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        categoryPlot16.select(generalPath21, rectangle2D22, renderingSource23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = barRenderer0.initialise(graphics2D14, rectangle2D15, categoryPlot16, categoryDataset25, plotRenderingInfo26);
        categoryPlot16.setBackgroundImageAlpha((float) (byte) 1);
        boolean boolean30 = categoryPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot32.getDomainGridlinePosition();
        categoryPlot32.clearDomainMarkers();
        categoryPlot32.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot32.getDomainAxis((int) (short) -1);
        categoryPlot32.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis40.setTickLabelFont(font41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.clearRangeMarkers();
        categoryPlot43.setWeight(0);
        java.awt.Stroke stroke47 = categoryPlot43.getRangeMinorGridlineStroke();
        categoryAxis40.setTickMarkStroke(stroke47);
        float float49 = categoryAxis40.getTickMarkInsideLength();
        java.util.List list50 = categoryPlot32.getCategoriesForAxis(categoryAxis40);
        try {
            categoryPlot16.mapDatasetToDomainAxes((int) (short) 10, list50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(categoryItemRendererState27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        categoryAxis0.setCategoryMargin((double) 100L);
        float float11 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot15.getDatasetRenderingOrder();
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot15.setDomainGridlineStroke(stroke18);
        java.awt.geom.GeneralPath generalPath20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.RenderingSource renderingSource22 = null;
        categoryPlot15.select(generalPath20, rectangle2D21, renderingSource22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot15.setDomainGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearRangeMarkers();
        boolean boolean28 = categoryPlot26.canSelectByPoint();
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = categoryPlot26.removeDomainMarker(2, marker30, layer31);
        categoryPlot15.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        double double34 = categoryPlot15.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot15.getRangeAxisEdge((int) ' ');
        try {
            double double37 = categoryAxis0.getCategoryStart((int) (byte) 0, (int) (byte) 0, rectangle2D14, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes((double) 3, plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation8 = axisLocation7.getOpposite();
        categoryPlot0.setDomainAxisLocation(axisLocation8, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(2, marker4, layer5);
        double double7 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        try {
            categoryPlot0.setRangeAxis((-12517377), valueAxis9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        java.lang.String str5 = categoryPlot0.getPlotType();
        java.awt.Image image6 = categoryPlot0.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        int int8 = categoryPlot0.indexOf(categoryDataset7);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        boolean boolean9 = barRenderer0.getItemCreateEntity((int) '4', 10, false);
        barRenderer0.setDrawBarOutline(true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        double double6 = rectangleInsets4.calculateTopInset((double) (-12517377));
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (short) -1);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis8.setTickLabelFont(font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.setWeight(0);
        java.awt.Stroke stroke15 = categoryPlot11.getRangeMinorGridlineStroke();
        categoryAxis8.setTickMarkStroke(stroke15);
        float float17 = categoryAxis8.getTickMarkInsideLength();
        java.util.List list18 = categoryPlot0.getCategoriesForAxis(categoryAxis8);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearRangeAxes();
        boolean boolean3 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        legendItem17.setOutlinePaint(paint21);
        java.awt.Stroke stroke23 = legendItem17.getOutlineStroke();
        java.lang.Object obj24 = legendItem17.clone();
        java.lang.String str25 = legendItem17.getToolTipText();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = barRenderer1.getSelectedItemAttributes();
        java.awt.Font font3 = renderAttributes2.getDefaultLabelFont();
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) font3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot7.getDomainGridlinePosition();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot7);
        java.awt.Font font10 = categoryPlot5.getNoDataMessageFont();
        boolean boolean11 = rectangleInsets0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot5.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot5.getRangeMarkers(2, layer16);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(renderAttributes2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke1 = null;
        try {
            renderAttributes0.setDefaultOutlineStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers();
        java.awt.Stroke stroke7 = categoryPlot5.getRangeZeroBaselineStroke();
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke7, false);
        boolean boolean10 = lineAndShapeRenderer2.getUseSeriesOffset();
        java.awt.Font font12 = lineAndShapeRenderer2.getSeriesItemLabelFont((int) '#');
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = categoryPlot7.getDatasetRenderingOrder();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot7.setDomainGridlineStroke(stroke10);
        categoryPlot0.setOutlineStroke(stroke10);
        java.awt.geom.GeneralPath generalPath13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.RenderingSource renderingSource15 = null;
        categoryPlot0.select(generalPath13, rectangle2D14, renderingSource15);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Color color1 = java.awt.Color.black;
        float[] floatArray8 = new float[] { (short) 1, 100, 2, 100, 'a', '#' };
        float[] floatArray9 = color1.getComponents(floatArray8);
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("{0}", (java.awt.Paint) color1);
        legendItem10.setURLText("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        java.awt.Font font5 = barRenderer0.getSeriesItemLabelFont(2);
        boolean boolean6 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = barRenderer8.getSelectedItemAttributes();
        java.awt.Shape shape10 = null;
        barRenderer8.setBaseLegendShape(shape10);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer8.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer8.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = barRenderer19.getSelectedItemAttributes();
        java.awt.Shape shape21 = null;
        barRenderer19.setBaseLegendShape(shape21);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator24 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer19.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes27 = barRenderer26.getSelectedItemAttributes();
        java.awt.Shape shape29 = barRenderer26.lookupLegendShape((int) 'a');
        java.awt.Font font30 = barRenderer26.getBaseItemLabelFont();
        barRenderer19.setBaseItemLabelFont(font30, false);
        barRenderer8.setBaseItemLabelFont(font30);
        barRenderer0.setSeriesItemLabelFont((int) (short) 10, font30);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(renderAttributes9);
        org.junit.Assert.assertNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(renderAttributes20);
        org.junit.Assert.assertNotNull(renderAttributes27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Font font5 = barRenderer0.lookupLegendTextFont(0);
        boolean boolean9 = barRenderer0.getItemCreateEntity((int) '4', 10, false);
        java.awt.Paint paint11 = barRenderer0.lookupSeriesOutlinePaint((int) (short) 1);
        java.awt.Paint paint13 = barRenderer0.getLegendTextPaint(0);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer3.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint15 = barRenderer3.lookupSeriesPaint(0);
        renderAttributes1.setDefaultPaint(paint15);
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.ShadowGenerator shadowGenerator13 = categoryPlot0.getShadowGenerator();
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint16 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(shadowGenerator13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        int int9 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        double double6 = rectangleInsets4.calculateLeftOutset(1.0d);
        double double7 = rectangleInsets4.getBottom();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (byte) 0, (int) (byte) 1);
        int int4 = chartColor3.getTransparency();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = categoryPlot1.getDomainGridlinePosition();
        categoryPlot1.clearRangeAxes();
        categoryPlot1.setRangePannable(false);
        categoryPlot1.setDomainGridlinesVisible(true);
        try {
            org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        barRenderer3.setBaseItemLabelFont(font25);
        renderAttributes1.setDefaultLabelFont(font25);
        java.awt.Paint paint30 = renderAttributes1.getDefaultLabelPaint();
        try {
            java.awt.Paint paint32 = renderAttributes1.getSeriesLabelPaint((-20561));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        categoryPlot0.clearSelection();
        org.jfree.data.KeyedObjects keyedObjects5 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj6 = null;
        boolean boolean7 = keyedObjects5.equals(obj6);
        java.util.List list8 = keyedObjects5.getKeys();
        java.util.List list9 = keyedObjects5.getKeys();
        try {
            categoryPlot0.mapDatasetToDomainAxes((-1), list9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke15, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = barRenderer18.getSelectedItemAttributes();
        java.awt.Shape shape20 = null;
        barRenderer18.setBaseLegendShape(shape20);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator23 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer18.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes26 = barRenderer25.getSelectedItemAttributes();
        java.awt.Shape shape28 = barRenderer25.lookupLegendShape((int) 'a');
        java.awt.Font font29 = barRenderer25.getBaseItemLabelFont();
        barRenderer18.setBaseItemLabelFont(font29, false);
        java.awt.Paint paint32 = barRenderer18.getBaseItemLabelPaint();
        barRenderer18.removeAnnotations();
        java.awt.Color color34 = java.awt.Color.black;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color34, false);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color34, true);
        barRenderer0.setSeriesVisible(3, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(renderAttributes19);
        org.junit.Assert.assertNotNull(renderAttributes26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean7 = lineAndShapeRenderer2.equals((java.lang.Object) categoryAnchor6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator8);
        java.awt.Paint paint11 = lineAndShapeRenderer2.lookupSeriesFillPaint((int) (short) -1);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getLabelPaint();
        legendItem17.setSeriesKey((java.lang.Comparable) true);
        legendItem17.setSeriesIndex((int) '4');
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        int int5 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.Plot plot6 = categoryAxis0.getPlot();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) 'a', stroke6, true);
        java.lang.Boolean boolean10 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        java.awt.Stroke stroke11 = barRenderer0.getBaseStroke();
        double double12 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection2);
        java.lang.Object obj4 = legendItemCollection2.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        java.lang.String str5 = categoryPlot0.getPlotType();
        java.awt.Image image6 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker(0, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Category Plot" + "'", str5.equals("Category Plot"));
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.removeAnnotations();
        java.awt.Stroke stroke5 = barRenderer0.getItemStroke(0, 0, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = barRenderer0.getSelectedItemAttributes();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(renderAttributes6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape3 = barRenderer0.lookupLegendShape((int) 'a');
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator6, false);
        java.awt.Stroke stroke9 = barRenderer0.getBaseStroke();
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot0.setRangeAxis((int) 'a', valueAxis21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot24.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator26 = null;
        categoryPlot24.setShadowGenerator(shadowGenerator26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot24.getInsets();
        java.awt.Paint paint29 = categoryPlot24.getDomainGridlinePaint();
        int int30 = categoryPlot24.getRendererCount();
        java.awt.Stroke stroke31 = categoryPlot24.getDomainGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke31);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        java.awt.Font font9 = categoryAxis0.getLabelFont();
        boolean boolean10 = categoryAxis0.isTickMarksVisible();
        java.awt.Paint paint11 = categoryAxis0.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot15.zoomRangeAxes((double) 0, plotRenderingInfo23, point2D24, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot15.getRangeAxisEdge();
        try {
            double double28 = categoryAxis0.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D14, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        java.util.List list3 = keyedObjects0.getKeys();
        try {
            java.lang.Comparable comparable5 = keyedObjects0.getKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.setWeight((int) (byte) 1);
        double double13 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = barRenderer23.getSelectedItemAttributes();
        java.awt.Shape shape26 = barRenderer23.lookupLegendShape((int) 'a');
        java.awt.Font font27 = barRenderer23.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        barRenderer23.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator29, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = barRenderer32.getSelectedItemAttributes();
        java.awt.Shape shape35 = barRenderer32.lookupLegendShape((int) 'a');
        barRenderer23.setBaseShape(shape35);
        legendItem17.setShape(shape35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = barRenderer40.getSelectedItemAttributes();
        java.lang.Boolean boolean43 = barRenderer40.getSeriesVisibleInLegend((-1));
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) boolean43);
        java.awt.Paint paint45 = defaultDrawingSupplier38.getNextPaint();
        legendItem17.setFillPaint(paint45);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes48 = barRenderer47.getSelectedItemAttributes();
        java.lang.Boolean boolean49 = renderAttributes48.getDefaultCreateEntity();
        java.awt.Paint paint51 = renderAttributes48.getSeriesFillPaint(2);
        java.awt.Paint paint54 = renderAttributes48.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes57 = barRenderer56.getSelectedItemAttributes();
        java.awt.Shape shape59 = barRenderer56.lookupLegendShape((int) 'a');
        java.awt.Font font60 = barRenderer56.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        barRenderer56.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator62, false);
        java.awt.Stroke stroke65 = barRenderer56.getBaseStroke();
        renderAttributes48.setSeriesStroke((int) (short) 100, stroke65);
        boolean boolean67 = legendItem17.equals((java.lang.Object) (short) 100);
        java.awt.Shape shape68 = legendItem17.getShape();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(renderAttributes24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(renderAttributes33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(renderAttributes41);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(renderAttributes48);
        org.junit.Assert.assertNull(boolean49);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(renderAttributes57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(shape68);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearRangeMarkers();
        categoryPlot3.setWeight(0);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeMinorGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot9.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator11 = null;
        categoryPlot9.setShadowGenerator(shadowGenerator11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getInsets();
        categoryAxis0.setLabelInsets(rectangleInsets13, false);
        categoryAxis0.setLowerMargin((-34.0d));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 100, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        java.awt.Image image6 = categoryPlot2.getBackgroundImage();
        java.awt.Stroke stroke7 = categoryPlot2.getRangeCrosshairStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot2.addChangeListener(plotChangeListener8);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        double double5 = barRenderer0.getShadowYOffset();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        legendItem17.setOutlinePaint(paint21);
        legendItem17.setLineVisible(true);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer1);
        java.awt.Paint paint3 = barRenderer0.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearRangeMarkers();
        categoryPlot4.setWeight(0);
        barRenderer0.setPlot(categoryPlot4);
        barRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = barRenderer7.getSelectedItemAttributes();
        java.awt.Shape shape10 = barRenderer7.lookupLegendShape((int) 'a');
        java.awt.Font font11 = barRenderer7.getBaseItemLabelFont();
        barRenderer0.setBaseItemLabelFont(font11, false);
        java.awt.Paint paint14 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint16 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke18 = barRenderer0.lookupSeriesStroke(10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint24 = barRenderer0.getItemFillPaint((int) (byte) 0, 0, false);
        java.awt.Color color25 = java.awt.Color.BLACK;
        barRenderer0.setBasePaint((java.awt.Paint) color25, true);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = barRenderer3.getSelectedItemAttributes();
        java.awt.Shape shape5 = null;
        barRenderer3.setBaseLegendShape(shape5);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer3.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer3.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = barRenderer14.getSelectedItemAttributes();
        java.awt.Shape shape16 = null;
        barRenderer14.setBaseLegendShape(shape16);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Shape shape24 = barRenderer21.lookupLegendShape((int) 'a');
        java.awt.Font font25 = barRenderer21.getBaseItemLabelFont();
        barRenderer14.setBaseItemLabelFont(font25, false);
        barRenderer3.setBaseItemLabelFont(font25);
        renderAttributes1.setDefaultLabelFont(font25);
        java.awt.Color color31 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(renderAttributes4);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(renderAttributes15);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape6 = null;
        barRenderer4.setBaseLegendShape(shape6);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = barRenderer11.getSelectedItemAttributes();
        java.awt.Shape shape14 = barRenderer11.lookupLegendShape((int) 'a');
        java.awt.Font font15 = barRenderer11.getBaseItemLabelFont();
        barRenderer4.setBaseItemLabelFont(font15, false);
        java.awt.Paint paint18 = barRenderer4.getBaseItemLabelPaint();
        barRenderer4.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Paint paint23 = barRenderer21.getBasePaint();
        barRenderer4.setSeriesPaint(10, paint23);
        barRenderer4.setItemLabelAnchorOffset((double) 0);
        java.awt.Paint paint30 = barRenderer4.getItemFillPaint((-12517377), (int) (short) -1, false);
        paintList0.setPaint(0, paint30);
        java.awt.Paint paint33 = paintList0.getPaint((int) (byte) 10);
        paintList0.clear();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(renderAttributes12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(paint33);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        boolean boolean13 = categoryPlot11.canSelectByPoint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(2, marker15, layer16);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot0.setRangeAxis((int) 'a', valueAxis21, false);
        try {
            categoryPlot0.zoom((double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRendererForDataset(categoryDataset13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = barRenderer17.getSelectedItemAttributes();
        java.lang.Boolean boolean20 = barRenderer17.getSeriesVisibleInLegend((-1));
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) boolean20);
        java.awt.Paint paint22 = defaultDrawingSupplier15.getNextPaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        java.awt.Paint paint24 = defaultDrawingSupplier15.getNextPaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Shape shape2 = null;
        barRenderer0.setBaseLegendShape(shape2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.removeAnnotations();
        java.awt.Stroke stroke19 = barRenderer14.getItemStroke(0, 0, true);
        barRenderer0.setSeriesStroke((int) (byte) 1, stroke19, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer22);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint4 = renderAttributes1.getSeriesFillPaint(2);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) 'a', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Font font11 = renderAttributes10.getDefaultLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes13 = barRenderer12.getSelectedItemAttributes();
        java.awt.Shape shape14 = null;
        barRenderer12.setBaseLegendShape(shape14);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer12.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer12.getURLGenerator(0, (int) (short) -1, true);
        java.awt.Paint paint24 = barRenderer12.lookupSeriesPaint(0);
        renderAttributes10.setDefaultPaint(paint24);
        renderAttributes1.setSeriesPaint((int) '4', paint24);
        java.awt.Paint paint29 = renderAttributes1.getItemOutlinePaint((int) (short) 1, 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = null;
        barRenderer31.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator33, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = null;
        barRenderer31.setBaseURLGenerator(categoryURLGenerator36, false);
        java.awt.Paint paint42 = barRenderer31.getItemFillPaint((int) (byte) 0, 0, false);
        barRenderer31.setAutoPopulateSeriesPaint(false);
        java.awt.Font font45 = barRenderer31.getBaseItemLabelFont();
        try {
            renderAttributes1.setSeriesLabelFont(10, font45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNotNull(renderAttributes13);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(font45);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes3 = barRenderer2.getSelectedItemAttributes();
        java.awt.Shape shape4 = null;
        barRenderer2.setBaseLegendShape(shape4);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer9.getSelectedItemAttributes();
        java.awt.Shape shape12 = barRenderer9.lookupLegendShape((int) 'a');
        java.awt.Font font13 = barRenderer9.getBaseItemLabelFont();
        barRenderer2.setBaseItemLabelFont(font13, false);
        barRenderer0.setLegendTextFont((int) '4', font13);
        java.awt.Stroke stroke18 = barRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.renderer.category.BarPainter barPainter19 = barRenderer0.getBarPainter();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer0.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = null;
        barRenderer0.setSeriesURLGenerator(2, categoryURLGenerator23, false);
        org.junit.Assert.assertNotNull(renderAttributes3);
        org.junit.Assert.assertNotNull(renderAttributes10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(barPainter19);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.panDomainAxes((double) 1, plotRenderingInfo13, point2D14);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot0.removeChangeListener(plotChangeListener17);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape6 = null;
        barRenderer4.setBaseLegendShape(shape6);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        barRenderer4.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = barRenderer11.getSelectedItemAttributes();
        java.awt.Shape shape14 = barRenderer11.lookupLegendShape((int) 'a');
        java.awt.Font font15 = barRenderer11.getBaseItemLabelFont();
        barRenderer4.setBaseItemLabelFont(font15, false);
        java.awt.Paint paint18 = barRenderer4.getBaseItemLabelPaint();
        barRenderer4.removeAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = barRenderer21.getSelectedItemAttributes();
        java.awt.Paint paint23 = barRenderer21.getBasePaint();
        barRenderer4.setSeriesPaint(10, paint23);
        barRenderer4.setItemLabelAnchorOffset((double) 0);
        java.awt.Paint paint30 = barRenderer4.getItemFillPaint((-12517377), (int) (short) -1, false);
        paintList0.setPaint(0, paint30);
        java.awt.Paint paint33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        paintList0.setPaint((int) (short) 0, paint33);
        org.jfree.chart.util.ObjectList objectList36 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        barRenderer38.setGradientPaintTransformer(gradientPaintTransformer39);
        java.awt.Paint paint44 = barRenderer38.getItemPaint((int) (short) 1, (int) (short) 0, true);
        java.awt.Paint paint46 = barRenderer38.getSeriesOutlinePaint(100);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        barRenderer38.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color48, false);
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray58 = new float[] { (-1L), 100.0f, (short) 1, (short) -1, 100L, 'a' };
        float[] floatArray59 = color51.getColorComponents(floatArray58);
        float[] floatArray60 = color48.getColorComponents(floatArray59);
        objectList36.set(0, (java.lang.Object) color48);
        paintList0.setPaint((int) (byte) 100, (java.awt.Paint) color48);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(renderAttributes12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(renderAttributes22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.clearDomainMarkers();
        java.awt.Font font7 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.setWeight(0);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeMinorGridlineStroke();
        categoryPlot0.setDomainCrosshairVisible(false);
        java.lang.Comparable comparable7 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) false);
        boolean boolean8 = lineAndShapeRenderer2.getItemLineVisible(1, 2);
        boolean boolean11 = lineAndShapeRenderer2.getItemLineVisible(3, (int) (short) 10);
        lineAndShapeRenderer2.setItemMargin(0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        boolean boolean2 = categoryPlot0.canSelectByPoint();
        java.awt.Image image3 = null;
        categoryPlot0.setBackgroundImage(image3);
        float float5 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        categoryPlot2.setRangeCrosshairValue((double) (short) 10);
        categoryPlot2.configureDomainAxes();
        boolean boolean8 = categoryPlot2.isRangePannable();
        boolean boolean9 = categoryPlot2.isOutlineVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        try {
            int int10 = categoryPlot0.getRangeAxisIndex(valueAxis9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        paintList0.clear();
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.Color color7 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = barRenderer0.getSelectedItemAttributes();
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke4 = renderAttributes1.getSeriesStroke((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis10 };
        categoryPlot6.setDomainAxes(categoryAxisArray11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot6.zoomRangeAxes((double) 0, plotRenderingInfo14, point2D15, true);
        boolean boolean18 = categoryPlot6.isRangeGridlinesVisible();
        java.util.List list19 = categoryPlot6.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearRangeMarkers();
        java.awt.Stroke stroke22 = categoryPlot20.getRangeZeroBaselineStroke();
        categoryPlot6.setRangeMinorGridlineStroke(stroke22);
        renderAttributes1.setSeriesStroke((int) (byte) 1, stroke22);
        java.awt.Paint paint26 = renderAttributes1.getSeriesOutlinePaint(3);
        java.awt.Stroke stroke29 = renderAttributes1.getItemStroke((int) (short) 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(renderAttributes1);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNull(stroke29);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = barRenderer4.getSelectedItemAttributes();
        java.awt.Shape shape7 = barRenderer4.lookupLegendShape((int) 'a');
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color9 = color8.brighter();
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeMarkers();
        java.awt.Stroke stroke14 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape7, (java.awt.Paint) color9, stroke14, (java.awt.Paint) color16);
        boolean boolean18 = legendItem17.isShapeVisible();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem17.setOutlineStroke(stroke19);
        legendItem17.setURLText("");
        boolean boolean24 = legendItem17.equals((java.lang.Object) (-34.0d));
        org.jfree.data.general.Dataset dataset25 = legendItem17.getDataset();
        org.junit.Assert.assertNotNull(renderAttributes5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(dataset25);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes2 = barRenderer1.getSelectedItemAttributes();
        java.awt.Font font3 = renderAttributes2.getDefaultLabelFont();
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) font3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot7.getDomainGridlinePosition();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot7);
        java.awt.Font font10 = categoryPlot5.getNoDataMessageFont();
        boolean boolean11 = rectangleInsets0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot5.getDomainAxisForDataset((int) ' ');
        categoryPlot5.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(renderAttributes2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font1);
        double double3 = categoryAxis0.getUpperMargin();
        float float4 = categoryAxis0.getTickMarkOutsideLength();
        int int5 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setUpperMargin((double) '4');
        java.awt.Paint paint9 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0d, (double) '#', (double) 0L, (double) (byte) 0);
        double double7 = rectangleInsets5.trimWidth((double) 1);
        double double9 = rectangleInsets5.calculateTopOutset((-34.0d));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-34.0d) + "'", double7 == (-34.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis((int) (short) -1);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis8.setTickLabelFont(font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearRangeMarkers();
        categoryPlot11.setWeight(0);
        java.awt.Stroke stroke15 = categoryPlot11.getRangeMinorGridlineStroke();
        categoryAxis8.setTickMarkStroke(stroke15);
        float float17 = categoryAxis8.getTickMarkInsideLength();
        java.util.List list18 = categoryPlot0.getCategoriesForAxis(categoryAxis8);
        categoryAxis8.setMaximumCategoryLabelWidthRatio(0.0f);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Color color1 = java.awt.Color.black;
        float[] floatArray8 = new float[] { (short) 1, 100, 2, 100, 'a', '#' };
        float[] floatArray9 = color1.getComponents(floatArray8);
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("{0}", (java.awt.Paint) color1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes16 = barRenderer15.getSelectedItemAttributes();
        java.awt.Shape shape18 = barRenderer15.lookupLegendShape((int) 'a');
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color20 = color19.brighter();
        java.awt.Color color21 = color20.darker();
        java.awt.Color color22 = color20.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearRangeMarkers();
        java.awt.Stroke stroke25 = categoryPlot23.getRangeZeroBaselineStroke();
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color27 = color26.brighter();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("", "{0}", "hi!", "Category Plot", shape18, (java.awt.Paint) color20, stroke25, (java.awt.Paint) color27);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape18, "java.awt.Color[r=64,g=64,b=64]", "DatasetRenderingOrder.REVERSE");
        legendItem10.setLine(shape18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(renderAttributes16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.ShadowGenerator shadowGenerator2 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint6 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = gradientPaintTransformType0.equals(obj1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.ShadowGenerator shadowGenerator13 = categoryPlot0.getShadowGenerator();
        try {
            org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxisForDataset((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(shadowGenerator13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.ShadowGenerator shadowGenerator5 = categoryPlot2.getShadowGenerator();
        categoryPlot2.clearRangeAxes();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot2.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(shadowGenerator5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.panDomainAxes((double) 1, plotRenderingInfo13, point2D14);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.Plot plot17 = categoryPlot0.getParent();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNull(plot17);
    }
}

