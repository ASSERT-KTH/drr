import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        try {
            timeSeries3.update((int) (byte) -1, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(timeSeriesDataItem8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            timeSeries3.update(regularTimePeriod6, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("January -9999");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            timeSeries3.add(timeSeriesDataItem8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        timeSeries3.clear();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str3 = month2.toString();
        int int5 = month2.compareTo((java.lang.Object) '#');
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -9999" + "'", str3.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        java.util.Calendar calendar11 = null;
        try {
            month8.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        try {
            java.lang.Number number7 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        int int4 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str22 = seriesChangeEvent21.toString();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long4 = month3.getLastMillisecond();
        int int5 = day0.compareTo((java.lang.Object) long4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 253405007999999L + "'", long4 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Calendar calendar15 = null;
        try {
            month11.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        java.util.TimeZone timeZone16 = null;
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day10.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        long long5 = year1.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month11.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        try {
            timeSeries3.update(100, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 100.0d);
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        java.util.Calendar calendar20 = null;
        try {
            year19.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9999L) + "'", long7 == (-9999L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        try {
            timeSeries3.delete(4, 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection15);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int3 = day0.compareTo((java.lang.Object) 10.0f);
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("32");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        try {
            timeSeries3.update((int) '4', (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.util.TimeZone timeZone17 = null;
        try {
            org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNull(class4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day12.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str7 = month6.toString();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = null;
        try {
            timeSeries3.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January -9999" + "'", str7.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year13 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month10.previous();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        java.lang.String str6 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str9 = seriesException8.toString();
        java.lang.String str10 = seriesException8.toString();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str13 = seriesException12.toString();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException12);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.String str16 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str13.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str16.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        long long5 = year1.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61125897600001L) + "'", long5 == (-61125897600001L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long4 = month3.getLastMillisecond();
        int int5 = day0.compareTo((java.lang.Object) long4);
        java.util.Calendar calendar6 = null;
        try {
            day0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 253405007999999L + "'", long4 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries3.setRangeDescription("hi!");
        double double15 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries19.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries19.getTimePeriods();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long28 = month27.getLastMillisecond();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month27, Double.NaN);
        long long31 = month27.getLastMillisecond();
        org.jfree.data.time.Year year32 = month27.getYear();
        long long33 = month27.getMiddleMillisecond();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 253405007999999L + "'", long28 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 253405007999999L + "'", long31 == 253405007999999L);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62153366400001L) + "'", long33 == (-62153366400001L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
        timeSeries3.add(timeSeriesDataItem9);
        boolean boolean11 = timeSeries3.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("32");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        java.util.TimeZone timeZone16 = null;
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year19.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        long long25 = fixedMillisecond23.getLastMillisecond();
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond23.previous();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-9999L) + "'", long25 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.clear();
        try {
            timeSeries3.setMaximumItemAge((-61125897600001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        org.jfree.data.time.Year year16 = month11.getYear();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month11.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertNotNull(year16);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.util.Calendar calendar6 = null;
        try {
            year1.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.lang.String str17 = day12.toString();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = day12.getLastMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) 1);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj36 = null;
        boolean boolean37 = year35.equals(obj36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries43.removeAgedItems(true);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str49 = month48.toString();
        boolean boolean50 = timeSeries43.equals((java.lang.Object) month48);
        double double51 = timeSeries43.getMinY();
        int int52 = timeSeriesDataItem39.compareTo((java.lang.Object) timeSeries43);
        boolean boolean53 = timeSeriesDataItem29.equals((java.lang.Object) int52);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "January -9999" + "'", str49.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        java.util.Calendar calendar58 = null;
        try {
            long long59 = month51.getFirstMillisecond(calendar58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries24.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long32 = month31.getLastMillisecond();
        java.lang.Number number33 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) month31);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month31, (double) 1560150000000L);
        boolean boolean36 = timeSeries3.equals((java.lang.Object) month31);
        java.util.Calendar calendar37 = null;
        try {
            long long38 = month31.getLastMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 253405007999999L + "'", long32 == 253405007999999L);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        java.util.Date date2 = year1.getStart();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 100);
//        java.util.List list10 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries14.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long22 = month21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) month21);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int27 = month26.getMonth();
//        java.lang.Class<?> wildcardClass28 = month26.getClass();
//        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) month26);
//        org.jfree.data.time.Year year30 = month26.getYear();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long34 = month33.getLastMillisecond();
//        int int35 = year30.compareTo((java.lang.Object) long34);
//        timeSeries3.setKey((java.lang.Comparable) int35);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 253405007999999L + "'", long22 == 253405007999999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 253405007999999L + "'", long34 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9999L) + "'", long8 == (-9999L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
        timeSeries3.add(timeSeriesDataItem9);
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = null;
        try {
            timeSeries3.add(timeSeriesDataItem12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 100.0d);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year13 = month10.getYear();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setMaximumItemCount((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        long long9 = fixedMillisecond7.getLastMillisecond();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        boolean boolean9 = timeSeries3.getNotify();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 100.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
//        long long15 = day10.getLastMillisecond();
//        int int16 = day10.getYear();
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str3 = month2.toString();
        long long4 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -9999" + "'", str3.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-119987L) + "'", long4 == (-119987L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        timeSeries3.setDescription("");
        timeSeries3.setMaximumItemAge((long) 10);
        java.lang.Comparable comparable8 = null;
        try {
            timeSeries3.setKey(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(class7);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.lang.String str17 = day12.toString();
//        java.util.Date date18 = day12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.TimeZone timeZone20 = null;
//        try {
//            org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        java.util.Collection collection7 = timeSeries3.getTimePeriods();
        timeSeries3.setDescription("100");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj28 = null;
        boolean boolean29 = year27.equals(obj28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 1560150000000L);
        timeSeries25.add(timeSeriesDataItem31);
        boolean boolean33 = timeSeries25.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries25);
        try {
            org.jfree.data.time.TimeSeries timeSeries37 = timeSeries25.createCopy(1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str6 = seriesException5.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable throwable8 = null;
        try {
            seriesException1.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj10 = null;
        boolean boolean11 = year9.equals(obj10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries17.removeAgedItems(true);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str23 = month22.toString();
        boolean boolean24 = timeSeries17.equals((java.lang.Object) month22);
        double double25 = timeSeries17.getMinY();
        int int26 = timeSeriesDataItem13.compareTo((java.lang.Object) timeSeries17);
        boolean boolean28 = timeSeriesDataItem13.equals((java.lang.Object) 10);
        timeSeriesDataItem13.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "January -9999" + "'", str23.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        try {
            java.lang.Number number7 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.util.Date date3 = month2.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month15.previous();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = month15.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2147483647) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        timeSeries3.setDescription("");
        timeSeries3.setMaximumItemAge((long) 10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.removeAgedItems(false);
        double double4 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(7, (int) ' ');
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries11.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long19 = month18.getLastMillisecond();
        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int24 = month23.getMonth();
        java.lang.Class<?> wildcardClass25 = month23.getClass();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.Year year27 = month23.getYear();
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 253405007999999L + "'", long19 == 253405007999999L);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(year27);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable throwable5 = null;
        try {
            seriesException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.util.TimeZone timeZone27 = null;
//        try {
//            org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date23, timeZone27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 0.0f);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month15.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getFirstMillisecond();
//        int int17 = day15.getDayOfMonth();
//        int int18 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj21 = null;
//        boolean boolean22 = year20.equals(obj21);
//        int int23 = year20.getYear();
//        int int24 = year20.getYear();
//        java.lang.String str25 = year20.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
//        boolean boolean27 = timeSeriesDataItem26.isSelected();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 32 + "'", int24 == 32);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "32" + "'", str25.equals("32"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 253405007999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        boolean boolean58 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean61 = timeSeries60.getNotify();
        java.lang.Class<?> wildcardClass62 = timeSeries60.getClass();
        boolean boolean63 = timeSeries3.equals((java.lang.Object) timeSeries60);
        timeSeries3.clear();
        timeSeries3.setMaximumItemCount(0);
        try {
            timeSeries3.delete(11, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries20.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener23);
//        java.util.Collection collection25 = timeSeries20.getTimePeriods();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long29 = month28.getLastMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month28, Double.NaN);
//        long long32 = month28.getLastMillisecond();
//        int int33 = day12.compareTo((java.lang.Object) month28);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int36 = day34.compareTo((java.lang.Object) 100.0d);
//        boolean boolean37 = day12.equals((java.lang.Object) int36);
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = day12.getFirstMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 253405007999999L + "'", long29 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 253405007999999L + "'", long32 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.util.TimeZone timeZone27 = null;
//        java.util.Locale locale28 = null;
//        try {
//            org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date23, timeZone27, locale28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setMaximumItemCount((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        long long9 = fixedMillisecond7.getLastMillisecond();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
        long long13 = fixedMillisecond7.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9999L) + "'", long12 == (-9999L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-9999L) + "'", long13 == (-9999L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        java.lang.Class class9 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        try {
            timeSeries1.delete((int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        int int15 = day12.getDayOfMonth();
//        java.util.Calendar calendar16 = null;
//        try {
//            day12.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.util.Date date3 = month2.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long16 = month15.getLastMillisecond();
        java.lang.Number number17 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560150000000L);
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.createCopy((int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        long long5 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-377711740800000L) + "'", long5 == (-377711740800000L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries17.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries17.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long25 = month24.getLastMillisecond();
        java.lang.Number number26 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month24);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month24, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.addOrUpdate(timeSeriesDataItem30);
        try {
            timeSeries3.delete((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 253405007999999L + "'", long25 == 253405007999999L);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj6 = null;
//        boolean boolean7 = year5.equals(obj6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
//        timeSeries3.add(timeSeriesDataItem9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries14.setDescription("");
//        timeSeries14.setMaximumItemCount(11);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
//        timeSeries14.setKey((java.lang.Comparable) day19);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day19);
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day19.getFirstMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries7.addOrUpdate(regularTimePeriod8, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month15.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        java.lang.String str16 = month11.toString();
        java.lang.String str17 = month11.toString();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month11.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "January -9999" + "'", str16.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "January -9999" + "'", str17.equals("January -9999"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 0.0f);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month15.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int24 = month23.getMonth();
        java.lang.Class<?> wildcardClass25 = month23.getClass();
        int int26 = month15.compareTo((java.lang.Object) month23);
        java.lang.String str27 = month23.toString();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "January -9999" + "'", str27.equals("January -9999"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("32");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long17 = month16.getLastMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month16, Double.NaN);
        long long20 = month16.getLastMillisecond();
        java.lang.String str21 = month16.toString();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 10);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries27.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries27.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries40.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries40.removeChangeListener(seriesChangeListener43);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long48 = month47.getLastMillisecond();
        java.lang.Number number49 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) month47);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month47, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, (double) 12);
        java.lang.Number number54 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month47);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 253405007999999L + "'", long17 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 253405007999999L + "'", long20 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "January -9999" + "'", str21.equals("January -9999"));
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 253405007999999L + "'", long48 == 253405007999999L);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 10.0d + "'", number54.equals(10.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException4.toString();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) comparable14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean18 = fixedMillisecond1.equals((java.lang.Object) 'a');
        long long19 = fixedMillisecond1.getMiddleMillisecond();
        long long20 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 'a' + "'", comparable14.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9999L) + "'", long19 == (-9999L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9999L) + "'", long20 == (-9999L));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.lang.String str17 = day12.toString();
//        java.util.Date date18 = day12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18);
//        java.util.TimeZone timeZone21 = null;
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date18, timeZone21, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1L));
//        java.lang.Class<?> wildcardClass5 = timeSeriesDataItem4.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        boolean boolean58 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean61 = timeSeries60.getNotify();
        java.lang.Class<?> wildcardClass62 = timeSeries60.getClass();
        boolean boolean63 = timeSeries3.equals((java.lang.Object) timeSeries60);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean67 = year65.equals((java.lang.Object) (byte) -1);
        long long68 = year65.getSerialIndex();
        java.lang.String str69 = year65.toString();
        java.lang.Class<?> wildcardClass70 = year65.getClass();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year65, (java.lang.Number) 5, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 32L + "'", long68 == 32L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "32" + "'", str69.equals("32"));
        org.junit.Assert.assertNotNull(wildcardClass70);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month11.previous();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month11.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day17.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries26.removeAgedItems(true);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str32 = month31.toString();
        boolean boolean33 = timeSeries26.equals((java.lang.Object) month31);
        double double34 = timeSeries26.getMinY();
        java.lang.String str35 = timeSeries26.getDescription();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int39 = month38.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (double) 0.0f);
        org.jfree.data.time.Year year42 = month38.getYear();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (short) 1, year42);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 32L);
        java.util.Calendar calendar46 = null;
        try {
            long long47 = month43.getLastMillisecond(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -9999" + "'", str32.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(year42);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy(0, (int) 'a');
        java.lang.String str10 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries20.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener23);
//        java.util.Collection collection25 = timeSeries20.getTimePeriods();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long29 = month28.getLastMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month28, Double.NaN);
//        long long32 = month28.getLastMillisecond();
//        int int33 = day12.compareTo((java.lang.Object) month28);
//        java.lang.String str34 = day12.toString();
//        java.util.Calendar calendar35 = null;
//        try {
//            long long36 = day12.getFirstMillisecond(calendar35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 253405007999999L + "'", long29 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 253405007999999L + "'", long32 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries7.addOrUpdate(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.util.Date date7 = regularTimePeriod6.getStart();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries7.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long16 = month15.getLastMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month15, Double.NaN);
        long long19 = month15.getLastMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, number20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month15.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 253405007999999L + "'", long19 == 253405007999999L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) 9223372036854775807L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem33.getPeriod();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        timeSeries1.removeAgedItems(false);
//        double double4 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries25.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        java.util.Collection collection30 = timeSeries25.getTimePeriods();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long34 = month33.getLastMillisecond();
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month33, Double.NaN);
//        long long37 = month33.getLastMillisecond();
//        int int38 = day17.compareTo((java.lang.Object) month33);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries42.removeChangeListener(seriesChangeListener43);
//        java.lang.Object obj45 = timeSeries42.clone();
//        int int46 = day17.compareTo((java.lang.Object) timeSeries42);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries1.addAndOrUpdate(timeSeries42);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 253405007999999L + "'", long34 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(obj45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(timeSeries47);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 100);
//        java.util.List list10 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries14.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long22 = month21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) month21);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int27 = month26.getMonth();
//        java.lang.Class<?> wildcardClass28 = month26.getClass();
//        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) month26);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries33.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long41 = month40.getLastMillisecond();
//        java.lang.Number number42 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) month40);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int46 = month45.getMonth();
//        java.lang.Class<?> wildcardClass47 = month45.getClass();
//        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) month45);
//        org.jfree.data.time.Year year49 = month45.getYear();
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj56 = null;
//        boolean boolean57 = year55.equals(obj56);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 1560150000000L);
//        timeSeries53.add(timeSeriesDataItem59);
//        boolean boolean61 = month45.equals((java.lang.Object) timeSeriesDataItem59);
//        boolean boolean63 = timeSeriesDataItem59.equals((java.lang.Object) 1);
//        timeSeriesDataItem59.setValue((java.lang.Number) 9);
//        timeSeries14.add(timeSeriesDataItem59, false);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries14);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 253405007999999L + "'", long22 == 253405007999999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 253405007999999L + "'", long41 == 253405007999999L);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        try {
            timeSeries3.update(9, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 100);
//        java.lang.String str10 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
//        try {
//            timeSeries3.update(regularTimePeriod11, (java.lang.Number) (-9999));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        timeSeries3.setDomainDescription("");
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy(2019, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond1.equals(obj6);
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8, "October 1", "32");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries11.add(regularTimePeriod12, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-9999L) + "'", long5 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9999L) + "'", long8 == (-9999L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.setRangeDescription("January -9999");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        try {
            java.util.Collection collection15 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        int int58 = year31.getYear();
        java.util.Date date59 = year31.getStart();
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 32 + "'", int58 == 32);
        org.junit.Assert.assertNotNull(date59);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries9.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries9.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long17 = month16.getLastMillisecond();
        java.lang.Number number18 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.Year year19 = month16.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (-1.0d));
        int int22 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 253405007999999L + "'", long17 == 253405007999999L);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        timeSeries3.clear();
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy((int) (byte) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str6 = seriesException5.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str10 = seriesException9.toString();
        java.lang.String str11 = seriesException9.toString();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.String str17 = seriesException13.toString();
        java.lang.String str18 = seriesException13.toString();
        seriesException9.addSuppressed((java.lang.Throwable) seriesException13);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str22 = seriesException21.toString();
        java.lang.String str23 = seriesException21.toString();
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str26 = seriesException25.toString();
        seriesException21.addSuppressed((java.lang.Throwable) seriesException25);
        seriesException13.addSuppressed((java.lang.Throwable) seriesException21);
        seriesException5.addSuppressed((java.lang.Throwable) seriesException13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str11.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str17.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str18.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str22.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str23.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str26.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.removeAgedItems(false);
        double double4 = timeSeries1.getMinY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        java.util.Date date2 = year1.getStart();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries3.createCopy(7, (int) ' ');
        try {
            timeSeries8.update((int) (short) 10, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy(0, (int) 'a');
        try {
            timeSeries3.delete(2147483647, 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9999L) + "'", long7 == (-9999L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries4.removeAgedItems(true);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str10 = month9.toString();
        boolean boolean11 = timeSeries4.equals((java.lang.Object) month9);
        double double12 = timeSeries4.getMinY();
        java.lang.String str13 = timeSeries4.getDescription();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int17 = month16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0.0f);
        org.jfree.data.time.Year year20 = month16.getYear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, year20);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year20.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January -9999" + "'", str10.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(year20);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setDomainDescription("org.jfree.data.general.SeriesException: hi!");
        timeSeries3.setDescription("10-June-2019");
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        long long21 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19);
        java.util.Calendar calendar23 = null;
        fixedMillisecond19.peg(calendar23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj27 = null;
        boolean boolean28 = year26.equals(obj27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) year26);
        try {
            timeSeries3.delete((int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9999L) + "'", long21 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        java.lang.String str6 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str9 = seriesException8.toString();
        java.lang.String str10 = seriesException8.toString();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str13 = seriesException12.toString();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException12);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str18 = seriesException17.toString();
        java.lang.String str19 = seriesException17.toString();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        seriesException21.addSuppressed((java.lang.Throwable) seriesException23);
        java.lang.String str25 = seriesException21.toString();
        java.lang.String str26 = seriesException21.toString();
        seriesException17.addSuppressed((java.lang.Throwable) seriesException21);
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str30 = seriesException29.toString();
        java.lang.String str31 = seriesException29.toString();
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str34 = seriesException33.toString();
        seriesException29.addSuppressed((java.lang.Throwable) seriesException33);
        seriesException21.addSuppressed((java.lang.Throwable) seriesException29);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException29);
        java.lang.String str38 = seriesException29.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str13.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str18.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str19.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str25.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str26.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str30.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str31.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str34.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str38.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.clear();
        boolean boolean6 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries5.setDescription("");
//        timeSeries5.setMaximumItemAge((long) 10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean14 = timeSeries13.getNotify();
//        timeSeries13.clear();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getSerialIndex();
//        long long18 = day16.getLastMillisecond();
//        long long19 = day16.getLastMillisecond();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        int int22 = year1.compareTo((java.lang.Object) day16);
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = year1.getFirstMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        long long15 = day12.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day12.next();
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day12.getLastMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long23 = month22.getLastMillisecond();
        int int24 = year19.compareTo((java.lang.Object) long23);
        java.lang.String str25 = year19.toString();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 253405007999999L + "'", long23 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-9999" + "'", str25.equals("-9999"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Sun Jun 09 00:00:00 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        java.lang.String str2 = year1.toString();
        java.lang.String str3 = year1.toString();
        int int4 = year1.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9999L) + "'", long2 == (-9999L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.util.TimeZone timeZone27 = null;
//        try {
//            org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date23, timeZone27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
        timeSeries3.add(timeSeriesDataItem9);
        boolean boolean11 = timeSeries3.isEmpty();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100, seriesChangeInfo1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        java.util.Date date2 = year1.getStart();
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        double double16 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        java.lang.Object obj32 = timeSeriesDataItem29.clone();
        java.lang.Object obj33 = timeSeriesDataItem29.clone();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem5.getPeriod();
        java.lang.Number number8 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1560150000000L + "'", number8.equals(1560150000000L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        double double13 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy(100, 9999);
        double double17 = timeSeries16.getMaxY();
        java.lang.String str18 = timeSeries16.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        try {
            timeSeries16.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        int int20 = year19.getYear();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-9999) + "'", int20 == (-9999));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long17 = month16.getLastMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month16, Double.NaN);
        long long20 = month16.getLastMillisecond();
        java.lang.String str21 = month16.toString();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 10);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener24);
        double double26 = timeSeries4.getMinY();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 253405007999999L + "'", long17 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 253405007999999L + "'", long20 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "January -9999" + "'", str21.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date28, timeZone29);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries25.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.removeChangeListener(seriesChangeListener28);
        java.util.Collection collection30 = timeSeries25.getTimePeriods();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long34 = month33.getLastMillisecond();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month33, Double.NaN);
        long long37 = month33.getLastMillisecond();
        int int38 = month33.getMonth();
        long long39 = month33.getFirstMillisecond();
        boolean boolean40 = timeSeries21.equals((java.lang.Object) month33);
        timeSeries21.setDomainDescription("10-June-2019");
        java.lang.Comparable comparable43 = timeSeries21.getKey();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 253405007999999L + "'", long34 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-377711740800000L) + "'", long39 == (-377711740800000L));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + "Overwritten values from: a" + "'", comparable43.equals("Overwritten values from: a"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries5.removeAgedItems(true);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str11 = month10.toString();
        boolean boolean12 = timeSeries5.equals((java.lang.Object) month10);
        double double13 = timeSeries5.getMinY();
        java.lang.String str14 = timeSeries5.getDescription();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int18 = month17.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 0.0f);
        org.jfree.data.time.Year year21 = month17.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, year21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(8, year21);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January -9999" + "'", str11.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(year21);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        java.util.Date date16 = regularTimePeriod15.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.lang.String str19 = fixedMillisecond18.toString();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Sun Jun 09 00:00:00 PDT 2019" + "'", str19.equals("Sun Jun 09 00:00:00 PDT 2019"));
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setRangeDescription("32");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries3.setRangeDescription("hi!");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries3.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        java.lang.String str3 = month2.toString();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, number4);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 1" + "'", str3.equals("October 1"));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        long long2 = year1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.lang.String str17 = day12.toString();
//        java.util.Date date18 = day12.getEnd();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = day12.equals(obj19);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1L));
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 10L);
//        long long16 = day9.getLastMillisecond();
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        int int16 = month11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.previous();
        java.lang.String str18 = month11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month11.previous();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January -9999" + "'", str18.equals("January -9999"));
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
//        java.util.Collection collection7 = timeSeries3.getTimePeriods();
//        java.util.List list8 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries12.removeAgedItems(true);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str18 = month17.toString();
//        boolean boolean19 = timeSeries12.equals((java.lang.Object) month17);
//        double double20 = timeSeries12.getMinY();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        java.lang.String str24 = day21.toString();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day21, 12.0d, true);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day21.getMiddleMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(collection7);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January -9999" + "'", str18.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        java.lang.Object obj9 = timeSeries3.clone();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries15.setDescription("");
//        timeSeries15.setMaximumItemAge((long) 10);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean24 = timeSeries23.getNotify();
//        timeSeries23.clear();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getLastMillisecond();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day26);
//        int int32 = year11.compareTo((java.lang.Object) day26);
//        timeSeries3.setKey((java.lang.Comparable) int32);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        seriesException5.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.String str9 = seriesException5.toString();
        java.lang.String str10 = seriesException5.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str14 = seriesException13.toString();
        java.lang.String str15 = seriesException13.toString();
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str18 = seriesException17.toString();
        seriesException13.addSuppressed((java.lang.Throwable) seriesException17);
        seriesException5.addSuppressed((java.lang.Throwable) seriesException13);
        java.lang.Throwable throwable21 = null;
        try {
            seriesException13.addSuppressed(throwable21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str14.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str15.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str18.equals("org.jfree.data.general.SeriesException: hi!"));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        long long12 = timeSeries3.getMaximumItemAge();
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy(100, 9999);
//        double double17 = timeSeries16.getMaxY();
//        java.lang.String str18 = timeSeries16.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries22.removeAgedItems(true);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str28 = month27.toString();
//        boolean boolean29 = timeSeries22.equals((java.lang.Object) month27);
//        double double30 = timeSeries22.getMinY();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
//        int int34 = day31.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day31.getSerialDate();
//        java.lang.Number number36 = null;
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day31, number36);
//        try {
//            java.lang.Number number39 = timeSeries16.getValue(32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January -9999" + "'", str28.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(serialDate35);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long16 = month15.getLastMillisecond();
        java.lang.Number number17 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560150000000L);
        try {
            timeSeries3.delete((int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
        org.junit.Assert.assertNull(number17);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        java.util.Collection collection20 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries25.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        java.util.Collection collection30 = timeSeries25.getTimePeriods();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long34 = month33.getLastMillisecond();
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month33, Double.NaN);
//        long long37 = month33.getLastMillisecond();
//        int int38 = month33.getMonth();
//        long long39 = month33.getFirstMillisecond();
//        boolean boolean40 = timeSeries21.equals((java.lang.Object) month33);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getFirstMillisecond();
//        int int44 = day41.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries49.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener52);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long57 = month56.getLastMillisecond();
//        java.lang.Number number58 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) month56);
//        timeSeries49.setRangeDescription("hi!");
//        double double61 = timeSeries49.getMaxY();
//        long long62 = timeSeries49.getMaximumItemAge();
//        int int63 = day41.compareTo((java.lang.Object) timeSeries49);
//        timeSeries49.setMaximumItemAge((long) 'a');
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 253405007999999L + "'", long34 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-377711740800000L) + "'", long39 == (-377711740800000L));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560150000000L + "'", long42 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 253405007999999L + "'", long57 == 253405007999999L);
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        java.util.Collection collection20 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries25.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        java.util.Collection collection30 = timeSeries25.getTimePeriods();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long34 = month33.getLastMillisecond();
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month33, Double.NaN);
//        long long37 = month33.getLastMillisecond();
//        int int38 = month33.getMonth();
//        long long39 = month33.getFirstMillisecond();
//        boolean boolean40 = timeSeries21.equals((java.lang.Object) month33);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getFirstMillisecond();
//        int int44 = day41.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries49.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener52);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long57 = month56.getLastMillisecond();
//        java.lang.Number number58 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) month56);
//        timeSeries49.setRangeDescription("hi!");
//        double double61 = timeSeries49.getMaxY();
//        long long62 = timeSeries49.getMaximumItemAge();
//        int int63 = day41.compareTo((java.lang.Object) timeSeries49);
//        java.lang.String str64 = day41.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 253405007999999L + "'", long34 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-377711740800000L) + "'", long39 == (-377711740800000L));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560150000000L + "'", long42 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 253405007999999L + "'", long57 == 253405007999999L);
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries4.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        java.lang.Number number13 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int17 = month16.getMonth();
        java.lang.Class<?> wildcardClass18 = month16.getClass();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.Year year20 = month16.getYear();
        long long21 = year20.getMiddleMillisecond();
        try {
            org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 100, year20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62138894400001L) + "'", long21 == (-62138894400001L));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries16.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) 9223372036854775807L);
        java.lang.Object obj34 = timeSeriesDataItem33.clone();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        double double13 = timeSeries3.getMinY();
        timeSeries3.setRangeDescription("10-June-2019");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj18 = null;
        boolean boolean19 = year17.equals(obj18);
        int int20 = year17.getYear();
        long long21 = year17.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, 12.0d, true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32 + "'", int20 == 32);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61125897600001L) + "'", long21 == (-61125897600001L));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str13 = month12.toString();
//        boolean boolean14 = timeSeries7.equals((java.lang.Object) month12);
//        double double15 = timeSeries7.getMinY();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
//        long long20 = day16.getLastMillisecond();
//        java.lang.String str21 = day16.toString();
//        java.util.Date date22 = day16.getEnd();
//        int int23 = day16.getDayOfMonth();
//        timeSeries3.setKey((java.lang.Comparable) day16);
//        java.lang.String str25 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj28 = null;
//        boolean boolean29 = year27.equals(obj28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem31.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem31.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem31);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.util.Date date38 = month37.getStart();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month37, (double) 1L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "January -9999" + "'", str13.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(date38);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        java.lang.String str6 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str9 = seriesException8.toString();
        java.lang.String str10 = seriesException8.toString();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str13 = seriesException12.toString();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException12);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str18 = seriesException17.toString();
        java.lang.String str19 = seriesException17.toString();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        seriesException21.addSuppressed((java.lang.Throwable) seriesException23);
        java.lang.String str25 = seriesException21.toString();
        java.lang.String str26 = seriesException21.toString();
        seriesException17.addSuppressed((java.lang.Throwable) seriesException21);
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str30 = seriesException29.toString();
        java.lang.String str31 = seriesException29.toString();
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str34 = seriesException33.toString();
        seriesException29.addSuppressed((java.lang.Throwable) seriesException33);
        seriesException21.addSuppressed((java.lang.Throwable) seriesException29);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException29);
        java.lang.Throwable[] throwableArray38 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str13.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str18.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str19.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str25.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str26.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str30.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str31.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str34.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray38);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 3, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries32.removeAgedItems(true);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str38 = month37.toString();
//        boolean boolean39 = timeSeries32.equals((java.lang.Object) month37);
//        double double40 = timeSeries32.getMinY();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.previous();
//        long long45 = day41.getLastMillisecond();
//        java.lang.String str46 = day41.toString();
//        java.util.Date date47 = day41.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date47);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date47, timeZone50);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date47);
//        java.util.TimeZone timeZone53 = null;
//        try {
//            org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date47, timeZone53);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January -9999" + "'", str38.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem29.getPeriod();
        timeSeriesDataItem29.setSelected(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem29.getPeriod();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj22 = seriesChangeEvent21.getSource();
        java.lang.Object obj23 = seriesChangeEvent21.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        seriesChangeEvent21.setSummary(seriesChangeInfo24);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo26 = seriesChangeEvent21.getSummary();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(seriesChangeInfo26);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        timeSeries3.setDescription("");
        timeSeries3.setMaximumItemAge((long) 10);
        timeSeries3.setMaximumItemCount((int) ' ');
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setMaximumItemCount((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        long long9 = fixedMillisecond7.getLastMillisecond();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        try {
            timeSeries21.delete(0, 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setRangeDescription("hi!");
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("-9999");
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 'a' + "'", comparable7.equals('a'));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries32.removeAgedItems(true);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str38 = month37.toString();
//        boolean boolean39 = timeSeries32.equals((java.lang.Object) month37);
//        double double40 = timeSeries32.getMinY();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.previous();
//        long long45 = day41.getLastMillisecond();
//        java.lang.String str46 = day41.toString();
//        java.util.Date date47 = day41.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date47);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date47, timeZone50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date47);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January -9999" + "'", str38.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long4 = month3.getLastMillisecond();
        int int5 = day0.compareTo((java.lang.Object) long4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        int int8 = day0.compareTo((java.lang.Object) 'a');
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 253405007999999L + "'", long4 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month11.previous();
        try {
            java.lang.String str17 = regularTimePeriod16.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        timeSeries3.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        org.jfree.data.time.Year year16 = month11.getYear();
        java.lang.String str17 = year16.toString();
        java.util.Calendar calendar18 = null;
        try {
            year16.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-9999" + "'", str17.equals("-9999"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries3.setRangeDescription("hi!");
        try {
            java.lang.Number number16 = timeSeries3.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.util.Calendar calendar18 = null;
        try {
            day17.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.lang.String str17 = day12.toString();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = day12.getFirstMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries26.removeAgedItems(true);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str32 = month31.toString();
        boolean boolean33 = timeSeries26.equals((java.lang.Object) month31);
        double double34 = timeSeries26.getMinY();
        java.lang.String str35 = timeSeries26.getDescription();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int39 = month38.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (double) 0.0f);
        org.jfree.data.time.Year year42 = month38.getYear();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (short) 1, year42);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 32L);
        java.util.List list46 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -9999" + "'", str32.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertNotNull(list46);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        timeSeriesDataItem6.setValue((java.lang.Number) 43626L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date8 = fixedMillisecond1.getStart();
        long long9 = fixedMillisecond1.getFirstMillisecond();
        long long10 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9999L) + "'", long7 == (-9999L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9999L) + "'", long10 == (-9999L));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        java.util.Collection collection30 = timeSeries3.getTimePeriods();
        double double31 = timeSeries3.getMaxY();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 12.0d + "'", double31 == 12.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("100");
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        java.lang.String str5 = year1.toString();
        long long6 = year1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61141708800001L) + "'", long6 == (-61141708800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries11.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long19 = month18.getLastMillisecond();
        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int24 = month23.getMonth();
        java.lang.Class<?> wildcardClass25 = month23.getClass();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month23);
        boolean boolean28 = timeSeries11.equals((java.lang.Object) "January -9999");
        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries11);
        timeSeries11.setDomainDescription("hi!");
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 253405007999999L + "'", long19 == 253405007999999L);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException4.toString();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) comparable14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean18 = fixedMillisecond1.equals((java.lang.Object) 'a');
        long long19 = fixedMillisecond1.getMiddleMillisecond();
        long long20 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 'a' + "'", comparable14.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9999L) + "'", long19 == (-9999L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9999L) + "'", long20 == (-9999L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        java.util.List list22 = timeSeries21.getItems();
        java.util.List list23 = timeSeries21.getItems();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries3.createCopy(7, (int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1);
        java.util.Calendar calendar12 = null;
        fixedMillisecond9.peg(calendar12);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        boolean boolean20 = timeSeries3.equals((java.lang.Object) "January -9999");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries24.removeAgedItems(true);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str30 = month29.toString();
        boolean boolean31 = timeSeries24.equals((java.lang.Object) month29);
        double double32 = timeSeries24.getMinY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day33.previous();
        java.util.Date date37 = regularTimePeriod36.getStart();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day38, 0.0d, false);
        try {
            timeSeries3.delete(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "January -9999" + "'", str30.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.removeAgedItems(false);
        double double4 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(7, (int) ' ');
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries7.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.previous();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 9, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.Object obj4 = seriesChangeEvent2.getSource();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        java.lang.String str6 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 100 + "'", obj3.equals((short) 100));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 100 + "'", obj4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (short) 100 + "'", obj5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str7 = month6.toString();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        long long9 = month6.getFirstMillisecond();
        org.jfree.data.time.Year year10 = month6.getYear();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January -9999" + "'", str7.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-377711740800000L) + "'", long9 == (-377711740800000L));
        org.junit.Assert.assertNotNull(year10);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        int int15 = day12.getDayOfMonth();
//        int int16 = day12.getYear();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries8.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long16 = month15.getLastMillisecond();
//        java.lang.Number number17 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries23.removeAgedItems(true);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str29 = month28.toString();
//        boolean boolean30 = timeSeries23.equals((java.lang.Object) month28);
//        double double31 = timeSeries23.getMinY();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 100);
//        long long35 = day32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = day32.getFirstMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "January -9999" + "'", str29.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        java.util.Collection collection16 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        java.lang.Object obj32 = timeSeriesDataItem29.clone();
        java.lang.Number number33 = timeSeriesDataItem29.getValue();
        java.lang.Object obj34 = timeSeriesDataItem29.clone();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1560150000000L + "'", number33.equals(1560150000000L));
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        java.lang.Object obj9 = timeSeries3.clone();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        java.lang.String str13 = month12.toString();
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, number14);
        timeSeries3.add(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "October 1" + "'", str13.equals("October 1"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException4.toString();
        java.lang.String str9 = seriesException4.toString();
        java.lang.Throwable[] throwableArray10 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries32.removeAgedItems(true);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str38 = month37.toString();
//        boolean boolean39 = timeSeries32.equals((java.lang.Object) month37);
//        double double40 = timeSeries32.getMinY();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.previous();
//        long long45 = day41.getLastMillisecond();
//        java.lang.String str46 = day41.toString();
//        java.util.Date date47 = day41.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date47);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date47, timeZone50);
//        java.util.TimeZone timeZone52 = null;
//        try {
//            org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date47, timeZone52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January -9999" + "'", str38.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries57.removeChangeListener(seriesChangeListener58);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        boolean boolean9 = timeSeries3.getNotify();
//        java.lang.String str10 = timeSeries3.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries14.removeAgedItems(true);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str20 = month19.toString();
//        boolean boolean21 = timeSeries14.equals((java.lang.Object) month19);
//        double double22 = timeSeries14.getMinY();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
//        long long27 = day23.getLastMillisecond();
//        java.lang.String str28 = day23.toString();
//        java.util.Date date29 = day23.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond30.peg(calendar31);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 11);
//        timeSeries3.setMaximumItemAge((long) ' ');
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "January -9999" + "'", str20.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560236399999L + "'", long27 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date29);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        boolean boolean7 = timeSeries3.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str11 = month10.toString();
        int int13 = month10.compareTo((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month10.next();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month10.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January -9999" + "'", str11.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        java.lang.Object obj22 = null;
        boolean boolean23 = timeSeries3.equals(obj22);
        timeSeries3.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries3.setRangeDescription("hi!");
        double double15 = timeSeries3.getMaxY();
        java.lang.String str16 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61141708800001L) + "'", long7 == (-61141708800001L));
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getFirstMillisecond();
//        int int17 = day15.getDayOfMonth();
//        int int18 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj21 = null;
//        boolean boolean22 = year20.equals(obj21);
//        int int23 = year20.getYear();
//        int int24 = year20.getYear();
//        java.lang.String str25 = year20.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
//        java.util.Calendar calendar27 = null;
//        try {
//            year20.peg(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 32 + "'", int24 == 32);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "32" + "'", str25.equals("32"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str7 = month6.toString();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January -9999" + "'", str7.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        try {
            timeSeries3.delete((int) '#', 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 'a');
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (-9999), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        java.util.Collection collection20 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = timeSeries3.equals(obj22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getDayOfMonth();
//        int int26 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) ' ');
//        java.util.Date date29 = year28.getEnd();
//        long long30 = year28.getFirstMillisecond();
//        timeSeries3.setKey((java.lang.Comparable) year28);
//        java.lang.Class class32 = timeSeries3.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61157520000000L) + "'", long30 == (-61157520000000L));
//        org.junit.Assert.assertNotNull(class32);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        boolean boolean7 = timeSeries3.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str11 = month10.toString();
        int int13 = month10.compareTo((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 8);
        try {
            timeSeries3.update(3, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January -9999" + "'", str11.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        boolean boolean58 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean61 = timeSeries60.getNotify();
        java.lang.Class<?> wildcardClass62 = timeSeries60.getClass();
        boolean boolean63 = timeSeries3.equals((java.lang.Object) timeSeries60);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean69 = timeSeries68.getNotify();
        timeSeries68.clear();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries74.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener77 = null;
        timeSeries74.removeChangeListener(seriesChangeListener77);
        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long82 = month81.getLastMillisecond();
        java.lang.Number number83 = timeSeries74.getValue((org.jfree.data.time.RegularTimePeriod) month81);
        org.jfree.data.time.Year year84 = month81.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month81, (java.lang.Number) (-1.0d));
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month81, (java.lang.Number) 1.0d, true);
        int int90 = month81.getMonth();
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 253405007999999L + "'", long82 == 253405007999999L);
        org.junit.Assert.assertNull(number83);
        org.junit.Assert.assertNotNull(year84);
        org.junit.Assert.assertNull(timeSeriesDataItem86);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        int int2 = year1.getYear();
        int int3 = year1.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean8 = timeSeries7.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries12.removeAgedItems(true);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str18 = month17.toString();
        boolean boolean19 = timeSeries12.equals((java.lang.Object) month17);
        double double20 = timeSeries12.getMinY();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
        java.util.Collection collection24 = timeSeries12.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries29.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries29.removeChangeListener(seriesChangeListener32);
        java.util.Collection collection34 = timeSeries29.getTimePeriods();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long38 = month37.getLastMillisecond();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month37, Double.NaN);
        long long41 = month37.getLastMillisecond();
        int int42 = month37.getMonth();
        long long43 = month37.getFirstMillisecond();
        boolean boolean44 = timeSeries25.equals((java.lang.Object) month37);
        timeSeries25.setDomainDescription("10-June-2019");
        boolean boolean47 = year1.equals((java.lang.Object) "10-June-2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January -9999" + "'", str18.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 253405007999999L + "'", long38 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 253405007999999L + "'", long41 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-377711740800000L) + "'", long43 == (-377711740800000L));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("100");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries12.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries12.getTimePeriods();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long21 = month20.getLastMillisecond();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month20, Double.NaN);
        long long24 = month20.getLastMillisecond();
        int int25 = month20.getMonth();
        timeSeries7.setKey((java.lang.Comparable) month20);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = month20.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 253405007999999L + "'", long21 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("-9999");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        int int2 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.delete(2019, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str7 = month6.toString();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        int int9 = month6.getMonth();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January -9999" + "'", str7.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date8 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9999L) + "'", long7 == (-9999L));
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setMaximumItemCount((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        long long9 = fixedMillisecond7.getLastMillisecond();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries19.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long27 = month26.getLastMillisecond();
        java.lang.Number number28 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month26, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 4);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 10L);
        try {
            timeSeries3.delete(9999, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 253405007999999L + "'", long27 == 253405007999999L);
        org.junit.Assert.assertNull(number28);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj6 = null;
//        boolean boolean7 = year5.equals(obj6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
//        timeSeries3.add(timeSeriesDataItem9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries14.setDescription("");
//        timeSeries14.setMaximumItemCount(11);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
//        timeSeries14.setKey((java.lang.Comparable) day19);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod24, (java.lang.Number) 1);
//        timeSeriesDataItem26.setSelected(true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        long long5 = fixedMillisecond3.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
        java.util.Calendar calendar7 = null;
        fixedMillisecond3.peg(calendar7);
        boolean boolean9 = year0.equals((java.lang.Object) fixedMillisecond3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-9999L) + "'", long5 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) 11);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean5, seriesChangeInfo6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException4.toString();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) comparable14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean18 = fixedMillisecond1.equals((java.lang.Object) 'a');
        long long19 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 'a' + "'", comparable14.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9999L) + "'", long19 == (-9999L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date2 = year1.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.Object obj4 = null;
        int int5 = month2.compareTo(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        timeSeries21.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        timeSeries29.add(timeSeriesDataItem35);
        java.util.Collection collection37 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Number number39 = null;
        try {
            timeSeries29.update(9999, number39);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(collection37);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        java.util.Date date16 = regularTimePeriod15.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.lang.String str19 = fixedMillisecond18.toString();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Sun Jun 09 00:00:00 PDT 2019" + "'", str19.equals("Sun Jun 09 00:00:00 PDT 2019"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        double double13 = timeSeries3.getMinY();
        timeSeries3.setRangeDescription("10-June-2019");
        int int16 = timeSeries3.getItemCount();
        long long17 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        timeSeries3.setDomainDescription("");
        try {
            timeSeries3.delete(2019, (int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.setRangeDescription("January -9999");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries18.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries31.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries31.removeChangeListener(seriesChangeListener34);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long39 = month38.getLastMillisecond();
        java.lang.Number number40 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) month38);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month38, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (double) 12);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj47 = null;
        boolean boolean48 = year46.equals(obj47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries54.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener57 = null;
        timeSeries54.removeChangeListener(seriesChangeListener57);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long62 = month61.getLastMillisecond();
        java.lang.Number number63 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) month61);
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int67 = month66.getMonth();
        java.lang.Class<?> wildcardClass68 = month66.getClass();
        timeSeries54.delete((org.jfree.data.time.RegularTimePeriod) month66);
        org.jfree.data.time.Year year70 = month66.getYear();
        java.lang.String str71 = month66.toString();
        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year46, (org.jfree.data.time.RegularTimePeriod) month66);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month66, 0.0d);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) 1.0d, false);
        java.util.Calendar calendar78 = null;
        try {
            month66.peg(calendar78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 'a' + "'", comparable8.equals('a'));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 253405007999999L + "'", long39 == 253405007999999L);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 253405007999999L + "'", long62 == 253405007999999L);
        org.junit.Assert.assertNull(number63);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(year70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "January -9999" + "'", str71.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries72);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        int int16 = month11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.previous();
        java.lang.String str18 = month11.toString();
        org.jfree.data.time.Year year19 = month11.getYear();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = month11.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January -9999" + "'", str18.equals("January -9999"));
        org.junit.Assert.assertNotNull(year19);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        timeSeries3.setRangeDescription("January -9999");
        timeSeries3.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj15 = null;
        boolean boolean16 = year14.equals(obj15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 1560150000000L);
        timeSeries12.add(timeSeriesDataItem18);
        timeSeriesDataItem18.setValue((java.lang.Number) 100.0f);
        boolean boolean22 = timeSeriesDataItem18.isSelected();
        timeSeries3.add(timeSeriesDataItem18);
        try {
            timeSeries3.delete((int) (short) -1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean18 = year16.equals((java.lang.Object) (byte) -1);
        long long19 = year16.getSerialIndex();
        java.lang.String str20 = year16.toString();
        int int21 = year16.getYear();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 32L + "'", long19 == 32L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "32" + "'", str20.equals("32"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries8.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long16 = month15.getLastMillisecond();
//        java.lang.Number number17 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries23.removeAgedItems(true);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str29 = month28.toString();
//        boolean boolean30 = timeSeries23.equals((java.lang.Object) month28);
//        double double31 = timeSeries23.getMinY();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 100);
//        long long35 = day32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
//        java.lang.Object obj37 = timeSeriesDataItem36.clone();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "January -9999" + "'", str29.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(obj37);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        java.util.Date date2 = year1.getStart();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries7.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        boolean boolean13 = timeSeries7.getNotify();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int16 = day14.compareTo((java.lang.Object) 100.0d);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) (short) 0);
        org.jfree.data.time.SerialDate serialDate19 = day14.getSerialDate();
        int int20 = year1.compareTo((java.lang.Object) serialDate19);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year1.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        java.util.Collection collection10 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = seriesChangeEvent11.getSummary();
        java.lang.Object obj13 = seriesChangeEvent11.getSource();
        java.lang.String str14 = seriesChangeEvent11.toString();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(seriesChangeInfo12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0d), seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.removeAgedItems(false);
        double double4 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(7, (int) ' ');
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 'a');
        int int3 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        java.lang.String str2 = year1.toString();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
        timeSeries3.add(timeSeriesDataItem9);
        timeSeriesDataItem9.setValue((java.lang.Number) 100.0f);
        int int14 = timeSeriesDataItem9.compareTo((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int14, "10-June-2019", "Time");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries3.createCopy(7, (int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1);
        double double12 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        long long8 = year6.getFirstMillisecond();
        boolean boolean9 = month2.equals((java.lang.Object) year6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61157520000000L) + "'", long8 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
        timeSeries3.add(timeSeriesDataItem9);
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        java.lang.Number number14 = null;
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year12, number14);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        org.jfree.data.time.Year year16 = month11.getYear();
        long long17 = month11.getMiddleMillisecond();
        long long18 = month11.getFirstMillisecond();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month11.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62153366400001L) + "'", long17 == (-62153366400001L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-377711740800000L) + "'", long18 == (-377711740800000L));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long4 = month3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) long4);
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 253405007999999L + "'", long4 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        boolean boolean8 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 'a' + "'", comparable7.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        java.util.Collection collection10 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries15.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long23 = month22.getLastMillisecond();
        java.lang.Number number24 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int28 = month27.getMonth();
        java.lang.Class<?> wildcardClass29 = month27.getClass();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Year year31 = month27.getYear();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj38 = null;
        boolean boolean39 = year37.equals(obj38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) 1560150000000L);
        timeSeries35.add(timeSeriesDataItem41);
        boolean boolean43 = month27.equals((java.lang.Object) timeSeriesDataItem41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) 9223372036854775807L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (-1L));
        try {
            timeSeries3.delete(32, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 253405007999999L + "'", long23 == 253405007999999L);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1L));
//        boolean boolean5 = timeSeriesDataItem4.isSelected();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries21.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries21.removeChangeListener(seriesChangeListener24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long29 = month28.getLastMillisecond();
        java.lang.Number number30 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month28, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (double) 12);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj37 = null;
        boolean boolean38 = year36.equals(obj37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries44.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries44.removeChangeListener(seriesChangeListener47);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long52 = month51.getLastMillisecond();
        java.lang.Number number53 = timeSeries44.getValue((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int57 = month56.getMonth();
        java.lang.Class<?> wildcardClass58 = month56.getClass();
        timeSeries44.delete((org.jfree.data.time.RegularTimePeriod) month56);
        org.jfree.data.time.Year year60 = month56.getYear();
        java.lang.String str61 = month56.toString();
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) month56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year36.next();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 253405007999999L + "'", long29 == 253405007999999L);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 253405007999999L + "'", long52 == 253405007999999L);
        org.junit.Assert.assertNull(number53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(year60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "January -9999" + "'", str61.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        timeSeries3.clear();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection15);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean4 = timeSeries3.getNotify();
//        timeSeries3.clear();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        long long8 = day6.getLastMillisecond();
//        long long9 = day6.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        double double11 = timeSeries3.getMinY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        boolean boolean9 = timeSeries3.getNotify();
//        java.util.Collection collection10 = timeSeries3.getTimePeriods();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries15.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener18);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long23 = month22.getLastMillisecond();
//        java.lang.Number number24 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) month22);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int28 = month27.getMonth();
//        java.lang.Class<?> wildcardClass29 = month27.getClass();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month27);
//        org.jfree.data.time.Year year31 = month27.getYear();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj38 = null;
//        boolean boolean39 = year37.equals(obj38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) 1560150000000L);
//        timeSeries35.add(timeSeriesDataItem41);
//        boolean boolean43 = month27.equals((java.lang.Object) timeSeriesDataItem41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) 9223372036854775807L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (-1L));
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries51.removeAgedItems(true);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str57 = month56.toString();
//        boolean boolean58 = timeSeries51.equals((java.lang.Object) month56);
//        double double59 = timeSeries51.getMinY();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) day60, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day60.previous();
//        java.util.Date date64 = regularTimePeriod63.getStart();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond(date64);
//        java.lang.String str67 = fixedMillisecond66.toString();
//        int int68 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        long long69 = fixedMillisecond66.getFirstMillisecond();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond66.getMiddleMillisecond(calendar70);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 253405007999999L + "'", long23 == 253405007999999L);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "January -9999" + "'", str57.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Sun Jun 09 00:00:00 PDT 2019" + "'", str67.equals("Sun Jun 09 00:00:00 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560063600000L + "'", long69 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560063600000L + "'", long71 == 1560063600000L);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries11.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long19 = month18.getLastMillisecond();
        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int24 = month23.getMonth();
        java.lang.Class<?> wildcardClass25 = month23.getClass();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month23);
        boolean boolean28 = timeSeries11.equals((java.lang.Object) "January -9999");
        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries11);
        java.util.List list30 = timeSeries11.getItems();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) list30, seriesChangeInfo31);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 253405007999999L + "'", long19 == 253405007999999L);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        timeSeries3.setDescription("");
        timeSeries3.setMaximumItemCount(11);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj10 = null;
        boolean boolean11 = year9.equals(obj10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries17.removeAgedItems(true);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str23 = month22.toString();
        boolean boolean24 = timeSeries17.equals((java.lang.Object) month22);
        double double25 = timeSeries17.getMinY();
        int int26 = timeSeriesDataItem13.compareTo((java.lang.Object) timeSeries17);
        timeSeries3.add(timeSeriesDataItem13);
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "January -9999" + "'", str23.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str7 = month6.toString();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        timeSeries3.removeAgedItems((long) 32, false);
        timeSeries3.clear();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January -9999" + "'", str7.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries22.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries22.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long30 = month29.getLastMillisecond();
        java.lang.Number number31 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int35 = month34.getMonth();
        java.lang.Class<?> wildcardClass36 = month34.getClass();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) month34);
        org.jfree.data.time.Year year38 = month34.getYear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj45 = null;
        boolean boolean46 = year44.equals(obj45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 1560150000000L);
        timeSeries42.add(timeSeriesDataItem48);
        boolean boolean50 = month34.equals((java.lang.Object) timeSeriesDataItem48);
        boolean boolean52 = timeSeriesDataItem48.equals((java.lang.Object) 1);
        timeSeriesDataItem48.setValue((java.lang.Number) 9);
        timeSeries3.add(timeSeriesDataItem48, false);
        java.lang.String str57 = timeSeries3.getDescription();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date61 = year60.getEnd();
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(1, year60);
        java.lang.String str63 = month62.toString();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month62, (java.lang.Number) (-61157520000000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 253405007999999L + "'", long30 == 253405007999999L);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "January 32" + "'", str63.equals("January 32"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Overwritten values from: a");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem29.getPeriod();
        timeSeriesDataItem29.setSelected(false);
        timeSeriesDataItem29.setSelected(true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        long long58 = year31.getFirstMillisecond();
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61157520000000L) + "'", long58 == (-61157520000000L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond1.equals(obj6);
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        long long9 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-9999L) + "'", long5 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9999L) + "'", long8 == (-9999L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("February 10");
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod58, (double) 1560150000000L);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9999L) + "'", long7 == (-9999L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException4.toString();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) comparable14);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        timeSeries19.setRangeDescription("January -9999");
        java.lang.String str23 = timeSeries19.getDomainDescription();
        boolean boolean24 = fixedMillisecond1.equals((java.lang.Object) timeSeries19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        long long27 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) year28);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries19.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 'a' + "'", comparable14.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 'a' + "'", comparable20.equals('a'));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9999L) + "'", long27 == (-9999L));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.util.TimeZone timeZone27 = null;
//        java.util.Locale locale28 = null;
//        try {
//            org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date23, timeZone27, locale28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries9.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries9.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long17 = month16.getLastMillisecond();
        java.lang.Number number18 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.Year year19 = month16.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (-1.0d));
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month16.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 253405007999999L + "'", long17 == 253405007999999L);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        int int15 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
//        long long19 = day18.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 0.0f);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month15.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int24 = month23.getMonth();
        java.lang.Class<?> wildcardClass25 = month23.getClass();
        int int26 = month15.compareTo((java.lang.Object) month23);
        long long27 = month15.getSerialIndex();
        java.lang.String str28 = month15.toString();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-119987L) + "'", long27 == (-119987L));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January -9999" + "'", str28.equals("January -9999"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.getNotify();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries7.removeAgedItems(true);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str13 = month12.toString();
        boolean boolean14 = timeSeries7.equals((java.lang.Object) month12);
        double double15 = timeSeries7.getMinY();
        java.lang.String str16 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.addChangeListener(seriesChangeListener17);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "January -9999" + "'", str13.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries16.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long24 = month23.getLastMillisecond();
//        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj32 = null;
//        boolean boolean33 = year31.equals(obj32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries39.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries39.removeChangeListener(seriesChangeListener42);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long47 = month46.getLastMillisecond();
//        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int52 = month51.getMonth();
//        java.lang.Class<?> wildcardClass53 = month51.getClass();
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
//        org.jfree.data.time.Year year55 = month51.getYear();
//        java.lang.String str56 = month51.toString();
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
//        boolean boolean58 = timeSeries3.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries62.removeAgedItems(true);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str68 = month67.toString();
//        boolean boolean69 = timeSeries62.equals((java.lang.Object) month67);
//        double double70 = timeSeries62.getMinY();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) day71, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day71.previous();
//        long long75 = day71.getLastMillisecond();
//        java.lang.String str76 = day71.toString();
//        java.util.Date date77 = day71.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond(date77);
//        java.lang.Number number79 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond78);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener80 = null;
//        timeSeries3.addChangeListener(seriesChangeListener80);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "January -9999" + "'", str68.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560236399999L + "'", long75 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "10-June-2019" + "'", str76.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 12.0d + "'", number79.equals(12.0d));
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.util.Date date6 = regularTimePeriod5.getStart();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        org.jfree.data.time.SerialDate serialDate15 = day10.getSerialDate();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day10.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries9.removeAgedItems(true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str15 = month14.toString();
        boolean boolean16 = timeSeries9.equals((java.lang.Object) month14);
        double double17 = timeSeries9.getMinY();
        int int18 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries9);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(1, 0);
        boolean boolean22 = timeSeriesDataItem5.equals((java.lang.Object) month21);
        long long23 = month21.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January -9999" + "'", str15.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries3.setDescription("");
//        timeSeries3.setMaximumItemAge((long) 10);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean12 = timeSeries11.getNotify();
//        timeSeries11.clear();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        long long16 = day14.getLastMillisecond();
//        long long17 = day14.getLastMillisecond();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = day14.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        int int5 = year1.compareTo((java.lang.Object) 32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 1);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int11 = month10.getMonth();
        java.lang.Class<?> wildcardClass12 = month10.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone18);
        boolean boolean20 = timeSeriesDataItem7.equals((java.lang.Object) timeZone18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-58979980800001L) + "'", long2 == (-58979980800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        double double13 = timeSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long16 = month15.getLastMillisecond();
        java.lang.Number number17 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 4);
        boolean boolean22 = timeSeriesDataItem21.isSelected();
        boolean boolean23 = timeSeriesDataItem21.isSelected();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long17 = month16.getLastMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month16, Double.NaN);
        long long20 = month16.getLastMillisecond();
        java.lang.String str21 = month16.toString();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 10);
        java.lang.String str24 = timeSeries4.getDomainDescription();
        try {
            timeSeries4.setMaximumItemAge((-58979980800001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 253405007999999L + "'", long17 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 253405007999999L + "'", long20 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "January -9999" + "'", str21.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.Year year4 = month2.getYear();
        long long5 = month2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-119987L) + "'", long5 == (-119987L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 100L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        boolean boolean20 = timeSeries3.equals((java.lang.Object) "January -9999");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries9.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries9.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries9.getTimePeriods();
        int int15 = month2.compareTo((java.lang.Object) timeSeries9);
        long long16 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-377711740800000L) + "'", long16 == (-377711740800000L));
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long11 = month10.getLastMillisecond();
//        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj19 = null;
//        boolean boolean20 = year18.equals(obj19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1560150000000L);
//        timeSeries16.add(timeSeriesDataItem22);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries27.setDescription("");
//        timeSeries27.setMaximumItemCount(11);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day32.previous();
//        timeSeries27.setKey((java.lang.Comparable) day32);
//        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
//        java.lang.String str38 = timeSeries3.getDescription();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNull(str38);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.getNotify();
        boolean boolean3 = timeSeries1.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        timeSeries8.removeAgedItems((long) (short) 10, false);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 100.0f);
        int int22 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        boolean boolean23 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries16.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long24 = month23.getLastMillisecond();
//        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj32 = null;
//        boolean boolean33 = year31.equals(obj32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries39.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries39.removeChangeListener(seriesChangeListener42);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long47 = month46.getLastMillisecond();
//        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int52 = month51.getMonth();
//        java.lang.Class<?> wildcardClass53 = month51.getClass();
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
//        org.jfree.data.time.Year year55 = month51.getYear();
//        java.lang.String str56 = month51.toString();
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
//        boolean boolean58 = timeSeries3.isEmpty();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        long long60 = day59.getFirstMillisecond();
//        int int61 = day59.getDayOfMonth();
//        int int62 = day59.getMonth();
//        long long63 = day59.getLastMillisecond();
//        java.lang.Number number64 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day59);
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries68.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener71 = null;
//        timeSeries68.removeChangeListener(seriesChangeListener71);
//        java.util.Collection collection73 = timeSeries68.getTimePeriods();
//        timeSeries68.removeAgedItems((long) (short) 10, false);
//        java.util.Collection collection77 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries68);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560150000000L + "'", long60 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560236399999L + "'", long63 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 12.0d + "'", number64.equals(12.0d));
//        org.junit.Assert.assertNotNull(collection73);
//        org.junit.Assert.assertNotNull(collection77);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        int int4 = year1.getYear();
        int int5 = year1.getYear();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int5, seriesChangeInfo6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent7.getSummary();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj19 = null;
        boolean boolean20 = year18.equals(obj19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1560150000000L);
        timeSeries16.add(timeSeriesDataItem22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem22);
        double double25 = timeSeries3.getMaxY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries3.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.56015E12d + "'", double25 == 1.56015E12d);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setDescription("Sun Jun 09 00:00:00 PDT 2019");
        double double12 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj19 = null;
        boolean boolean20 = year18.equals(obj19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1560150000000L);
        timeSeries16.add(timeSeriesDataItem22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem22);
        double double25 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.addAndOrUpdate(timeSeries26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.56015E12d + "'", double25 == 1.56015E12d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj28 = null;
        boolean boolean29 = year27.equals(obj28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 1560150000000L);
        timeSeries25.add(timeSeriesDataItem31);
        boolean boolean33 = timeSeries25.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(12);
        java.util.Date date37 = year36.getStart();
        long long38 = year36.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) (byte) 10);
        java.lang.Comparable comparable41 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 12L + "'", long38 == 12L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 'a' + "'", comparable41.equals('a'));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        long long4 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61757049600001L) + "'", long4 == (-61757049600001L));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.removeChangeListener(seriesChangeListener12);
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries18.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long26 = month25.getLastMillisecond();
        java.lang.Number number27 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int31 = month30.getMonth();
        java.lang.Class<?> wildcardClass32 = month30.getClass();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Year year34 = month30.getYear();
        java.lang.String str35 = month30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month30.next();
        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 253405007999999L + "'", long26 == 253405007999999L);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "January -9999" + "'", str35.equals("January -9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries4.removeAgedItems(true);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str10 = month9.toString();
        boolean boolean11 = timeSeries4.equals((java.lang.Object) month9);
        double double12 = timeSeries4.getMinY();
        java.lang.String str13 = timeSeries4.getDescription();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int17 = month16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0.0f);
        org.jfree.data.time.Year year20 = month16.getYear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, year20);
        long long22 = year20.getSerialIndex();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year20.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January -9999" + "'", str10.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-9999L) + "'", long22 == (-9999L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries3.addChangeListener(seriesChangeListener30);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries17.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries17.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long25 = month24.getLastMillisecond();
        java.lang.Number number26 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month24);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month24, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.addOrUpdate(timeSeriesDataItem30);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries3.addChangeListener(seriesChangeListener32);
        java.util.Collection collection34 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 253405007999999L + "'", long25 == 253405007999999L);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(collection34);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException4.toString();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) comparable14);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        timeSeries19.setRangeDescription("January -9999");
        java.lang.String str23 = timeSeries19.getDomainDescription();
        boolean boolean24 = fixedMillisecond1.equals((java.lang.Object) timeSeries19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        long long27 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) year28);
        try {
            timeSeries30.delete(8, (int) 'a', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 'a' + "'", comparable14.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 'a' + "'", comparable20.equals('a'));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9999L) + "'", long27 == (-9999L));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        timeSeries3.setRangeDescription("January -9999");
        java.lang.String str7 = timeSeries3.getDomainDescription();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries3.equals(obj8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries13.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        java.util.Collection collection18 = timeSeries13.getTimePeriods();
        boolean boolean19 = timeSeries13.getNotify();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int22 = day20.compareTo((java.lang.Object) 100.0d);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (short) 0);
        org.jfree.data.time.SerialDate serialDate25 = day20.getSerialDate();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 20);
        int int29 = day26.getYear();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries8.removeChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long17 = month16.getLastMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month16, Double.NaN);
        long long20 = month16.getLastMillisecond();
        java.lang.String str21 = month16.toString();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 10);
        java.lang.String str24 = timeSeries4.getDomainDescription();
        try {
            java.lang.Number number26 = timeSeries4.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 253405007999999L + "'", long17 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 253405007999999L + "'", long20 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "January -9999" + "'", str21.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        java.util.Date date16 = regularTimePeriod15.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.lang.String str19 = fixedMillisecond18.toString();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Sun Jun 09 00:00:00 PDT 2019" + "'", str19.equals("Sun Jun 09 00:00:00 PDT 2019"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemCount(2147483647);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.previous();
        java.util.Date date15 = fixedMillisecond13.getTime();
        java.lang.Number number16 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 6);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 1" + "'", str3.equals("October 1"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        boolean boolean7 = timeSeries3.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str11 = month10.toString();
        int int13 = month10.compareTo((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 8);
        timeSeries3.setMaximumItemAge((long) 4);
        timeSeries3.setNotify(true);
        timeSeries3.removeAgedItems((long) 100, false);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January -9999" + "'", str11.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-9999));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries9.removeAgedItems(true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str15 = month14.toString();
        boolean boolean16 = timeSeries9.equals((java.lang.Object) month14);
        double double17 = timeSeries9.getMinY();
        int int18 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries9);
        boolean boolean20 = timeSeriesDataItem5.equals((java.lang.Object) 10);
        timeSeriesDataItem5.setValue((java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem5.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January -9999" + "'", str15.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        java.lang.String str12 = timeSeries3.getDescription();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int16 = month15.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 0.0f);
//        org.jfree.data.time.Year year19 = month15.getYear();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        int int23 = day20.getMonth();
//        long long24 = day20.getFirstMillisecond();
//        int int25 = year19.compareTo((java.lang.Object) day20);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo26 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int25, seriesChangeInfo26);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.String str8 = timeSeries7.getDomainDescription();
        try {
            timeSeries7.delete(1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.lang.String str17 = day12.toString();
//        java.util.Date date18 = day12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = month20.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setMaximumItemCount((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        long long9 = fixedMillisecond7.getLastMillisecond();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries19.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.removeChangeListener(seriesChangeListener22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long27 = month26.getLastMillisecond();
        java.lang.Number number28 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) month26);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month26, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 4);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 10L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Date date37 = fixedMillisecond36.getEnd();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9999L) + "'", long9 == (-9999L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 253405007999999L + "'", long27 == 253405007999999L);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(date37);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries8.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long16 = month15.getLastMillisecond();
//        java.lang.Number number17 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries23.removeAgedItems(true);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str29 = month28.toString();
//        boolean boolean30 = timeSeries23.equals((java.lang.Object) month28);
//        double double31 = timeSeries23.getMinY();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 100);
//        long long35 = day32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
//        long long37 = day32.getMiddleMillisecond();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "January -9999" + "'", str29.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560193199999L + "'", long37 == 1560193199999L);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        java.util.Collection collection20 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
//        java.util.List list22 = timeSeries21.getItems();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int26 = month25.getMonth();
//        java.lang.Class<?> wildcardClass27 = month25.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries31.removeAgedItems(true);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str37 = month36.toString();
//        boolean boolean38 = timeSeries31.equals((java.lang.Object) month36);
//        double double39 = timeSeries31.getMinY();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day40.previous();
//        long long44 = day40.getLastMillisecond();
//        java.lang.String str45 = day40.toString();
//        java.util.Date date46 = day40.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date46, timeZone48);
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond52.previous();
//        org.jfree.data.general.SeriesException seriesException55 = new org.jfree.data.general.SeriesException("hi!");
//        org.jfree.data.general.SeriesException seriesException57 = new org.jfree.data.general.SeriesException("hi!");
//        seriesException55.addSuppressed((java.lang.Throwable) seriesException57);
//        java.lang.String str59 = seriesException55.toString();
//        boolean boolean60 = fixedMillisecond52.equals((java.lang.Object) str59);
//        long long61 = fixedMillisecond52.getSerialIndex();
//        java.util.Date date62 = fixedMillisecond52.getTime();
//        java.util.TimeZone timeZone63 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date62, timeZone63);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date62);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date62);
//        try {
//            timeSeries21.update((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(list22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "January -9999" + "'", str37.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str59.equals("org.jfree.data.general.SeriesException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-9999L) + "'", long61 == (-9999L));
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries11.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long19 = month18.getLastMillisecond();
        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int24 = month23.getMonth();
        java.lang.Class<?> wildcardClass25 = month23.getClass();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month23);
        boolean boolean28 = timeSeries11.equals((java.lang.Object) "January -9999");
        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries11);
        try {
            timeSeries11.setMaximumItemCount((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 253405007999999L + "'", long19 == 253405007999999L);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.String str8 = timeSeries7.getDomainDescription();
        try {
            timeSeries7.delete((int) '#', 8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(1, year2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem29.getPeriod();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean38 = year36.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year36.previous();
        boolean boolean40 = timeSeriesDataItem29.equals((java.lang.Object) regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries10.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries10.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long18 = month17.getLastMillisecond();
        java.lang.Number number19 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Year year20 = month17.getYear();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month17, (double) 5);
        timeSeries6.clear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 253405007999999L + "'", long18 == 253405007999999L);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertNotNull(year20);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        java.lang.String str5 = year1.toString();
        int int6 = year1.getYear();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries10.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries10.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries10.getTimePeriods();
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.String str17 = timeSeries10.getRangeDescription();
        timeSeries10.clear();
        boolean boolean19 = year1.equals((java.lang.Object) timeSeries10);
        java.util.List list20 = timeSeries10.getItems();
        timeSeries10.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        java.util.Collection collection7 = timeSeries3.getTimePeriods();
        timeSeries3.clear();
        try {
            timeSeries3.delete(0, 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        long long6 = month3.getSerialIndex();
        org.jfree.data.time.Year year7 = month3.getYear();
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(0, year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January -9999" + "'", str4.equals("January -9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-119987L) + "'", long6 == (-119987L));
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) (short) 10, false);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 100.0f);
        java.lang.String str17 = timeSeries3.getDomainDescription();
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.util.Date date7 = regularTimePeriod6.getStart();
        long long8 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61141708800001L) + "'", long8 == (-61141708800001L));
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        int int4 = day3.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.getNotify();
        boolean boolean3 = timeSeries1.isEmpty();
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, (int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year19.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        boolean boolean3 = year1.equals((java.lang.Object) (byte) -1);
        long long4 = year1.getSerialIndex();
        java.lang.String str5 = year1.toString();
        int int6 = year1.getYear();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries10.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries10.removeChangeListener(seriesChangeListener13);
        java.util.Collection collection15 = timeSeries10.getTimePeriods();
        boolean boolean16 = timeSeries10.getNotify();
        java.lang.String str17 = timeSeries10.getRangeDescription();
        timeSeries10.clear();
        boolean boolean19 = year1.equals((java.lang.Object) timeSeries10);
        long long20 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61157520000000L) + "'", long20 == (-61157520000000L));
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries5.setDescription("");
//        timeSeries5.setMaximumItemAge((long) 10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean14 = timeSeries13.getNotify();
//        timeSeries13.clear();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getSerialIndex();
//        long long18 = day16.getLastMillisecond();
//        long long19 = day16.getLastMillisecond();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        int int22 = year1.compareTo((java.lang.Object) day16);
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = year1.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        int int4 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-58979980800001L) + "'", long2 == (-58979980800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long11 = month10.getLastMillisecond();
//        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
//        timeSeries3.setRangeDescription("hi!");
//        double double15 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries19.removeAgedItems(true);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str25 = month24.toString();
//        boolean boolean26 = timeSeries19.equals((java.lang.Object) month24);
//        double double27 = timeSeries19.getMinY();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.previous();
//        long long32 = day28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries36.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener39);
//        java.util.Collection collection41 = timeSeries36.getTimePeriods();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long45 = month44.getLastMillisecond();
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month44, Double.NaN);
//        long long48 = month44.getLastMillisecond();
//        int int49 = day28.compareTo((java.lang.Object) month44);
//        java.lang.String str50 = day28.toString();
//        java.lang.Number number51 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day28);
//        java.util.Calendar calendar52 = null;
//        try {
//            long long53 = day28.getFirstMillisecond(calendar52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "January -9999" + "'", str25.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 253405007999999L + "'", long45 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 253405007999999L + "'", long48 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "10-June-2019" + "'", str50.equals("10-June-2019"));
//        org.junit.Assert.assertNull(number51);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException4.toString();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) str8);
        long long10 = fixedMillisecond1.getSerialIndex();
        java.util.Date date11 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9999L) + "'", long10 == (-9999L));
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 'a');
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date16);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        boolean boolean4 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries9.removeAgedItems(true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str15 = month14.toString();
        boolean boolean16 = timeSeries9.equals((java.lang.Object) month14);
        double double17 = timeSeries9.getMinY();
        int int18 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries9);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(1, 0);
        boolean boolean22 = timeSeriesDataItem5.equals((java.lang.Object) month21);
        long long23 = month21.getLastMillisecond();
        int int24 = month21.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January -9999" + "'", str15.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62133062400001L) + "'", long23 == (-62133062400001L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int3 = month2.getMonth();
//        java.lang.Class<?> wildcardClass4 = month2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        long long21 = day17.getLastMillisecond();
//        java.lang.String str22 = day17.toString();
//        java.util.Date date23 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date23, timeZone25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("hi!");
//        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("hi!");
//        seriesException32.addSuppressed((java.lang.Throwable) seriesException34);
//        java.lang.String str36 = seriesException32.toString();
//        boolean boolean37 = fixedMillisecond29.equals((java.lang.Object) str36);
//        long long38 = fixedMillisecond29.getSerialIndex();
//        java.util.Date date39 = fixedMillisecond29.getTime();
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date39, timeZone40);
//        java.util.TimeZone timeZone42 = null;
//        try {
//            org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date39, timeZone42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str36.equals("org.jfree.data.general.SeriesException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-9999L) + "'", long38 == (-9999L));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener12);
//        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries18.removeAgedItems(true);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str24 = month23.toString();
//        boolean boolean25 = timeSeries18.equals((java.lang.Object) month23);
//        double double26 = timeSeries18.getMinY();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day27.previous();
//        long long31 = day27.getLastMillisecond();
//        java.lang.String str32 = day27.toString();
//        java.util.Date date33 = day27.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Calendar calendar35 = null;
//        fixedMillisecond34.peg(calendar35);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 12.0d, false);
//        java.lang.Class class40 = timeSeries3.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "January -9999" + "'", str24.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(class40);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        timeSeries3.setRangeDescription("January -9999");
        java.lang.String str7 = timeSeries3.getDomainDescription();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries3.equals(obj8);
        java.lang.Class class10 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int29 = month28.getMonth();
        java.lang.Class<?> wildcardClass30 = month28.getClass();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.Year year32 = month28.getYear();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj39 = null;
        boolean boolean40 = year38.equals(obj39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 1560150000000L);
        timeSeries36.add(timeSeriesDataItem42);
        boolean boolean44 = month28.equals((java.lang.Object) timeSeriesDataItem42);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) month28);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeries45);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries10.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries10.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long18 = month17.getLastMillisecond();
        java.lang.Number number19 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int23 = month22.getMonth();
        java.lang.Class<?> wildcardClass24 = month22.getClass();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.time.Year year26 = month22.getYear();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj33 = null;
        boolean boolean34 = year32.equals(obj33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 1560150000000L);
        timeSeries30.add(timeSeriesDataItem36);
        boolean boolean38 = month22.equals((java.lang.Object) timeSeriesDataItem36);
        boolean boolean40 = timeSeriesDataItem36.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem36.getPeriod();
        timeSeries3.add(timeSeriesDataItem36, true);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 10);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 253405007999999L + "'", long18 == 253405007999999L);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.removeChangeListener(seriesChangeListener13);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        int int4 = year1.getYear();
        long long5 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries5.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries5.getTimePeriods();
//        timeSeries5.removeAgedItems((long) (short) 10, false);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean18 = timeSeries17.getNotify();
//        timeSeries17.clear();
//        boolean boolean20 = timeSeries5.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries17.addChangeListener(seriesChangeListener21);
//        java.lang.String str23 = timeSeries17.getRangeDescription();
//        boolean boolean24 = day0.equals((java.lang.Object) timeSeries17);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        int int16 = month11.getMonth();
        long long17 = month11.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (byte) 100);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond19.getClass();
        boolean boolean26 = month11.equals((java.lang.Object) wildcardClass25);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-377711740800000L) + "'", long17 == (-377711740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-9999L) + "'", long22 == (-9999L));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries24.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long32 = month31.getLastMillisecond();
        java.lang.Number number33 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) month31);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month31, (double) 1560150000000L);
        boolean boolean36 = timeSeries3.equals((java.lang.Object) month31);
        long long37 = month31.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 253405007999999L + "'", long32 == 253405007999999L);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setDescription("Sun Jun 09 00:00:00 PDT 2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries15.removeAgedItems(true);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str21 = month20.toString();
        boolean boolean22 = timeSeries15.equals((java.lang.Object) month20);
        double double23 = timeSeries15.getMinY();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 100);
        java.util.Collection collection27 = timeSeries15.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries36.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries36.removeChangeListener(seriesChangeListener39);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long44 = month43.getLastMillisecond();
        java.lang.Number number45 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) month43);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month43, (double) 1560150000000L);
        boolean boolean48 = timeSeries15.equals((java.lang.Object) month43);
        int int49 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month43);
        try {
            java.lang.Number number51 = timeSeries3.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "January -9999" + "'", str21.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 253405007999999L + "'", long44 == 253405007999999L);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries7.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long16 = month15.getLastMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month15, Double.NaN);
        long long19 = month15.getLastMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, number20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((-62138894400001L));
        int int24 = month15.compareTo((java.lang.Object) (-62138894400001L));
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries28.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries28.removeChangeListener(seriesChangeListener31);
        java.util.Collection collection33 = timeSeries28.getTimePeriods();
        timeSeries28.removeAgedItems((long) (short) 10, false);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean41 = timeSeries40.getNotify();
        timeSeries40.clear();
        boolean boolean43 = timeSeries28.equals((java.lang.Object) timeSeries40);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries40.addChangeListener(seriesChangeListener44);
        int int46 = month15.compareTo((java.lang.Object) seriesChangeListener44);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 253405007999999L + "'", long19 == 253405007999999L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries3.setDescription("");
//        timeSeries3.setMaximumItemCount(11);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timeSeries3.setKey((java.lang.Comparable) day8);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day8.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-62138894400001L));
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62138894400001L) + "'", long2 == (-62138894400001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62138894400001L) + "'", long4 == (-62138894400001L));
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        java.lang.String str15 = day12.toString();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day12.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month15.previous();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        java.lang.String str16 = month11.toString();
        org.jfree.data.time.Year year17 = month11.getYear();
        long long18 = year17.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "January -9999" + "'", str16.equals("January -9999"));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-377711740800000L) + "'", long18 == (-377711740800000L));
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
//        double double16 = timeSeries8.getMinY();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        java.util.Collection collection20 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries25.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        java.util.Collection collection30 = timeSeries25.getTimePeriods();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long34 = month33.getLastMillisecond();
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month33, Double.NaN);
//        long long37 = month33.getLastMillisecond();
//        int int38 = month33.getMonth();
//        long long39 = month33.getFirstMillisecond();
//        boolean boolean40 = timeSeries21.equals((java.lang.Object) month33);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getFirstMillisecond();
//        int int44 = day41.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries49.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries49.removeChangeListener(seriesChangeListener52);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long57 = month56.getLastMillisecond();
//        java.lang.Number number58 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) month56);
//        timeSeries49.setRangeDescription("hi!");
//        double double61 = timeSeries49.getMaxY();
//        long long62 = timeSeries49.getMaximumItemAge();
//        int int63 = day41.compareTo((java.lang.Object) timeSeries49);
//        boolean boolean64 = timeSeries49.getNotify();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 253405007999999L + "'", long34 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-377711740800000L) + "'", long39 == (-377711740800000L));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560150000000L + "'", long42 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 253405007999999L + "'", long57 == 253405007999999L);
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        java.util.List list22 = timeSeries21.getItems();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj25 = null;
        boolean boolean26 = year24.equals(obj25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries32.removeAgedItems(true);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str38 = month37.toString();
        boolean boolean39 = timeSeries32.equals((java.lang.Object) month37);
        double double40 = timeSeries32.getMinY();
        int int41 = timeSeriesDataItem28.compareTo((java.lang.Object) timeSeries32);
        boolean boolean43 = timeSeriesDataItem28.equals((java.lang.Object) 10);
        timeSeriesDataItem28.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries21.addOrUpdate(timeSeriesDataItem28);
        try {
            timeSeriesDataItem46.setSelected(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January -9999" + "'", str38.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        java.lang.String str30 = timeSeries3.getRangeDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries3.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        java.lang.String str16 = month14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "October 1" + "'", str16.equals("October 1"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        java.util.List list7 = timeSeries3.getItems();
        timeSeries3.clear();
        int int9 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries11.removeAgedItems(true);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str17 = month16.toString();
//        boolean boolean18 = timeSeries11.equals((java.lang.Object) month16);
//        double double19 = timeSeries11.getMinY();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (byte) 100);
//        java.util.Collection collection23 = timeSeries11.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries28.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        java.util.Collection collection33 = timeSeries28.getTimePeriods();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long37 = month36.getLastMillisecond();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month36, Double.NaN);
//        long long40 = month36.getLastMillisecond();
//        int int41 = month36.getMonth();
//        long long42 = month36.getFirstMillisecond();
//        boolean boolean43 = timeSeries24.equals((java.lang.Object) month36);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        long long45 = day44.getFirstMillisecond();
//        int int47 = day44.compareTo((java.lang.Object) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
//        int int49 = month2.compareTo((java.lang.Object) timeSeries24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "January -9999" + "'", str17.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 253405007999999L + "'", long40 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-377711740800000L) + "'", long42 == (-377711740800000L));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560150000000L + "'", long45 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        boolean boolean20 = timeSeries3.equals((java.lang.Object) "January -9999");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries24.removeAgedItems(true);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str30 = month29.toString();
        boolean boolean31 = timeSeries24.equals((java.lang.Object) month29);
        double double32 = timeSeries24.getMinY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day33.previous();
        java.util.Date date37 = regularTimePeriod36.getStart();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day38, 0.0d, false);
        org.jfree.data.time.TimeSeries timeSeries42 = null;
        try {
            java.util.Collection collection43 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "January -9999" + "'", str30.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries20.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener23);
//        java.util.Collection collection25 = timeSeries20.getTimePeriods();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long29 = month28.getLastMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month28, Double.NaN);
//        long long32 = month28.getLastMillisecond();
//        int int33 = day12.compareTo((java.lang.Object) month28);
//        int int34 = month28.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 253405007999999L + "'", long29 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 253405007999999L + "'", long32 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        timeSeries3.setDomainDescription("");
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 10 + "'", comparable7.equals((short) 10));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        timeSeries3.setDescription("");
        timeSeries3.setMaximumItemAge((long) 10);
        timeSeries3.setNotify(false);
        try {
            timeSeries3.delete((int) '4', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str7 = month6.toString();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January -9999" + "'", str7.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        long long4 = year1.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61157520000000L) + "'", long4 == (-61157520000000L));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj28 = null;
        boolean boolean29 = year27.equals(obj28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 1560150000000L);
        timeSeries25.add(timeSeriesDataItem31);
        boolean boolean33 = timeSeries25.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries25);
        try {
            java.lang.Number number36 = timeSeries25.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        long long12 = timeSeries3.getMaximumItemAge();
        double double13 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy(100, 9999);
        double double17 = timeSeries16.getMaxY();
        java.lang.String str18 = timeSeries16.getDomainDescription();
        timeSeries16.setNotify(true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, "January 32", "January 32");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setDomainDescription("org.jfree.data.general.SeriesException: hi!");
        long long6 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "Sun Jun 09 00:00:00 PDT 2019", "Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries3.setDescription("");
//        timeSeries3.setMaximumItemCount(11);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timeSeries3.setKey((java.lang.Comparable) day8);
//        int int12 = day8.getDayOfMonth();
//        java.util.Calendar calendar13 = null;
//        try {
//            day8.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long11 = month10.getLastMillisecond();
//        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int16 = month15.getMonth();
//        java.lang.Class<?> wildcardClass17 = month15.getClass();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        boolean boolean20 = timeSeries3.equals((java.lang.Object) "January -9999");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries24.removeAgedItems(true);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str30 = month29.toString();
//        boolean boolean31 = timeSeries24.equals((java.lang.Object) month29);
//        double double32 = timeSeries24.getMinY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day33.previous();
//        java.util.Date date37 = regularTimePeriod36.getStart();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day38, 0.0d, false);
//        int int42 = day38.getYear();
//        long long43 = day38.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "January -9999" + "'", str30.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560149999999L + "'", long43 == 1560149999999L);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        boolean boolean9 = timeSeries3.getNotify();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 100.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
//        long long15 = day10.getLastMillisecond();
//        int int16 = day10.getDayOfMonth();
//        long long17 = day10.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day10.previous();
//        long long19 = day10.getLastMillisecond();
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj10 = null;
        boolean boolean11 = year9.equals(obj10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries17.removeAgedItems(true);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str23 = month22.toString();
        boolean boolean24 = timeSeries17.equals((java.lang.Object) month22);
        double double25 = timeSeries17.getMinY();
        int int26 = timeSeriesDataItem13.compareTo((java.lang.Object) timeSeries17);
        timeSeries3.add(timeSeriesDataItem13, true);
        timeSeriesDataItem13.setSelected(false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "January -9999" + "'", str23.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries11.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long19 = month18.getLastMillisecond();
        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int24 = month23.getMonth();
        java.lang.Class<?> wildcardClass25 = month23.getClass();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month23);
        boolean boolean28 = timeSeries11.equals((java.lang.Object) "January -9999");
        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries11);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener30);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 253405007999999L + "'", long19 == 253405007999999L);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) 11);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9999L) + "'", long7 == (-9999L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries16.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long24 = month23.getLastMillisecond();
//        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj32 = null;
//        boolean boolean33 = year31.equals(obj32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries39.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries39.removeChangeListener(seriesChangeListener42);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long47 = month46.getLastMillisecond();
//        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int52 = month51.getMonth();
//        java.lang.Class<?> wildcardClass53 = month51.getClass();
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
//        org.jfree.data.time.Year year55 = month51.getYear();
//        java.lang.String str56 = month51.toString();
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
//        boolean boolean58 = timeSeries3.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries62.removeAgedItems(true);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str68 = month67.toString();
//        boolean boolean69 = timeSeries62.equals((java.lang.Object) month67);
//        double double70 = timeSeries62.getMinY();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) day71, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        long long75 = day74.getFirstMillisecond();
//        int int76 = day74.getDayOfMonth();
//        int int77 = timeSeries62.getIndex((org.jfree.data.time.RegularTimePeriod) day74);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj80 = null;
//        boolean boolean81 = year79.equals(obj80);
//        int int82 = year79.getYear();
//        int int83 = year79.getYear();
//        java.lang.String str84 = year79.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) year79);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year79, 10.0d, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "January -9999" + "'", str68.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560150000000L + "'", long75 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 10 + "'", int76 == 10);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 32 + "'", int82 == 32);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 32 + "'", int83 == 32);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "32" + "'", str84.equals("32"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem85);
//    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
//        java.util.Date date3 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getFirstMillisecond();
//        int int6 = day4.getDayOfMonth();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day4.equals(obj7);
//        boolean boolean9 = fixedMillisecond1.equals(obj7);
//        java.util.Date date10 = fixedMillisecond1.getEnd();
//        java.lang.Object obj11 = null;
//        int int12 = fixedMillisecond1.compareTo(obj11);
//        long long13 = fixedMillisecond1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-9999L) + "'", long13 == (-9999L));
//    }
//}

