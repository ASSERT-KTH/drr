import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test01");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        boolean boolean9 = timeSeries3.getNotify();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 100.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries18.removeAgedItems(true);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str24 = month23.toString();
//        boolean boolean25 = timeSeries18.equals((java.lang.Object) month23);
//        double double26 = timeSeries18.getMinY();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getFirstMillisecond();
//        int int32 = day30.getDayOfMonth();
//        int int33 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day30.previous();
//        java.util.Date date35 = regularTimePeriod34.getEnd();
//        int int36 = day10.compareTo((java.lang.Object) date35);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "January -9999" + "'", str24.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long4 = month3.getLastMillisecond();
        int int5 = day0.compareTo((java.lang.Object) long4);
        int int6 = day0.getMonth();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent8.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent8.getSummary();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 253405007999999L + "'", long4 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(seriesChangeInfo9);
        org.junit.Assert.assertNull(seriesChangeInfo10);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.lang.Object obj4 = null;
        int int5 = fixedMillisecond1.compareTo(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "January -9999");
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        boolean boolean12 = timeSeries10.getNotify();
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries10.getDataItem(regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(1, year2);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str9 = month8.toString();
        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(true);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) true, seriesChangeInfo15);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = seriesChangeEvent16.getSummary();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(seriesChangeInfo17);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        long long21 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19);
        java.util.Calendar calendar23 = null;
        fixedMillisecond19.peg(calendar23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj27 = null;
        boolean boolean28 = year26.equals(obj27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries3.getNextTimePeriod();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9999L) + "'", long21 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj28 = null;
        boolean boolean29 = year27.equals(obj28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 1560150000000L);
        timeSeries25.add(timeSeriesDataItem31);
        boolean boolean33 = timeSeries25.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries25);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries40.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries40.removeChangeListener(seriesChangeListener43);
        java.util.Collection collection45 = timeSeries40.getTimePeriods();
        boolean boolean46 = timeSeries40.getNotify();
        java.util.Collection collection47 = timeSeries40.getTimePeriods();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries40);
        java.lang.Comparable comparable49 = timeSeries40.getKey();
        int int50 = timeSeries40.getItemCount();
        java.util.Collection collection51 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeries3.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 'a' + "'", comparable49.equals('a'));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(collection51);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        long long15 = month11.getLastMillisecond();
        org.jfree.data.time.Year year16 = month11.getYear();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 253405007999999L + "'", long15 == 253405007999999L);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(date17);
    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test11");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) 11);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-9999L) + "'", long7 == (-9999L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9999L) + "'", long8 == (-9999L));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries5.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries5.getTimePeriods();
        boolean boolean11 = timeSeries5.getNotify();
        java.lang.String str12 = timeSeries5.getRangeDescription();
        timeSeries5.clear();
        timeSeries5.setDomainDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries5.setDescription("10-June-2019");
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(20);
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "20" + "'", str2.equals("20"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long11 = month10.getLastMillisecond();
        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int16 = month15.getMonth();
        java.lang.Class<?> wildcardClass17 = month15.getClass();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year19 = month15.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1560150000000L);
        timeSeries23.add(timeSeriesDataItem29);
        boolean boolean31 = month15.equals((java.lang.Object) timeSeriesDataItem29);
        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) 1);
        timeSeriesDataItem29.setValue((java.lang.Number) 9);
        java.lang.Number number36 = timeSeriesDataItem29.getValue();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 9 + "'", number36.equals(9));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.setNotify(false);
        double double9 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        boolean boolean6 = timeSeries3.equals((java.lang.Object) (-1L));
        int int7 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date10 = year9.getEnd();
        long long11 = year9.getFirstMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61157520000000L) + "'", long11 == (-61157520000000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries12.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries12.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries12.getTimePeriods();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long21 = month20.getLastMillisecond();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month20, Double.NaN);
        long long24 = month20.getLastMillisecond();
        int int25 = month20.getMonth();
        timeSeries7.setKey((java.lang.Comparable) month20);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries30.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries30.removeChangeListener(seriesChangeListener33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long38 = month37.getLastMillisecond();
        java.lang.Number number39 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int43 = month42.getMonth();
        java.lang.Class<?> wildcardClass44 = month42.getClass();
        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) month42);
        org.jfree.data.time.Year year46 = month42.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year46, (java.lang.Number) (-9999L), true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 253405007999999L + "'", long21 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 253405007999999L + "'", long38 == 253405007999999L);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(year46);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries9.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries9.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries9.getTimePeriods();
        int int15 = month2.compareTo((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries19.removeAgedItems(true);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str25 = month24.toString();
        boolean boolean26 = timeSeries19.equals((java.lang.Object) month24);
        double double27 = timeSeries19.getMinY();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, 1.56015E12d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries9.addOrUpdate(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "January -9999" + "'", str25.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        java.lang.String str7 = year6.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "32" + "'", str7.equals("32"));
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test21");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long11 = month10.getLastMillisecond();
//        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month10);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int16 = month15.getMonth();
//        java.lang.Class<?> wildcardClass17 = month15.getClass();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month15);
//        boolean boolean20 = timeSeries3.equals((java.lang.Object) "January -9999");
//        long long21 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries25.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries38.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries38.removeChangeListener(seriesChangeListener41);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long46 = month45.getLastMillisecond();
//        java.lang.Number number47 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) month45);
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month45, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 12);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) ' ');
//        java.lang.Object obj54 = null;
//        boolean boolean55 = year53.equals(obj54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries61.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener64 = null;
//        timeSeries61.removeChangeListener(seriesChangeListener64);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long69 = month68.getLastMillisecond();
//        java.lang.Number number70 = timeSeries61.getValue((org.jfree.data.time.RegularTimePeriod) month68);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int74 = month73.getMonth();
//        java.lang.Class<?> wildcardClass75 = month73.getClass();
//        timeSeries61.delete((org.jfree.data.time.RegularTimePeriod) month73);
//        org.jfree.data.time.Year year77 = month73.getYear();
//        java.lang.String str78 = month73.toString();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year53, (org.jfree.data.time.RegularTimePeriod) month73);
//        boolean boolean80 = timeSeries25.isEmpty();
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        long long82 = day81.getFirstMillisecond();
//        int int83 = day81.getDayOfMonth();
//        int int84 = day81.getMonth();
//        long long85 = day81.getLastMillisecond();
//        java.lang.Number number86 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) day81);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day81, (java.lang.Number) 0.0f);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 253405007999999L + "'", long11 == 253405007999999L);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class34);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 253405007999999L + "'", long46 == 253405007999999L);
//        org.junit.Assert.assertNull(number47);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 253405007999999L + "'", long69 == 253405007999999L);
//        org.junit.Assert.assertNull(number70);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(year77);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "January -9999" + "'", str78.equals("January -9999"));
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560150000000L + "'", long82 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 6 + "'", int84 == 6);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560236399999L + "'", long85 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 12.0d + "'", number86.equals(12.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem88);
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test22");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getFirstMillisecond();
//        int int17 = day15.getDayOfMonth();
//        int int18 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
//        long long19 = day15.getFirstMillisecond();
//        java.lang.String str20 = day15.toString();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560150000000L + "'", long19 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "January -9999");
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj14 = null;
        boolean boolean15 = year13.equals(obj14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries21.removeAgedItems(true);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str27 = month26.toString();
        boolean boolean28 = timeSeries21.equals((java.lang.Object) month26);
        double double29 = timeSeries21.getMinY();
        int int30 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries21);
        timeSeriesDataItem17.setValue((java.lang.Number) 253405007999999L);
        timeSeries10.add(timeSeriesDataItem17, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "January -9999" + "'", str27.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        boolean boolean7 = timeSeries3.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        long long11 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9);
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 5, false);
        try {
            java.lang.Number number19 = timeSeries3.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9999L) + "'", long11 == (-9999L));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems((long) (short) 10, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean16 = timeSeries15.getNotify();
        timeSeries15.clear();
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries15);
        double double19 = timeSeries3.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(1, year2);
        org.jfree.data.time.Year year5 = month4.getYear();
        long long6 = month4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61157520000000L) + "'", long6 == (-61157520000000L));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (byte) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        try {
            org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test29");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        java.lang.String str12 = timeSeries3.getDescription();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        int int16 = month15.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 0.0f);
//        org.jfree.data.time.Year year19 = month15.getYear();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        timeSeries23.setDescription("");
//        timeSeries23.setMaximumItemCount(11);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
//        timeSeries23.setKey((java.lang.Comparable) day28);
//        boolean boolean32 = month15.equals((java.lang.Object) timeSeries23);
//        long long33 = month15.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-377711740800000L) + "'", long33 == (-377711740800000L));
//    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str6 = seriesException5.toString();
        java.lang.String str7 = seriesException5.toString();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        seriesException9.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.String str13 = seriesException9.toString();
        java.lang.String str14 = seriesException9.toString();
        java.lang.Throwable[] throwableArray15 = seriesException9.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException9);
        boolean boolean17 = timeSeries1.equals((java.lang.Object) seriesException5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str7.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str13.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str14.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        boolean boolean7 = timeSeries3.getNotify();
        int int8 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries5.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries5.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries5.getTimePeriods();
        boolean boolean11 = timeSeries5.getNotify();
        java.lang.String str12 = timeSeries5.getRangeDescription();
        timeSeries5.clear();
        timeSeries5.setDomainDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries20.setMaximumItemCount((int) ' ');
        timeSeries20.setNotify(true);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj27 = null;
        boolean boolean28 = year26.equals(obj27);
        long long29 = year26.getFirstMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year26);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries36.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries36.removeChangeListener(seriesChangeListener39);
        java.util.Collection collection41 = timeSeries36.getTimePeriods();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long45 = month44.getLastMillisecond();
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) month44, Double.NaN);
        long long48 = month44.getLastMillisecond();
        org.jfree.data.time.Year year49 = month44.getYear();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 20);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries5.addAndOrUpdate(timeSeries20);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61157520000000L) + "'", long29 == (-61157520000000L));
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 253405007999999L + "'", long45 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 253405007999999L + "'", long48 == 253405007999999L);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(timeSeries52);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test34");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries8.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries8.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long16 = month15.getLastMillisecond();
//        java.lang.Number number17 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries23.removeAgedItems(true);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str29 = month28.toString();
//        boolean boolean30 = timeSeries23.equals((java.lang.Object) month28);
//        double double31 = timeSeries23.getMinY();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 100);
//        long long35 = day32.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        java.lang.Comparable comparable41 = timeSeries40.getKey();
//        boolean boolean43 = timeSeries40.equals((java.lang.Object) (-1L));
//        java.util.Collection collection44 = timeSeries40.getTimePeriods();
//        boolean boolean45 = timeSeriesDataItem36.equals((java.lang.Object) timeSeries40);
//        timeSeriesDataItem36.setSelected(false);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 253405007999999L + "'", long16 == 253405007999999L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "January -9999" + "'", str29.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 'a' + "'", comparable41.equals('a'));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Date date18 = fixedMillisecond16.getTime();
        java.lang.Number number19 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.List list20 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) 0 + "'", number19.equals((short) 0));
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int3 = month2.getMonth();
        java.lang.Class<?> wildcardClass4 = month2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "");
        java.lang.String str8 = timeSeries7.getDomainDescription();
        timeSeries7.fireSeriesChanged();
        double double10 = timeSeries7.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        int int5 = timeSeries3.getItemCount();
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        boolean boolean7 = timeSeries3.getNotify();
        double double8 = timeSeries3.getMaxY();
        long long9 = timeSeries3.getMaximumItemAge();
        timeSeries3.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        int int16 = month11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.previous();
        java.lang.String str18 = month11.toString();
        org.jfree.data.time.Year year19 = month11.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries23.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries23.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long31 = month30.getLastMillisecond();
        java.lang.Number number32 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int36 = month35.getMonth();
        java.lang.Class<?> wildcardClass37 = month35.getClass();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.Year year39 = month35.getYear();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj46 = null;
        boolean boolean47 = year45.equals(obj46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 1560150000000L);
        timeSeries43.add(timeSeriesDataItem49);
        boolean boolean51 = month35.equals((java.lang.Object) timeSeriesDataItem49);
        boolean boolean53 = timeSeriesDataItem49.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeriesDataItem49.getPeriod();
        boolean boolean55 = timeSeriesDataItem49.isSelected();
        boolean boolean56 = year19.equals((java.lang.Object) boolean55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year19.next();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January -9999" + "'", str18.equals("January -9999"));
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 253405007999999L + "'", long31 == 253405007999999L);
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test39");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str13 = month12.toString();
//        boolean boolean14 = timeSeries7.equals((java.lang.Object) month12);
//        double double15 = timeSeries7.getMinY();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
//        long long20 = day16.getLastMillisecond();
//        java.lang.String str21 = day16.toString();
//        java.util.Date date22 = day16.getEnd();
//        int int23 = day16.getDayOfMonth();
//        timeSeries3.setKey((java.lang.Comparable) day16);
//        long long25 = day16.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "January -9999" + "'", str13.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560150000000L + "'", long25 == 1560150000000L);
//    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long12 = month11.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, Double.NaN);
        java.util.Date date15 = month11.getEnd();
        int int16 = month11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.previous();
        java.lang.String str18 = month11.toString();
        org.jfree.data.time.Year year19 = month11.getYear();
        long long20 = month11.getSerialIndex();
        java.lang.String str21 = month11.toString();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253405007999999L + "'", long12 == 253405007999999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January -9999" + "'", str18.equals("January -9999"));
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-119987L) + "'", long20 == (-119987L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "January -9999" + "'", str21.equals("January -9999"));
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (byte) 100);
//        java.lang.Class<?> wildcardClass7 = fixedMillisecond1.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        boolean boolean11 = timeSeries10.getNotify();
//        java.lang.Class<?> wildcardClass12 = timeSeries10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries16.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener19);
//        java.util.Collection collection21 = timeSeries16.getTimePeriods();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        long long25 = month24.getLastMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month24, Double.NaN);
//        long long28 = month24.getLastMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, number29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-62138894400001L));
//        int int33 = month24.compareTo((java.lang.Object) (-62138894400001L));
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62138894400001L), "Sun Jun 09 00:00:00 PDT 2019", "100");
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries44.removeAgedItems(true);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str50 = month49.toString();
//        boolean boolean51 = timeSeries44.equals((java.lang.Object) month49);
//        double double52 = timeSeries44.getMinY();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day53.previous();
//        long long57 = day53.getLastMillisecond();
//        java.lang.String str58 = day53.toString();
//        java.util.Date date59 = day53.getEnd();
//        int int60 = day53.getDayOfMonth();
//        timeSeries40.setKey((java.lang.Comparable) day53);
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        java.lang.Comparable comparable66 = timeSeries65.getKey();
//        timeSeries65.setRangeDescription("January -9999");
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timeSeries65.removePropertyChangeListener(propertyChangeListener69);
//        int int71 = day53.compareTo((java.lang.Object) propertyChangeListener69);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        boolean boolean76 = timeSeries75.getNotify();
//        timeSeries75.clear();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        long long79 = day78.getSerialIndex();
//        long long80 = day78.getLastMillisecond();
//        long long81 = day78.getLastMillisecond();
//        timeSeries75.delete((org.jfree.data.time.RegularTimePeriod) day78);
//        int int84 = day78.compareTo((java.lang.Object) (-62138894400001L));
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) day78);
//        boolean boolean86 = fixedMillisecond1.equals((java.lang.Object) day78);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-9999L) + "'", long4 == (-9999L));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 253405007999999L + "'", long25 == 253405007999999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 253405007999999L + "'", long28 == 253405007999999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "January -9999" + "'", str50.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "10-June-2019" + "'", str58.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 'a' + "'", comparable66.equals('a'));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 43626L + "'", long79 == 43626L);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560236399999L + "'", long80 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560236399999L + "'", long81 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(timeSeries85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test42");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        int int15 = day12.getDayOfMonth();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day12.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2147483647L + "'", long3 == 2147483647L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2147483647L + "'", long4 == 2147483647L);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        timeSeries3.setDescription("");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        int int11 = month8.getMonth();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long3 = month2.getLastMillisecond();
        long long4 = month2.getMiddleMillisecond();
        org.jfree.data.time.Year year5 = month2.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 253405007999999L + "'", long3 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62153366400001L) + "'", long4 == (-62153366400001L));
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int12 = day10.compareTo((java.lang.Object) 100.0d);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (short) 0);
        org.jfree.data.time.SerialDate serialDate15 = day10.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        java.lang.Comparable comparable21 = timeSeries20.getKey();
        int int22 = timeSeries20.getItemCount();
        boolean boolean24 = timeSeries20.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        long long28 = fixedMillisecond26.getLastMillisecond();
        boolean boolean30 = fixedMillisecond26.equals((java.lang.Object) 11);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond26.getFirstMillisecond(calendar31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 'a');
        boolean boolean35 = day16.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 'a' + "'", comparable21.equals('a'));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-9999L) + "'", long28 == (-9999L));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-9999L) + "'", long32 == (-9999L));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "January -9999");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries16.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long24 = month23.getLastMillisecond();
        java.lang.Number number25 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560150000000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 12);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries39.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries39.removeChangeListener(seriesChangeListener42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long47 = month46.getLastMillisecond();
        java.lang.Number number48 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        int int52 = month51.getMonth();
        java.lang.Class<?> wildcardClass53 = month51.getClass();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Year year55 = month51.getYear();
        java.lang.String str56 = month51.toString();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) month51);
        boolean boolean58 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries60.removeAgedItems(false);
        double double63 = timeSeries60.getMinY();
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries3.addAndOrUpdate(timeSeries60);
        try {
            java.lang.Number number66 = timeSeries60.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253405007999999L + "'", long24 == 253405007999999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 253405007999999L + "'", long47 == 253405007999999L);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "January -9999" + "'", str56.equals("January -9999"));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries64);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries3.createCopy(7, (int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1);
        java.util.Collection collection12 = timeSeries3.getTimePeriods();
        double double13 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        boolean boolean4 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        java.lang.String str14 = month13.toString();
        boolean boolean15 = timeSeries8.equals((java.lang.Object) month13);
        double double16 = timeSeries8.getMinY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        java.util.Collection collection20 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries25.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.removeChangeListener(seriesChangeListener28);
        java.util.Collection collection30 = timeSeries25.getTimePeriods();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
        long long34 = month33.getLastMillisecond();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month33, Double.NaN);
        long long37 = month33.getLastMillisecond();
        int int38 = month33.getMonth();
        long long39 = month33.getFirstMillisecond();
        boolean boolean40 = timeSeries21.equals((java.lang.Object) month33);
        java.lang.String str41 = timeSeries21.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries21.removeChangeListener(seriesChangeListener42);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -9999" + "'", str14.equals("January -9999"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 253405007999999L + "'", long34 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 253405007999999L + "'", long37 == 253405007999999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-377711740800000L) + "'", long39 == (-377711740800000L));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-9999L) + "'", long5 == (-9999L));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries7.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        boolean boolean13 = timeSeries7.getNotify();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int16 = day14.compareTo((java.lang.Object) 100.0d);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) (short) 0);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        long long20 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test52");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, (-9999));
//        java.lang.String str9 = month8.toString();
//        boolean boolean10 = timeSeries3.equals((java.lang.Object) month8);
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day12.previous();
//        long long16 = day12.getLastMillisecond();
//        java.lang.String str17 = day12.toString();
//        java.util.Date date18 = day12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.util.Calendar calendar22 = null;
//        fixedMillisecond19.peg(calendar22);
//        java.util.Date date24 = fixedMillisecond19.getTime();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        int int26 = year25.getYear();
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = year25.getFirstMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -9999" + "'", str9.equals("January -9999"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "hi!", "hi!");
        timeSeries3.setMaximumItemCount((int) ' ');
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) ' ');
        java.lang.Object obj10 = null;
        boolean boolean11 = year9.equals(obj10);
        long long12 = year9.getFirstMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61157520000000L) + "'", long12 == (-61157520000000L));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }
}

