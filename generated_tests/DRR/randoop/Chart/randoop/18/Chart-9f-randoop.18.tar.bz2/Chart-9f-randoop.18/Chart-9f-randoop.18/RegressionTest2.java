import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test01");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
//        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
//        java.lang.Object obj7 = timeSeries4.clone();
//        timeSeries4.clear();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class12);
//        boolean boolean15 = timeSeries13.equals((java.lang.Object) (byte) 1);
//        java.util.Collection collection16 = timeSeries13.getTimePeriods();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries13.addPropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (short) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        int int28 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeriesDataItem27);
//        try {
//            timeSeries4.add(timeSeriesDataItem27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191912051L + "'", long22 == 1560191912051L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test02");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date5);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date5);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 1560191872330L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191912062L + "'", long2 == 1560191912062L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 9999);
        long long3 = month2.getSerialIndex();
        java.lang.Object obj4 = null;
        int int5 = month2.compareTo(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 119993L + "'", long3 == 119993L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int3 = spreadsheetDate2.toSerial();
        java.lang.String str4 = spreadsheetDate2.getDescription();
        int int5 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int10 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int13 = spreadsheetDate12.toSerial();
        boolean boolean14 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int15 = spreadsheetDate7.getDayOfWeek();
        boolean boolean16 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int19 = spreadsheetDate18.toSerial();
        java.lang.String str20 = spreadsheetDate18.getDescription();
        boolean boolean21 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int26 = spreadsheetDate25.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int29 = spreadsheetDate28.toSerial();
        boolean boolean30 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int31 = spreadsheetDate23.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int37 = spreadsheetDate36.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int40 = spreadsheetDate39.toSerial();
        boolean boolean41 = spreadsheetDate34.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int47 = spreadsheetDate46.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int50 = spreadsheetDate49.toSerial();
        boolean boolean51 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        java.lang.String str52 = spreadsheetDate44.toString();
        int int53 = spreadsheetDate44.getYYYY();
        org.jfree.data.time.SerialDate serialDate54 = serialDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean55 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean56 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 97 + "'", int26 == 97);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 97 + "'", int37 == 97);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 97 + "'", int40 == 97);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 97 + "'", int47 == 97);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 97 + "'", int50 == 97);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "6-April-1900" + "'", str52.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1900 + "'", int53 == 1900);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(serialDate57);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int5 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int15 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int18 = spreadsheetDate17.toSerial();
        boolean boolean19 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str20 = spreadsheetDate12.toString();
        int int21 = spreadsheetDate12.getYYYY();
        org.jfree.data.time.SerialDate serialDate22 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int25 = spreadsheetDate24.toSerial();
        int int26 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int32 = spreadsheetDate31.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int35 = spreadsheetDate34.toSerial();
        boolean boolean36 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean38 = spreadsheetDate24.isOn(serialDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int44 = spreadsheetDate43.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int47 = spreadsheetDate46.toSerial();
        boolean boolean48 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean50 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date51 = spreadsheetDate24.toDate();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6-April-1900" + "'", str20.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 97 + "'", int35 == 97);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 97 + "'", int44 == 97);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 97 + "'", int47 == 97);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f, class1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) (short) 100);
//        java.util.Date date8 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
//        long long12 = year11.getSerialIndex();
//        long long13 = year11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, 0.0d);
//        long long17 = year11.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191912447L + "'", long5 == 1560191912447L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:38:17 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int3 = spreadsheetDate2.toSerial();
        java.lang.String str4 = spreadsheetDate2.toString();
        int int5 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int8 = spreadsheetDate7.toSerial();
        java.lang.String str9 = spreadsheetDate7.getDescription();
        boolean boolean10 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean13 = spreadsheetDate7.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int20 = spreadsheetDate19.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int23 = spreadsheetDate22.toSerial();
        boolean boolean24 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int30 = spreadsheetDate29.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int33 = spreadsheetDate32.toSerial();
        boolean boolean34 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        java.lang.String str35 = spreadsheetDate27.toString();
        int int36 = spreadsheetDate27.getYYYY();
        org.jfree.data.time.SerialDate serialDate37 = serialDate25.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.lang.String str38 = spreadsheetDate27.getDescription();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(8, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int44 = spreadsheetDate43.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int47 = spreadsheetDate46.toSerial();
        boolean boolean48 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.lang.String str49 = spreadsheetDate43.toString();
        boolean boolean50 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate43);
        int int51 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.lang.String str52 = spreadsheetDate7.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "6-April-1900" + "'", str4.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "6-April-1900" + "'", str35.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 97 + "'", int44 == 97);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 97 + "'", int47 == 97);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "6-April-1900" + "'", str49.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(str52);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test09");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) (short) 100);
//        java.util.Date date15 = fixedMillisecond10.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date15);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date15, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date5, timeZone21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) 1560191832596L);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class29);
//        boolean boolean32 = timeSeries30.equals((java.lang.Object) (byte) 1);
//        java.util.Collection collection33 = timeSeries30.getTimePeriods();
//        java.lang.String str34 = timeSeries30.getDescription();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class36);
//        java.util.Collection collection38 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        timeSeries37.clear();
//        java.util.List list40 = timeSeries37.getItems();
//        boolean boolean41 = day23.equals((java.lang.Object) timeSeries37);
//        timeSeries37.setRangeDescription("Mon Jun 10 11:37:22 PDT 2019");
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191912581L + "'", long2 == 1560191912581L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191912582L + "'", long12 == 1560191912582L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int2 = spreadsheetDate1.toSerial();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        int int4 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int9 = spreadsheetDate8.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int12 = spreadsheetDate11.toSerial();
//        boolean boolean13 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate11);
//        int int14 = spreadsheetDate8.getDayOfWeek();
//        boolean boolean15 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int18 = spreadsheetDate17.toSerial();
//        java.lang.String str19 = spreadsheetDate17.getDescription();
//        int int20 = spreadsheetDate17.getDayOfMonth();
//        boolean boolean21 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int22 = spreadsheetDate1.getDayOfMonth();
//        int int23 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int29 = spreadsheetDate28.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int32 = spreadsheetDate31.toSerial();
//        boolean boolean33 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int35 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (short) 100);
//        java.util.Date date41 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        long long43 = year42.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year42.next();
//        try {
//            int int46 = spreadsheetDate28.compareTo((java.lang.Object) regularTimePeriod45);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6-April-1900" + "'", str3.equals("6-April-1900"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560191912802L + "'", long38 == 1560191912802L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int7 = spreadsheetDate6.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int10 = spreadsheetDate9.toSerial();
        boolean boolean11 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getDayOfMonth();
        spreadsheetDate9.setDescription("Mon Jun 10 11:37:43 PDT 2019");
        int int16 = spreadsheetDate9.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj7 = timeSeries4.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timeSeries4.getMaximumItemCount();
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int2 = spreadsheetDate1.toSerial();
//        java.lang.String str3 = spreadsheetDate1.toString();
//        int int4 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 9999);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int4, "hi!", "October", (java.lang.Class) wildcardClass9);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 100);
//        java.util.Date date18 = fixedMillisecond13.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date18, timeZone26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (short) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, 10.0d);
//        java.util.Date date35 = fixedMillisecond28.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) (short) 100);
//        java.util.Date date42 = fixedMillisecond37.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date42, timeZone44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date42);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date42, timeZone48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date35, timeZone48);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date18, timeZone48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6-April-1900" + "'", str3.equals("6-April-1900"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191912849L + "'", long15 == 1560191912849L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191912851L + "'", long30 == 1560191912851L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560191912858L + "'", long39 == 1560191912858L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(timeZone48);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException9.getSuppressed();
        java.lang.String str15 = timePeriodFormatException9.toString();
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 9999);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9999L + "'", long5 == 9999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9999L + "'", long7 == 9999L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        java.util.List list5 = timeSeries4.getItems();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        int int7 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test17");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number6 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, number6);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.util.Date date9 = fixedMillisecond5.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) (short) 100);
//        java.util.Date date15 = fixedMillisecond10.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) (short) 100);
//        java.util.Date date28 = fixedMillisecond23.getEnd();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date28, timeZone34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date15, timeZone34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date9, timeZone34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) (short) 100);
//        java.util.Date date43 = fixedMillisecond38.getEnd();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43, timeZone45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date43);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date43);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date43, timeZone49);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date9, timeZone49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date9);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191913458L + "'", long12 == 1560191913458L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560191913459L + "'", long25 == 1560191913459L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560191913462L + "'", long40 == 1560191913462L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(timeZone49);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int5 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int15 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int18 = spreadsheetDate17.toSerial();
        boolean boolean19 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str20 = spreadsheetDate12.toString();
        int int21 = spreadsheetDate12.getYYYY();
        org.jfree.data.time.SerialDate serialDate22 = serialDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str23 = spreadsheetDate12.getDescription();
        int int24 = spreadsheetDate12.getMonth();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class28);
        boolean boolean31 = timeSeries29.equals((java.lang.Object) (byte) 1);
        java.util.Collection collection32 = timeSeries29.getTimePeriods();
        java.lang.String str33 = timeSeries29.getDescription();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class35);
        java.util.Collection collection37 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(5, 9999);
        int int41 = month40.getYearValue();
        int int42 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) month40);
        boolean boolean43 = spreadsheetDate12.equals((java.lang.Object) timeSeries29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int46 = spreadsheetDate45.toSerial();
        java.lang.String str47 = spreadsheetDate45.toString();
        int int48 = spreadsheetDate45.toSerial();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        java.lang.Class<?> wildcardClass53 = fixedMillisecond52.getClass();
        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int48, "hi!", "October", (java.lang.Class) wildcardClass53);
        java.util.Collection collection56 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries55);
        long long57 = timeSeries29.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6-April-1900" + "'", str20.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9999 + "'", int41 == 9999);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "6-April-1900" + "'", str47.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test19");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int13 = spreadsheetDate12.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int16 = spreadsheetDate15.toSerial();
//        boolean boolean17 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int23 = spreadsheetDate22.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int26 = spreadsheetDate25.toSerial();
//        boolean boolean27 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate25);
//        java.lang.String str28 = spreadsheetDate20.toString();
//        int int29 = spreadsheetDate20.getYYYY();
//        org.jfree.data.time.SerialDate serialDate30 = serialDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int33 = spreadsheetDate32.toSerial();
//        int int34 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int40 = spreadsheetDate39.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int43 = spreadsheetDate42.toSerial();
//        boolean boolean44 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate39, (org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate39);
//        boolean boolean46 = spreadsheetDate32.isOn(serialDate45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int49 = spreadsheetDate48.toSerial();
//        java.lang.String str50 = spreadsheetDate48.getDescription();
//        int int51 = spreadsheetDate48.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int56 = spreadsheetDate55.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int59 = spreadsheetDate58.toSerial();
//        boolean boolean60 = spreadsheetDate53.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate55, (org.jfree.data.time.SerialDate) spreadsheetDate58);
//        int int61 = spreadsheetDate53.getDayOfWeek();
//        boolean boolean62 = spreadsheetDate48.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int65 = spreadsheetDate64.toSerial();
//        java.lang.String str66 = spreadsheetDate64.toString();
//        int int67 = spreadsheetDate64.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int72 = spreadsheetDate71.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
//        int int75 = spreadsheetDate74.toSerial();
//        boolean boolean76 = spreadsheetDate69.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate71, (org.jfree.data.time.SerialDate) spreadsheetDate74);
//        int int77 = spreadsheetDate71.getDayOfWeek();
//        boolean boolean78 = spreadsheetDate64.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        boolean boolean79 = spreadsheetDate48.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        org.jfree.data.time.SerialDate serialDate80 = serialDate45.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        int int81 = day6.compareTo((java.lang.Object) serialDate80);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191914235L + "'", long2 == 1560191914235L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 97 + "'", int26 == 97);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "6-April-1900" + "'", str28.equals("6-April-1900"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 97 + "'", int40 == 97);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 97 + "'", int43 == 97);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 97 + "'", int49 == 97);
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 97 + "'", int56 == 97);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 97 + "'", int59 == 97);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 97 + "'", int65 == 97);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "6-April-1900" + "'", str66.equals("6-April-1900"));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 97 + "'", int67 == 97);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 97 + "'", int72 == 97);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 97 + "'", int75 == 97);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.toSerial();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9999 + "'", int4 == 9999);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        java.util.List list5 = timeSeries4.getItems();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class9);
        boolean boolean12 = timeSeries10.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj13 = timeSeries10.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Number number17 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries10.addChangeListener(seriesChangeListener19);
        java.lang.Class class21 = timeSeries10.getTimePeriodClass();
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNull(class21);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:38:07 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int5 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int11 = spreadsheetDate4.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int19 = spreadsheetDate18.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int22 = spreadsheetDate21.toSerial();
        boolean boolean23 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str24 = spreadsheetDate16.toString();
        int int25 = spreadsheetDate16.toSerial();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean27 = spreadsheetDate13.isBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int33 = spreadsheetDate32.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int36 = spreadsheetDate35.toSerial();
        boolean boolean37 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int43 = spreadsheetDate42.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int46 = spreadsheetDate45.toSerial();
        boolean boolean47 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        java.lang.String str48 = spreadsheetDate40.toString();
        int int49 = spreadsheetDate40.getYYYY();
        org.jfree.data.time.SerialDate serialDate50 = serialDate38.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.lang.String str51 = spreadsheetDate40.getDescription();
        int int52 = spreadsheetDate40.getMonth();
        boolean boolean53 = spreadsheetDate4.isInRange(serialDate26, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 97 + "'", int22 == 97);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "6-April-1900" + "'", str24.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 97 + "'", int36 == 97);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 97 + "'", int43 == 97);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "6-April-1900" + "'", str48.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int7 = spreadsheetDate6.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int10 = spreadsheetDate9.toSerial();
        boolean boolean11 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str12 = spreadsheetDate4.toString();
        int int13 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean15 = spreadsheetDate1.isBefore(serialDate14);
        java.util.Date date16 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "6-April-1900" + "'", str12.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj7 = timeSeries4.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number9);
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        long long12 = timeSeries4.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries4.getRangeDescription();
        int int16 = timeSeries4.getMaximumItemCount();
        java.lang.Object obj17 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test28");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class10);
//        boolean boolean13 = timeSeries11.equals((java.lang.Object) (byte) 1);
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        java.lang.String str15 = timeSeries11.getDescription();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
//        java.util.Collection collection19 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        timeSeries18.clear();
//        int int21 = timeSeries18.getMaximumItemCount();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(5, 9999);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        int int26 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) month24);
//        java.lang.String str27 = timeSeries18.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (short) 100);
//        java.util.Date date33 = fixedMillisecond28.getEnd();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date33, timeZone35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date33);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date33);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date33);
//        long long40 = year39.getSerialIndex();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) year39);
//        int int42 = day6.compareTo((java.lang.Object) year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day6.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191914906L + "'", long2 == 1560191914906L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191914909L + "'", long30 == 1560191914909L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test29");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getDayOfMonth();
//        int int8 = day6.getDayOfMonth();
//        boolean boolean10 = day6.equals((java.lang.Object) 10.0d);
//        int int11 = day6.getMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day6.getSerialDate();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class16);
//        boolean boolean19 = timeSeries17.equals((java.lang.Object) (byte) 1);
//        java.lang.Object obj20 = timeSeries17.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        java.lang.Number number24 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        long long25 = fixedMillisecond21.getLastMillisecond();
//        long long26 = fixedMillisecond21.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 9999);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond30.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21, "Monday", "Mon Jun 10 11:37:11 PDT 2019", (java.lang.Class) wildcardClass31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12, (java.lang.Class) wildcardClass31);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191915111L + "'", long2 == 1560191915111L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560191915114L + "'", long25 == 1560191915114L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560191915114L + "'", long26 == 1560191915114L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj7 = timeSeries4.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number16 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, number16);
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 11);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(5, 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        java.lang.String str26 = month24.toString();
        long long27 = month24.getSerialIndex();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class31);
        boolean boolean34 = timeSeries32.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj35 = timeSeries32.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number37 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        timeSeries32.setNotify(true);
        timeSeries32.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
        int int42 = month24.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month24.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month24);
        java.lang.Number number45 = timeSeriesDataItem44.getValue();
        java.lang.Object obj46 = timeSeriesDataItem44.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "May 9999" + "'", str26.equals("May 9999"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 119993L + "'", long27 == 119993L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 11.0d + "'", number45.equals(11.0d));
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj7 = timeSeries4.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timeSeries4.getMaximumItemCount();
        java.lang.Class class11 = timeSeries4.getTimePeriodClass();
        long long12 = timeSeries4.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test32");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191915348L + "'", long2 == 1560191915348L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class6);
        boolean boolean9 = timeSeries7.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj10 = timeSeries7.clone();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        int int13 = timeSeries7.getMaximumItemCount();
        timeSeries7.setKey((java.lang.Comparable) 8);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timeSeries7.isEmpty();
        java.util.Collection collection19 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        java.util.List list21 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(list21);
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test34");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560191865319L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191915413L + "'", long1 == 1560191915413L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191915413L + "'", long2 == 1560191915413L);
//    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test35");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getLastMillisecond(calendar8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getLastMillisecond(calendar10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191915422L + "'", long2 == 1560191915422L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191915422L + "'", long9 == 1560191915422L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560191915422L + "'", long11 == 1560191915422L);
//    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test36");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
//        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
//        java.util.Collection collection7 = timeSeries4.getTimePeriods();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class11);
//        java.util.Collection collection13 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Comparable comparable14 = timeSeries4.getKey();
//        java.lang.String str15 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) (short) 100);
//        java.util.Date date21 = fixedMillisecond16.getEnd();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        int int23 = day22.getDayOfMonth();
//        int int24 = day22.getDayOfMonth();
//        boolean boolean26 = day22.equals((java.lang.Object) 10.0d);
//        long long27 = day22.getSerialIndex();
//        int int28 = day22.getYear();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        int int30 = day22.getDayOfMonth();
//        long long31 = day22.getFirstMillisecond();
//        long long32 = day22.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(collection7);
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191915437L + "'", long18 == 1560191915437L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43626L + "'", long32 == 43626L);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        java.lang.String str5 = timeSeries4.getDescription();
        java.lang.Object obj6 = timeSeries4.clone();
        timeSeries4.setNotify(false);
        timeSeries4.setDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        try {
            java.util.Collection collection12 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj7 = timeSeries4.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number16 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, number16);
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 11);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(5, 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        java.lang.String str26 = month24.toString();
        long long27 = month24.getSerialIndex();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class31);
        boolean boolean34 = timeSeries32.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj35 = timeSeries32.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number37 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        timeSeries32.setNotify(true);
        timeSeries32.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
        int int42 = month24.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month24.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month24);
        java.lang.Number number45 = timeSeriesDataItem44.getValue();
        java.lang.Number number46 = timeSeriesDataItem44.getValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "May 9999" + "'", str26.equals("May 9999"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 119993L + "'", long27 == 119993L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 11.0d + "'", number45.equals(11.0d));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 11.0d + "'", number46.equals(11.0d));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:37:11 PDT 2019");
    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test40");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191915611L + "'", long2 == 1560191915611L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 100);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
//        int int9 = day6.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191915621L + "'", long2 == 1560191915621L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int4 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        int int7 = spreadsheetDate6.toSerial();
        boolean boolean8 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date18 = fixedMillisecond14.getTime();
        boolean boolean19 = spreadsheetDate6.equals((java.lang.Object) fixedMillisecond14);
        java.util.Date date20 = spreadsheetDate6.toDate();
        java.lang.String str21 = spreadsheetDate6.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class6);
        boolean boolean9 = timeSeries7.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj10 = timeSeries7.clone();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        int int13 = timeSeries7.getMaximumItemCount();
        timeSeries7.setKey((java.lang.Comparable) 8);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timeSeries7.isEmpty();
        java.util.Collection collection19 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setRangeDescription("9999");
        java.lang.String str22 = timeSeries7.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class11);
        java.util.Collection collection13 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem16.getPeriod();
        int int18 = timeSeries12.getIndex(regularTimePeriod17);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class22);
        boolean boolean25 = timeSeries23.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries12);
        java.lang.Object obj28 = seriesChangeEvent27.getSource();
        java.lang.Object obj29 = seriesChangeEvent27.getSource();
        java.lang.Object obj30 = seriesChangeEvent27.getSource();
        java.lang.String str31 = seriesChangeEvent27.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 4);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10, 31, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100, (-9902), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) (byte) 1);
        java.lang.Object obj7 = timeSeries4.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timeSeries4.getMaximumItemCount();
        timeSeries4.setKey((java.lang.Comparable) 8);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener13);
        boolean boolean15 = timeSeries4.isEmpty();
        java.lang.Object obj16 = timeSeries4.clone();
        timeSeries4.setDomainDescription("May 9999");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (int) (byte) 10, (-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 9999);
        long long3 = month2.getSerialIndex();
        java.lang.Object obj4 = null;
        int int5 = month2.compareTo(obj4);
        int int6 = month2.getYearValue();
        org.jfree.data.time.Year year7 = month2.getYear();
        int int8 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 119993L + "'", long3 == 119993L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9999 + "'", int6 == 9999);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9999 + "'", int8 == 9999);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "", "hi!", class6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number9);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        int int12 = timeSeriesDataItem2.compareTo((java.lang.Object) timeSeries7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem2.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem2.getPeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (short) 100);
//        java.util.Date date20 = fixedMillisecond15.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (short) 100);
//        java.util.Date date30 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date30, timeZone32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date30);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date30);
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date30, timeZone36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date20, timeZone36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, (double) 1560191832596L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 9999);
//        java.lang.Class<?> wildcardClass46 = fixedMillisecond45.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) (short) 100);
//        java.util.Date date52 = fixedMillisecond47.getEnd();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date52, timeZone54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(date52);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond59.getMiddleMillisecond(calendar60);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) (short) 100);
//        java.util.Date date64 = fixedMillisecond59.getEnd();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date64, timeZone66);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond69.getMiddleMillisecond(calendar70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (java.lang.Number) (short) 100);
//        java.util.Date date74 = fixedMillisecond69.getEnd();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date74, timeZone76);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond(date74);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date74);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date74, timeZone80);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date64, timeZone80);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date52, timeZone80);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar85 = null;
//        long long86 = fixedMillisecond84.getMiddleMillisecond(calendar85);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84, (java.lang.Number) (short) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84, 10.0d);
//        java.util.Date date91 = fixedMillisecond84.getEnd();
//        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date91);
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date91, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date52, timeZone93);
//        org.jfree.data.time.TimeSeries timeSeries96 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560191826273L, (java.lang.Class) wildcardClass46);
//        org.jfree.data.time.TimeSeries timeSeries97 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem40, "November", "Mon Jun 10 11:37:00 PDT 2019", (java.lang.Class) wildcardClass46);
//        int int98 = timeSeriesDataItem2.compareTo((java.lang.Object) "Mon Jun 10 11:37:00 PDT 2019");
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560191915806L + "'", long17 == 1560191915806L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560191915807L + "'", long27 == 1560191915807L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560191915810L + "'", long49 == 1560191915810L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560191915811L + "'", long61 == 1560191915811L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560191915822L + "'", long71 == 1560191915822L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560191915824L + "'", long86 == 1560191915824L);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone93);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 1 + "'", int98 == 1);
//    }
//}

