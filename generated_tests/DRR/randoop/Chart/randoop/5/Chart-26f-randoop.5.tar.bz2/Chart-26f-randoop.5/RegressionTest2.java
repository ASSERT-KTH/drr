import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setUpperBound(4.0d);
        java.awt.Paint paint5 = numberAxis0.getLabelPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        groupedStackedBarRenderer5.drawRangeGridline(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) numberAxis8, rectangle2D11, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = groupedStackedBarRenderer5.getDrawingSupplier();
        java.awt.Stroke stroke17 = groupedStackedBarRenderer5.getItemStroke(0, 2);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        ringPlot18.setForegroundAlpha(0.0f);
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setSeparatorPaint(paint21);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, paint4, stroke17, paint21, stroke23, (float) (short) 0);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        groupedStackedBarRenderer26.drawRangeGridline(graphics2D27, categoryPlot28, (org.jfree.chart.axis.ValueAxis) numberAxis29, rectangle2D32, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = groupedStackedBarRenderer26.getDrawingSupplier();
        java.awt.Stroke stroke38 = groupedStackedBarRenderer26.getItemStroke(0, 2);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.clone(shape46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setAutoRangeStickyZero(true);
        java.awt.Paint paint52 = numberAxis49.getLabelPaint();
        java.awt.Paint paint54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape59 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke60 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint62 = polarPlot61.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape46, true, paint52, false, paint54, stroke55, true, shape59, stroke60, paint62);
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = polarPlot64.getInsets();
        polarPlot64.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint68 = polarPlot64.getRadiusGridlinePaint();
        java.awt.Stroke stroke69 = polarPlot64.getRadiusGridlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent70 = null;
        polarPlot64.markerChanged(markerChangeEvent70);
        java.awt.Stroke stroke72 = polarPlot64.getRadiusGridlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker74 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), 8.0d, paint21, stroke38, paint54, stroke72, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(drawingSupplier35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        double double11 = dateRange9.getUpperBound();
        boolean boolean13 = dateRange9.contains((-21.0d));
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange9);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = polarPlot31.getInsets();
        polarPlot31.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint35 = polarPlot31.getRadiusGridlinePaint();
        java.awt.Stroke stroke36 = polarPlot31.getRadiusGridlineStroke();
        java.awt.Color color37 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape25, paint30, stroke36, (java.awt.Paint) color37);
        piePlot0.setLabelOutlineStroke(stroke36);
        piePlot0.setInteriorGap((double) (short) 0);
        double double42 = piePlot0.getShadowXOffset();
        java.lang.String str43 = piePlot0.getPlotType();
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Pie Plot" + "'", str43.equals("Pie Plot"));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = statisticalLineAndShapeRenderer2.getLegendItemURLGenerator();
        java.awt.Color color5 = java.awt.Color.yellow;
        statisticalLineAndShapeRenderer2.setSeriesOutlinePaint(1905, (java.awt.Paint) color5, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setSeparatorPaint(paint3);
        java.lang.String str5 = ringPlot0.getPlotType();
        java.awt.Paint paint7 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) 86400000L);
        java.awt.Paint paint9 = ringPlot0.getSectionPaint((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset33);
        org.jfree.data.Range range36 = defaultBoxAndWhiskerCategoryDataset33.getRangeBounds(false);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis38.getTickMarkPosition();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.clone(shape42);
        dateAxis38.setDownArrow(shape42);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition45 = dateAxis38.getTickMarkPosition();
        dateAxis38.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape48 = dateAxis38.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition50 = dateAxis49.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int52 = dateTickUnit51.getCount();
        dateAxis49.setTickUnit(dateTickUnit51, true, false);
        java.util.Date date56 = dateAxis38.calculateLowestVisibleTickValue(dateTickUnit51);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        java.lang.Number number58 = defaultBoxAndWhiskerCategoryDataset33.getMinRegularValue((java.lang.Comparable) 12.0d, (java.lang.Comparable) date56);
        java.lang.Comparable comparable60 = null;
        java.util.List list61 = defaultBoxAndWhiskerCategoryDataset33.getOutliers((java.lang.Comparable) (short) 100, comparable60);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(attributedString32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(dateTickMarkPosition45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(dateTickMarkPosition50);
        org.junit.Assert.assertNotNull(dateTickUnit51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(number58);
        org.junit.Assert.assertNull(list61);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint4 = numberAxis3.getLabelPaint();
        boolean boolean5 = categoryAxis3D1.equals((java.lang.Object) paint4);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) "UnitType.ABSOLUTE", "Layer.BACKGROUND");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        xYPlot20.clearDomainAxes();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone(shape30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeStickyZero(true);
        java.awt.Paint paint36 = numberAxis33.getLabelPaint();
        java.awt.Paint paint38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint46 = polarPlot45.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape30, true, paint36, false, paint38, stroke39, true, shape43, stroke44, paint46);
        piePlot22.setLabelLinkPaint(paint38);
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot22.setBaseSectionOutlineStroke(stroke49);
        java.awt.Paint paint51 = piePlot22.getLabelShadowPaint();
        xYPlot20.setRangeCrosshairPaint(paint51);
        xYPlot20.setDomainCrosshairValue((double) '4', false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        boolean boolean3 = waterfallBarRenderer0.isItemLabelVisible(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        groupedStackedBarRenderer0.setBaseStroke(stroke22);
        groupedStackedBarRenderer0.setSeriesVisible(31, (java.lang.Boolean) false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean32 = groupedStackedBarRenderer0.equals((java.lang.Object) "ThreadContext");
        groupedStackedBarRenderer0.setAutoPopulateSeriesPaint(true);
        boolean boolean35 = groupedStackedBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = groupedStackedBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(itemLabelPosition36);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        xYPlot20.setRangeCrosshairValue((double) (byte) -1);
        xYPlot20.setDomainCrosshairVisible(false);
        boolean boolean38 = xYPlot20.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        int int2 = stackedAreaRenderer1.getPassCount();
        int int3 = stackedAreaRenderer1.getRowCount();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range6 = defaultBoxAndWhiskerCategoryDataset4.getRangeBounds(false);
        java.lang.Comparable comparable7 = null;
        java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset4.getMeanValue(comparable7, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj12 = categoryAxis3D11.clone();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        dateAxis13.setDownArrow(shape17);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis13.getTickMarkPosition();
        dateAxis13.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape23 = dateAxis13.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis13.setStandardTickUnits(tickUnitSource24);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer26 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setTickLabelsVisible(false);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis28.setLabelFont(font33);
        numberAxis28.setVisible(false);
        float float37 = numberAxis28.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.axis.AxisState axisState44 = numberAxis28.draw(graphics2D38, (double) 1, rectangle2D40, rectangle2D41, rectangleEdge42, plotRenderingInfo43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis28, valueAxis45, xYItemRenderer46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setAutoRangeStickyZero(true);
        java.awt.Paint paint52 = numberAxis49.getLabelPaint();
        xYPlot47.setQuadrantPaint(0, paint52);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot47.setDataset(xYDataset54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        xYPlot47.setRangeAxis((int) '4', valueAxis57, false);
        java.awt.Paint[] paintArray60 = null;
        java.awt.Paint[] paintArray61 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray64 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray60, paintArray61, strokeArray62, strokeArray63, shapeArray64);
        xYPlot47.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = xYPlot47.getLegendItems();
        java.awt.Paint paint68 = xYPlot47.getRangeCrosshairPaint();
        boxAndWhiskerRenderer26.setBaseItemLabelPaint(paint68, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer26);
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = categoryPlot71.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D74 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D76 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D76.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int80 = dateTickUnit79.getCount();
        categoryAxis3D76.removeCategoryLabelToolTip((java.lang.Comparable) int80);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D83 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray84 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D74, categoryAxis3D76, categoryAxis3D83 };
        categoryPlot71.setDomainAxes(categoryAxisArray84);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer86 = null;
        categoryPlot71.setRenderer(categoryItemRenderer86);
        boolean boolean88 = stackedAreaRenderer1.hasListener((java.util.EventListener) categoryPlot71);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = categoryPlot71.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis90 = categoryPlot71.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(axisState44);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paintArray61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(shapeArray64);
        org.junit.Assert.assertNotNull(legendItemCollection67);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertNotNull(categoryAxis90);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge((int) '#');
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeStickyZero(true);
        numberAxis31.setTickLabelsVisible(false);
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis31.setLabelFont(font36);
        numberAxis31.setVisible(false);
        float float40 = numberAxis31.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.axis.AxisState axisState47 = numberAxis31.draw(graphics2D41, (double) 1, rectangle2D43, rectangle2D44, rectangleEdge45, plotRenderingInfo46);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis48, xYItemRenderer49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        numberAxis52.setAutoRangeStickyZero(true);
        java.awt.Paint paint55 = numberAxis52.getLabelPaint();
        xYPlot50.setQuadrantPaint(0, paint55);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        xYPlot50.setDataset(xYDataset57);
        java.awt.Paint paint59 = xYPlot50.getRangeGridlinePaint();
        java.awt.Paint[] paintArray60 = null;
        java.awt.Paint[] paintArray61 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray64 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray60, paintArray61, strokeArray62, strokeArray63, shapeArray64);
        xYPlot50.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        try {
            java.awt.Stroke stroke68 = defaultDrawingSupplier65.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 2.0f + "'", float40 == 2.0f);
        org.junit.Assert.assertNotNull(axisState47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paintArray61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(shapeArray64);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        piePlot0.setLabelLinkPaint(paint16);
        double double27 = piePlot0.getLabelLinkMargin();
        piePlot0.setExplodePercent((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (double) 86400000L);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setAutoRangeStickyZero(true);
        numberAxis34.setTickLabelsVisible(false);
        java.awt.Font font39 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis34.setLabelFont(font39);
        numberAxis34.setVisible(false);
        float float43 = numberAxis34.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.axis.AxisState axisState50 = numberAxis34.draw(graphics2D44, (double) 1, rectangle2D46, rectangle2D47, rectangleEdge48, plotRenderingInfo49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis34, valueAxis51, xYItemRenderer52);
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        numberAxis55.setAutoRangeStickyZero(true);
        java.awt.Paint paint58 = numberAxis55.getLabelPaint();
        xYPlot53.setQuadrantPaint(0, paint58);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        xYPlot53.setDataset(xYDataset60);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        xYPlot53.setRangeAxis((int) '4', valueAxis63, false);
        org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot53.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer67 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator70 = groupedStackedBarRenderer67.getToolTipGenerator(0, 0);
        boolean boolean71 = groupedStackedBarRenderer67.isDrawBarOutline();
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = null;
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis();
        dateAxis74.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker80 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        groupedStackedBarRenderer67.drawRangeMarker(graphics2D72, categoryPlot73, (org.jfree.chart.axis.ValueAxis) dateAxis74, (org.jfree.chart.plot.Marker) intervalMarker80, rectangle2D81);
        java.awt.Paint paint83 = dateAxis74.getAxisLinePaint();
        xYPlot53.setNoDataMessagePaint(paint83);
        java.awt.geom.Point2D point2D85 = xYPlot53.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState86 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        try {
            piePlot0.draw(graphics2D31, rectangle2D32, point2D85, plotState86, plotRenderingInfo87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 2.0f + "'", float43 == 2.0f);
        org.junit.Assert.assertNotNull(axisState50);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(valueAxis66);
        org.junit.Assert.assertNull(categoryToolTipGenerator70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(point2D85);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test20");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        long long3 = month0.getSerialIndex();
//        long long4 = month0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) categoryLabelPositions2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        double double6 = multiplePiePlot5.getLimit();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot5.getPieChart();
        float float8 = jFreeChart7.getBackgroundImageAlpha();
        rendererChangeEvent4.setChart(jFreeChart7);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getBackgroundPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        polarPlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = polarPlot0.getOrientation();
        java.awt.Font font5 = polarPlot0.getAngleLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset70 = categoryPlot67.getDataset(2019);
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = categoryPlot67.getDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder72 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot67.setDatasetRenderingOrder(datasetRenderingOrder72);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D75 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions76 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis3D75.setCategoryLabelPositions(categoryLabelPositions76);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent78 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) categoryLabelPositions76);
        boolean boolean79 = datasetRenderingOrder72.equals((java.lang.Object) rendererChangeEvent78);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNull(categoryDataset70);
        org.junit.Assert.assertNotNull(categoryAxis71);
        org.junit.Assert.assertNotNull(datasetRenderingOrder72);
        org.junit.Assert.assertNotNull(categoryLabelPositions76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot20.addChangeListener(plotChangeListener27);
        int int29 = xYPlot20.getDatasetCount();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeStickyZero(true);
        numberAxis31.setTickLabelsVisible(false);
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis31.setLabelFont(font36);
        numberAxis31.setVisible(false);
        float float40 = numberAxis31.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.axis.AxisState axisState47 = numberAxis31.draw(graphics2D41, (double) 1, rectangle2D43, rectangle2D44, rectangleEdge45, plotRenderingInfo46);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis48, xYItemRenderer49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        numberAxis52.setAutoRangeStickyZero(true);
        java.awt.Paint paint55 = numberAxis52.getLabelPaint();
        xYPlot50.setQuadrantPaint(0, paint55);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        xYPlot50.setDataset(xYDataset57);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        xYPlot50.setRangeAxis((int) '4', valueAxis60, false);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot50.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation64 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot50.setRangeAxisLocation(axisLocation64, false);
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition69 = dateAxis68.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit70 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int71 = dateTickUnit70.getCount();
        dateAxis68.setTickUnit(dateTickUnit70, true, false);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = null;
        double double78 = dateAxis68.valueToJava2D((double) (short) 0, rectangle2D76, rectangleEdge77);
        xYPlot50.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis68, false);
        boolean boolean81 = dateAxis68.isTickMarksVisible();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis68);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 2.0f + "'", float40 == 2.0f);
        org.junit.Assert.assertNotNull(axisState47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertNotNull(dateTickMarkPosition69);
        org.junit.Assert.assertNotNull(dateTickUnit70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        boolean boolean4 = categoryLabelWidthType2.equals((java.lang.Object) 31);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1900);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType7 = categoryLabelPosition6.getWidthType();
        java.lang.String str8 = categoryLabelWidthType7.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str8.equals("CategoryLabelWidthType.RANGE"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.block.BorderArrangement borderArrangement68 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement68.clear();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor70 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.Object obj71 = null;
        boolean boolean72 = categoryAnchor70.equals(obj71);
        org.jfree.chart.axis.DateTickUnit dateTickUnit73 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean74 = categoryAnchor70.equals((java.lang.Object) dateTickUnit73);
        boolean boolean75 = borderArrangement68.equals((java.lang.Object) dateTickUnit73);
        java.util.Date date76 = dateAxis9.calculateHighestVisibleTickValue(dateTickUnit73);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(categoryAnchor70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTickUnit73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(date76);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        java.awt.Paint paint1 = null;
        java.awt.Color color2 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str6 = verticalAlignment5.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement10 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource3, (org.jfree.chart.block.Arrangement) flowArrangement9, (org.jfree.chart.block.Arrangement) centerArrangement10);
        boolean boolean12 = legendTitle11.getNotify();
        boolean boolean13 = legendTitle11.getNotify();
        java.awt.Paint paint14 = legendTitle11.getItemPaint();
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer15 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint0, paint1, (java.awt.Paint) color2, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positiveBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str6.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) true);
        boolean boolean6 = statisticalLineAndShapeRenderer2.getBaseShapesVisible();
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) (-16777216));
        double double14 = dateRange9.constrain((double) 2);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) 1L, false);
        boolean boolean19 = dateRange9.contains(2.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(0.0d, 0.0d);
        java.lang.Object obj4 = dateAxis0.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int6 = dateTickUnit5.getCount();
        dateAxis0.setTickUnit(dateTickUnit5, false, false);
        java.lang.Object obj10 = null;
        int int11 = dateTickUnit5.compareTo(obj10);
        int int12 = dateTickUnit5.getUnit();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        xYPlot20.setRangeCrosshairValue((double) (byte) -1);
        xYPlot20.setDomainCrosshairVisible(false);
        double double38 = xYPlot20.getRangeCrosshairValue();
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot();
        ringPlot39.setStartAngle((double) 0.0f);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_BLUE;
        ringPlot39.setLabelBackgroundPaint((java.awt.Paint) color42);
        xYPlot20.setRangeCrosshairPaint((java.awt.Paint) color42);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        boolean boolean2 = lineRenderer3D0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot20.setDataset((int) (short) 10, xYDataset30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = xYPlot20.getFixedRangeAxisSpace();
        java.awt.Stroke stroke33 = xYPlot20.getRangeGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setAutoRangeStickyZero(true);
        numberAxis35.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange43, (org.jfree.data.Range) dateRange46);
        dateAxis40.setRangeWithMargins((org.jfree.data.Range) dateRange43);
        numberAxis35.setDefaultAutoRange((org.jfree.data.Range) dateRange43);
        java.awt.Paint paint50 = numberAxis35.getLabelPaint();
        xYPlot20.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis35, true);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        xYPlot20.drawBackgroundImage(graphics2D53, rectangle2D54);
        double double56 = xYPlot20.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        try {
            java.lang.Number number6 = taskSeriesCollection1.getStartValue(10, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = groupedStackedBarRenderer34.getToolTipGenerator(0, 0);
        boolean boolean38 = groupedStackedBarRenderer34.isDrawBarOutline();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        groupedStackedBarRenderer34.drawRangeMarker(graphics2D39, categoryPlot40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.plot.Marker) intervalMarker47, rectangle2D48);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        xYPlot20.setRenderer(xYItemRenderer51);
        org.jfree.chart.axis.AxisSpace axisSpace53 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean56 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge55);
        axisSpace53.add((double) (byte) 1, rectangleEdge55);
        xYPlot20.setFixedDomainAxisSpace(axisSpace53);
        double double59 = axisSpace53.getTop();
        axisSpace53.setTop((double) 11L);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        groupedStackedBarRenderer0.setBaseStroke(stroke22);
        groupedStackedBarRenderer0.setSeriesVisible(31, (java.lang.Boolean) false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean32 = groupedStackedBarRenderer0.equals((java.lang.Object) "ThreadContext");
        groupedStackedBarRenderer0.setAutoPopulateSeriesPaint(true);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) false, false);
        groupedStackedBarRenderer0.setMaximumBarWidth(0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        java.util.Iterator iterator2 = outlierListCollection0.iterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(iterator2);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        java.awt.Paint paint2 = ringPlot0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        java.awt.Paint paint5 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", paint5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition21 = dateAxis20.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int23 = dateTickUnit22.getCount();
        dateAxis20.setTickUnit(dateTickUnit22, true, false);
        java.util.Date date27 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit22);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        int int29 = spreadsheetDate8.compare(serialDate28);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition31 = dateAxis30.getTickMarkPosition();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.clone(shape34);
        dateAxis30.setDownArrow(shape34);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition37 = dateAxis30.getTickMarkPosition();
        dateAxis30.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape40 = dateAxis30.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition42 = dateAxis41.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int44 = dateTickUnit43.getCount();
        dateAxis41.setTickUnit(dateTickUnit43, true, false);
        java.util.Date date48 = dateAxis30.calculateLowestVisibleTickValue(dateTickUnit43);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        boolean boolean50 = spreadsheetDate8.isOn(serialDate49);
        org.jfree.data.time.SerialDate serialDate52 = serialDate49.getNearestDayOfWeek(3);
        java.awt.Stroke stroke53 = null;
        piePlot0.setSectionOutlineStroke((java.lang.Comparable) serialDate52, stroke53);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(dateTickMarkPosition21);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-23550) + "'", int29 == (-23550));
        org.junit.Assert.assertNotNull(dateTickMarkPosition31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(dateTickMarkPosition37);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(dateTickMarkPosition42);
        org.junit.Assert.assertNotNull(dateTickUnit43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate52);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setAutoRangeStickyZero(true);
        numberAxis7.setTickLabelsVisible(false);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis7.setLabelFont(font12);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("ThreadContext", font12);
        textTitle0.setFont(font12);
        textTitle0.setID("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getBaseItemLabelPaint();
        int int12 = statisticalLineAndShapeRenderer2.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) ' ');
        boolean boolean15 = statisticalLineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder50 = xYPlot43.getSeriesRenderingOrder();
        xYPlot20.setSeriesRenderingOrder(seriesRenderingOrder50);
        org.jfree.chart.LegendItemCollection legendItemCollection52 = xYPlot20.getFixedLegendItems();
        xYPlot20.setDomainCrosshairValue((double) 100L, false);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot20.getDomainAxisForDataset(0);
        org.jfree.chart.axis.AxisSpace axisSpace58 = xYPlot20.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder50);
        org.junit.Assert.assertNull(legendItemCollection52);
        org.junit.Assert.assertNotNull(valueAxis57);
        org.junit.Assert.assertNull(axisSpace58);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        java.awt.Paint paint3 = numberAxis0.getLabelPaint();
        boolean boolean4 = numberAxis0.isNegativeArrowVisible();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        numberAxis0.setUpArrow(shape7);
        numberAxis0.setFixedDimension(5.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        dateAxis2.setDownArrow(shape6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis2.getTickMarkPosition();
        dateAxis2.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape12 = dateAxis2.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int16 = dateTickUnit15.getCount();
        dateAxis13.setTickUnit(dateTickUnit15, true, false);
        java.util.Date date20 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit15);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = spreadsheetDate1.compare(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2019);
        boolean boolean25 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-23550) + "'", int22 == (-23550));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        dateAxis0.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape10 = dateAxis0.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis11.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int14 = dateTickUnit13.getCount();
        dateAxis11.setTickUnit(dateTickUnit13, true, false);
        java.util.Date date18 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test55");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        int int2 = month0.getYearValue();
//        boolean boolean4 = month0.equals((java.lang.Object) "AreaRendererEndType.LEVEL");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset5.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
//        java.util.List list10 = defaultCategoryDataset5.getColumnKeys();
//        int int11 = month0.compareTo((java.lang.Object) defaultCategoryDataset5);
//        try {
//            defaultCategoryDataset5.removeRow(1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str3 = verticalAlignment2.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        boolean boolean9 = legendTitle8.getNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getItemLabelPadding();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str3.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalLineAndShapeRenderer2.getItemLabelGenerator((int) (byte) 0, (int) (short) 10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.block.BorderArrangement borderArrangement2 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement2.clear();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryAnchor4.equals(obj5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean8 = categoryAnchor4.equals((java.lang.Object) dateTickUnit7);
        boolean boolean9 = borderArrangement2.equals((java.lang.Object) dateTickUnit7);
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] { 1.0f, (short) -1, dateTickUnit7 };
        java.lang.String[] strArray11 = org.jfree.data.time.SerialDate.getMonths();
        double[] doubleArray18 = new double[] { 35L, 0.0f, 3, 8.0d, 0.5f, 900000L };
        double[] doubleArray25 = new double[] { 35L, 0.0f, 3, 8.0d, 0.5f, 900000L };
        double[] doubleArray32 = new double[] { 35L, 0.0f, 3, 8.0d, 0.5f, 900000L };
        double[] doubleArray39 = new double[] { 35L, 0.0f, 3, 8.0d, 0.5f, 900000L };
        double[] doubleArray46 = new double[] { 35L, 0.0f, 3, 8.0d, 0.5f, 900000L };
        double[][] doubleArray47 = new double[][] { doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray10, (java.lang.Comparable[]) strArray11, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        xYPlot20.setRangeCrosshairValue((double) (byte) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = xYPlot20.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot20.setDataset(xYDataset37);
        xYPlot20.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(plotOrientation36);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("TextBlockAnchor.TOP_LEFT");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setUpperBound(4.0d);
        java.awt.Shape shape5 = numberAxis0.getDownArrow();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, 10.0d, 0.0d);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape8, "UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        jFreeChart2.setBackgroundImageAlignment((int) (short) 1);
        boolean boolean6 = jFreeChart2.isNotify();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.entity.EntityCollection entityCollection3 = categoryItemRendererState1.getEntityCollection();
        double double4 = categoryItemRendererState1.getBarWidth();
        double double5 = categoryItemRendererState1.getBarWidth();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = categoryItemRendererState1.getInfo();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(entityCollection3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo6);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setWidth((double) ' ');
    }
}

