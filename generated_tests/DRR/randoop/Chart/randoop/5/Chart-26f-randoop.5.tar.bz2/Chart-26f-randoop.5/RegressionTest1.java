import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (byte) -1;
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 11, (java.lang.Object) 1);
        java.lang.Object obj3 = keyedObject2.clone();
        java.lang.Object obj4 = keyedObject2.getObject();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1 + "'", obj4.equals(1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator41 = statisticalLineAndShapeRenderer2.getSeriesToolTipGenerator(2);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryToolTipGenerator41);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset33);
        org.jfree.data.Range range36 = defaultBoxAndWhiskerCategoryDataset33.getRangeBounds(false);
        double double38 = defaultBoxAndWhiskerCategoryDataset33.getRangeUpperBound(true);
        try {
            java.lang.Number number41 = defaultBoxAndWhiskerCategoryDataset33.getMaxOutlier(2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(attributedString32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        try {
            numberAxis0.setRangeWithMargins(0.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle0.setHorizontalAlignment(horizontalAlignment2);
        java.awt.Paint paint4 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis3D1.draw(graphics2D2, (double) 'a', rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection30 = xYPlot20.getFixedLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeStickyZero(true);
        numberAxis31.setTickLabelsVisible(false);
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis31.setLabelFont(font36);
        org.jfree.data.Range range38 = xYPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.awt.Font font39 = numberAxis31.getTickLabelFont();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Paint paint4 = numberAxis1.getLabelPaint();
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        polarPlot7.zoom((double) (byte) 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        boolean boolean10 = numberAxis0.isAutoTickUnitSelection();
        boolean boolean11 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        org.jfree.data.RangeType rangeType2 = org.jfree.data.RangeType.POSITIVE;
        java.lang.String str3 = rangeType2.toString();
        boolean boolean5 = rangeType2.equals((java.lang.Object) 10L);
        boolean boolean6 = xYPlot0.equals((java.lang.Object) rangeType2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RangeType.POSITIVE" + "'", str3.equals("RangeType.POSITIVE"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot20.setRangeAxisLocation(axisLocation34, false);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis38.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int41 = dateTickUnit40.getCount();
        dateAxis38.setTickUnit(dateTickUnit40, true, false);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = dateAxis38.valueToJava2D((double) (short) 0, rectangle2D46, rectangleEdge47);
        xYPlot20.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis38, false);
        int int51 = xYPlot20.getDatasetCount();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        polarPlot0.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint4 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke5 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        polarPlot0.markerChanged(markerChangeEvent6);
        java.awt.Stroke stroke8 = polarPlot0.getRadiusGridlineStroke();
        boolean boolean9 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = xYPlot20.getFixedRangeAxisSpace();
        xYPlot20.mapDatasetToDomainAxis(5, (int) (byte) 0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(axisSpace27);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        dateAxis2.setDownArrow(shape6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis2.getTickMarkPosition();
        dateAxis2.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape12 = dateAxis2.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int16 = dateTickUnit15.getCount();
        dateAxis13.setTickUnit(dateTickUnit15, true, false);
        java.util.Date date20 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit15);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = spreadsheetDate1.compare(serialDate21);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition24 = dateAxis23.getTickMarkPosition();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.clone(shape27);
        dateAxis23.setDownArrow(shape27);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition30 = dateAxis23.getTickMarkPosition();
        dateAxis23.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape33 = dateAxis23.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition35 = dateAxis34.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int37 = dateTickUnit36.getCount();
        dateAxis34.setTickUnit(dateTickUnit36, true, false);
        java.util.Date date41 = dateAxis23.calculateLowestVisibleTickValue(dateTickUnit36);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        boolean boolean43 = spreadsheetDate1.isOn(serialDate42);
        org.jfree.data.time.SerialDate serialDate45 = serialDate42.getNearestDayOfWeek(2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-23550) + "'", int22 == (-23550));
        org.junit.Assert.assertNotNull(dateTickMarkPosition24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(dateTickMarkPosition30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(dateTickMarkPosition35);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot20.setRangeAxisLocation(axisLocation34, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation34, plotOrientation37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = axisLocation34.getOpposite();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setRange((double) (short) 10, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis0.getLabelInsets();
        double double5 = numberAxis0.getLowerBound();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setAutoRangeStickyZero(true);
        java.awt.Paint paint23 = numberAxis20.getLabelPaint();
        java.awt.Paint paint25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint33 = polarPlot32.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape17, true, paint23, false, paint25, stroke26, true, shape30, stroke31, paint33);
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = polarPlot36.getInsets();
        polarPlot36.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint40 = polarPlot36.getRadiusGridlinePaint();
        java.awt.Stroke stroke41 = polarPlot36.getRadiusGridlineStroke();
        java.awt.Color color42 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape30, paint35, stroke41, (java.awt.Paint) color42);
        numberAxis0.setAxisLineStroke(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 0, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        java.lang.String str10 = projectInfo7.getName();
        projectInfo7.setLicenceText("TextAnchor.BASELINE_CENTER");
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "({0}, {1}) = {2}" + "'", str10.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        intervalBarRenderer0.setSeriesURLGenerator((int) '4', categoryURLGenerator2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        xYPlot20.clearDomainAxes();
        boolean boolean22 = xYPlot20.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (byte) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean4 = shapeList0.equals((java.lang.Object) rectangleEdge3);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        boolean boolean5 = segmentedTimeline3.containsDomainValue((long) 11);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getLabelInsets();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, (double) 10, 0.0d);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getRowKeys();
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 0, 2019, (int) (short) 100, 0, dateFormat6);
        int int8 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) dateTickUnit7);
        try {
            java.lang.Comparable comparable10 = defaultKeyedValues2D0.getRowKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        int int1 = boxAndWhiskerRenderer0.getColumnCount();
        double double2 = boxAndWhiskerRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer6.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer6.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = statisticalLineAndShapeRenderer6.getLegendItemLabelGenerator();
        boolean boolean13 = statisticalLineAndShapeRenderer6.getItemLineVisible((int) (short) 100, 0);
        java.lang.Boolean boolean15 = statisticalLineAndShapeRenderer6.getSeriesShapesFilled((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = statisticalLineAndShapeRenderer6.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition17.getItemLabelAnchor();
        boxAndWhiskerRenderer0.setSeriesPositiveItemLabelPosition(3, itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = null;
        groupedStackedBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator17, false);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            groupedStackedBarRenderer0.drawDomainGridline(graphics2D20, categoryPlot21, rectangle2D22, (double) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.chart.axis.TickUnits tickUnits7 = new org.jfree.chart.axis.TickUnits();
        dateAxis0.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits7);
        java.util.TimeZone timeZone9 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getRowKeys();
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 0, 2019, (int) (short) 100, 0, dateFormat6);
        int int8 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) dateTickUnit7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setLowerBound((double) 100L);
        numberAxis9.setUpperBound(4.0d);
        java.awt.Shape shape14 = numberAxis9.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint16 = numberAxis15.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis15.getTickUnit();
        numberAxis9.setTickUnit(numberTickUnit17, false, false);
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) false, (java.lang.Comparable) 4);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod4);
        task2.removeSubtask(task5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        task5.setDuration((org.jfree.data.time.TimePeriod) regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot20.getLegendItems();
        java.awt.Paint paint41 = xYPlot20.getRangeCrosshairPaint();
        java.io.ObjectOutputStream objectOutputStream42 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint41, objectOutputStream42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.lang.Boolean boolean11 = statisticalLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 10);
        java.lang.Boolean boolean13 = statisticalLineAndShapeRenderer2.getSeriesShapesVisible(4);
        java.awt.Font font14 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        dateAxis2.setDownArrow(shape6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis2.getTickMarkPosition();
        dateAxis2.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape12 = dateAxis2.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int16 = dateTickUnit15.getCount();
        dateAxis13.setTickUnit(dateTickUnit15, true, false);
        java.util.Date date20 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit15);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = spreadsheetDate1.compare(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2019);
        boolean boolean25 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate24.getYYYY();
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-23550) + "'", int22 == (-23550));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1905 + "'", int26 == 1905);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        piePlot0.setLabelLinkPaint(paint16);
        java.awt.Paint paint27 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setStartAngle((double) 0L);
        org.jfree.chart.util.Rotation rotation30 = null;
        try {
            piePlot0.setDirection(rotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        int int4 = taskSeriesCollection2.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        java.awt.Paint paint6 = multiplePiePlot5.getAggregatedItemsPaint();
        boolean boolean7 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color1, paint6);
        boolean boolean8 = year0.equals((java.lang.Object) boolean7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        double double3 = numberAxis0.getFixedAutoRange();
        java.awt.Paint paint4 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        boolean boolean11 = lengthConstraintType9.equals((java.lang.Object) standardCategoryURLGenerator10);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange18);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, (org.jfree.data.Range) dateRange25);
        java.lang.String str27 = rectangleConstraint26.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = rectangleConstraint26.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) 5, range8, lengthConstraintType9, (double) 11, (org.jfree.data.Range) dateRange15, lengthConstraintType28);
        org.jfree.data.Range range30 = rectangleConstraint29.getHeightRange();
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str27.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor4, categoryLabelWidthType5, (float) 1L);
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) 2019, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        boolean boolean40 = statisticalLineAndShapeRenderer2.getItemShapeFilled((int) (short) -1, 1);
        int int41 = statisticalLineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        double double12 = ringPlot11.getMinimumArcAngleToDraw();
        ringPlot11.setCircular(true);
        java.awt.Paint paint15 = ringPlot11.getLabelShadowPaint();
        boolean boolean16 = segmentedTimeline3.equals((java.lang.Object) paint15);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(paint15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0E-5d + "'", double12 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D1.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCount();
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) int5);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle((double) 0.0f);
        java.awt.Paint paint3 = null;
        ringPlot0.setLabelBackgroundPaint(paint3);
        java.awt.Font font5 = ringPlot0.getLabelFont();
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        boolean boolean18 = groupedStackedBarRenderer0.equals((java.lang.Object) '4');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection19 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection19);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection19, 0);
        org.jfree.data.Range range24 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection19);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Paint paint29 = xYPlot20.getRangeGridlinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation30 = null;
        try {
            boolean boolean31 = xYPlot20.removeAnnotation(xYAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color4 = java.awt.Color.WHITE;
        float[] floatArray11 = new float[] { (-1.0f), (byte) 100, 10L, (byte) -1, 10.0f, ' ' };
        float[] floatArray12 = color4.getColorComponents(floatArray11);
        float[] floatArray13 = color3.getColorComponents(floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB((-1), 0, (int) (short) 100, floatArray13);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot20.getLegendItems();
        java.awt.Paint paint41 = xYPlot20.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.plot.Plot plot21 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        piePlot0.setLabelLinkPaint(paint16);
        piePlot0.setBackgroundAlpha((float) (short) 100);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor29 = piePlot0.getLabelDistributor();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor29);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        boolean boolean5 = ganttRenderer0.hasListener((java.util.EventListener) waferMapPlot2);
        java.awt.Paint paint7 = ganttRenderer0.getSeriesPaint(11);
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ganttRenderer0.setIncompletePaint(paint8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.util.Date date0 = null;
        java.text.DateFormat dateFormat5 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 0, 2019, (int) (short) 100, 0, dateFormat5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis7.getTickMarkPosition();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        dateAxis7.setDownArrow(shape11);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis7.getTickMarkPosition();
        dateAxis7.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape17 = dateAxis7.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = dateAxis18.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int21 = dateTickUnit20.getCount();
        dateAxis18.setTickUnit(dateTickUnit20, true, false);
        java.util.Date date25 = dateAxis7.calculateLowestVisibleTickValue(dateTickUnit20);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        java.lang.String str27 = dateTickUnit6.dateToString(date25);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date0, date25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(dateTickMarkPosition19);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1/1/70" + "'", str27.equals("1/1/70"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection30 = xYPlot20.getFixedLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeStickyZero(true);
        numberAxis31.setTickLabelsVisible(false);
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis31.setLabelFont(font36);
        org.jfree.data.Range range38 = xYPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis31);
        boolean boolean39 = xYPlot20.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(0, 255);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle((double) 0.0f);
        ringPlot0.setCircular(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeStickyZero(true);
        numberAxis5.setTickLabelsVisible(false);
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis5.setLabelFont(font10);
        ringPlot0.setNoDataMessageFont(font10);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        boolean boolean18 = groupedStackedBarRenderer0.equals((java.lang.Object) '4');
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeStickyZero(true);
        numberAxis19.setTickLabelsVisible(false);
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis19.setLabelFont(font24);
        groupedStackedBarRenderer0.setBaseItemLabelFont(font24);
        double double27 = groupedStackedBarRenderer0.getUpperClip();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        try {
            groupedStackedBarRenderer0.drawDomainGridline(graphics2D28, categoryPlot29, rectangle2D30, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D1.setUpperMargin((double) 0.0f);
        int int4 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        try {
            double double10 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor5, (int) (short) 0, 0, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = groupedStackedBarRenderer0.getDrawingSupplier();
        java.awt.Stroke stroke12 = groupedStackedBarRenderer0.getItemStroke(0, 2);
        java.awt.Paint paint14 = groupedStackedBarRenderer0.lookupSeriesPaint(11);
        groupedStackedBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        stackedBarRenderer1.setAutoPopulateSeriesStroke(false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker3.setStartValue(1.0d);
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker3.setLabelPaint(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = intervalMarker3.getLabelOffset();
        double double10 = rectangleInsets8.trimWidth(0.2d);
        java.lang.Class<?> wildcardClass11 = rectangleInsets8.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-5.8d) + "'", double10 == (-5.8d));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(inputStream13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setInverted(false);
        numberAxis0.setRangeWithMargins((double) (short) -1, (-1.0d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2, categoryLabelWidthType3, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = categoryLabelPosition5.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition5);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10, categoryLabelWidthType11, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryLabelPosition13.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions8, categoryLabelPosition13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor17, categoryLabelWidthType18, (float) 1L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions8, categoryLabelPosition20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor23, textBlockAnchor24, categoryLabelWidthType25, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = categoryLabelPosition27.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition27);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(categoryLabelPositions29);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Paint paint28 = xYPlot20.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot20.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        int int31 = xYPlot20.indexOf(xYDataset30);
        xYPlot20.clearDomainMarkers(2019);
        boolean boolean34 = xYPlot20.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        textTitle0.setPadding(rectangleInsets8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (org.jfree.data.Range) dateRange17);
        java.lang.String str19 = rectangleConstraint18.toString();
        double double20 = rectangleConstraint18.getHeight();
        double double21 = rectangleConstraint18.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D22 = textTitle0.arrange(graphics2D11, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str19.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineRenderer3D0.drawBackground(graphics2D1, categoryPlot2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint1 = numberAxis0.getLabelPaint();
        org.jfree.data.RangeType rangeType2 = numberAxis0.getRangeType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ItemLabelAnchor.INSIDE9", "", "");
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        boolean boolean6 = verticalAlignment2.equals((java.lang.Object) numberAxis3);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 100, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, (double) '4', 0.05d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        xYPlot20.mapDatasetToRangeAxis((int) (short) 100, 7);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        double double17 = groupedStackedBarRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalLineAndShapeRenderer20.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer20.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = statisticalLineAndShapeRenderer20.getLegendItemLabelGenerator();
        boolean boolean27 = statisticalLineAndShapeRenderer20.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.clone(shape36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setAutoRangeStickyZero(true);
        java.awt.Paint paint42 = numberAxis39.getLabelPaint();
        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint52 = polarPlot51.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape36, true, paint42, false, paint44, stroke45, true, shape49, stroke50, paint52);
        statisticalLineAndShapeRenderer20.setSeriesPaint((int) ' ', paint44, true);
        groupedStackedBarRenderer0.setBaseOutlinePaint(paint44, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator59 = groupedStackedBarRenderer0.getSeriesToolTipGenerator((int) (short) -1);
        java.awt.Font font60 = groupedStackedBarRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(categoryToolTipGenerator59);
        org.junit.Assert.assertNotNull(font60);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("LengthConstraintType.FIXED", "", "Layer.BACKGROUND", image3, "AreaRendererEndType.LEVEL", "CategoryAnchor.END", "ERROR : Relative To String");
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setSeparatorPaint(paint3);
        java.lang.String str5 = ringPlot0.getPlotType();
        java.awt.Paint paint7 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) 86400000L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        labelBlock8.setToolTipText("Multiple Pie Plot");
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        textTitle0.setPadding(rectangleInsets8);
        boolean boolean11 = textTitle0.getExpandToFitSpace();
        java.awt.Paint paint12 = null;
        try {
            textTitle0.setPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = groupedStackedBarRenderer34.getToolTipGenerator(0, 0);
        boolean boolean38 = groupedStackedBarRenderer34.isDrawBarOutline();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        groupedStackedBarRenderer34.drawRangeMarker(graphics2D39, categoryPlot40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.plot.Marker) intervalMarker47, rectangle2D48);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        xYPlot20.setRangeGridlinesVisible(true);
        xYPlot20.clearDomainMarkers((int) (short) 1);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer55 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        numberAxis58.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        groupedStackedBarRenderer55.drawRangeGridline(graphics2D56, categoryPlot57, (org.jfree.chart.axis.ValueAxis) numberAxis58, rectangle2D61, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier64 = groupedStackedBarRenderer55.getDrawingSupplier();
        java.awt.Stroke stroke67 = groupedStackedBarRenderer55.getItemStroke(0, 2);
        java.awt.Paint paint69 = groupedStackedBarRenderer55.lookupSeriesPaint(11);
        xYPlot20.setRangeTickBandPaint(paint69);
        java.lang.Object obj71 = xYPlot20.clone();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(drawingSupplier64);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(obj71);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        polarPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = polarPlot0.getOutlinePaint();
        polarPlot0.addCornerTextItem("CategoryAnchor.END");
        polarPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = groupedStackedBarRenderer34.getToolTipGenerator(0, 0);
        boolean boolean38 = groupedStackedBarRenderer34.isDrawBarOutline();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        groupedStackedBarRenderer34.drawRangeMarker(graphics2D39, categoryPlot40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.plot.Marker) intervalMarker47, rectangle2D48);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        xYPlot20.setRenderer(xYItemRenderer51);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        numberAxis55.setAutoRangeStickyZero(true);
        numberAxis55.setTickLabelsVisible(false);
        java.awt.Font font60 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis55.setLabelFont(font60);
        numberAxis55.setVisible(false);
        float float64 = numberAxis55.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        org.jfree.chart.axis.AxisState axisState71 = numberAxis55.draw(graphics2D65, (double) 1, rectangle2D67, rectangle2D68, rectangleEdge69, plotRenderingInfo70);
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) numberAxis55, valueAxis72, xYItemRenderer73);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis();
        numberAxis76.setAutoRangeStickyZero(true);
        java.awt.Paint paint79 = numberAxis76.getLabelPaint();
        xYPlot74.setQuadrantPaint(0, paint79);
        org.jfree.data.xy.XYDataset xYDataset81 = null;
        xYPlot74.setDataset(xYDataset81);
        org.jfree.chart.axis.ValueAxis valueAxis84 = null;
        xYPlot74.setRangeAxis((int) '4', valueAxis84, false);
        org.jfree.chart.axis.ValueAxis valueAxis87 = xYPlot74.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation88 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot74.setRangeAxisLocation(axisLocation88, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation91 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation88, plotOrientation91);
        xYPlot20.setDomainAxisLocation(12, axisLocation88, false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 2.0f + "'", float64 == 2.0f);
        org.junit.Assert.assertNotNull(axisState71);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(valueAxis87);
        org.junit.Assert.assertNotNull(axisLocation88);
        org.junit.Assert.assertNotNull(plotOrientation91);
        org.junit.Assert.assertNotNull(rectangleEdge92);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        groupedStackedBarRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.plot.Marker) intervalMarker13, rectangle2D14);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.clone(shape23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeStickyZero(true);
        java.awt.Paint paint29 = numberAxis26.getLabelPaint();
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint39 = polarPlot38.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape23, true, paint29, false, paint31, stroke32, true, shape36, stroke37, paint39);
        groupedStackedBarRenderer0.setBaseShape(shape36);
        java.awt.Stroke stroke44 = groupedStackedBarRenderer0.getItemStroke(5, 11);
        groupedStackedBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        stackedBarRenderer3D0.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, rectangle2D6, 3.0d);
        java.awt.Paint paint11 = stackedBarRenderer3D0.getItemFillPaint(12, (int) (short) 0);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int2 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Object obj4 = null;
        boolean boolean5 = taskSeriesCollection0.equals(obj4);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        dateAxis1.setDownArrow(shape5);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis1.getTickMarkPosition();
        dateAxis1.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape11 = dateAxis1.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis12.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int15 = dateTickUnit14.getCount();
        dateAxis12.setTickUnit(dateTickUnit14, true, false);
        java.util.Date date19 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        boolean boolean21 = projectInfo0.equals((java.lang.Object) serialDate20);
        java.lang.String str22 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "LGPL" + "'", str22.equals("LGPL"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeStickyZero(true);
        numberAxis2.setTickLabelsVisible(false);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis2.setLabelFont(font7);
        numberAxis2.setVisible(false);
        float float11 = numberAxis2.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.axis.AxisState axisState18 = numberAxis2.draw(graphics2D12, (double) 1, rectangle2D14, rectangle2D15, rectangleEdge16, plotRenderingInfo17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeStickyZero(true);
        java.awt.Paint paint26 = numberAxis23.getLabelPaint();
        xYPlot21.setQuadrantPaint(0, paint26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot21.setDataset(xYDataset28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        xYPlot21.setRangeAxis((int) '4', valueAxis31, false);
        java.awt.Paint[] paintArray34 = null;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray38 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray34, paintArray35, strokeArray36, strokeArray37, shapeArray38);
        xYPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = xYPlot21.getLegendItems();
        java.awt.Paint paint42 = xYPlot21.getRangeCrosshairPaint();
        boxAndWhiskerRenderer0.setBaseItemLabelPaint(paint42, false);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState50 = boxAndWhiskerRenderer0.initialise(graphics2D45, rectangle2D46, categoryPlot47, 2, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(axisState18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(legendItemCollection41);
        org.junit.Assert.assertNotNull(paint42);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.util.Locale locale1 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker4.setStartValue(1.0d);
        java.awt.Paint paint7 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker4.setLabelPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = intervalMarker4.getLabelOffset();
        double double11 = rectangleInsets9.trimWidth(0.2d);
        java.lang.Class<?> wildcardClass12 = rectangleInsets9.getClass();
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
        java.util.ResourceBundle.Control control14 = null;
        try {
            java.util.ResourceBundle resourceBundle15 = java.util.ResourceBundle.getBundle("Pie Plot", locale1, classLoader13, control14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-5.8d) + "'", double11 == (-5.8d));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(classLoader13);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = groupedStackedBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((double) (-16777216), (java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (java.lang.Comparable) "-3,-3,3,3");
        try {
            defaultCategoryDataset0.removeRow((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        double double8 = textTitle0.getContentXOffset();
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textTitle0.arrange(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2, categoryLabelWidthType3, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = categoryLabelPosition5.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor9, categoryLabelWidthType10, (float) 1L);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = categoryLabelPosition12.getLabelAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = groupedStackedBarRenderer34.getToolTipGenerator(0, 0);
        boolean boolean38 = groupedStackedBarRenderer34.isDrawBarOutline();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        groupedStackedBarRenderer34.drawRangeMarker(graphics2D39, categoryPlot40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.plot.Marker) intervalMarker47, rectangle2D48);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        xYPlot20.setRangeGridlinesVisible(true);
        xYPlot20.clearDomainMarkers((int) (short) 1);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer55 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        numberAxis58.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        groupedStackedBarRenderer55.drawRangeGridline(graphics2D56, categoryPlot57, (org.jfree.chart.axis.ValueAxis) numberAxis58, rectangle2D61, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier64 = groupedStackedBarRenderer55.getDrawingSupplier();
        java.awt.Stroke stroke67 = groupedStackedBarRenderer55.getItemStroke(0, 2);
        java.awt.Paint paint69 = groupedStackedBarRenderer55.lookupSeriesPaint(11);
        xYPlot20.setRangeTickBandPaint(paint69);
        xYPlot20.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(drawingSupplier64);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        boolean boolean42 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) '#', 1905);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int2 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot3.setAggregatedItemsPaint((java.awt.Paint) color5);
        java.lang.Comparable comparable7 = multiplePiePlot3.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "Other" + "'", comparable7.equals("Other"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.util.Locale locale1 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker4.setStartValue(1.0d);
        java.awt.Paint paint7 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker4.setLabelPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = intervalMarker4.getLabelOffset();
        double double11 = rectangleInsets9.trimWidth(0.2d);
        java.lang.Class<?> wildcardClass12 = rectangleInsets9.getClass();
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
        try {
            java.util.ResourceBundle resourceBundle14 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", locale1, classLoader13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-5.8d) + "'", double11 == (-5.8d));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(classLoader13);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) (-16777216));
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange9, (double) (short) -1);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range14, (double) 31);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setYOffset((double) (short) 100);
        double double3 = lineRenderer3D0.getYOffset();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            lineRenderer3D0.drawBackground(graphics2D4, categoryPlot5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) multiplePiePlot7);
        java.awt.Paint paint9 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        numberAxis1.setAutoRangeMinimumSize((double) 3600000L);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.setHeight((double) (short) -1);
        textTitle8.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        textTitle8.setPadding(rectangleInsets16);
        textTitle0.setMargin(rectangleInsets16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = null;
        try {
            textTitle0.setTextAlignment(horizontalAlignment21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeStickyZero(true);
        numberAxis2.setTickLabelsVisible(false);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis2.setLabelFont(font7);
        numberAxis2.setVisible(false);
        float float11 = numberAxis2.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.axis.AxisState axisState18 = numberAxis2.draw(graphics2D12, (double) 1, rectangle2D14, rectangle2D15, rectangleEdge16, plotRenderingInfo17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeStickyZero(true);
        java.awt.Paint paint26 = numberAxis23.getLabelPaint();
        xYPlot21.setQuadrantPaint(0, paint26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot21.setDataset(xYDataset28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        xYPlot21.setRangeAxis((int) '4', valueAxis31, false);
        java.awt.Paint[] paintArray34 = null;
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray38 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray34, paintArray35, strokeArray36, strokeArray37, shapeArray38);
        xYPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = xYPlot21.getLegendItems();
        java.awt.Paint paint42 = xYPlot21.getRangeCrosshairPaint();
        boxAndWhiskerRenderer0.setBaseItemLabelPaint(paint42, false);
        java.awt.Shape shape45 = boxAndWhiskerRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(axisState18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(legendItemCollection41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.axis.TickUnit tickUnit2 = null;
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getLargerTickUnit(tickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        int int29 = xYPlot20.getDomainAxisCount();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        ringPlot0.setSectionDepth((double) '4');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        int int7 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        java.awt.Color color9 = java.awt.Color.WHITE;
        java.awt.Color color10 = color9.darker();
        multiplePiePlot8.setAggregatedItemsPaint((java.awt.Paint) color10);
        boolean boolean12 = ringPlot0.equals((java.lang.Object) multiplePiePlot8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNull(pieURLGenerator14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeStickyZero(true);
        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
        boolean boolean29 = textLine3.equals((java.lang.Object) legendItem28);
        legendItem28.setDatasetIndex((int) '#');
        java.awt.Shape shape32 = legendItem28.getLine();
        int int33 = legendItem28.getSeriesIndex();
        java.text.AttributedString attributedString34 = legendItem28.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset35 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem28.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset35);
        org.jfree.data.Range range37 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset35);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset35);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(attributedString34);
        org.junit.Assert.assertNull(range37);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        java.lang.String str3 = licences0.getGPL();
        java.lang.String str4 = licences0.getGPL();
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalLineAndShapeRenderer4.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer4.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalLineAndShapeRenderer4.getLegendItemLabelGenerator();
        boolean boolean11 = statisticalLineAndShapeRenderer4.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.clone(shape20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeStickyZero(true);
        java.awt.Paint paint26 = numberAxis23.getLabelPaint();
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint36 = polarPlot35.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape20, true, paint26, false, paint28, stroke29, true, shape33, stroke34, paint36);
        statisticalLineAndShapeRenderer4.setSeriesPaint((int) ' ', paint28, true);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        textTitle40.setHeight((double) (short) -1);
        textTitle40.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle40);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle40.setPosition(rectangleEdge46);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        textTitle48.setHeight((double) (short) -1);
        textTitle48.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle();
        textTitle56.setHeight((double) (short) -1);
        textTitle56.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType65 = rectangleInsets64.getUnitType();
        textTitle56.setPadding(rectangleInsets64);
        textTitle48.setMargin(rectangleInsets64);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment68 = textTitle48.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment69 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis();
        numberAxis70.setLowerBound((double) 100L);
        boolean boolean73 = verticalAlignment69.equals((java.lang.Object) numberAxis70);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation76 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis();
        numberAxis77.setRange((double) (short) 10, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = numberAxis77.getLabelInsets();
        boolean boolean82 = meanAndStandardDeviation76.equals((java.lang.Object) rectangleInsets81);
        org.jfree.chart.title.TextTitle textTitle83 = new org.jfree.chart.title.TextTitle("({0}, {1}) = {3} - {4}", font1, paint28, rectangleEdge46, horizontalAlignment68, verticalAlignment69, rectangleInsets81);
        textTitle83.setID("Other");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(unitType65);
        org.junit.Assert.assertNotNull(horizontalAlignment68);
        org.junit.Assert.assertNotNull(verticalAlignment69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(rectangleInsets81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        int int2 = stackedAreaRenderer1.getPassCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection3);
        int int5 = taskSeriesCollection3.getRowCount();
        org.jfree.data.Range range6 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (byte) 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeStickyZero(true);
        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
        groupedStackedBarRenderer3.setBaseStroke(stroke25);
        polarPlot1.setRadiusGridlineStroke(stroke25);
        java.awt.Stroke stroke31 = polarPlot1.getRadiusGridlineStroke();
        int int32 = dateTickUnit0.compareTo((java.lang.Object) polarPlot1);
        java.awt.Paint paint33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        polarPlot1.setOutlinePaint(paint33);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = polarPlot1.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        polarPlot1.setDataset(xYDataset36);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(plotOrientation35);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        textTitle0.setToolTipText("VerticalAlignment.BOTTOM");
        textTitle0.setToolTipText("");
        textTitle0.setWidth(0.25d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Color color0 = java.awt.Color.GREEN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = java.awt.Color.YELLOW;
        stackedBarRenderer3D0.setWallPaint((java.awt.Paint) color1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setAutoRangeStickyZero(true);
        numberAxis4.setTickLabelsVisible(false);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis4.setLabelFont(font9);
        numberAxis4.setVisible(false);
        float float13 = numberAxis4.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.axis.AxisState axisState20 = numberAxis4.draw(graphics2D14, (double) 1, rectangle2D16, rectangle2D17, rectangleEdge18, plotRenderingInfo19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis21, xYItemRenderer22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setAutoRangeStickyZero(true);
        java.awt.Paint paint28 = numberAxis25.getLabelPaint();
        xYPlot23.setQuadrantPaint(0, paint28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot23.setDataset(xYDataset30);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        xYPlot23.setRangeAxis((int) '4', valueAxis33, false);
        java.awt.Paint[] paintArray36 = null;
        java.awt.Paint[] paintArray37 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray39 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray40 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray37, strokeArray38, strokeArray39, shapeArray40);
        xYPlot23.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier41);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = xYPlot23.getLegendItems();
        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot23.setRangeTickBandPaint(paint44);
        stackedBarRenderer3D0.setWallPaint(paint44);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNotNull(axisState20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertNotNull(shapeArray40);
        org.junit.Assert.assertNotNull(legendItemCollection43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor4, categoryLabelWidthType5, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = categoryLabelPosition7.getCategoryAnchor();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        polarPlot9.removeChangeListener(plotChangeListener10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        polarPlot9.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        polarPlot9.setRenderer(polarItemRenderer14);
        boolean boolean16 = rectangleAnchor8.equals((java.lang.Object) polarPlot9);
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.05d, 4.0d, rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setSeparatorPaint(paint3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        ringPlot0.removeChangeListener(plotChangeListener5);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        groupedStackedBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        groupedStackedBarRenderer0.setSeriesItemLabelGenerator(11, categoryItemLabelGenerator8, false);
        groupedStackedBarRenderer0.setMaximumBarWidth((double) (byte) 1);
        boolean boolean14 = groupedStackedBarRenderer0.isSeriesVisibleInLegend(0);
        groupedStackedBarRenderer0.setItemLabelAnchorOffset((double) (-16777216));
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Paint paint4 = numberAxis1.getLabelPaint();
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean1 = intervalBarRenderer0.getBaseItemLabelsVisible();
        intervalBarRenderer0.setBaseCreateEntities(true, true);
        double double5 = intervalBarRenderer0.getLowerClip();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        xYPlot20.clearDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection23 = xYPlot20.getRangeMarkers(layer22);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.lang.String str2 = dateTickMarkPosition1.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickMarkPosition.START" + "'", str2.equals("DateTickMarkPosition.START"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setItemMargin((double) (-1L));
        boolean boolean3 = boxAndWhiskerRenderer0.getFillBox();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("UnitType.RELATIVE", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
        java.util.List list5 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) '#', (java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = rectangleConstraint0.getHeightRange();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        groupedStackedBarRenderer1.drawRangeGridline(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis4, rectangle2D7, (double) 0);
        groupedStackedBarRenderer1.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer1.setSeriesItemLabelFont((int) (short) 1, font15, false);
        java.awt.Paint paint18 = null;
        try {
            org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("({0}, {1}) = {3} - {4}", font15, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        java.lang.String str3 = licences0.getGPL();
        java.lang.String str4 = licences0.getLGPL();
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, (org.jfree.data.Range) dateRange11);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange8);
        java.awt.Paint paint15 = numberAxis0.getLabelPaint();
        numberAxis0.setFixedAutoRange((-1.0d));
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot20.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart41 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent44 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) legendItemCollection40, jFreeChart41, 0, 5);
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.clone(shape54);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        numberAxis57.setAutoRangeStickyZero(true);
        java.awt.Paint paint60 = numberAxis57.getLabelPaint();
        java.awt.Paint paint62 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke63 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape67 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke68 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot69 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint70 = polarPlot69.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape54, true, paint60, false, paint62, stroke63, true, shape67, stroke68, paint70);
        boolean boolean72 = textLine46.equals((java.lang.Object) legendItem71);
        legendItem71.setDatasetIndex((int) '#');
        java.awt.Shape shape75 = legendItem71.getLine();
        int int76 = legendItem71.getSeriesIndex();
        java.text.AttributedString attributedString77 = legendItem71.getAttributedLabel();
        java.lang.String str78 = legendItem71.getDescription();
        legendItemCollection40.add(legendItem71);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNull(attributedString77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "({0}, {1}) = {2}" + "'", str78.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.time.TimePeriod timePeriod2 = null;
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod2);
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod5);
        task3.removeSubtask(task6);
        task6.setDescription("ItemLabelAnchor.INSIDE9");
        keyedObjects2D0.addObject((java.lang.Object) "ItemLabelAnchor.INSIDE9", (java.lang.Comparable) 100.0d, (java.lang.Comparable) "UnitType.ABSOLUTE");
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        boolean boolean14 = segmentedTimeline3.containsDomainRange((long) '#', (long) (byte) 100);
        segmentedTimeline3.setStartTime((-1L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RangeType.POSITIVE", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        dateAxis1.setDownArrow(shape5);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis1.getTickMarkPosition();
        boolean boolean9 = taskSeriesCollection0.equals((java.lang.Object) dateAxis1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1900);
        int int3 = objectList1.indexOf((java.lang.Object) "-3,-3,3,3");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D1.setUpperMargin((double) 0.0f);
        int int4 = categoryAxis3D1.getMaximumCategoryLabelLines();
        categoryAxis3D1.setLowerMargin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        groupedStackedBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        groupedStackedBarRenderer0.setSeriesItemLabelGenerator(11, categoryItemLabelGenerator8, false);
        groupedStackedBarRenderer0.setMaximumBarWidth((double) (byte) 1);
        int int13 = groupedStackedBarRenderer0.getRowCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine1.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        java.lang.Object obj9 = statisticalLineAndShapeRenderer2.clone();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        xYPlot0.setRangeGridlineStroke(stroke17);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        groupedStackedBarRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.plot.Marker) intervalMarker13, rectangle2D14);
        intervalMarker13.setStartValue(0.25d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        intervalMarker13.notifyListeners(markerChangeEvent18);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomOutset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker2.getLabelOffsetType();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        intervalMarker2.setLabelTextAnchor(textAnchor11);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setUpperBound(4.0d);
        boolean boolean5 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        boolean boolean11 = numberAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
        try {
            defaultCategoryDataset0.removeColumn((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        java.awt.Color color6 = java.awt.Color.MAGENTA;
        boolean boolean7 = textTitle0.equals((java.lang.Object) color6);
        java.awt.color.ColorSpace colorSpace8 = color6.getColorSpace();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(colorSpace8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryAnchor0.equals(obj1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = categoryAnchor0.equals((java.lang.Object) dateTickUnit3);
        java.lang.String str5 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CategoryAnchor.END" + "'", str5.equals("CategoryAnchor.END"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLowerBound((double) 100L);
        boolean boolean7 = verticalAlignment3.equals((java.lang.Object) numberAxis4);
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) boolean7);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        java.lang.Object obj3 = blockContainer1.clone();
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder50 = xYPlot43.getSeriesRenderingOrder();
        xYPlot20.setSeriesRenderingOrder(seriesRenderingOrder50);
        org.jfree.chart.LegendItemCollection legendItemCollection52 = xYPlot20.getFixedLegendItems();
        xYPlot20.setDomainCrosshairValue((double) 100L, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = xYPlot20.getRenderer((int) (byte) 0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder50);
        org.junit.Assert.assertNull(legendItemCollection52);
        org.junit.Assert.assertNull(xYItemRenderer57);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        groupedStackedBarRenderer0.setBaseStroke(stroke22);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection27 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        taskSeriesCollection27.validateObject();
        org.jfree.data.Range range30 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        groupedStackedBarRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0.0d + "'", number28.equals(0.0d));
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = polarPlot31.getInsets();
        polarPlot31.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint35 = polarPlot31.getRadiusGridlinePaint();
        java.awt.Stroke stroke36 = polarPlot31.getRadiusGridlineStroke();
        java.awt.Color color37 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape25, paint30, stroke36, (java.awt.Paint) color37);
        piePlot0.setLabelOutlineStroke(stroke36);
        piePlot0.setCircular(false, true);
        double double43 = piePlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setUpperBound(4.0d);
        java.awt.Shape shape5 = numberAxis0.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint7 = numberAxis6.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis6.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit8, false, false);
        numberAxis0.setLabel("");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset33);
        java.lang.String str35 = legendItem26.getDescription();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(attributedString32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "({0}, {1}) = {2}" + "'", str35.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        polarPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = polarPlot0.getOutlinePaint();
        polarPlot0.addCornerTextItem("CategoryAnchor.END");
        org.jfree.chart.LegendItemCollection legendItemCollection6 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.lang.Object obj2 = null;
        boolean boolean3 = legendItemCollection1.equals(obj2);
        java.util.Iterator iterator4 = legendItemCollection1.iterator();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setAutoRangeStickyZero(true);
        numberAxis6.setTickLabelsVisible(false);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis6.setLabelFont(font11);
        numberAxis6.setVisible(false);
        float float15 = numberAxis6.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.axis.AxisState axisState22 = numberAxis6.draw(graphics2D16, (double) 1, rectangle2D18, rectangle2D19, rectangleEdge20, plotRenderingInfo21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis6, valueAxis23, xYItemRenderer24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeStickyZero(true);
        java.awt.Paint paint30 = numberAxis27.getLabelPaint();
        xYPlot25.setQuadrantPaint(0, paint30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot25.setDataset(xYDataset32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        xYPlot25.setRangeAxis((int) '4', valueAxis35, false);
        java.awt.Paint[] paintArray38 = null;
        java.awt.Paint[] paintArray39 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray38, paintArray39, strokeArray40, strokeArray41, shapeArray42);
        xYPlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = xYPlot25.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart46 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent49 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) legendItemCollection45, jFreeChart46, 0, 5);
        legendItemCollection1.addAll(legendItemCollection45);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iterator4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertNotNull(axisState22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paintArray39);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNotNull(legendItemCollection45);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 1.0d, (java.lang.Number) (-1));
        java.lang.Number number3 = null;
        defaultKeyedValue2.setValue(number3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot20.setDataset((int) (short) 10, xYDataset30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = xYPlot20.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = groupedStackedBarRenderer33.getToolTipGenerator(0, 0);
        boolean boolean37 = groupedStackedBarRenderer33.isDrawBarOutline();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        dateAxis40.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        groupedStackedBarRenderer33.drawRangeMarker(graphics2D38, categoryPlot39, (org.jfree.chart.axis.ValueAxis) dateAxis40, (org.jfree.chart.plot.Marker) intervalMarker46, rectangle2D47);
        double double49 = dateAxis40.getUpperBound();
        int int50 = xYPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = polarPlot31.getInsets();
        polarPlot31.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint35 = polarPlot31.getRadiusGridlinePaint();
        java.awt.Stroke stroke36 = polarPlot31.getRadiusGridlineStroke();
        java.awt.Color color37 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape25, paint30, stroke36, (java.awt.Paint) color37);
        piePlot0.setLabelOutlineStroke(stroke36);
        piePlot0.setCircular(false, true);
        java.awt.Paint paint43 = null;
        piePlot0.setBackgroundPaint(paint43);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator45 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator45);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor47 = piePlot0.getLabelDistributor();
        piePlot0.setShadowXOffset(0.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor47);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        java.awt.Paint paint3 = numberAxis0.getLabelPaint();
        numberAxis0.setFixedDimension(0.0d);
        numberAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(11, (double) '#');
        layeredBarRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Paint paint9 = layeredBarRenderer0.getItemPaint((int) (byte) 0, 31);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str3 = verticalAlignment2.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        boolean boolean9 = legendTitle8.getNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateRightOutset(0.0d);
        legendTitle8.setLegendItemGraphicPadding(rectangleInsets10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor15);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str3.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot20.addChangeListener(plotChangeListener27);
        int int29 = xYPlot20.getDatasetCount();
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection31);
        int int33 = taskSeriesCollection31.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection31);
        java.awt.Paint paint35 = multiplePiePlot34.getAggregatedItemsPaint();
        boolean boolean36 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color30, paint35);
        xYPlot20.setDomainTickBandPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        ringPlot0.setSectionDepth((double) '4');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        int int7 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        java.awt.Color color9 = java.awt.Color.WHITE;
        java.awt.Color color10 = color9.darker();
        multiplePiePlot8.setAggregatedItemsPaint((java.awt.Paint) color10);
        boolean boolean12 = ringPlot0.equals((java.lang.Object) multiplePiePlot8);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot0.setLabelLinkStroke(stroke13);
        java.lang.Object obj15 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        double double3 = numberAxis0.getFixedAutoRange();
        numberAxis0.setFixedAutoRange((double) (short) -1);
        numberAxis0.setTickMarkInsideLength((float) 86400000L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor5, textAnchor6, (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2019, "RangeType.POSITIVE", textAnchor6, textAnchor9, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor12 = numberTick11.getRotationAnchor();
        java.lang.Object obj13 = numberTick11.clone();
        int int14 = month0.compareTo((java.lang.Object) numberTick11);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        java.lang.Boolean boolean4 = statisticalLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 0);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = groupedStackedBarRenderer34.getToolTipGenerator(0, 0);
        boolean boolean38 = groupedStackedBarRenderer34.isDrawBarOutline();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        groupedStackedBarRenderer34.drawRangeMarker(graphics2D39, categoryPlot40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.plot.Marker) intervalMarker47, rectangle2D48);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        xYPlot20.setRangeGridlinesVisible(true);
        xYPlot20.clearDomainMarkers((int) (short) 1);
        java.awt.Stroke stroke55 = xYPlot20.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = groupedStackedBarRenderer0.getPlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, (double) (short) 10, (double) (-16777216));
        groupedStackedBarRenderer0.setSeriesShape((int) (short) 10, shape18);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        int int4 = segmentedTimeline3.getSegmentsIncluded();
        int int5 = segmentedTimeline3.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = statisticalLineAndShapeRenderer2.getPlot();
        double double12 = statisticalLineAndShapeRenderer2.getItemLabelAnchorOffset();
        boolean boolean13 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str3 = verticalAlignment2.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        boolean boolean9 = legendTitle8.getNotify();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        numberAxis11.setTickLabelsVisible(false);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis11.setLabelFont(font16);
        numberAxis11.setVisible(false);
        float float20 = numberAxis11.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.axis.AxisState axisState27 = numberAxis11.draw(graphics2D21, (double) 1, rectangle2D23, rectangle2D24, rectangleEdge25, plotRenderingInfo26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis11, valueAxis28, xYItemRenderer29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeStickyZero(true);
        java.awt.Paint paint35 = numberAxis32.getLabelPaint();
        xYPlot30.setQuadrantPaint(0, paint35);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder37 = xYPlot30.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot30.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot30.getFixedLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot30.setRenderers(xYItemRendererArray41);
        legendTitle8.setSources((org.jfree.chart.LegendItemSource[]) xYItemRendererArray41);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str3.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNotNull(axisState27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(seriesRenderingOrder37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(xYItemRendererArray41);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str3 = verticalAlignment2.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        boolean boolean9 = legendTitle8.getNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getItemLabelPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            rectangleInsets10.trim(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str3.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getTransparency();
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, (org.jfree.data.Range) dateRange11);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange8);
        double double15 = dateRange8.getLength();
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker2.getLabelOffsetType();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick17 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor14, textAnchor15, (double) (short) 100);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean19 = intervalBarRenderer18.getBaseItemLabelsVisible();
        boolean boolean20 = numberTick17.equals((java.lang.Object) boolean19);
        org.jfree.chart.text.TextAnchor textAnchor21 = numberTick17.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor21);
        intervalMarker2.setLabelTextAnchor(textAnchor21);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker26.setStartValue(1.0d);
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker26.setLabelPaint(paint29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = intervalMarker26.getLabelOffset();
        intervalMarker26.setEndValue(0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = intervalMarker26.getLabelOffsetType();
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType34);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        boolean boolean3 = jFreeChart2.isBorderVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "CategoryAnchor.END", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        java.lang.Object obj7 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        try {
            taskSeriesCollection0.remove((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange5);
        java.lang.String str7 = rectangleConstraint6.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toFixedWidth((double) 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str7.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge2);
        axisSpace0.add((double) (byte) 1, rectangleEdge2);
        axisSpace0.setBottom((double) 10L);
        java.lang.String str7 = axisSpace0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        boolean boolean11 = lengthConstraintType9.equals((java.lang.Object) standardCategoryURLGenerator10);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange18);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, (org.jfree.data.Range) dateRange25);
        java.lang.String str27 = rectangleConstraint26.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = rectangleConstraint26.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) 5, range8, lengthConstraintType9, (double) 11, (org.jfree.data.Range) dateRange15, lengthConstraintType28);
        java.lang.Class<?> wildcardClass30 = lengthConstraintType9.getClass();
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str27.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setMaximumBarWidth((double) 11L);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = groupedStackedBarRenderer0.getBaseToolTipGenerator();
        java.awt.Color color13 = java.awt.Color.blue;
        groupedStackedBarRenderer0.setSeriesItemLabelPaint(100, (java.awt.Paint) color13);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean3 = areaRendererEndType0.equals((java.lang.Object) numberAxis2);
        java.lang.String str4 = areaRendererEndType0.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean6 = areaRendererEndType0.equals((java.lang.Object) itemLabelAnchor5);
        java.lang.Object obj7 = null;
        boolean boolean8 = areaRendererEndType0.equals(obj7);
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AreaRendererEndType.LEVEL" + "'", str4.equals("AreaRendererEndType.LEVEL"));
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        groupedStackedBarRenderer0.setBaseStroke(stroke22);
        groupedStackedBarRenderer0.setSeriesVisible(31, (java.lang.Boolean) false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean32 = groupedStackedBarRenderer0.equals((java.lang.Object) "ThreadContext");
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = groupedStackedBarRenderer0.getToolTipGenerator((int) (byte) 1, 2);
        groupedStackedBarRenderer0.setItemMargin(100.0d);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator38 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        groupedStackedBarRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator38);
        boolean boolean40 = groupedStackedBarRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainZoomable();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot0.setDomainGridlinePaint(paint2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D70 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D72 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D72.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int76 = dateTickUnit75.getCount();
        categoryAxis3D72.removeCategoryLabelToolTip((java.lang.Comparable) int76);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D79 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray80 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D70, categoryAxis3D72, categoryAxis3D79 };
        categoryPlot67.setDomainAxes(categoryAxisArray80);
        int int82 = categoryPlot67.getDomainAxisCount();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer83 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D84 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = null;
        org.jfree.chart.axis.NumberAxis numberAxis86 = new org.jfree.chart.axis.NumberAxis();
        numberAxis86.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        groupedStackedBarRenderer83.drawRangeGridline(graphics2D84, categoryPlot85, (org.jfree.chart.axis.ValueAxis) numberAxis86, rectangle2D89, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier92 = groupedStackedBarRenderer83.getDrawingSupplier();
        java.awt.Stroke stroke95 = groupedStackedBarRenderer83.getItemStroke(0, 2);
        categoryPlot67.setDomainGridlineStroke(stroke95);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNotNull(dateTickUnit75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 3 + "'", int82 == 3);
        org.junit.Assert.assertNull(drawingSupplier92);
        org.junit.Assert.assertNotNull(stroke95);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeStickyZero(true);
        java.awt.Paint paint13 = numberAxis10.getLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint23 = polarPlot22.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape7, true, paint13, false, paint15, stroke16, true, shape20, stroke21, paint23);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj26 = standardGradientPaintTransformer25.clone();
        legendItem24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.awt.GradientPaint gradientPaint28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.clone(shape38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setAutoRangeStickyZero(true);
        java.awt.Paint paint44 = numberAxis41.getLabelPaint();
        java.awt.Paint paint46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint54 = polarPlot53.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape38, true, paint44, false, paint46, stroke47, true, shape51, stroke52, paint54);
        numberAxis30.setUpArrow(shape51);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape51, (-21.0d), 0.0f, (float) 3600000L);
        try {
            java.awt.GradientPaint gradientPaint61 = standardGradientPaintTransformer25.transform(gradientPaint28, shape60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(shape60);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D70 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D72 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D72.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int76 = dateTickUnit75.getCount();
        categoryAxis3D72.removeCategoryLabelToolTip((java.lang.Comparable) int76);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D79 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray80 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D70, categoryAxis3D72, categoryAxis3D79 };
        categoryPlot67.setDomainAxes(categoryAxisArray80);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        categoryPlot67.setRenderer(categoryItemRenderer82);
        org.jfree.chart.axis.AxisLocation axisLocation85 = categoryPlot67.getRangeAxisLocation(1900);
        org.jfree.chart.axis.ValueAxis valueAxis87 = categoryPlot67.getRangeAxisForDataset((int) (short) 100);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNotNull(dateTickUnit75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray80);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertNotNull(valueAxis87);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLowerBound((double) 100L);
        double double7 = numberAxis4.getAutoRangeMinimumSize();
        java.awt.Shape shape8 = numberAxis4.getUpArrow();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        piePlot10.setLabelLinkPaint(paint26);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot10.setBaseSectionOutlineStroke(stroke37);
        java.awt.Color color39 = java.awt.Color.YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "SerialDate.weekInMonthToString(): invalid code.", "", shape8, (java.awt.Paint) color9, stroke37, (java.awt.Paint) color39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-8d + "'", double7 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        java.lang.String str31 = legendItem26.getDescription();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "({0}, {1}) = {2}" + "'", str31.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNull(attributedString32);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getCount();
        int int2 = dateTickUnit0.getCount();
        int int3 = dateTickUnit0.getRollUnit();
        java.lang.String str4 = dateTickUnit0.toString();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str4.equals("DateTickUnit[DAY, 1]"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 10, true);
        java.lang.Object obj43 = null;
        boolean boolean44 = statisticalLineAndShapeRenderer2.equals(obj43);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D70 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D72 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D72.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int76 = dateTickUnit75.getCount();
        categoryAxis3D72.removeCategoryLabelToolTip((java.lang.Comparable) int76);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D79 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray80 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D70, categoryAxis3D72, categoryAxis3D79 };
        categoryPlot67.setDomainAxes(categoryAxisArray80);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        categoryPlot67.setRenderer(categoryItemRenderer82);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray84 = null;
        try {
            categoryPlot67.setRangeAxes(valueAxisArray84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNotNull(dateTickUnit75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray80);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.setHeight((double) (short) -1);
        textTitle8.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        textTitle8.setPadding(rectangleInsets16);
        textTitle0.setMargin(rectangleInsets16);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) "VerticalAlignment.BOTTOM", (java.lang.Object) polarPlot1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        int int3 = taskSeriesCollection0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setForegroundAlpha(0.0f);
        ringPlot3.setSectionDepth((double) '4');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection8);
        int int10 = taskSeriesCollection8.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection8);
        java.awt.Color color12 = java.awt.Color.WHITE;
        java.awt.Color color13 = color12.darker();
        multiplePiePlot11.setAggregatedItemsPaint((java.awt.Paint) color13);
        boolean boolean15 = ringPlot3.equals((java.lang.Object) multiplePiePlot11);
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot3.setLabelLinkStroke(stroke16);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone(shape25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        java.awt.Paint paint31 = numberAxis28.getLabelPaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint41 = polarPlot40.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape25, true, paint31, false, paint33, stroke34, true, shape38, stroke39, paint41);
        java.awt.Stroke stroke43 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) (-1.0f), (java.awt.Paint) color2, stroke16, paint41, stroke43, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0d + "'", number9.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        boolean boolean18 = groupedStackedBarRenderer0.equals((java.lang.Object) '4');
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeStickyZero(true);
        numberAxis19.setTickLabelsVisible(false);
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis19.setLabelFont(font24);
        groupedStackedBarRenderer0.setBaseItemLabelFont(font24);
        double double27 = groupedStackedBarRenderer0.getUpperClip();
        java.awt.Paint paint28 = groupedStackedBarRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        int int4 = taskSeriesCollection0.indexOf((java.lang.Comparable) "({0}, {1}) = {2}");
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setInfo("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image13, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo17.setCopyright("VerticalAlignment.BOTTOM");
        projectInfo17.setVersion("ThreadContext");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex(comparable2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 6, 52.0d, (double) 255, (double) 1559372400000L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle0.setPosition(rectangleEdge6);
        java.lang.Object obj8 = textTitle0.clone();
        textTitle0.setID("ItemLabelAnchor.INSIDE9");
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        java.awt.Paint paint3 = stackedBarRenderer1.getSeriesItemLabelPaint((int) 'a');
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getBaseItemLabelPaint();
        int int12 = statisticalLineAndShapeRenderer2.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) ' ');
        org.jfree.chart.LegendItem legendItem17 = statisticalLineAndShapeRenderer2.getLegendItem((int) (byte) 10, (int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(1);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = java.awt.Color.YELLOW;
        stackedBarRenderer3D0.setWallPaint((java.awt.Paint) color1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color3);
        stackedBarRenderer3D0.setRenderAsPercentages(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = null;
        try {
            statisticalBarRenderer0.setBaseOutlinePaint(paint1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        xYPlot20.clearDomainAxes();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone(shape30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeStickyZero(true);
        java.awt.Paint paint36 = numberAxis33.getLabelPaint();
        java.awt.Paint paint38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint46 = polarPlot45.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape30, true, paint36, false, paint38, stroke39, true, shape43, stroke44, paint46);
        piePlot22.setLabelLinkPaint(paint38);
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot22.setBaseSectionOutlineStroke(stroke49);
        java.awt.Paint paint51 = piePlot22.getLabelShadowPaint();
        xYPlot20.setRangeCrosshairPaint(paint51);
        int int53 = xYPlot20.getDatasetCount();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        xYPlot20.clearRangeMarkers();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        dateAxis0.setLabelURL("TextAnchor.BASELINE_CENTER");
        dateAxis0.setFixedDimension((double) 1.0f);
        org.jfree.chart.axis.Timeline timeline12 = dateAxis0.getTimeline();
        dateAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(timeline12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalLineAndShapeRenderer4.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer4.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalLineAndShapeRenderer4.getLegendItemLabelGenerator();
        boolean boolean11 = statisticalLineAndShapeRenderer4.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = statisticalLineAndShapeRenderer4.getDrawingSupplier();
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer4.getBaseItemLabelPaint();
        int int14 = statisticalLineAndShapeRenderer4.getRowCount();
        boolean boolean15 = lineRenderer3D0.equals((java.lang.Object) int14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = lineRenderer3D0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(drawingSupplier16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeStickyZero(true);
        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = polarPlot30.getInsets();
        polarPlot30.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint34 = polarPlot30.getRadiusGridlinePaint();
        java.awt.Stroke stroke35 = polarPlot30.getRadiusGridlineStroke();
        java.awt.Color color36 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape24, paint29, stroke35, (java.awt.Paint) color36);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection40 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection40);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection40);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint44 = numberAxis43.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit45 = numberAxis43.getTickUnit();
        java.lang.String str47 = numberTickUnit45.valueToString(3.0d);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity49 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "ERROR : Relative To String", "VerticalAlignment.BOTTOM", (org.jfree.data.category.CategoryDataset) taskSeriesCollection40, (java.lang.Comparable) str47, (java.lang.Comparable) (-1));
        java.lang.String str50 = categoryItemEntity49.getShapeType();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.0d + "'", number41.equals(0.0d));
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(numberTickUnit45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "3" + "'", str47.equals("3"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "poly" + "'", str50.equals("poly"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        numberAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        ringPlot23.setStartAngle((double) 0.0f);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot23);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D1.setUpperMargin((double) 0.0f);
        categoryAxis3D1.setCategoryMargin((double) 1L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getFirstBarPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        dateAxis2.setDownArrow(shape6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis2.getTickMarkPosition();
        dateAxis2.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape12 = dateAxis2.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int16 = dateTickUnit15.getCount();
        dateAxis13.setTickUnit(dateTickUnit15, true, false);
        java.util.Date date20 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit15);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        boolean boolean22 = segmentedTimeline0.containsDomainValue(date20);
        long long23 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 604800000L + "'", long23 == 604800000L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        piePlot0.setLabelLinkPaint(paint16);
        double double27 = piePlot0.getLabelLinkMargin();
        piePlot0.setExplodePercent((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (double) 86400000L);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color31);
        org.jfree.chart.util.Rotation rotation33 = piePlot0.getDirection();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rotation33);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle0.setPosition(rectangleEdge6);
        java.lang.Object obj8 = textTitle0.clone();
        double double9 = textTitle0.getContentYOffset();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.setHeight((double) (short) -1);
        textTitle8.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        textTitle8.setPadding(rectangleInsets16);
        textTitle0.setMargin(rectangleInsets16);
        textTitle0.setNotify(true);
        double double22 = textTitle0.getContentXOffset();
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getRowKeys();
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 0, 2019, (int) (short) 100, 0, dateFormat6);
        int int8 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) dateTickUnit7);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer9 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setAutoRangeStickyZero(true);
        java.awt.Paint paint23 = numberAxis20.getLabelPaint();
        java.awt.Paint paint25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint33 = polarPlot32.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape17, true, paint23, false, paint25, stroke26, true, shape30, stroke31, paint33);
        groupedStackedBarRenderer9.setBaseStroke(stroke31);
        boolean boolean36 = defaultKeyedValues2D0.equals((java.lang.Object) stroke31);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot20.getDomainAxisForDataset(0);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLowerBound((double) 100L);
        double double29 = numberAxis26.getAutoRangeMinimumSize();
        xYPlot20.setDomainAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        numberAxis26.setFixedDimension(0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0E-8d + "'", double29 == 1.0E-8d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("SerialDate.weekInMonthToString(): invalid code.", font2);
        java.lang.Object obj4 = null;
        centerArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj4);
        java.lang.String str6 = textTitle3.getURLText();
        java.lang.String str7 = textTitle3.getToolTipText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        xYPlot20.setRangeCrosshairValue((double) (byte) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = xYPlot20.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot20.setDataset(xYDataset37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        xYPlot20.drawAnnotations(graphics2D39, rectangle2D40, plotRenderingInfo41);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer43 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        numberAxis45.setTickLabelsVisible(false);
        java.awt.Font font50 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis45.setLabelFont(font50);
        numberAxis45.setVisible(false);
        float float54 = numberAxis45.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        org.jfree.chart.axis.AxisState axisState61 = numberAxis45.draw(graphics2D55, (double) 1, rectangle2D57, rectangle2D58, rectangleEdge59, plotRenderingInfo60);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis45, valueAxis62, xYItemRenderer63);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        numberAxis66.setAutoRangeStickyZero(true);
        java.awt.Paint paint69 = numberAxis66.getLabelPaint();
        xYPlot64.setQuadrantPaint(0, paint69);
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        xYPlot64.setDataset(xYDataset71);
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        xYPlot64.setRangeAxis((int) '4', valueAxis74, false);
        java.awt.Paint[] paintArray77 = null;
        java.awt.Paint[] paintArray78 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray79 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray80 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray81 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier82 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray77, paintArray78, strokeArray79, strokeArray80, shapeArray81);
        xYPlot64.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier82);
        org.jfree.chart.LegendItemCollection legendItemCollection84 = xYPlot64.getLegendItems();
        java.awt.Paint paint85 = xYPlot64.getRangeCrosshairPaint();
        boxAndWhiskerRenderer43.setBaseItemLabelPaint(paint85, false);
        xYPlot20.setOutlinePaint(paint85);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNotNull(axisState61);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(paintArray78);
        org.junit.Assert.assertNotNull(strokeArray79);
        org.junit.Assert.assertNotNull(strokeArray80);
        org.junit.Assert.assertNotNull(shapeArray81);
        org.junit.Assert.assertNotNull(legendItemCollection84);
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((double) (-16777216), (java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (java.lang.Comparable) "-3,-3,3,3");
        java.util.List list5 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        long long2 = month1.getLastMillisecond();
//        int int3 = month1.getYearValue();
//        boolean boolean5 = month1.equals((java.lang.Object) "AreaRendererEndType.LEVEL");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset6.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
//        java.util.List list11 = defaultCategoryDataset6.getColumnKeys();
//        int int12 = month1.compareTo((java.lang.Object) defaultCategoryDataset6);
//        try {
//            java.lang.String str14 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        textTitle0.setToolTipText("VerticalAlignment.BOTTOM");
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalLineAndShapeRenderer12.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer12.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = statisticalLineAndShapeRenderer12.getLegendItemLabelGenerator();
        boolean boolean19 = statisticalLineAndShapeRenderer12.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.clone(shape28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeStickyZero(true);
        java.awt.Paint paint34 = numberAxis31.getLabelPaint();
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint44 = polarPlot43.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape28, true, paint34, false, paint36, stroke37, true, shape41, stroke42, paint44);
        statisticalLineAndShapeRenderer12.setSeriesPaint((int) ' ', paint36, true);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        textTitle48.setHeight((double) (short) -1);
        textTitle48.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle48);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle48.setPosition(rectangleEdge54);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle();
        textTitle56.setHeight((double) (short) -1);
        textTitle56.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle();
        textTitle64.setHeight((double) (short) -1);
        textTitle64.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType73 = rectangleInsets72.getUnitType();
        textTitle64.setPadding(rectangleInsets72);
        textTitle56.setMargin(rectangleInsets72);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment76 = textTitle56.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment77 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis();
        numberAxis78.setLowerBound((double) 100L);
        boolean boolean81 = verticalAlignment77.equals((java.lang.Object) numberAxis78);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation84 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        org.jfree.chart.axis.NumberAxis numberAxis85 = new org.jfree.chart.axis.NumberAxis();
        numberAxis85.setRange((double) (short) 10, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets89 = numberAxis85.getLabelInsets();
        boolean boolean90 = meanAndStandardDeviation84.equals((java.lang.Object) rectangleInsets89);
        org.jfree.chart.title.TextTitle textTitle91 = new org.jfree.chart.title.TextTitle("({0}, {1}) = {3} - {4}", font9, paint36, rectangleEdge54, horizontalAlignment76, verticalAlignment77, rectangleInsets89);
        textTitle0.setHorizontalAlignment(horizontalAlignment76);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(unitType73);
        org.junit.Assert.assertNotNull(horizontalAlignment76);
        org.junit.Assert.assertNotNull(verticalAlignment77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(rectangleInsets89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition21 = dateAxis20.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int23 = dateTickUnit22.getCount();
        dateAxis20.setTickUnit(dateTickUnit22, true, false);
        java.util.Date date27 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit22);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition29 = dateAxis28.getTickMarkPosition();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.clone(shape32);
        dateAxis28.setDownArrow(shape32);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition35 = dateAxis28.getTickMarkPosition();
        dateAxis28.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape38 = dateAxis28.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition40 = dateAxis39.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int42 = dateTickUnit41.getCount();
        dateAxis39.setTickUnit(dateTickUnit41, true, false);
        java.util.Date date46 = dateAxis28.calculateLowestVisibleTickValue(dateTickUnit41);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.DateRange dateRange48 = new org.jfree.data.time.DateRange(date27, date46);
        dateAxis0.setMinimumDate(date27);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(dateTickMarkPosition21);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(dateTickMarkPosition29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(dateTickMarkPosition35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(dateTickMarkPosition40);
        org.junit.Assert.assertNotNull(dateTickUnit41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset33);
        org.jfree.data.Range range36 = defaultBoxAndWhiskerCategoryDataset33.getRangeBounds(false);
        double double38 = defaultBoxAndWhiskerCategoryDataset33.getRangeUpperBound(true);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset33);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(attributedString32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.0d + "'", number39.equals(0.0d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = groupedStackedBarRenderer0.getDrawingSupplier();
        java.awt.Stroke stroke12 = groupedStackedBarRenderer0.getItemStroke(0, 2);
        java.awt.Paint paint14 = groupedStackedBarRenderer0.lookupSeriesPaint(11);
        groupedStackedBarRenderer0.setBase((double) 5);
        org.junit.Assert.assertNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = groupedStackedBarRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(categoryURLGenerator17);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (int) '4');
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset6, (java.lang.Comparable) 12, (double) (-1), (int) ' ');
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset70 = categoryPlot67.getDataset(2019);
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = categoryPlot67.getDomainAxis();
        java.lang.Object obj72 = categoryAxis71.clone();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNull(categoryDataset70);
        org.junit.Assert.assertNotNull(categoryAxis71);
        org.junit.Assert.assertNotNull(obj72);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        java.awt.Paint paint6 = textFragment5.getPaint();
        float float7 = textFragment5.getBaselineOffset();
        textLine1.addFragment(textFragment5);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1561964399999L, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange5);
        java.lang.String str7 = rectangleConstraint6.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint6.toFixedHeight(0.0d);
        double double10 = rectangleConstraint9.getWidth();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str7.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        java.lang.String str10 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "({0}, {1}) = {2} version ThreadContext.\nVerticalAlignment.BOTTOM.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:None\n({0}, {1}) = {2} LICENCE TERMS:\nThreadContext" + "'", str10.equals("({0}, {1}) = {2} version ThreadContext.\nVerticalAlignment.BOTTOM.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ({0}, {1}) = {2}:None\n({0}, {1}) = {2} LICENCE TERMS:\nThreadContext"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        dateAxis2.setDownArrow(shape6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis2.getTickMarkPosition();
        dateAxis2.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape12 = dateAxis2.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int16 = dateTickUnit15.getCount();
        dateAxis13.setTickUnit(dateTickUnit15, true, false);
        java.util.Date date20 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit15);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        boolean boolean22 = segmentedTimeline0.containsDomainValue(date20);
        long long25 = segmentedTimeline0.getExceptionSegmentCount((long) 12, (long) 3);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot20.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart41 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent44 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) legendItemCollection40, jFreeChart41, 0, 5);
        chartProgressEvent44.setType(0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(legendItemCollection40);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisState1.moveCursor((double) 12, rectangleEdge3);
        axisState1.cursorUp((double) 3);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis3.getTickMarkPosition();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        dateAxis3.setDownArrow(shape7);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis3.getTickMarkPosition();
        dateAxis3.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape13 = dateAxis3.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis14.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int17 = dateTickUnit16.getCount();
        dateAxis14.setTickUnit(dateTickUnit16, true, false);
        java.util.Date date21 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit16);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        int int23 = spreadsheetDate2.compare(serialDate22);
        int int24 = keyedObjects2D0.getRowIndex((java.lang.Comparable) int23);
        try {
            java.lang.Comparable comparable26 = keyedObjects2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-23550) + "'", int23 == (-23550));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        xYPlot20.setRangeCrosshairVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYPlot20.rendererChanged(rendererChangeEvent35);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(2, 11, dateFormat2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Font font1 = boxAndWhiskerRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = numberAxis3D0.draw(graphics2D1, (double) 11L, rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (byte) 0);
        long long6 = segmentedTimeline3.getSegmentSize();
        long long8 = segmentedTimeline3.getTimeFromLong(0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker3.setStartValue(1.0d);
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker3.setLabelPaint(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = intervalMarker3.getLabelOffset();
        intervalMarker3.setEndValue(0.0d);
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = statisticalLineAndShapeRenderer15.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer15.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalLineAndShapeRenderer15.getLegendItemLabelGenerator();
        boolean boolean22 = statisticalLineAndShapeRenderer15.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.clone(shape31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setAutoRangeStickyZero(true);
        java.awt.Paint paint37 = numberAxis34.getLabelPaint();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint47 = polarPlot46.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape31, true, paint37, false, paint39, stroke40, true, shape44, stroke45, paint47);
        statisticalLineAndShapeRenderer15.setSeriesPaint((int) ' ', paint39, true);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        textTitle51.setHeight((double) (short) -1);
        textTitle51.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle51);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle51.setPosition(rectangleEdge57);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle();
        textTitle59.setHeight((double) (short) -1);
        textTitle59.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle();
        textTitle67.setHeight((double) (short) -1);
        textTitle67.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType76 = rectangleInsets75.getUnitType();
        textTitle67.setPadding(rectangleInsets75);
        textTitle59.setMargin(rectangleInsets75);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment79 = textTitle59.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment80 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis numberAxis81 = new org.jfree.chart.axis.NumberAxis();
        numberAxis81.setLowerBound((double) 100L);
        boolean boolean84 = verticalAlignment80.equals((java.lang.Object) numberAxis81);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation87 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        org.jfree.chart.axis.NumberAxis numberAxis88 = new org.jfree.chart.axis.NumberAxis();
        numberAxis88.setRange((double) (short) 10, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets92 = numberAxis88.getLabelInsets();
        boolean boolean93 = meanAndStandardDeviation87.equals((java.lang.Object) rectangleInsets92);
        org.jfree.chart.title.TextTitle textTitle94 = new org.jfree.chart.title.TextTitle("({0}, {1}) = {3} - {4}", font12, paint39, rectangleEdge57, horizontalAlignment79, verticalAlignment80, rectangleInsets92);
        intervalMarker3.setLabelFont(font12);
        org.jfree.chart.title.TextTitle textTitle96 = new org.jfree.chart.title.TextTitle("3", font12);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(unitType76);
        org.junit.Assert.assertNotNull(horizontalAlignment79);
        org.junit.Assert.assertNotNull(verticalAlignment80);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(rectangleInsets92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getDomainAxis((-1));
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer32 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke34 = stackedAreaRenderer32.lookupSeriesOutlineStroke(2);
        xYPlot20.setDomainZeroBaselineStroke(stroke34);
        java.awt.Stroke stroke36 = xYPlot20.getRangeZeroBaselineStroke();
        java.awt.Color color37 = java.awt.Color.CYAN;
        int int38 = color37.getAlpha();
        xYPlot20.setOutlinePaint((java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) true);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone(shape14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setAutoRangeStickyZero(true);
        java.awt.Paint paint20 = numberAxis17.getLabelPaint();
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint30 = polarPlot29.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape14, true, paint20, false, paint22, stroke23, true, shape27, stroke28, paint30);
        statisticalLineAndShapeRenderer2.setSeriesFillPaint(0, paint20);
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = statisticalLineAndShapeRenderer2.getSeriesItemLabelGenerator(6);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryItemLabelGenerator36);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker2.getLabelOffsetType();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        intervalMarker2.notifyListeners(markerChangeEvent11);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeListener titleChangeListener1 = null;
        textTitle0.addChangeListener(titleChangeListener1);
        java.awt.Font font3 = null;
        try {
            textTitle0.setFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) "TextBlockAnchor.BOTTOM_LEFT", (java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        double double6 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setCircular(true);
        java.awt.Paint paint4 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setSeparatorsVisible(false);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            ringPlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextBlockAnchor.TOP_LEFT", "SerialDate.weekInMonthToString(): invalid code.", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "poly");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        textTitle0.setPadding(rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle0.getMargin();
        double double13 = rectangleInsets11.calculateBottomInset((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = groupedStackedBarRenderer34.getToolTipGenerator(0, 0);
        boolean boolean38 = groupedStackedBarRenderer34.isDrawBarOutline();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        groupedStackedBarRenderer34.drawRangeMarker(graphics2D39, categoryPlot40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.plot.Marker) intervalMarker47, rectangle2D48);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        java.lang.Object obj51 = intervalMarker47.clone();
        intervalMarker47.setLabel("AreaRendererEndType.LEVEL");
        double double54 = intervalMarker47.getEndValue();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 10.0d + "'", double54 == 10.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
        java.util.List list5 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.validateObject();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.Object obj8 = null;
        boolean boolean9 = categoryAnchor7.equals(obj8);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean11 = categoryAnchor7.equals((java.lang.Object) dateTickUnit10);
        try {
            java.lang.Number number13 = defaultCategoryDataset0.getValue((java.lang.Comparable) dateTickUnit10, (java.lang.Comparable) (-8.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -8.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle3 = jFreeChart2.getTitle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(textTitle3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        dateAxis2.setDownArrow(shape6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis2.getTickMarkPosition();
        dateAxis2.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape12 = dateAxis2.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int16 = dateTickUnit15.getCount();
        dateAxis13.setTickUnit(dateTickUnit15, true, false);
        java.util.Date date20 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit15);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = spreadsheetDate1.compare(serialDate21);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition24 = dateAxis23.getTickMarkPosition();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.clone(shape27);
        dateAxis23.setDownArrow(shape27);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition30 = dateAxis23.getTickMarkPosition();
        dateAxis23.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape33 = dateAxis23.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition35 = dateAxis34.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int37 = dateTickUnit36.getCount();
        dateAxis34.setTickUnit(dateTickUnit36, true, false);
        java.util.Date date41 = dateAxis23.calculateLowestVisibleTickValue(dateTickUnit36);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        boolean boolean43 = spreadsheetDate1.isOn(serialDate42);
        java.util.Date date44 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-23550) + "'", int22 == (-23550));
        org.junit.Assert.assertNotNull(dateTickMarkPosition24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(dateTickMarkPosition30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(dateTickMarkPosition35);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle0.setPosition(rectangleEdge6);
        textTitle0.setID("");
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle((double) 0.0f);
        ringPlot0.setCircular(false);
        double double5 = ringPlot0.getMaximumLabelWidth();
        java.awt.Paint paint6 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        groupedStackedBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        groupedStackedBarRenderer0.setSeriesItemLabelGenerator(11, categoryItemLabelGenerator8, false);
        groupedStackedBarRenderer0.setMaximumBarWidth((double) (byte) 1);
        boolean boolean14 = groupedStackedBarRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        groupedStackedBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color15, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle3.setHorizontalAlignment(horizontalAlignment5);
        java.awt.Font font7 = textTitle3.getFont();
        ringPlot0.setLabelFont(font7);
        ringPlot0.setSectionOutlinesVisible(true);
        java.awt.Stroke stroke11 = ringPlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle((double) 0.0f);
        ringPlot0.setCircular(false);
        double double5 = ringPlot0.getMaximumLabelWidth();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor10, textAnchor11, (double) (short) 100);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer14.getBaseItemLabelsVisible();
        boolean boolean16 = numberTick13.equals((java.lang.Object) boolean15);
        org.jfree.chart.text.TextAnchor textAnchor17 = numberTick13.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor7, textAnchor17);
        try {
            statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition((-1), itemLabelPosition18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        try {
            java.awt.image.BufferedImage bufferedImage5 = jFreeChart2.createBufferedImage((-1), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (5) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone(shape15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeStickyZero(true);
        java.awt.Paint paint21 = numberAxis18.getLabelPaint();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint31 = polarPlot30.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape15, true, paint21, false, paint23, stroke24, true, shape28, stroke29, paint31);
        java.awt.Paint paint33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = polarPlot34.getInsets();
        polarPlot34.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint38 = polarPlot34.getRadiusGridlinePaint();
        java.awt.Stroke stroke39 = polarPlot34.getRadiusGridlineStroke();
        java.awt.Color color40 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape28, paint33, stroke39, (java.awt.Paint) color40);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer42 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.clone(shape50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        numberAxis53.setAutoRangeStickyZero(true);
        java.awt.Paint paint56 = numberAxis53.getLabelPaint();
        java.awt.Paint paint58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke64 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot65 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint66 = polarPlot65.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape50, true, paint56, false, paint58, stroke59, true, shape63, stroke64, paint66);
        groupedStackedBarRenderer42.setBaseStroke(stroke64);
        groupedStackedBarRenderer42.setSeriesVisible(31, (java.lang.Boolean) false);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean74 = groupedStackedBarRenderer42.equals((java.lang.Object) "ThreadContext");
        groupedStackedBarRenderer42.setAutoPopulateSeriesPaint(true);
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        groupedStackedBarRenderer42.setBaseFillPaint((java.awt.Paint) color77, true);
        try {
            org.jfree.chart.LegendItem legendItem80 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "CategoryAnchor.END", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", shape28, (java.awt.Paint) color77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(color77);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Paint paint29 = xYPlot20.getRangeGridlinePaint();
        java.awt.Paint[] paintArray30 = null;
        java.awt.Paint[] paintArray31 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, strokeArray32, strokeArray33, shapeArray34);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        xYPlot20.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) (-16777216));
        double double14 = dateRange9.constrain((double) 2);
        java.util.Date date15 = dateRange9.getUpperDate();
        java.util.TimeZone timeZone16 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15, timeZone16);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot20.setRangeAxisLocation(axisLocation34, false);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis38.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int41 = dateTickUnit40.getCount();
        dateAxis38.setTickUnit(dateTickUnit40, true, false);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = dateAxis38.valueToJava2D((double) (short) 0, rectangle2D46, rectangleEdge47);
        xYPlot20.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis38, false);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color52 = java.awt.Color.WHITE;
        float[] floatArray59 = new float[] { (-1.0f), (byte) 100, 10L, (byte) -1, 10.0f, ' ' };
        float[] floatArray60 = color52.getColorComponents(floatArray59);
        float[] floatArray61 = color51.getColorComponents(floatArray60);
        dateAxis38.setLabelPaint((java.awt.Paint) color51);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        java.awt.Font font9 = labelBlock8.getFont();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis3.getTickMarkPosition();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        dateAxis3.setDownArrow(shape7);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis3.getTickMarkPosition();
        dateAxis3.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape13 = dateAxis3.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis14.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int17 = dateTickUnit16.getCount();
        dateAxis14.setTickUnit(dateTickUnit16, true, false);
        java.util.Date date21 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit16);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        int int23 = spreadsheetDate2.compare(serialDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2019);
        boolean boolean26 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((-16777216), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-23550) + "'", int23 == (-23550));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setInverted(false);
        org.jfree.chart.plot.Plot plot5 = numberAxis0.getPlot();
        numberAxis0.configure();
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.axis.AxisState axisState16 = numberAxis0.draw(graphics2D10, (double) 1, rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
        axisState16.cursorLeft((-1.0d));
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection19 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection19);
        java.util.List list21 = taskSeriesCollection19.getRowKeys();
        axisState16.setTicks(list21);
        axisState16.setCursor((double) 1L);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(axisState16);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (int) '4');
        try {
            java.lang.Number number10 = taskSeriesCollection0.getPercentComplete(0, 1905, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset70 = categoryPlot67.getDataset(2019);
        categoryPlot67.clearAnnotations();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNull(categoryDataset70);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        projectInfo7.setName("({0}, {1}) = {2}");
        java.awt.Image image12 = projectInfo7.getLogo();
        org.junit.Assert.assertNull(image12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalLineAndShapeRenderer2.getBaseToolTipGenerator();
        statisticalLineAndShapeRenderer2.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str3 = verticalAlignment2.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        boolean boolean9 = legendTitle8.getNotify();
        boolean boolean10 = legendTitle8.getNotify();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj12 = textTitle11.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle11.setHorizontalAlignment(horizontalAlignment13);
        java.awt.Font font15 = textTitle11.getFont();
        legendTitle8.setItemFont(font15);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str3.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis3.getTickMarkPosition();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        dateAxis3.setDownArrow(shape7);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis3.getTickMarkPosition();
        dateAxis3.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape13 = dateAxis3.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis14.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int17 = dateTickUnit16.getCount();
        dateAxis14.setTickUnit(dateTickUnit16, true, false);
        java.util.Date date21 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit16);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        int int23 = spreadsheetDate2.compare(serialDate22);
        int int24 = keyedObjects2D0.getRowIndex((java.lang.Comparable) int23);
        java.lang.Object obj25 = keyedObjects2D0.clone();
        int int26 = keyedObjects2D0.getColumnCount();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = dateAxis27.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int30 = dateTickUnit29.getCount();
        dateAxis27.setTickUnit(dateTickUnit29, true, false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        boolean boolean39 = segmentedTimeline37.containsDomainValue((long) 11);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition41 = dateAxis40.getTickMarkPosition();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.clone(shape44);
        dateAxis40.setDownArrow(shape44);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition47 = dateAxis40.getTickMarkPosition();
        dateAxis40.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape50 = dateAxis40.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition52 = dateAxis51.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int54 = dateTickUnit53.getCount();
        dateAxis51.setTickUnit(dateTickUnit53, true, false);
        java.util.Date date58 = dateAxis40.calculateLowestVisibleTickValue(dateTickUnit53);
        segmentedTimeline37.addException(date58);
        java.util.Date date60 = dateTickUnit29.addToDate(date58);
        int int61 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) dateTickUnit29);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-23550) + "'", int23 == (-23550));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTickMarkPosition28);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition41);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(dateTickMarkPosition47);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(dateTickMarkPosition52);
        org.junit.Assert.assertNotNull(dateTickUnit53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint1 = numberAxis0.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis0.getTickUnit();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range5 = groupedStackedBarRenderer3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range5, (double) 100.0f);
        boolean boolean8 = numberTickUnit2.equals((java.lang.Object) range5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.awt.Paint paint32 = legendItem26.getLinePaint();
        boolean boolean33 = legendItem26.isLineVisible();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle((double) 0.0f);
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        projectInfo7.setVersion("ThreadContext");
        projectInfo7.setLicenceName("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str1 = layer0.toString();
        java.lang.String str2 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.BACKGROUND" + "'", str1.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Layer.BACKGROUND" + "'", str2.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        textLine1.removeFragment(textFragment5);
        java.awt.Font font7 = textFragment5.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str10 = verticalAlignment9.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) 'a', (double) 10L);
        flowArrangement13.clear();
        boolean boolean15 = textFragment5.equals((java.lang.Object) flowArrangement13);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str10.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.toTimelineValue((long) (short) -1);
        segmentedTimeline3.setStartTime(0L);
        int int16 = segmentedTimeline3.getGroupSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline3.getSegment((long) (short) 1);
        segment18.inc();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertNotNull(segment18);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = groupedStackedBarRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Color color0 = java.awt.Color.blue;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke3 = stackedAreaRenderer1.lookupSeriesOutlineStroke(2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        org.jfree.data.Range range7 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        int int8 = stackedAreaRenderer1.getPassCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker2.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType13 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12, categoryLabelWidthType13, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = categoryLabelPosition15.getCategoryAnchor();
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        polarPlot17.removeChangeListener(plotChangeListener18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        polarPlot17.datasetChanged(datasetChangeEvent20);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        polarPlot17.setRenderer(polarItemRenderer22);
        boolean boolean24 = rectangleAnchor16.equals((java.lang.Object) polarPlot17);
        intervalMarker2.setLabelAnchor(rectangleAnchor16);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(categoryLabelWidthType13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setLowerBound((double) 100L);
        numberAxis1.setUpperBound(4.0d);
        java.awt.Shape shape6 = numberAxis1.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint8 = numberAxis7.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis7.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit9, false, false);
        int int13 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) false);
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(pieDataset15);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getItemLabelGenerator((int) (short) 100, (int) '#');
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        jFreeChart2.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.event.ChartProgressListener chartProgressListener6 = null;
        jFreeChart2.removeProgressListener(chartProgressListener6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalLineAndShapeRenderer14.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer14.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = statisticalLineAndShapeRenderer14.getLegendItemLabelGenerator();
        boolean boolean21 = statisticalLineAndShapeRenderer14.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone(shape30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeStickyZero(true);
        java.awt.Paint paint36 = numberAxis33.getLabelPaint();
        java.awt.Paint paint38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint46 = polarPlot45.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape30, true, paint36, false, paint38, stroke39, true, shape43, stroke44, paint46);
        statisticalLineAndShapeRenderer14.setSeriesPaint((int) ' ', paint38, true);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        textTitle50.setHeight((double) (short) -1);
        textTitle50.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle50);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle50.setPosition(rectangleEdge56);
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle();
        textTitle58.setHeight((double) (short) -1);
        textTitle58.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        textTitle66.setHeight((double) (short) -1);
        textTitle66.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType75 = rectangleInsets74.getUnitType();
        textTitle66.setPadding(rectangleInsets74);
        textTitle58.setMargin(rectangleInsets74);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment78 = textTitle58.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment79 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis();
        numberAxis80.setLowerBound((double) 100L);
        boolean boolean83 = verticalAlignment79.equals((java.lang.Object) numberAxis80);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation86 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        org.jfree.chart.axis.NumberAxis numberAxis87 = new org.jfree.chart.axis.NumberAxis();
        numberAxis87.setRange((double) (short) 10, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets91 = numberAxis87.getLabelInsets();
        boolean boolean92 = meanAndStandardDeviation86.equals((java.lang.Object) rectangleInsets91);
        org.jfree.chart.title.TextTitle textTitle93 = new org.jfree.chart.title.TextTitle("({0}, {1}) = {3} - {4}", font11, paint38, rectangleEdge56, horizontalAlignment78, verticalAlignment79, rectangleInsets91);
        intervalMarker2.setLabelFont(font11);
        org.jfree.chart.axis.DateTickUnit dateTickUnit95 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int96 = dateTickUnit95.getCount();
        int int97 = dateTickUnit95.getCount();
        int int98 = dateTickUnit95.getRollUnit();
        boolean boolean99 = intervalMarker2.equals((java.lang.Object) dateTickUnit95);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(unitType75);
        org.junit.Assert.assertNotNull(horizontalAlignment78);
        org.junit.Assert.assertNotNull(verticalAlignment79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(rectangleInsets91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(dateTickUnit95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1 + "'", int97 == 1);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 2 + "'", int98 == 2);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 5, (float) 1559372400000L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str3 = verticalAlignment2.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) flowArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        boolean boolean9 = legendTitle8.getNotify();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.clone(shape19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint35 = polarPlot34.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape19, true, paint25, false, paint27, stroke28, true, shape32, stroke33, paint35);
        boolean boolean37 = textLine11.equals((java.lang.Object) legendItem36);
        legendItem36.setDatasetIndex((int) '#');
        java.awt.Shape shape40 = legendItem36.getLine();
        int int41 = legendItem36.getSeriesIndex();
        java.awt.Paint paint42 = legendItem36.getLinePaint();
        boolean boolean43 = legendTitle8.equals((java.lang.Object) paint42);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str3.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.toTimelineValue((long) (short) -1);
        segmentedTimeline3.setStartTime(0L);
        int int16 = segmentedTimeline3.getGroupSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline3.getSegment((long) (short) 1);
        long long19 = segment18.getMillisecond();
        segment18.moveIndexToEnd();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
//        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
//        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis12.setAutoRangeStickyZero(true);
//        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
//        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
//        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
//        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
//        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
//        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
//        legendItem26.setDatasetIndex((int) '#');
//        java.awt.Shape shape30 = legendItem26.getLine();
//        int int31 = legendItem26.getSeriesIndex();
//        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
//        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset33);
//        double double36 = defaultBoxAndWhiskerCategoryDataset33.getRangeLowerBound(true);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        long long38 = month37.getLastMillisecond();
//        org.jfree.data.time.Year year39 = month37.getYear();
//        java.util.List list41 = defaultBoxAndWhiskerCategoryDataset33.getOutliers((java.lang.Comparable) year39, (java.lang.Comparable) (-23550));
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
//        java.lang.Number number45 = defaultBoxAndWhiskerCategoryDataset33.getMinRegularValue((java.lang.Comparable) regularTimePeriod43, (java.lang.Comparable) (-53.0d));
//        org.junit.Assert.assertNotNull(shape9);
//        org.junit.Assert.assertNotNull(shape10);
//        org.junit.Assert.assertNotNull(paint15);
//        org.junit.Assert.assertNotNull(paint17);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(shape22);
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(shape30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNull(attributedString32);
//        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNull(list41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNull(number45);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        java.awt.Font font10 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getBackgroundPaint();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        groupedStackedBarRenderer4.setBaseStroke(stroke26);
        polarPlot2.setRadiusGridlineStroke(stroke26);
        java.awt.Stroke stroke32 = polarPlot2.getRadiusGridlineStroke();
        int int33 = dateTickUnit1.compareTo((java.lang.Object) polarPlot2);
        java.awt.Paint paint34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        polarPlot2.setOutlinePaint(paint34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = polarPlot2.getOrientation();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer37 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        groupedStackedBarRenderer37.drawRangeGridline(graphics2D38, categoryPlot39, (org.jfree.chart.axis.ValueAxis) numberAxis40, rectangle2D43, (double) 0);
        groupedStackedBarRenderer37.setMaximumBarWidth((double) 11L);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator48 = groupedStackedBarRenderer37.getBaseToolTipGenerator();
        boolean boolean49 = plotOrientation36.equals((java.lang.Object) groupedStackedBarRenderer37);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation36);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNull(categoryToolTipGenerator48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        boolean boolean5 = ganttRenderer0.hasListener((java.util.EventListener) waferMapPlot2);
        java.awt.Paint paint7 = ganttRenderer0.getSeriesPaint(11);
        boolean boolean8 = ganttRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomOutset(0.0d);
        double double4 = rectangleInsets0.calculateTopInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("-3,-3,3,3", "", "poly");
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge((int) '#');
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeStickyZero(true);
        numberAxis31.setTickLabelsVisible(false);
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis31.setLabelFont(font36);
        numberAxis31.setVisible(false);
        float float40 = numberAxis31.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.axis.AxisState axisState47 = numberAxis31.draw(graphics2D41, (double) 1, rectangle2D43, rectangle2D44, rectangleEdge45, plotRenderingInfo46);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis48, xYItemRenderer49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        numberAxis52.setAutoRangeStickyZero(true);
        java.awt.Paint paint55 = numberAxis52.getLabelPaint();
        xYPlot50.setQuadrantPaint(0, paint55);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        xYPlot50.setDataset(xYDataset57);
        java.awt.Paint paint59 = xYPlot50.getRangeGridlinePaint();
        java.awt.Paint[] paintArray60 = null;
        java.awt.Paint[] paintArray61 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray64 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray60, paintArray61, strokeArray62, strokeArray63, shapeArray64);
        xYPlot50.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        try {
            java.awt.Stroke stroke68 = defaultDrawingSupplier65.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 2.0f + "'", float40 == 2.0f);
        org.junit.Assert.assertNotNull(axisState47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paintArray61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(shapeArray64);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        xYPlot20.setRangeCrosshairValue((double) (byte) -1);
        xYPlot20.setDomainCrosshairVisible(false);
        xYPlot20.mapDatasetToRangeAxis((int) (byte) 0, 2019);
        java.awt.Paint paint42 = xYPlot20.getQuadrantPaint(3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNull(paint42);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        boolean boolean13 = statisticalLineAndShapeRenderer2.getItemShapeFilled(15, (int) (byte) 1);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        try {
            java.awt.Shape shape40 = defaultDrawingSupplier38.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = java.awt.Color.YELLOW;
        stackedBarRenderer3D0.setWallPaint((java.awt.Paint) color1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color3);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator5 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator5);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.Plot plot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge7);
        axisSpace5.add((double) (byte) 1, rectangleEdge7);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        numberAxis11.setTickLabelsVisible(false);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis11.setLabelFont(font16);
        numberAxis11.setVisible(false);
        float float20 = numberAxis11.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.axis.AxisState axisState27 = numberAxis11.draw(graphics2D21, (double) 1, rectangle2D23, rectangle2D24, rectangleEdge25, plotRenderingInfo26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis11, valueAxis28, xYItemRenderer29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeStickyZero(true);
        java.awt.Paint paint35 = numberAxis32.getLabelPaint();
        xYPlot30.setQuadrantPaint(0, paint35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot30.setDataset(xYDataset37);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        xYPlot30.setRangeAxis((int) '4', valueAxis40, false);
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot30.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer44 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = groupedStackedBarRenderer44.getToolTipGenerator(0, 0);
        boolean boolean48 = groupedStackedBarRenderer44.isDrawBarOutline();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        dateAxis51.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker57 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        groupedStackedBarRenderer44.drawRangeMarker(graphics2D49, categoryPlot50, (org.jfree.chart.axis.ValueAxis) dateAxis51, (org.jfree.chart.plot.Marker) intervalMarker57, rectangle2D58);
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker57);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        xYPlot30.setRenderer(xYItemRenderer61);
        org.jfree.chart.axis.AxisSpace axisSpace63 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean66 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge65);
        axisSpace63.add((double) (byte) 1, rectangleEdge65);
        xYPlot30.setFixedDomainAxisSpace(axisSpace63);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace69 = numberAxis1.reserveSpace(graphics2D2, plot3, rectangle2D4, rectangleEdge7, axisSpace63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNotNull(axisState27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(valueAxis43);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3, categoryLabelWidthType4, (float) 1L);
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType4, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setYOffset((double) (short) 100);
        double double3 = lineRenderer3D0.getYOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineRenderer3D0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        java.awt.Paint paint10 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot20.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart41 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent44 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) legendItemCollection40, jFreeChart41, 0, 5);
        chartProgressEvent44.setPercent(5);
        int int47 = chartProgressEvent44.getPercent();
        java.lang.Object obj48 = chartProgressEvent44.getSource();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 5 + "'", int47 == 5);
        org.junit.Assert.assertNotNull(obj48);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        long long5 = month4.getLastMillisecond();
//        org.jfree.data.time.Year year6 = month4.getYear();
//        defaultStatisticalCategoryDataset0.add((java.lang.Number) 5, (java.lang.Number) 7, (java.lang.Comparable) 2019, (java.lang.Comparable) month4);
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis8.getTickMarkPosition();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        int int11 = dateTickUnit10.getCount();
//        dateAxis8.setTickUnit(dateTickUnit10, true, false);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
//        boolean boolean20 = segmentedTimeline18.containsDomainValue((long) 11);
//        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis21.getTickMarkPosition();
//        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone(shape25);
//        dateAxis21.setDownArrow(shape25);
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = dateAxis21.getTickMarkPosition();
//        dateAxis21.setLabelURL("TextAnchor.BASELINE_CENTER");
//        java.awt.Shape shape31 = dateAxis21.getRightArrow();
//        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = dateAxis32.getTickMarkPosition();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        int int35 = dateTickUnit34.getCount();
//        dateAxis32.setTickUnit(dateTickUnit34, true, false);
//        java.util.Date date39 = dateAxis21.calculateLowestVisibleTickValue(dateTickUnit34);
//        segmentedTimeline18.addException(date39);
//        java.util.Date date41 = dateTickUnit10.addToDate(date39);
//        java.lang.Comparable comparable42 = null;
//        java.lang.Number number43 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) date39, comparable42);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
//        org.junit.Assert.assertNotNull(dateTickUnit10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
//        org.junit.Assert.assertNotNull(shape25);
//        org.junit.Assert.assertNotNull(shape26);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition28);
//        org.junit.Assert.assertNotNull(shape31);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
//        org.junit.Assert.assertNotNull(dateTickUnit34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(number43);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setMaximumBarWidth((double) 11L);
        java.awt.Paint paint12 = groupedStackedBarRenderer0.lookupSeriesPaint((int) (short) 100);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Paint paint30 = legendItem26.getLinePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer31 = legendItem26.getFillPaintTransformer();
        java.awt.Paint paint32 = legendItem26.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setUpperBound(4.0d);
        java.awt.Shape shape5 = numberAxis0.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint7 = numberAxis6.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis6.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit8);
        double double10 = numberAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = groupedStackedBarRenderer0.getDrawingSupplier();
        java.awt.Stroke stroke12 = groupedStackedBarRenderer0.getItemStroke(0, 2);
        java.awt.Paint paint14 = groupedStackedBarRenderer0.lookupSeriesPaint(11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = groupedStackedBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(itemLabelPosition15);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot20.addChangeListener(plotChangeListener27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeStickyZero(true);
        numberAxis32.setTickLabelsVisible(false);
        java.awt.Font font37 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis32.setLabelFont(font37);
        numberAxis32.setVisible(false);
        float float41 = numberAxis32.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.chart.axis.AxisState axisState48 = numberAxis32.draw(graphics2D42, (double) 1, rectangle2D44, rectangle2D45, rectangleEdge46, plotRenderingInfo47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) numberAxis32, valueAxis49, xYItemRenderer50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        numberAxis53.setAutoRangeStickyZero(true);
        java.awt.Paint paint56 = numberAxis53.getLabelPaint();
        xYPlot51.setQuadrantPaint(0, paint56);
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        xYPlot51.setDataset(xYDataset58);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        xYPlot51.setRangeAxis((int) '4', valueAxis61, false);
        org.jfree.chart.axis.ValueAxis valueAxis64 = xYPlot51.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer65 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator68 = groupedStackedBarRenderer65.getToolTipGenerator(0, 0);
        boolean boolean69 = groupedStackedBarRenderer65.isDrawBarOutline();
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = null;
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis();
        dateAxis72.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker78 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        groupedStackedBarRenderer65.drawRangeMarker(graphics2D70, categoryPlot71, (org.jfree.chart.axis.ValueAxis) dateAxis72, (org.jfree.chart.plot.Marker) intervalMarker78, rectangle2D79);
        java.awt.Paint paint81 = dateAxis72.getAxisLinePaint();
        xYPlot51.setNoDataMessagePaint(paint81);
        java.awt.geom.Point2D point2D83 = xYPlot51.getQuadrantOrigin();
        xYPlot20.zoomRangeAxes(1.0E-8d, plotRenderingInfo30, point2D83);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
        org.junit.Assert.assertNotNull(axisState48);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(valueAxis64);
        org.junit.Assert.assertNull(categoryToolTipGenerator68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(point2D83);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeStickyZero(true);
        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = polarPlot30.getInsets();
        polarPlot30.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint34 = polarPlot30.getRadiusGridlinePaint();
        java.awt.Stroke stroke35 = polarPlot30.getRadiusGridlineStroke();
        java.awt.Color color36 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape24, paint29, stroke35, (java.awt.Paint) color36);
        boolean boolean38 = legendItem37.isShapeFilled();
        java.awt.Paint paint39 = legendItem37.getLinePaint();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.axis.AxisState axisState16 = numberAxis0.draw(graphics2D10, (double) 1, rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
        numberAxis0.setRangeAboutValue((double) (-16777216), (double) 10L);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) 60000L, (double) 24234L, (double) 0L, (double) (short) 1, font24);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(axisState16);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setAutoPopulateSeriesOutlineStroke(false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.clone(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, (double) (short) 10, (double) (-16777216));
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, 10.0d, (double) '4');
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        java.text.DateFormat dateFormat9 = null;
        dateAxis0.setDateFormatOverride(dateFormat9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.setHeight((double) (short) -1);
        textTitle1.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.setHeight((double) (short) -1);
        textTitle9.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        textTitle9.setPadding(rectangleInsets17);
        textTitle1.setMargin(rectangleInsets17);
        textTitle1.setNotify(true);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean25 = layer23.equals((java.lang.Object) "({0}, {1}) = {3} - {4}");
        centerArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) "({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        long long5 = month4.getLastMillisecond();
//        org.jfree.data.time.Year year6 = month4.getYear();
//        defaultStatisticalCategoryDataset0.add((java.lang.Number) 5, (java.lang.Number) 7, (java.lang.Comparable) 2019, (java.lang.Comparable) month4);
//        org.jfree.data.Range range9 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(range9);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        int int2 = stackedAreaRenderer1.getPassCount();
        int int3 = stackedAreaRenderer1.getRowCount();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range6 = defaultBoxAndWhiskerCategoryDataset4.getRangeBounds(false);
        java.lang.Comparable comparable7 = null;
        java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset4.getMeanValue(comparable7, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj12 = categoryAxis3D11.clone();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        dateAxis13.setDownArrow(shape17);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis13.getTickMarkPosition();
        dateAxis13.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape23 = dateAxis13.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis13.setStandardTickUnits(tickUnitSource24);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer26 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setTickLabelsVisible(false);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis28.setLabelFont(font33);
        numberAxis28.setVisible(false);
        float float37 = numberAxis28.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.axis.AxisState axisState44 = numberAxis28.draw(graphics2D38, (double) 1, rectangle2D40, rectangle2D41, rectangleEdge42, plotRenderingInfo43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis28, valueAxis45, xYItemRenderer46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setAutoRangeStickyZero(true);
        java.awt.Paint paint52 = numberAxis49.getLabelPaint();
        xYPlot47.setQuadrantPaint(0, paint52);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot47.setDataset(xYDataset54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        xYPlot47.setRangeAxis((int) '4', valueAxis57, false);
        java.awt.Paint[] paintArray60 = null;
        java.awt.Paint[] paintArray61 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray64 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray60, paintArray61, strokeArray62, strokeArray63, shapeArray64);
        xYPlot47.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = xYPlot47.getLegendItems();
        java.awt.Paint paint68 = xYPlot47.getRangeCrosshairPaint();
        boxAndWhiskerRenderer26.setBaseItemLabelPaint(paint68, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer26);
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = categoryPlot71.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D74 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D76 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D76.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int80 = dateTickUnit79.getCount();
        categoryAxis3D76.removeCategoryLabelToolTip((java.lang.Comparable) int80);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D83 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray84 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D74, categoryAxis3D76, categoryAxis3D83 };
        categoryPlot71.setDomainAxes(categoryAxisArray84);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer86 = null;
        categoryPlot71.setRenderer(categoryItemRenderer86);
        boolean boolean88 = stackedAreaRenderer1.hasListener((java.util.EventListener) categoryPlot71);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder89 = categoryPlot71.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(axisState44);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paintArray61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(shapeArray64);
        org.junit.Assert.assertNotNull(legendItemCollection67);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder89);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((double) (-16777216), (java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (java.lang.Comparable) "-3,-3,3,3");
        int int6 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) 255);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = polarPlot31.getInsets();
        polarPlot31.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint35 = polarPlot31.getRadiusGridlinePaint();
        java.awt.Stroke stroke36 = polarPlot31.getRadiusGridlineStroke();
        java.awt.Color color37 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape25, paint30, stroke36, (java.awt.Paint) color37);
        boolean boolean39 = paintList0.equals((java.lang.Object) color37);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setAutoRangeStickyZero(true);
        numberAxis40.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange48 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange51 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange48, (org.jfree.data.Range) dateRange51);
        dateAxis45.setRangeWithMargins((org.jfree.data.Range) dateRange48);
        numberAxis40.setDefaultAutoRange((org.jfree.data.Range) dateRange48);
        org.jfree.data.Range range55 = numberAxis40.getRange();
        boolean boolean56 = paintList0.equals((java.lang.Object) numberAxis40);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        int int2 = stackedAreaRenderer1.getPassCount();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint5 = numberAxis4.getLabelPaint();
        stackedAreaRenderer1.setSeriesFillPaint(5, paint5, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Paint paint28 = xYPlot20.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot20.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        int int31 = xYPlot20.indexOf(xYDataset30);
        xYPlot20.clearDomainMarkers(2019);
        java.awt.Paint paint34 = xYPlot20.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot20.setQuadrantPaint(0, paint29);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeStickyZero(true);
        numberAxis33.setTickLabelsVisible(false);
        java.awt.Font font38 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis33.setLabelFont(font38);
        numberAxis33.setVisible(false);
        float float42 = numberAxis33.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.axis.AxisState axisState49 = numberAxis33.draw(graphics2D43, (double) 1, rectangle2D45, rectangle2D46, rectangleEdge47, plotRenderingInfo48);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis33, valueAxis50, xYItemRenderer51);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        numberAxis54.setAutoRangeStickyZero(true);
        java.awt.Paint paint57 = numberAxis54.getLabelPaint();
        xYPlot52.setQuadrantPaint(0, paint57);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        xYPlot52.setDataset(xYDataset59);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        xYPlot52.setRangeAxis((int) '4', valueAxis62, false);
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot52.getDomainAxis();
        xYPlot52.setRangeCrosshairValue((double) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation69 = xYPlot52.getDomainAxisLocation((int) (short) 1);
        xYPlot20.setDomainAxisLocation((int) (byte) 10, axisLocation69, true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
        org.junit.Assert.assertNotNull(axisState49);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(valueAxis65);
        org.junit.Assert.assertNotNull(axisLocation69);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        groupedStackedBarRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.plot.Marker) intervalMarker13, rectangle2D14);
        java.awt.Paint paint16 = dateAxis7.getAxisLinePaint();
        java.lang.Object obj17 = dateAxis7.clone();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle3.setHorizontalAlignment(horizontalAlignment5);
        java.awt.Font font7 = textTitle3.getFont();
        ringPlot0.setLabelFont(font7);
        java.awt.Paint paint9 = ringPlot0.getBaseSectionPaint();
        ringPlot0.setOuterSeparatorExtension((double) (byte) 1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset70 = categoryPlot67.getDataset(2019);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        try {
            categoryPlot67.handleClick((int) '#', 1, plotRenderingInfo73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNull(categoryDataset70);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Paint paint29 = xYPlot20.getRangeGridlinePaint();
        java.awt.Paint[] paintArray30 = null;
        java.awt.Paint[] paintArray31 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, strokeArray32, strokeArray33, shapeArray34);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        xYPlot20.setRangeCrosshairValue((double) 11, false);
        java.awt.Paint paint40 = null;
        xYPlot20.setOutlinePaint(paint40);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement1);
        blockContainer2.clear();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (org.jfree.data.Range) dateRange10);
        java.lang.String str12 = rectangleConstraint11.toString();
        try {
            org.jfree.chart.util.Size2D size2D13 = centerArrangement0.arrange(blockContainer2, graphics2D4, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str12.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = piePlot0.getLabelLinkStroke();
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke4, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Paint paint30 = legendItem26.getLinePaint();
        org.jfree.data.general.Dataset dataset31 = legendItem26.getDataset();
        java.awt.Shape shape32 = legendItem26.getLine();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(dataset31);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, true);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        taskSeriesCollection9.removeAll();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean24 = segmentedTimeline22.equals((java.lang.Object) (byte) 0);
        segmentedTimeline18.setBaseTimeline(segmentedTimeline22);
        long long27 = segmentedTimeline18.toTimelineValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment29 = segmentedTimeline18.getSegment((long) (byte) 1);
        boolean boolean30 = segment29.inExceptionSegments();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity31 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "Multiple Pie Plot", "DateTickMarkPosition.START", (org.jfree.data.category.CategoryDataset) taskSeriesCollection9, (java.lang.Comparable) 10.0f, (java.lang.Comparable) boolean30);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(segment29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = categoryLabelPosition4.getCategoryAnchor();
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        polarPlot6.removeChangeListener(plotChangeListener7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot6.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot6.setRenderer(polarItemRenderer11);
        boolean boolean13 = rectangleAnchor5.equals((java.lang.Object) polarPlot6);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16, categoryLabelWidthType17, (float) 1L);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor14, categoryLabelWidthType17, (float) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getBackgroundPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        polarPlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        polarPlot0.handleClick((int) (short) 100, 255, plotRenderingInfo6);
        polarPlot0.setAngleLabelsVisible(true);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        double double17 = groupedStackedBarRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalLineAndShapeRenderer20.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer20.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = statisticalLineAndShapeRenderer20.getLegendItemLabelGenerator();
        boolean boolean27 = statisticalLineAndShapeRenderer20.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.clone(shape36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setAutoRangeStickyZero(true);
        java.awt.Paint paint42 = numberAxis39.getLabelPaint();
        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint52 = polarPlot51.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape36, true, paint42, false, paint44, stroke45, true, shape49, stroke50, paint52);
        statisticalLineAndShapeRenderer20.setSeriesPaint((int) ' ', paint44, true);
        groupedStackedBarRenderer0.setBaseOutlinePaint(paint44, false);
        groupedStackedBarRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.awt.Paint paint32 = legendItem26.getLinePaint();
        java.awt.Paint paint33 = legendItem26.getLinePaint();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection30 = xYPlot20.getFixedLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray31 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot20.setRenderers(xYItemRendererArray31);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeStickyZero(true);
        numberAxis33.setTickLabelsVisible(false);
        java.awt.Font font38 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis33.setLabelFont(font38);
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        numberAxis33.setDefaultAutoRange((org.jfree.data.Range) dateRange42);
        numberAxis33.setAutoTickUnitSelection(true);
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis33);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(xYItemRendererArray31);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(0.0d, 0.0d);
        java.lang.Object obj4 = dateAxis0.clone();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setAutoRangeStickyZero(true);
        java.awt.Paint paint23 = numberAxis20.getLabelPaint();
        java.awt.Paint paint25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint33 = polarPlot32.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape17, true, paint23, false, paint25, stroke26, true, shape30, stroke31, paint33);
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = polarPlot36.getInsets();
        polarPlot36.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint40 = polarPlot36.getRadiusGridlinePaint();
        java.awt.Stroke stroke41 = polarPlot36.getRadiusGridlineStroke();
        java.awt.Color color42 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape30, paint35, stroke41, (java.awt.Paint) color42);
        piePlot5.setLabelOutlineStroke(stroke41);
        piePlot5.setCircular(false, true);
        java.awt.Paint paint48 = null;
        piePlot5.setBackgroundPaint(paint48);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = null;
        piePlot5.setLegendLabelToolTipGenerator(pieSectionLabelGenerator50);
        java.awt.Paint paint52 = piePlot5.getOutlinePaint();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot5);
        try {
            dateAxis0.zoomRange((double) 2.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.setHeight((double) (short) -1);
        textTitle1.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle1);
        textTitle1.setToolTipText("VerticalAlignment.BOTTOM");
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle1.getVerticalAlignment();
        boolean boolean10 = dateTickMarkPosition0.equals((java.lang.Object) textTitle1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeStickyZero(true);
        numberAxis2.setTickLabelsVisible(false);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis2.setLabelFont(font7);
        numberAxis2.setVisible(false);
        float float11 = numberAxis2.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.axis.AxisState axisState18 = numberAxis2.draw(graphics2D12, (double) 1, rectangle2D14, rectangle2D15, rectangleEdge16, plotRenderingInfo17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeStickyZero(true);
        java.awt.Paint paint26 = numberAxis23.getLabelPaint();
        xYPlot21.setQuadrantPaint(0, paint26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot21.setDataset(xYDataset28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        xYPlot21.setRangeAxis((int) '4', valueAxis31, false);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer35 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator38 = groupedStackedBarRenderer35.getToolTipGenerator(0, 0);
        boolean boolean39 = groupedStackedBarRenderer35.isDrawBarOutline();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        dateAxis42.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker48 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        groupedStackedBarRenderer35.drawRangeMarker(graphics2D40, categoryPlot41, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.plot.Marker) intervalMarker48, rectangle2D49);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker48);
        java.lang.Object obj52 = intervalMarker48.clone();
        boolean boolean53 = standardCategoryToolTipGenerator0.equals((java.lang.Object) intervalMarker48);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(axisState18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNull(categoryToolTipGenerator38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ERROR : Relative To String");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("LengthConstraintType.FIXED");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        java.lang.Number number70 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 0L, (java.lang.Comparable) 3600000L);
        java.lang.Comparable comparable71 = null;
        java.lang.Number number73 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value(comparable71, (java.lang.Comparable) 0L);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNull(number70);
        org.junit.Assert.assertNull(number73);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue(0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = intervalMarker2.getLabelOffsetType();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick17 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor14, textAnchor15, (double) (short) 100);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean19 = intervalBarRenderer18.getBaseItemLabelsVisible();
        boolean boolean20 = numberTick17.equals((java.lang.Object) boolean19);
        org.jfree.chart.text.TextAnchor textAnchor21 = numberTick17.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor21);
        intervalMarker2.setLabelTextAnchor(textAnchor21);
        intervalMarker2.setAlpha(0.5f);
        java.awt.Paint paint26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        intervalMarker2.setOutlinePaint(paint26);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        textLine1.removeFragment(textFragment5);
        java.lang.Object obj7 = null;
        boolean boolean8 = textLine1.equals(obj7);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange7);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(0.35d, (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (double) 10.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setCircular(true);
        java.awt.Paint paint4 = ringPlot0.getLabelShadowPaint();
        java.awt.Color color5 = java.awt.Color.BLACK;
        int int6 = color5.getTransparency();
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable3, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj8 = categoryAxis3D7.clone();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis9.getTickMarkPosition();
        dateAxis9.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape19 = dateAxis9.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis9.setStandardTickUnits(tickUnitSource20);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        xYPlot43.setDataset(xYDataset50);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot43.setRangeAxis((int) '4', valueAxis53, false);
        java.awt.Paint[] paintArray56 = null;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray60 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray56, paintArray57, strokeArray58, strokeArray59, shapeArray60);
        xYPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.jfree.chart.LegendItemCollection legendItemCollection63 = xYPlot43.getLegendItems();
        java.awt.Paint paint64 = xYPlot43.getRangeCrosshairPaint();
        boxAndWhiskerRenderer22.setBaseItemLabelPaint(paint64, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot67.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D70 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D72 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D72.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int76 = dateTickUnit75.getCount();
        categoryAxis3D72.removeCategoryLabelToolTip((java.lang.Comparable) int76);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D79 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray80 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D70, categoryAxis3D72, categoryAxis3D79 };
        categoryPlot67.setDomainAxes(categoryAxisArray80);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = null;
        categoryPlot67.setRenderer(categoryItemRenderer82);
        org.jfree.chart.axis.AxisLocation axisLocation85 = categoryPlot67.getRangeAxisLocation(1900);
        categoryPlot67.setDrawSharedDomainAxis(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker88 = null;
        try {
            categoryPlot67.addDomainMarker(categoryMarker88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shapeArray60);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNotNull(dateTickUnit75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray80);
        org.junit.Assert.assertNotNull(axisLocation85);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        xYPlot20.clearDomainAxes();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str23 = layer22.toString();
        java.util.Collection collection24 = xYPlot20.getDomainMarkers(layer22);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.BACKGROUND" + "'", str23.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(paint2);
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape1, paint2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLowerBound((double) 100L);
        numberAxis5.setUpperBound(4.0d);
        java.awt.Shape shape10 = numberAxis5.getDownArrow();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, 10.0d, 0.0d);
        legendGraphic4.setShape(shape10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.lang.Boolean boolean11 = statisticalLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 10);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(true);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = polarPlot6.getInsets();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        polarPlot6.drawBackgroundImage(graphics2D8, rectangle2D9);
        polarPlot6.setBackgroundAlpha((float) 86400000L);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        polarPlot6.addChangeListener(plotChangeListener13);
        boolean boolean15 = polarPlot6.isAngleLabelsVisible();
        statisticalLineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        numberAxis0.setTickLabelInsets(rectangleInsets3);
        double double7 = rectangleInsets3.calculateRightOutset((double) ' ');
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint5 = polarPlot4.getBackgroundPaint();
        piePlot0.setShadowPaint(paint5);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.setHeight((double) (short) -1);
        textTitle8.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        textTitle8.setPadding(rectangleInsets16);
        textTitle0.setMargin(rectangleInsets16);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle0.setFont(font20);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle((double) 0.0f);
        ringPlot0.setCircular(false);
        ringPlot0.setNoDataMessage("VerticalAlignment.BOTTOM");
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D1.setUpperMargin((double) 0.0f);
        int int4 = categoryAxis3D1.getMaximumCategoryLabelLines();
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(0.0f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        projectInfo7.setName("({0}, {1}) = {2}");
        projectInfo7.setLicenceText("TextBlockAnchor.TOP_LEFT");
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setCircular(true);
        ringPlot0.setStartAngle((double) 1L);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = ringPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Paint paint4 = numberAxis1.getLabelPaint();
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis8.getTickMarkPosition();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        dateAxis8.setDownArrow(shape12);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis8.getTickMarkPosition();
        dateAxis8.setLabelURL("TextAnchor.BASELINE_CENTER");
        dateAxis8.setFixedDimension((double) 1.0f);
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Point2D point2D23 = null;
        org.jfree.chart.plot.PlotState plotState24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            polarPlot7.draw(graphics2D21, rectangle2D22, point2D23, plotState24, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test447");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        int int2 = month0.getYearValue();
//        boolean boolean4 = month0.equals((java.lang.Object) "AreaRendererEndType.LEVEL");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset5.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
//        java.util.List list10 = defaultCategoryDataset5.getColumnKeys();
//        int int11 = month0.compareTo((java.lang.Object) defaultCategoryDataset5);
//        org.jfree.data.KeyedObjects2D keyedObjects2D12 = new org.jfree.data.KeyedObjects2D();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
//        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis15.getTickMarkPosition();
//        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.clone(shape19);
//        dateAxis15.setDownArrow(shape19);
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis15.getTickMarkPosition();
//        dateAxis15.setLabelURL("TextAnchor.BASELINE_CENTER");
//        java.awt.Shape shape25 = dateAxis15.getRightArrow();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition27 = dateAxis26.getTickMarkPosition();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        int int29 = dateTickUnit28.getCount();
//        dateAxis26.setTickUnit(dateTickUnit28, true, false);
//        java.util.Date date33 = dateAxis15.calculateLowestVisibleTickValue(dateTickUnit28);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
//        int int35 = spreadsheetDate14.compare(serialDate34);
//        int int36 = keyedObjects2D12.getRowIndex((java.lang.Comparable) int35);
//        java.lang.Object obj37 = keyedObjects2D12.clone();
//        boolean boolean38 = defaultCategoryDataset5.equals((java.lang.Object) keyedObjects2D12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
//        org.junit.Assert.assertNotNull(shape19);
//        org.junit.Assert.assertNotNull(shape20);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
//        org.junit.Assert.assertNotNull(shape25);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition27);
//        org.junit.Assert.assertNotNull(dateTickUnit28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-23550) + "'", int35 == (-23550));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        textLine1.removeFragment(textFragment5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeStickyZero(true);
        numberAxis9.setTickLabelsVisible(false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis9.setLabelFont(font14);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ThreadContext", font14);
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setLowerBound((double) 100L);
        numberAxis18.setInverted(false);
        org.jfree.chart.plot.Plot plot23 = numberAxis18.getPlot();
        numberAxis18.setUpperMargin(0.25d);
        boolean boolean26 = color17.equals((java.lang.Object) 0.25d);
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("Layer.BACKGROUND", font14, (java.awt.Paint) color17, (float) (byte) -1);
        textLine1.removeFragment(textFragment28);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        java.awt.Image image3 = jFreeChart2.getBackgroundImage();
        jFreeChart2.setBackgroundImageAlignment((int) (short) 1);
        int int6 = jFreeChart2.getSubtitleCount();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("SerialDate.weekInMonthToString(): invalid code.", font2);
        java.lang.Object obj4 = null;
        centerArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj4);
        java.lang.String str6 = textTitle3.getURLText();
        java.awt.Paint paint7 = textTitle3.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int5 = color4.getBlue();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) 86400000L, (double) (short) 10, 0.05d, 0.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeStickyZero(true);
        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
        boolean boolean29 = textLine3.equals((java.lang.Object) legendItem28);
        legendItem28.setDatasetIndex((int) '#');
        java.awt.Shape shape32 = legendItem28.getLine();
        int int33 = legendItem28.getSeriesIndex();
        java.text.AttributedString attributedString34 = legendItem28.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset35 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem28.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset35);
        org.jfree.data.Range range37 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset35);
        org.jfree.data.Range range39 = defaultBoxAndWhiskerCategoryDataset35.getRangeBounds(true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(attributedString34);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getBaseItemLabelPaint();
        java.lang.Boolean boolean13 = statisticalLineAndShapeRenderer2.getSeriesShapesFilled((int) (byte) -1);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        int int2 = stackedAreaRenderer1.getPassCount();
        int int3 = stackedAreaRenderer1.getRowCount();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range6 = defaultBoxAndWhiskerCategoryDataset4.getRangeBounds(false);
        java.lang.Comparable comparable7 = null;
        java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset4.getMeanValue(comparable7, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj12 = categoryAxis3D11.clone();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis13.getTickMarkPosition();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        dateAxis13.setDownArrow(shape17);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis13.getTickMarkPosition();
        dateAxis13.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape23 = dateAxis13.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis13.setStandardTickUnits(tickUnitSource24);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer26 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setTickLabelsVisible(false);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis28.setLabelFont(font33);
        numberAxis28.setVisible(false);
        float float37 = numberAxis28.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.axis.AxisState axisState44 = numberAxis28.draw(graphics2D38, (double) 1, rectangle2D40, rectangle2D41, rectangleEdge42, plotRenderingInfo43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis28, valueAxis45, xYItemRenderer46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setAutoRangeStickyZero(true);
        java.awt.Paint paint52 = numberAxis49.getLabelPaint();
        xYPlot47.setQuadrantPaint(0, paint52);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot47.setDataset(xYDataset54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        xYPlot47.setRangeAxis((int) '4', valueAxis57, false);
        java.awt.Paint[] paintArray60 = null;
        java.awt.Paint[] paintArray61 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray64 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray60, paintArray61, strokeArray62, strokeArray63, shapeArray64);
        xYPlot47.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier65);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = xYPlot47.getLegendItems();
        java.awt.Paint paint68 = xYPlot47.getRangeCrosshairPaint();
        boxAndWhiskerRenderer26.setBaseItemLabelPaint(paint68, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer26);
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = categoryPlot71.getOrientation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D74 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D76 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D76.setUpperMargin((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int80 = dateTickUnit79.getCount();
        categoryAxis3D76.removeCategoryLabelToolTip((java.lang.Comparable) int80);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D83 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray84 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D74, categoryAxis3D76, categoryAxis3D83 };
        categoryPlot71.setDomainAxes(categoryAxisArray84);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer86 = null;
        categoryPlot71.setRenderer(categoryItemRenderer86);
        boolean boolean88 = stackedAreaRenderer1.hasListener((java.util.EventListener) categoryPlot71);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = categoryPlot71.getDomainAxisEdge();
        org.jfree.chart.util.VerticalAlignment verticalAlignment90 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.axis.NumberAxis numberAxis91 = new org.jfree.chart.axis.NumberAxis();
        numberAxis91.setLowerBound((double) 100L);
        boolean boolean94 = verticalAlignment90.equals((java.lang.Object) numberAxis91);
        java.lang.Object obj95 = null;
        boolean boolean96 = numberAxis91.equals(obj95);
        org.jfree.data.Range range97 = categoryPlot71.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis91);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(axisState44);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paintArray61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNotNull(shapeArray64);
        org.junit.Assert.assertNotNull(legendItemCollection67);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertNotNull(verticalAlignment90);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNull(range97);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod4);
        task2.removeSubtask(task5);
        task5.setPercentComplete(0.0d);
        task5.setDescription("Multiple Pie Plot");
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke5 = stackedAreaRenderer3.lookupSeriesOutlineStroke(2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection6 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection6);
        org.jfree.data.Range range9 = stackedAreaRenderer3.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection6);
        java.lang.Object obj10 = stackedAreaRenderer3.clone();
        boolean boolean11 = blockContainer1.equals(obj10);
        java.lang.Object obj12 = null;
        boolean boolean13 = blockContainer1.equals(obj12);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke3 = stackedAreaRenderer1.lookupSeriesOutlineStroke(2);
        int int4 = stackedAreaRenderer1.getColumnCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test458");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        int int2 = month0.getYearValue();
//        boolean boolean4 = month0.equals((java.lang.Object) "AreaRendererEndType.LEVEL");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset5.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
//        java.util.List list10 = defaultCategoryDataset5.getColumnKeys();
//        int int11 = month0.compareTo((java.lang.Object) defaultCategoryDataset5);
//        defaultCategoryDataset5.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeStickyZero(true);
        java.awt.Paint paint13 = numberAxis10.getLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint23 = polarPlot22.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape7, true, paint13, false, paint15, stroke16, true, shape20, stroke21, paint23);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj26 = standardGradientPaintTransformer25.clone();
        legendItem24.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        boolean boolean28 = legendItem24.isShapeFilled();
        boolean boolean29 = legendItem24.isShapeFilled();
        int int30 = legendItem24.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        double double3 = numberAxis0.getFixedAutoRange();
        float float4 = numberAxis0.getTickMarkOutsideLength();
        numberAxis0.setLowerBound((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot20.addChangeListener(plotChangeListener27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition31 = dateAxis30.getTickMarkPosition();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.clone(shape34);
        dateAxis30.setDownArrow(shape34);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition37 = dateAxis30.getTickMarkPosition();
        dateAxis30.setLabelURL("TextAnchor.BASELINE_CENTER");
        org.jfree.data.time.DateRange dateRange42 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange42, (org.jfree.data.Range) dateRange45);
        dateAxis30.setRange((org.jfree.data.Range) dateRange42);
        xYPlot20.setDomainAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) dateAxis30, true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(dateTickMarkPosition31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(dateTickMarkPosition37);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) multiplePiePlot7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        dateAxis9.setDownArrow(shape13);
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone(shape25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        java.awt.Paint paint31 = numberAxis28.getLabelPaint();
        java.awt.Paint paint33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint41 = polarPlot40.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape25, true, paint31, false, paint33, stroke34, true, shape38, stroke39, paint41);
        boolean boolean43 = textLine17.equals((java.lang.Object) legendItem42);
        legendItem42.setDatasetIndex((int) '#');
        java.awt.Shape shape46 = legendItem42.getLine();
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.clone(shape46);
        dateAxis9.setLeftArrow(shape47);
        boolean boolean49 = multiplePiePlot7.equals((java.lang.Object) shape47);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 0, 2019, (int) (short) 100, 0, dateFormat4);
        int int6 = dateTickUnit5.getRollCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = groupedStackedBarRenderer1.getToolTipGenerator(0, 0);
        groupedStackedBarRenderer1.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, false);
        boolean boolean9 = groupedStackedBarRenderer1.getBaseItemLabelsVisible();
        boolean boolean10 = waterfallBarRenderer0.equals((java.lang.Object) groupedStackedBarRenderer1);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.clone(shape20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setAutoRangeStickyZero(true);
        java.awt.Paint paint26 = numberAxis23.getLabelPaint();
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint36 = polarPlot35.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape20, true, paint26, false, paint28, stroke29, true, shape33, stroke34, paint36);
        groupedStackedBarRenderer12.setBaseStroke(stroke34);
        groupedStackedBarRenderer12.setSeriesVisible(31, (java.lang.Boolean) false);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean44 = groupedStackedBarRenderer12.equals((java.lang.Object) "ThreadContext");
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = groupedStackedBarRenderer12.getToolTipGenerator((int) (byte) 1, 2);
        groupedStackedBarRenderer12.setItemMargin(100.0d);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator50 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        groupedStackedBarRenderer12.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator50);
        waterfallBarRenderer0.setSeriesToolTipGenerator(15, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator50);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        ringPlot0.setSectionDepth((double) '4');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        int int7 = taskSeriesCollection5.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection5);
        java.awt.Color color9 = java.awt.Color.WHITE;
        java.awt.Color color10 = color9.darker();
        multiplePiePlot8.setAggregatedItemsPaint((java.awt.Paint) color10);
        boolean boolean12 = ringPlot0.equals((java.lang.Object) multiplePiePlot8);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        ringPlot0.setLabelLinkStroke(stroke13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoRangeStickyZero(true);
        numberAxis16.setTickLabelsVisible(false);
        java.awt.Font font21 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis16.setLabelFont(font21);
        numberAxis16.setVisible(false);
        float float25 = numberAxis16.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.axis.AxisState axisState32 = numberAxis16.draw(graphics2D26, (double) 1, rectangle2D28, rectangle2D29, rectangleEdge30, plotRenderingInfo31);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis16, valueAxis33, xYItemRenderer34);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setAutoRangeStickyZero(true);
        java.awt.Paint paint40 = numberAxis37.getLabelPaint();
        xYPlot35.setQuadrantPaint(0, paint40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot35.setDataset(xYDataset42);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        xYPlot35.setRangeAxis((int) '4', valueAxis45, false);
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot35.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer49 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator52 = groupedStackedBarRenderer49.getToolTipGenerator(0, 0);
        boolean boolean53 = groupedStackedBarRenderer49.isDrawBarOutline();
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        dateAxis56.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker62 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        groupedStackedBarRenderer49.drawRangeMarker(graphics2D54, categoryPlot55, (org.jfree.chart.axis.ValueAxis) dateAxis56, (org.jfree.chart.plot.Marker) intervalMarker62, rectangle2D63);
        xYPlot35.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker62);
        xYPlot35.setRangeGridlinesVisible(true);
        xYPlot35.clearDomainMarkers((int) (short) 1);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer70 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = null;
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis();
        numberAxis73.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        groupedStackedBarRenderer70.drawRangeGridline(graphics2D71, categoryPlot72, (org.jfree.chart.axis.ValueAxis) numberAxis73, rectangle2D76, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier79 = groupedStackedBarRenderer70.getDrawingSupplier();
        java.awt.Stroke stroke82 = groupedStackedBarRenderer70.getItemStroke(0, 2);
        java.awt.Paint paint84 = groupedStackedBarRenderer70.lookupSeriesPaint(11);
        xYPlot35.setRangeTickBandPaint(paint84);
        ringPlot0.setSeparatorPaint(paint84);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNotNull(axisState32);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertNull(categoryToolTipGenerator52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNull(drawingSupplier79);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(paint84);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.toTimelineValue((long) (short) -1);
        segmentedTimeline3.setStartTime(0L);
        int int16 = segmentedTimeline3.getGroupSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline3.getSegment((long) (short) 1);
        segmentedTimeline3.addException(1L, (long) 4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertNotNull(segment18);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE9", font1, paint2);
        java.lang.Object obj4 = labelBlock3.clone();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj7 = textTitle6.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle6.setHorizontalAlignment(horizontalAlignment8);
        java.awt.Font font10 = textTitle6.getFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("", font10);
        labelBlock3.setFont(font10);
        java.awt.Paint paint13 = labelBlock3.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = groupedStackedBarRenderer1.getToolTipGenerator(0, 0);
        groupedStackedBarRenderer1.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, false);
        boolean boolean9 = groupedStackedBarRenderer1.getBaseItemLabelsVisible();
        boolean boolean10 = waterfallBarRenderer0.equals((java.lang.Object) groupedStackedBarRenderer1);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        double double14 = categoryItemRendererState13.getSeriesRunningTotal();
        org.jfree.chart.entity.EntityCollection entityCollection15 = categoryItemRendererState13.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range19 = defaultBoxAndWhiskerCategoryDataset17.getRangeBounds(false);
        java.lang.Comparable comparable20 = null;
        java.lang.Number number22 = defaultBoxAndWhiskerCategoryDataset17.getMeanValue(comparable20, (java.lang.Comparable) 3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        java.lang.Object obj25 = categoryAxis3D24.clone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition27 = dateAxis26.getTickMarkPosition();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone(shape30);
        dateAxis26.setDownArrow(shape30);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = dateAxis26.getTickMarkPosition();
        dateAxis26.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape36 = dateAxis26.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource37 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis26.setStandardTickUnits(tickUnitSource37);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer39 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setAutoRangeStickyZero(true);
        numberAxis41.setTickLabelsVisible(false);
        java.awt.Font font46 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis41.setLabelFont(font46);
        numberAxis41.setVisible(false);
        float float50 = numberAxis41.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.axis.AxisState axisState57 = numberAxis41.draw(graphics2D51, (double) 1, rectangle2D53, rectangle2D54, rectangleEdge55, plotRenderingInfo56);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis41, valueAxis58, xYItemRenderer59);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis();
        numberAxis62.setAutoRangeStickyZero(true);
        java.awt.Paint paint65 = numberAxis62.getLabelPaint();
        xYPlot60.setQuadrantPaint(0, paint65);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        xYPlot60.setDataset(xYDataset67);
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        xYPlot60.setRangeAxis((int) '4', valueAxis70, false);
        java.awt.Paint[] paintArray73 = null;
        java.awt.Paint[] paintArray74 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray75 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray76 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray77 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier78 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray73, paintArray74, strokeArray75, strokeArray76, shapeArray77);
        xYPlot60.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier78);
        org.jfree.chart.LegendItemCollection legendItemCollection80 = xYPlot60.getLegendItems();
        java.awt.Paint paint81 = xYPlot60.getRangeCrosshairPaint();
        boxAndWhiskerRenderer39.setBaseItemLabelPaint(paint81, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) boxAndWhiskerRenderer39);
        org.jfree.chart.plot.PlotOrientation plotOrientation85 = categoryPlot84.getOrientation();
        java.util.List list86 = categoryPlot84.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D88 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D88.setUpperMargin((double) 0.0f);
        int int91 = categoryAxis3D88.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.NumberAxis numberAxis93 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset94 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            waterfallBarRenderer0.drawItem(graphics2D11, categoryItemRendererState13, rectangle2D16, categoryPlot84, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D88, (org.jfree.chart.axis.ValueAxis) numberAxis93, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset94, (int) (short) 10, (-1), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(entityCollection15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(dateTickMarkPosition27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(tickUnitSource37);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 2.0f + "'", float50 == 2.0f);
        org.junit.Assert.assertNotNull(axisState57);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(paintArray74);
        org.junit.Assert.assertNotNull(strokeArray75);
        org.junit.Assert.assertNotNull(strokeArray76);
        org.junit.Assert.assertNotNull(shapeArray77);
        org.junit.Assert.assertNotNull(legendItemCollection80);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(plotOrientation85);
        org.junit.Assert.assertNotNull(list86);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle3.setHorizontalAlignment(horizontalAlignment5);
        java.awt.Font font7 = textTitle3.getFont();
        ringPlot0.setLabelFont(font7);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list10 = taskSeriesCollection9.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, (int) (byte) 1);
        ringPlot0.setDataset(pieDataset12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset12);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        textLine1.removeFragment(textFragment5);
        java.awt.Font font7 = textFragment5.getFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            float float10 = textFragment5.calculateBaselineOffset(graphics2D8, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 8.0d, shape21, "", "CategoryAnchor.END");
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        double double8 = textTitle0.getContentXOffset();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        textTitle0.setPaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot0.getInsets();
        double double4 = rectangleInsets2.trimHeight(0.0d);
        double double5 = rectangleInsets2.getBottom();
        double double7 = rectangleInsets2.calculateRightInset((double) (-23550));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        groupedStackedBarRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.plot.Marker) intervalMarker13, rectangle2D14);
        dateAxis7.setPositiveArrowVisible(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone(shape16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeStickyZero(true);
        java.awt.Paint paint22 = numberAxis19.getLabelPaint();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint32 = polarPlot31.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape16, true, paint22, false, paint24, stroke25, true, shape29, stroke30, paint32);
        boolean boolean34 = textLine8.equals((java.lang.Object) legendItem33);
        legendItem33.setDatasetIndex((int) '#');
        java.awt.Shape shape37 = legendItem33.getLine();
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.clone(shape37);
        dateAxis0.setLeftArrow(shape38);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition41 = dateAxis40.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int43 = dateTickUnit42.getCount();
        dateAxis40.setTickUnit(dateTickUnit42, true, false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline50 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        boolean boolean52 = segmentedTimeline50.containsDomainValue((long) 11);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition54 = dateAxis53.getTickMarkPosition();
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.clone(shape57);
        dateAxis53.setDownArrow(shape57);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition60 = dateAxis53.getTickMarkPosition();
        dateAxis53.setLabelURL("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape63 = dateAxis53.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition65 = dateAxis64.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int67 = dateTickUnit66.getCount();
        dateAxis64.setTickUnit(dateTickUnit66, true, false);
        java.util.Date date71 = dateAxis53.calculateLowestVisibleTickValue(dateTickUnit66);
        segmentedTimeline50.addException(date71);
        java.util.Date date73 = dateTickUnit42.addToDate(date71);
        dateAxis0.setMaximumDate(date73);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(dateTickMarkPosition41);
        org.junit.Assert.assertNotNull(dateTickUnit42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition54);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(dateTickMarkPosition60);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(dateTickMarkPosition65);
        org.junit.Assert.assertNotNull(dateTickUnit66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(date73);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setNoDataMessage("RangeType.POSITIVE");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot0.getPieChart();
        boolean boolean3 = jFreeChart2.getAntiAlias();
        java.awt.Image image4 = null;
        jFreeChart2.setBackgroundImage(image4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot20.getDomainAxisForDataset(0);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setLowerBound((double) 100L);
        double double29 = numberAxis26.getAutoRangeMinimumSize();
        xYPlot20.setDomainAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        boolean boolean32 = xYPlot20.isSubplot();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0E-8d + "'", double29 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        java.awt.Paint paint3 = numberAxis0.getLabelPaint();
        boolean boolean4 = numberAxis0.isNegativeArrowVisible();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        numberAxis0.setUpArrow(shape7);
        numberAxis0.setFixedDimension((double) (byte) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isHighFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        int int9 = groupedStackedBarRenderer0.getRowCount();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(false);
        java.awt.Shape shape42 = statisticalLineAndShapeRenderer2.getBaseShape();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity45 = new org.jfree.chart.entity.TickLabelEntity(shape42, "", "DateTickUnit[DAY, 1]");
        java.lang.String str46 = tickLabelEntity45.getShapeCoords();
        java.lang.String str47 = tickLabelEntity45.toString();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-3,-3,3,3" + "'", str46.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ChartEntity: tooltip = " + "'", str47.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        statisticalLineAndShapeRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setCircular(true);
        ringPlot0.setStartAngle((double) 1L);
        boolean boolean6 = ringPlot0.isCircular();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle3.setHorizontalAlignment(horizontalAlignment5);
        java.awt.Font font7 = textTitle3.getFont();
        ringPlot0.setLabelFont(font7);
        ringPlot0.setSectionOutlinesVisible(true);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        ringPlot0.setNoDataMessagePaint(paint34);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(paint2);
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape1, paint2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        stackedBarRenderer3D5.setWallPaint((java.awt.Paint) color6);
        legendGraphic4.setOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        double double2 = rectangleInsets1.getBottom();
        double double4 = rectangleInsets1.extendWidth(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.05d + "'", double4 == 16.05d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
        boolean boolean5 = ganttRenderer0.hasListener((java.util.EventListener) waferMapPlot2);
        java.awt.Paint paint7 = ganttRenderer0.getSeriesPaint(11);
        boolean boolean10 = ganttRenderer0.getItemCreateEntity((int) (short) -1, (int) (short) -1);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        ganttRenderer0.setBaseStroke(stroke11, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(paint2);
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape1, paint2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLowerBound((double) 100L);
        numberAxis5.setUpperBound(4.0d);
        java.awt.Shape shape10 = numberAxis5.getDownArrow();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, 10.0d, 0.0d);
        legendGraphic4.setShape(shape13);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBaseItemLabelsVisible(true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint5 = polarPlot4.getBackgroundPaint();
        piePlot0.setShadowPaint(paint5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str9 = verticalAlignment8.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) 'a', (double) 10L);
        flowArrangement12.clear();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str17 = verticalAlignment16.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) 'a', (double) 10L);
        org.jfree.chart.block.CenterArrangement centerArrangement21 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource14, (org.jfree.chart.block.Arrangement) flowArrangement20, (org.jfree.chart.block.Arrangement) centerArrangement21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0, (org.jfree.chart.block.Arrangement) flowArrangement12, (org.jfree.chart.block.Arrangement) flowArrangement20);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str9.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str17.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 10);
        axisState1.setCursor((double) (-16777216));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, false);
        boolean boolean8 = groupedStackedBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Paint paint10 = groupedStackedBarRenderer0.getSeriesFillPaint(100);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test499");
//        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
//        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis14.setAutoRangeStickyZero(true);
//        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
//        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
//        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
//        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
//        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
//        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
//        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
//        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.util.RectangleInsets rectangleInsets31 = polarPlot30.getInsets();
//        polarPlot30.setBackgroundAlpha((-1.0f));
//        java.awt.Paint paint34 = polarPlot30.getRadiusGridlinePaint();
//        java.awt.Stroke stroke35 = polarPlot30.getRadiusGridlineStroke();
//        java.awt.Color color36 = java.awt.Color.blue;
//        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape24, paint29, stroke35, (java.awt.Paint) color36);
//        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        long long43 = month42.getLastMillisecond();
//        int int44 = month42.getYearValue();
//        boolean boolean46 = month42.equals((java.lang.Object) "AreaRendererEndType.LEVEL");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset47.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
//        java.util.List list52 = defaultCategoryDataset47.getColumnKeys();
//        int int53 = month42.compareTo((java.lang.Object) defaultCategoryDataset47);
//        try {
//            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "LGPL", "CategoryAnchor.END", categoryDataset40, (java.lang.Comparable) "VerticalAlignment.BOTTOM", (java.lang.Comparable) month42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(shape11);
//        org.junit.Assert.assertNotNull(shape12);
//        org.junit.Assert.assertNotNull(paint17);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNotNull(shape24);
//        org.junit.Assert.assertNotNull(stroke25);
//        org.junit.Assert.assertNotNull(paint27);
//        org.junit.Assert.assertNotNull(paint29);
//        org.junit.Assert.assertNotNull(rectangleInsets31);
//        org.junit.Assert.assertNotNull(paint34);
//        org.junit.Assert.assertNotNull(stroke35);
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(list52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.clone(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, (double) (short) 10, (double) (-16777216));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8, categoryLabelWidthType9, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = categoryLabelPosition11.getCategoryAnchor();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor12, (double) 5, 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(shape15);
    }
}

