import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape2 = null;
        try {
            java.awt.GradientPaint gradientPaint3 = standardGradientPaintTransformer0.transform(gradientPaint1, shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray4 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        try {
            java.awt.Shape shape6 = defaultDrawingSupplier5.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.DateTick dateTick5 = new org.jfree.chart.axis.DateTick(date0, "hi!", textAnchor2, textAnchor3, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        double[] doubleArray4 = new double[] { 0, '4' };
        double[] doubleArray7 = new double[] { 0, '4' };
        double[] doubleArray10 = new double[] { 0, '4' };
        double[] doubleArray13 = new double[] { 0, '4' };
        double[] doubleArray16 = new double[] { 0, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, (java.lang.Comparable[]) strArray1, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        java.util.Date date4 = null;
        try {
            segmentedTimeline3.addBaseTimelineException(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "", "ThreadContext", "VerticalAlignment.BOTTOM", shape6, paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("({0}, {1}) = {2}", font1, paint2, (float) (byte) -1, 100, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int3 = java.awt.Color.HSBtoRGB((float) 10, (float) (short) 1, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ThreadContext", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Comparable comparable0 = null;
        java.awt.Paint paint1 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        java.awt.Stroke stroke2 = null;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker(comparable0, paint1, stroke2, paint3, stroke4, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 0, (double) 1L, (int) (byte) -1, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        try {
            java.util.Date date2 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setRange((double) (short) 10, (double) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        try {
            groupedStackedBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryDataset10, (int) (byte) -1, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        groupedStackedBarRenderer1.drawRangeGridline(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis4, rectangle2D7, (double) 0);
        boolean boolean10 = gradientPaintTransformType0.equals((java.lang.Object) rectangle2D7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(0.0d, 0.0d);
        java.util.Date date4 = null;
        try {
            dateAxis0.setMaximumDate(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 10.0d, (float) (-1L), (float) (short) 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        try {
            textTitle0.setHorizontalAlignment(horizontalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.util.Date date2 = null;
        try {
            dateAxis0.setMaximumDate(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            taskSeriesCollection0.remove(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Paint paint0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getBackgroundPaint();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setAutoRangeStickyZero(true);
        java.awt.Paint paint16 = numberAxis13.getLabelPaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint26 = polarPlot25.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape10, true, paint16, false, paint18, stroke19, true, shape23, stroke24, paint26);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone(shape35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeStickyZero(true);
        java.awt.Paint paint41 = numberAxis38.getLabelPaint();
        java.awt.Paint paint43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint51 = polarPlot50.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape35, true, paint41, false, paint43, stroke44, true, shape48, stroke49, paint51);
        java.awt.Stroke stroke53 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', paint2, stroke24, paint43, stroke53, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue(100, 12, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double4 = dateAxis0.java2DToValue((double) 31, rectangle2D2, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        org.jfree.data.Range range2 = null;
        try {
            dateAxis0.setRange(range2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        boolean boolean18 = groupedStackedBarRenderer0.equals((java.lang.Object) '4');
        java.awt.Color color20 = java.awt.Color.CYAN;
        try {
            groupedStackedBarRenderer0.setSeriesOutlinePaint((-16777216), (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 100.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 1.0d, (java.lang.Number) (-1));
        defaultKeyedValue2.setValue((java.lang.Number) 100.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE9" + "'", str1.equals("ItemLabelAnchor.INSIDE9"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("({0}, {1}) = {2}", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (byte) 0);
        java.util.Date date6 = null;
        try {
            boolean boolean7 = segmentedTimeline3.containsDomainValue(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color0 = java.awt.Color.CYAN;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getRGBComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        try {
            java.util.Date date2 = dateTickUnit0.rollDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getBackgroundPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            polarPlot0.drawOutline(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getBackgroundPaint();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        groupedStackedBarRenderer4.setBaseStroke(stroke26);
        polarPlot2.setRadiusGridlineStroke(stroke26);
        java.awt.Stroke stroke32 = polarPlot2.getRadiusGridlineStroke();
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = polarPlot33.getInsets();
        polarPlot33.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint37 = polarPlot33.getRadiusGridlinePaint();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12, (java.awt.Paint) color1, stroke32, paint37, stroke38, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        double double2 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            taskSeriesCollection0.remove(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        java.util.Date date2 = null;
        try {
            segmentedTimeline0.addException(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(0.0d, 0.0d);
        try {
            dateAxis0.setRange((double) 0L, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            int int4 = taskSeriesCollection0.getSubIntervalCount((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor2, textAnchor3, (double) (short) 100);
        double double6 = numberTick5.getAngle();
        java.lang.String str7 = numberTick5.getText();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = itemLabelPosition3.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 5, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getStartValue((int) (byte) -1, (-16777216), (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("DateTickUnit[DAY, 1]", graphics2D1, (float) 12, (float) 31, textAnchor4, (double) 0L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) (short) -1, (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 1, (double) 1L, 31, (java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.toTimelineValue((long) (short) -1);
        long long14 = segmentedTimeline3.getSegmentSize();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        double double2 = rectangleInsets1.getBottom();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets1.createOutsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) 0.05d, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor2, textAnchor3, (double) (short) 100);
        java.lang.String str6 = textAnchor3.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str6.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 11L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "VerticalAlignment.BOTTOM", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", image3, "DateTickUnit[DAY, 1]", "", "ERROR : Relative To String");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.lang.Object obj1 = null;
        boolean boolean2 = blockBorder0.equals(obj1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RangeType.POSITIVE");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int2 = taskSeriesCollection0.getRowCount();
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.Number number5 = taskSeriesCollection0.getValue((java.lang.Comparable) "RangeType.POSITIVE", comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        boolean boolean11 = lengthConstraintType9.equals((java.lang.Object) standardCategoryURLGenerator10);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange18);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, (org.jfree.data.Range) dateRange25);
        java.lang.String str27 = rectangleConstraint26.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = rectangleConstraint26.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) 5, range8, lengthConstraintType9, (double) 11, (org.jfree.data.Range) dateRange15, lengthConstraintType28);
        org.jfree.data.Range range31 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange15, 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str27.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        projectInfo7.setVersion("ThreadContext");
        org.jfree.chart.ui.Library library12 = null;
        try {
            projectInfo7.addLibrary(library12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        groupedStackedBarRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.plot.Marker) intervalMarker13, rectangle2D14);
        boolean boolean16 = dateAxis7.isInverted();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        boolean boolean9 = numberAxis3.isVisible();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeStickyZero(true);
        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
        java.awt.Stroke stroke29 = null;
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("({0}, {1}) = {3} - {4}", "RangeType.POSITIVE", "DateTickUnit[DAY, 1]", "", shape11, stroke29, paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryAnchor0.equals(obj1);
        java.lang.String str3 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryAnchor.END" + "'", str3.equals("CategoryAnchor.END"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getBackgroundPaint();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setAutoRangeStickyZero(true);
        java.awt.Paint paint16 = numberAxis13.getLabelPaint();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint26 = polarPlot25.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape10, true, paint16, false, paint18, stroke19, true, shape23, stroke24, paint26);
        groupedStackedBarRenderer2.setBaseStroke(stroke24);
        polarPlot0.setRadiusGridlineStroke(stroke24);
        boolean boolean30 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(10, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D1, categoryPlot2, rectangle2D3, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) (short) 100, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        java.awt.Image image3 = polarPlot0.getBackgroundImage();
        try {
            polarPlot0.setBackgroundImageAlpha(100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        double double17 = groupedStackedBarRenderer0.getItemMargin();
        boolean boolean18 = groupedStackedBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray3 = new float[] { 10L, 86400000L };
        try {
            float[] floatArray4 = color0.getColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod4);
        task2.removeSubtask(task5);
        task5.setDescription("ItemLabelAnchor.INSIDE9");
        task5.setPercentComplete((double) 255);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int2 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.String str4 = multiplePiePlot3.getPlotType();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        java.lang.String str8 = dateTickMarkPosition7.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTickMarkPosition.START" + "'", str8.equals("DateTickMarkPosition.START"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        piePlot0.setLabelLinkPaint(paint16);
        try {
            piePlot0.setInteriorGap((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1L);
        float float5 = categoryLabelPosition4.getWidthRatio();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        paintList0.clear();
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "VerticalAlignment.BOTTOM", "SerialDate.weekInMonthToString(): invalid code.", shape7, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            float float5 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("DateTickUnit[DAY, 1]", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine1.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        polarPlot0.setBackgroundImageAlignment((int) (byte) 100);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            polarPlot0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod4);
        task2.removeSubtask(task5);
        task5.setDescription("ItemLabelAnchor.INSIDE9");
        boolean boolean10 = task5.equals((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 3600000L, "CategoryAnchor.END", textAnchor2, textAnchor3, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setAutoRangeStickyZero(true);
        numberAxis6.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (org.jfree.data.Range) dateRange17);
        dateAxis11.setRangeWithMargins((org.jfree.data.Range) dateRange14);
        numberAxis6.setDefaultAutoRange((org.jfree.data.Range) dateRange14);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection21 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection21);
        int int23 = taskSeriesCollection21.getRowCount();
        try {
            stackedBarRenderer3D0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.data.category.CategoryDataset) taskSeriesCollection21, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.0d + "'", number22.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        polarPlot0.markerChanged(markerChangeEvent2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (byte) 100, 0.0d, plotRenderingInfo6, point2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            piePlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double[] doubleArray8 = new double[] { 0L, '#', (-1.0d), 5, 1.0f, 10L };
        double[] doubleArray15 = new double[] { 0L, '#', (-1.0d), 5, 1.0f, 10L };
        double[] doubleArray22 = new double[] { 0L, '#', (-1.0d), 5, 1.0f, 10L };
        double[] doubleArray29 = new double[] { 0L, '#', (-1.0d), 5, 1.0f, 10L };
        double[][] doubleArray30 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.RIGHT", "", doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) 'a', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value((int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod1);
        org.jfree.data.time.TimePeriod timePeriod4 = null;
        org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", timePeriod4);
        task2.removeSubtask(task5);
        org.jfree.data.time.TimePeriod timePeriod7 = task2.getDuration();
        org.junit.Assert.assertNull(timePeriod7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        java.lang.String str6 = textTitle0.getText();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) true);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone(shape14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setAutoRangeStickyZero(true);
        java.awt.Paint paint20 = numberAxis17.getLabelPaint();
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint30 = polarPlot29.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape14, true, paint20, false, paint22, stroke23, true, shape27, stroke28, paint30);
        statisticalLineAndShapeRenderer2.setSeriesFillPaint(0, paint20);
        boolean boolean33 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke35 = statisticalLineAndShapeRenderer2.getSeriesOutlineStroke(11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(stroke35);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint15 = polarPlot14.getBackgroundPaint();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer16 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.clone(shape24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeStickyZero(true);
        java.awt.Paint paint30 = numberAxis27.getLabelPaint();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint40 = polarPlot39.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape24, true, paint30, false, paint32, stroke33, true, shape37, stroke38, paint40);
        groupedStackedBarRenderer16.setBaseStroke(stroke38);
        polarPlot14.setRadiusGridlineStroke(stroke38);
        java.awt.Stroke stroke44 = polarPlot14.getRadiusGridlineStroke();
        int int45 = dateTickUnit13.compareTo((java.lang.Object) polarPlot14);
        boolean boolean46 = groupedStackedBarRenderer0.hasListener((java.util.EventListener) polarPlot14);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        polarPlot14.datasetChanged(datasetChangeEvent47);
        try {
            polarPlot14.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) standardCategoryURLGenerator1);
        java.lang.Object obj3 = standardCategoryURLGenerator1.clone();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        int int6 = taskSeriesCollection4.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        try {
            java.lang.String str10 = standardCategoryURLGenerator1.generateURL((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color1 = java.awt.Color.getColor("DateTickUnit[DAY, 1]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        org.jfree.data.gantt.TaskSeries taskSeries5 = null;
        try {
            taskSeriesCollection0.add(taskSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        java.lang.String str6 = seriesChangeEvent5.toString();
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        polarPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Color color3 = java.awt.Color.BLUE;
        boolean boolean4 = polarPlot0.equals((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis7.getTickMarkPosition();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        dateAxis7.setDownArrow(shape11);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            stackedAreaRenderer1.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, 0, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        try {
            java.awt.Paint paint22 = xYPlot20.getQuadrantPaint(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setAutoRangeStickyZero(true);
        numberAxis10.setTickLabelsVisible(false);
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis10.setLabelFont(font15);
        numberAxis10.setVisible(false);
        float float19 = numberAxis10.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.axis.AxisState axisState26 = numberAxis10.draw(graphics2D20, (double) 1, rectangle2D22, rectangle2D23, rectangleEdge24, plotRenderingInfo25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis10, valueAxis27, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeStickyZero(true);
        java.awt.Paint paint34 = numberAxis31.getLabelPaint();
        xYPlot29.setQuadrantPaint(0, paint34);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = xYPlot29.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot29.getRangeAxisEdge((int) '#');
        try {
            double double39 = numberAxis0.lengthToJava2D((double) 100.0f, rectangle2D8, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(axisState26);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        groupedStackedBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            groupedStackedBarRenderer0.drawBackground(graphics2D7, categoryPlot8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long13 = segmentedTimeline3.getExceptionSegmentCount(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("SerialDate.weekInMonthToString(): invalid code.", font1);
        java.awt.Font font3 = null;
        try {
            textTitle2.setFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle0.setHorizontalAlignment(horizontalAlignment2);
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle0.arrange(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((int) ' ', 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = groupedStackedBarRenderer0.getPlot();
        org.jfree.data.KeyToGroupMap keyToGroupMap14 = null;
        try {
            groupedStackedBarRenderer0.setSeriesToGroupMap(keyToGroupMap14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'map' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryPlot13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, (double) (byte) -1, (double) 10L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 11L, (double) 100L, (double) (byte) 10, (double) 2.0f);
        double double7 = rectangleInsets5.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-21.0d) + "'", double7 == (-21.0d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint paint33 = null;
        try {
            xYPlot20.setDomainCrosshairPaint(paint33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset33);
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem37 = defaultBoxAndWhiskerCategoryDataset33.getItem((int) 'a', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(attributedString32);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) standardCategoryURLGenerator1);
        java.lang.String str3 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LengthConstraintType.FIXED" + "'", str3.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot0.getInsets();
        double double3 = rectangleInsets2.getBottom();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets2.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1L);
        java.lang.String str5 = textBlockAnchor1.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str5.equals("TextBlockAnchor.TOP_LEFT"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("ThreadContext");
        java.lang.String str10 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ThreadContext" + "'", str10.equals("ThreadContext"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getValue(10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Paint paint28 = xYPlot20.getDomainCrosshairPaint();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getRangeAxisForDataset(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str1 = dateTickUnit0.toString();
        int int2 = dateTickUnit0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str1.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) standardCategorySeriesLabelGenerator0);
        boolean boolean3 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) 100L);
        boolean boolean5 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) "hi!");
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone(shape15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeStickyZero(true);
        java.awt.Paint paint21 = numberAxis18.getLabelPaint();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint31 = polarPlot30.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape15, true, paint21, false, paint23, stroke24, true, shape28, stroke29, paint31);
        boolean boolean33 = textLine7.equals((java.lang.Object) legendItem32);
        legendItem32.setDatasetIndex((int) '#');
        java.awt.Shape shape36 = legendItem32.getLine();
        int int37 = legendItem32.getSeriesIndex();
        java.text.AttributedString attributedString38 = legendItem32.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset39 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem32.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset39);
        try {
            java.lang.String str42 = standardCategorySeriesLabelGenerator0.generateLabel((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset39, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(attributedString38);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(0.0d, 0.0d);
        java.lang.Object obj4 = dateAxis0.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int6 = dateTickUnit5.getCount();
        dateAxis0.setTickUnit(dateTickUnit5, false, false);
        java.text.DateFormat dateFormat10 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("({0}, {1}) = {3} - {4}", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor8, textAnchor9, (double) (short) 100);
        try {
            java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("({0}, {1}) = {2}", graphics2D1, (float) 31, (float) (-1), textAnchor4, (double) 10.0f, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ThreadContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list6 = dateAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        groupedStackedBarRenderer1.drawRangeGridline(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis4, rectangle2D7, (double) 0);
        groupedStackedBarRenderer1.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer1.setSeriesItemLabelFont((int) (short) 1, font15, false);
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = polarPlot18.getInsets();
        org.jfree.data.xy.XYDataset xYDataset20 = polarPlot18.getDataset();
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        polarPlot18.setRadiusGridlinePaint(paint21);
        org.jfree.chart.text.TextMeasurer textMeasurer24 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", font15, paint21, (float) 31, textMeasurer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.setHeight((double) (short) -1);
        textTitle8.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        textTitle8.setPadding(rectangleInsets16);
        textTitle0.setMargin(rectangleInsets16);
        java.awt.Color color20 = java.awt.Color.YELLOW;
        int int21 = color20.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset4, (java.lang.Comparable) 1561964399999L, (double) 2);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1L, (double) 0L, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        double double3 = numberAxis0.getFixedAutoRange();
        numberAxis0.setFixedAutoRange((double) (short) -1);
        numberAxis0.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Paint paint4 = numberAxis1.getLabelPaint();
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            polarPlot7.drawOutline(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            statisticalLineAndShapeRenderer2.drawDomainMarker(graphics2D38, categoryPlot39, categoryAxis40, categoryMarker41, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            piePlot0.setInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.toTimelineValue((long) (short) -1);
        segmentedTimeline3.setStartTime(0L);
        segmentedTimeline3.setStartTime(10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        groupedStackedBarRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.plot.Marker) intervalMarker13, rectangle2D14);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.clone(shape23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeStickyZero(true);
        java.awt.Paint paint29 = numberAxis26.getLabelPaint();
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint39 = polarPlot38.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape23, true, paint29, false, paint31, stroke32, true, shape36, stroke37, paint39);
        groupedStackedBarRenderer0.setBaseShape(shape36);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator43 = null;
        groupedStackedBarRenderer0.setSeriesToolTipGenerator(1, categoryToolTipGenerator43);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        double double5 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.resizeRange(0.0d, 0.0d);
        java.lang.Object obj10 = dateAxis6.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int12 = dateTickUnit11.getCount();
        dateAxis6.setTickUnit(dateTickUnit11, false, false);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset4, (java.lang.Comparable) false, 4.0d);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D42 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list43 = defaultKeyedValues2D42.getRowKeys();
        xYPlot20.drawDomainTickBands(graphics2D40, rectangle2D41, list43);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) ' ', (double) 1.0f, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setAutoRangeStickyZero(true);
        numberAxis4.setTickLabelsVisible(false);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis4.setLabelFont(font9);
        numberAxis4.setVisible(false);
        float float13 = numberAxis4.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.axis.AxisState axisState20 = numberAxis4.draw(graphics2D14, (double) 1, rectangle2D16, rectangle2D17, rectangleEdge18, plotRenderingInfo19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis21, xYItemRenderer22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setAutoRangeStickyZero(true);
        java.awt.Paint paint28 = numberAxis25.getLabelPaint();
        xYPlot23.setQuadrantPaint(0, paint28);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder30 = xYPlot23.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot23.getRangeAxisEdge((int) '#');
        try {
            double double33 = dateAxis0.valueToJava2D((double) 1L, rectangle2D2, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNotNull(axisState20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(seriesRenderingOrder30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setInfo("TextBlockAnchor.TOP_LEFT");
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("DateTickUnit[DAY, 1]", graphics2D1, (double) 7, (float) '#', (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        try {
            dateAxis0.setRangeAboutValue((double) ' ', (-5.8d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (34.9) <= upper (29.1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor4, textAnchor5, (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2019, "RangeType.POSITIVE", textAnchor5, textAnchor8, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor11 = numberTick10.getRotationAnchor();
        java.lang.String str12 = numberTick10.toString();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RangeType.POSITIVE" + "'", str12.equals("RangeType.POSITIVE"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 11, (java.lang.Object) 1);
        keyedObject2.setObject((java.lang.Object) "DateTickMarkPosition.START");
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.axis.AxisState axisState16 = numberAxis0.draw(graphics2D10, (double) 1, rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
        axisState16.cursorLeft((-1.0d));
        double double19 = axisState16.getMax();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(axisState16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int2 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.awt.Paint paint4 = multiplePiePlot3.getAggregatedItemsPaint();
        org.jfree.chart.util.TableOrder tableOrder5 = multiplePiePlot3.getDataExtractOrder();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(tableOrder5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot0.getInsets();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = polarPlot0.getOrientation();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(plotOrientation3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setTickLabelsVisible(false);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis28.setLabelFont(font33);
        numberAxis28.setVisible(false);
        float float37 = numberAxis28.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.axis.AxisState axisState44 = numberAxis28.draw(graphics2D38, (double) 1, rectangle2D40, rectangle2D41, rectangleEdge42, plotRenderingInfo43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis28, valueAxis45, xYItemRenderer46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setAutoRangeStickyZero(true);
        java.awt.Paint paint52 = numberAxis49.getLabelPaint();
        xYPlot47.setQuadrantPaint(0, paint52);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder54 = xYPlot47.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot47.getRangeAxisEdge((int) '#');
        java.lang.String str57 = rectangleEdge56.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        try {
            org.jfree.chart.axis.AxisState axisState59 = numberAxis21.draw(graphics2D23, (double) (short) 0, rectangle2D25, rectangle2D26, rectangleEdge56, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(axisState44);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(seriesRenderingOrder54);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleEdge.RIGHT" + "'", str57.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(0, (int) (byte) 100, dateFormat2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("VerticalAlignment.BOTTOM");
        projectInfo7.setName("({0}, {1}) = {2}");
        projectInfo7.setLicenceText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.ui.Library library14 = null;
        try {
            projectInfo7.addLibrary(library14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        try {
            java.lang.Number number8 = taskSeriesCollection0.getStartValue(2019, 255, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getDomainAxis((-1));
        boolean boolean31 = xYPlot20.isRangeZoomable();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("RectangleEdge.RIGHT", (org.jfree.data.time.TimePeriod) year6);
        try {
            int int9 = taskSeriesCollection1.getSubIntervalCount((java.lang.Comparable) "LengthConstraintType.FIXED", (java.lang.Comparable) "RectangleEdge.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = polarPlot31.getInsets();
        polarPlot31.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint35 = polarPlot31.getRadiusGridlinePaint();
        java.awt.Stroke stroke36 = polarPlot31.getRadiusGridlineStroke();
        java.awt.Color color37 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape25, paint30, stroke36, (java.awt.Paint) color37);
        piePlot0.setLabelOutlineStroke(stroke36);
        piePlot0.setInteriorGap((double) (short) 0);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator42 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator42);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        double double2 = rectangleInsets1.getBottom();
        double double3 = rectangleInsets1.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        int int3 = taskSeriesCollection1.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        java.awt.Paint paint5 = multiplePiePlot4.getAggregatedItemsPaint();
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, paint5);
        java.awt.color.ColorSpace colorSpace7 = null;
        java.awt.Color color8 = java.awt.Color.WHITE;
        float[] floatArray15 = new float[] { (-1.0f), (byte) 100, 10L, (byte) -1, 10.0f, ' ' };
        float[] floatArray16 = color8.getColorComponents(floatArray15);
        try {
            float[] floatArray17 = color0.getColorComponents(colorSpace7, floatArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        piePlot0.setLabelLinkPaint(paint16);
        double double27 = piePlot0.getLabelLinkMargin();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange39 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, (org.jfree.data.Range) dateRange39);
        dateAxis33.setRangeWithMargins((org.jfree.data.Range) dateRange36);
        numberAxis28.setDefaultAutoRange((org.jfree.data.Range) dateRange36);
        java.awt.Paint paint43 = numberAxis28.getLabelPaint();
        piePlot0.setLabelOutlinePaint(paint43);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(paint15);
        paintList0.setPaint(12, paint15);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Paint paint28 = xYPlot20.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot20.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot20.getDataset();
        java.awt.Stroke stroke31 = null;
        try {
            xYPlot20.setRangeCrosshairStroke(stroke31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(xYDataset30);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getRowKeys();
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { Double.NaN };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { Double.NaN };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { Double.NaN };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { Double.NaN };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.TOP_LEFT", "VerticalAlignment.BOTTOM", numberArray10);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange8);
        java.lang.String str10 = rectangleConstraint9.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint9.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint9.toFixedHeight((double) 12);
        try {
            org.jfree.chart.util.Size2D size2D14 = centerArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str10.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = null;
        try {
            org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, keyToGroupMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        groupedStackedBarRenderer2.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, rectangle2D8, (double) 0);
        groupedStackedBarRenderer2.setMaximumBarWidth((double) 11L);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLowerBound((double) 100L);
        numberAxis13.setUpperBound(4.0d);
        java.awt.Shape shape18 = numberAxis13.getDownArrow();
        groupedStackedBarRenderer2.setBaseShape(shape18);
        try {
            shapeList0.setShape((int) (short) -1, shape18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str1.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setRenderAsPercentages(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setAutoRangeStickyZero(true);
        numberAxis7.setTickLabelsVisible(false);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis7.setLabelFont(font12);
        numberAxis7.setVisible(false);
        float float16 = numberAxis7.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.axis.AxisState axisState23 = numberAxis7.draw(graphics2D17, (double) 1, rectangle2D19, rectangle2D20, rectangleEdge21, plotRenderingInfo22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis7, valueAxis24, xYItemRenderer25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        java.awt.Paint paint31 = numberAxis28.getLabelPaint();
        xYPlot26.setQuadrantPaint(0, paint31);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        xYPlot26.setDataset(xYDataset33);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        xYPlot26.setRangeAxis((int) '4', valueAxis36, false);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot26.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer40 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator43 = groupedStackedBarRenderer40.getToolTipGenerator(0, 0);
        boolean boolean44 = groupedStackedBarRenderer40.isDrawBarOutline();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        dateAxis47.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker53 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        groupedStackedBarRenderer40.drawRangeMarker(graphics2D45, categoryPlot46, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.plot.Marker) intervalMarker53, rectangle2D54);
        xYPlot26.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker53);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        try {
            stackedBarRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis5, (org.jfree.chart.plot.Marker) intervalMarker53, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertNotNull(axisState23);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(valueAxis39);
        org.junit.Assert.assertNull(categoryToolTipGenerator43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = segmentedTimeline3.getBaseTimeline();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.RIGHT", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.util.List list2 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 0, (java.lang.Comparable) year4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        boolean boolean2 = categoryLabelWidthType0.equals((java.lang.Object) 31);
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryLabelWidthType0.equals(obj3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setCircular(true);
        java.awt.Paint paint4 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setIgnoreNullValues(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = statisticalLineAndShapeRenderer2.getPlot();
        double double12 = statisticalLineAndShapeRenderer2.getItemLabelAnchorOffset();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setHeight((double) (short) -1);
        textTitle13.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        textTitle21.setHeight((double) (short) -1);
        textTitle21.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets29.getUnitType();
        textTitle21.setPadding(rectangleInsets29);
        textTitle13.setMargin(rectangleInsets29);
        boolean boolean33 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) rectangleInsets29);
        java.lang.Boolean boolean35 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible(7);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(boolean35);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("AreaRendererEndType.LEVEL", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, false);
        java.awt.Paint paint8 = groupedStackedBarRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(0, (int) (byte) 1, dateFormat2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor8, textAnchor9, (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick14 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2019, "RangeType.POSITIVE", textAnchor9, textAnchor12, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor18, textAnchor19, (double) (short) 100);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("({0}, {1}) = {3} - {4}", graphics2D1, (float) (byte) -1, (float) 1561964399999L, textAnchor12, (double) 31, textAnchor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1.0d + "'", number3.equals(1.0d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        polarPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = polarPlot0.getOutlinePaint();
        polarPlot0.addCornerTextItem("CategoryAnchor.END");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.Point point9 = polarPlot0.translateValueThetaRadiusToJava2D(0.0d, (double) 7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        textTitle8.setHeight((double) (short) -1);
        textTitle8.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        textTitle8.setPadding(rectangleInsets16);
        textTitle0.setMargin(rectangleInsets16);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        textTitle0.draw(graphics2D20, rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        groupedStackedBarRenderer0.setBaseStroke(stroke22);
        java.awt.Stroke stroke29 = groupedStackedBarRenderer0.getItemStroke(0, 255);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, (org.jfree.data.Range) dateRange11);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange8);
        java.lang.String str15 = dateRange8.toString();
        double double17 = dateRange8.constrain(1.0E-5d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str15.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0E-5d + "'", double17 == 1.0E-5d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = dateAxis18.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int21 = dateTickUnit20.getCount();
        dateAxis18.setTickUnit(dateTickUnit20, true, false);
        boolean boolean25 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection27 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range28 = groupedStackedBarRenderer26.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        try {
            statisticalLineAndShapeRenderer2.drawItem(graphics2D11, categoryItemRendererState13, rectangle2D14, categoryPlot15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.data.category.CategoryDataset) taskSeriesCollection27, (int) (byte) 10, 3, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition19);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        textLine1.removeFragment(textFragment5);
        java.lang.String str7 = textFragment5.getText();
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        groupedStackedBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        java.awt.Stroke stroke8 = groupedStackedBarRenderer0.getSeriesStroke(5);
        boolean boolean9 = groupedStackedBarRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        polarPlot0.removeChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = polarPlot0.getOutlinePaint();
        polarPlot0.addCornerTextItem("CategoryAnchor.END");
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot0);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getRowCount();
        defaultKeyedValues2D0.addValue((java.lang.Number) 0, (java.lang.Comparable) 0.0f, (java.lang.Comparable) (short) 0);
        defaultKeyedValues2D0.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int3 = dateTickUnit2.getCount();
        dateAxis0.setTickUnit(dateTickUnit2, true, false);
        java.util.Date date7 = null;
        try {
            java.lang.String str8 = dateTickUnit2.dateToString(date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        polarPlot0.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint4 = polarPlot0.getRadiusGridlinePaint();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot0.setRenderer(polarItemRenderer5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange6);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        boolean boolean11 = lengthConstraintType9.equals((java.lang.Object) standardCategoryURLGenerator10);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange18);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange22, (org.jfree.data.Range) dateRange25);
        java.lang.String str27 = rectangleConstraint26.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = rectangleConstraint26.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) 5, range8, lengthConstraintType9, (double) 11, (org.jfree.data.Range) dateRange15, lengthConstraintType28);
        double double30 = rectangleConstraint29.getWidth();
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str27.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 5.0d + "'", double30 == 5.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        groupedStackedBarRenderer0.drawRangeMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.plot.Marker) intervalMarker13, rectangle2D14);
        java.awt.Paint paint16 = dateAxis7.getAxisLinePaint();
        java.util.Date date17 = null;
        try {
            dateAxis7.setMaximumDate(date17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "TextBlockAnchor.TOP_LEFT", "({0}, {1}) = {2}");
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setAutoRangeStickyZero(true);
        numberAxis28.setTickLabelsVisible(false);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis28.setLabelFont(font33);
        numberAxis28.setVisible(false);
        float float37 = numberAxis28.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.axis.AxisState axisState44 = numberAxis28.draw(graphics2D38, (double) 1, rectangle2D40, rectangle2D41, rectangleEdge42, plotRenderingInfo43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis28, valueAxis45, xYItemRenderer46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        numberAxis49.setAutoRangeStickyZero(true);
        java.awt.Paint paint52 = numberAxis49.getLabelPaint();
        xYPlot47.setQuadrantPaint(0, paint52);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot47.setDataset(xYDataset54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        xYPlot47.setRangeAxis((int) '4', valueAxis57, false);
        org.jfree.chart.axis.ValueAxis valueAxis60 = xYPlot47.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot47.setRangeAxisLocation(axisLocation61, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation64 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation61, plotOrientation64);
        try {
            java.util.List list66 = numberAxis21.refreshTicks(graphics2D23, axisState25, rectangle2D26, rectangleEdge65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(axisState44);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(valueAxis60);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(plotOrientation64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = groupedStackedBarRenderer1.getToolTipGenerator(0, 0);
        boolean boolean5 = groupedStackedBarRenderer1.isDrawBarOutline();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        groupedStackedBarRenderer1.drawRangeMarker(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.plot.Marker) intervalMarker14, rectangle2D15);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.clone(shape24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeStickyZero(true);
        java.awt.Paint paint30 = numberAxis27.getLabelPaint();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint40 = polarPlot39.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape24, true, paint30, false, paint32, stroke33, true, shape37, stroke38, paint40);
        groupedStackedBarRenderer1.setBaseShape(shape37);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.clone(shape37);
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 11L, (java.lang.Object) shape37);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        java.awt.Color color7 = java.awt.Color.WHITE;
        float[] floatArray14 = new float[] { (-1.0f), (byte) 100, 10L, (byte) -1, 10.0f, ' ' };
        float[] floatArray15 = color7.getColorComponents(floatArray14);
        statisticalLineAndShapeRenderer2.setSeriesOutlinePaint(0, (java.awt.Paint) color7);
        int int17 = statisticalLineAndShapeRenderer2.getRowCount();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            textTitle0.setBounds(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        valueAxis33.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setAutoRangeStickyZero(true);
        numberAxis4.setTickLabelsVisible(false);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis4.setLabelFont(font9);
        numberAxis4.setVisible(false);
        float float13 = numberAxis4.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.axis.AxisState axisState20 = numberAxis4.draw(graphics2D14, (double) 1, rectangle2D16, rectangle2D17, rectangleEdge18, plotRenderingInfo19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis21, xYItemRenderer22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setAutoRangeStickyZero(true);
        numberAxis25.setTickLabelsVisible(false);
        java.awt.Font font30 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis25.setLabelFont(font30);
        numberAxis25.setVisible(false);
        float float34 = numberAxis25.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.axis.AxisState axisState41 = numberAxis25.draw(graphics2D35, (double) 1, rectangle2D37, rectangle2D38, rectangleEdge39, plotRenderingInfo40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis25, valueAxis42, xYItemRenderer43);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        numberAxis46.setAutoRangeStickyZero(true);
        java.awt.Paint paint49 = numberAxis46.getLabelPaint();
        xYPlot44.setQuadrantPaint(0, paint49);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        xYPlot44.setDataset(xYDataset51);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        xYPlot44.setRangeAxis((int) '4', valueAxis54, false);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot44.getDomainAxis();
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer58 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator61 = groupedStackedBarRenderer58.getToolTipGenerator(0, 0);
        boolean boolean62 = groupedStackedBarRenderer58.isDrawBarOutline();
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = null;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        dateAxis65.resizeRange(0.0d, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker71 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        groupedStackedBarRenderer58.drawRangeMarker(graphics2D63, categoryPlot64, (org.jfree.chart.axis.ValueAxis) dateAxis65, (org.jfree.chart.plot.Marker) intervalMarker71, rectangle2D72);
        xYPlot44.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker71);
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        try {
            stackedBarRenderer3D0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis21, (org.jfree.chart.plot.Marker) intervalMarker71, rectangle2D75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNotNull(axisState20);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 2.0f + "'", float34 == 2.0f);
        org.junit.Assert.assertNotNull(axisState41);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(valueAxis57);
        org.junit.Assert.assertNull(categoryToolTipGenerator61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        int int6 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        boolean boolean10 = numberAxis0.isAutoTickUnitSelection();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double14 = numberAxis0.lengthToJava2D((double) 100, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Color color0 = java.awt.Color.WHITE;
        float[] floatArray2 = new float[] { (byte) 1 };
        try {
            float[] floatArray3 = color0.getRGBColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        java.awt.Paint paint7 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = statisticalLineAndShapeRenderer2.getToolTipGenerator((int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot20.setQuadrantPaint(0, paint29);
        boolean boolean32 = xYPlot20.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat22 = null;
        dateAxis21.setDateFormatOverride(dateFormat22);
        xYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(0.0d, 0.0d);
        java.lang.Object obj4 = dateAxis0.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int6 = dateTickUnit5.getCount();
        dateAxis0.setTickUnit(dateTickUnit5, false, false);
        java.util.TimeZone timeZone10 = dateAxis0.getTimeZone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj4 = textTitle3.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle3.setHorizontalAlignment(horizontalAlignment5);
        java.awt.Font font7 = textTitle3.getFont();
        ringPlot0.setLabelFont(font7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            ringPlot0.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.axis.AxisState axisState16 = numberAxis0.draw(graphics2D10, (double) 1, rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
        axisState16.cursorLeft((-1.0d));
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection19 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection19);
        java.util.List list21 = taskSeriesCollection19.getRowKeys();
        axisState16.setTicks(list21);
        axisState16.setMax((double) 10L);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(axisState16);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Color color1 = java.awt.Color.WHITE;
        intervalBarRenderer0.setBaseFillPaint((java.awt.Paint) color1, false);
        java.awt.Font font4 = intervalBarRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        try {
            defaultCategoryDataset0.removeRow(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.Number number6 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 1.0E-8d, comparable4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Comparable comparable1 = null;
        int int2 = taskSeriesCollection0.getRowIndex(comparable1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        java.awt.Paint paint29 = xYPlot20.getRangeGridlinePaint();
        java.awt.Paint[] paintArray30 = null;
        java.awt.Paint[] paintArray31 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray31, strokeArray32, strokeArray33, shapeArray34);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        try {
            java.awt.Paint paint37 = defaultDrawingSupplier35.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot0.getInsets();
        java.awt.Stroke stroke3 = polarPlot0.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(0.0d, 0.0d);
        java.lang.Object obj4 = dateAxis0.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int6 = dateTickUnit5.getCount();
        dateAxis0.setTickUnit(dateTickUnit5, false, false);
        java.util.Date date10 = null;
        try {
            java.util.Date date11 = dateTickUnit5.rollDate(date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = categoryLabelPosition4.getCategoryAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        boolean boolean12 = categoryLabelWidthType10.equals((java.lang.Object) 31);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6, textAnchor8, (double) 11L, categoryLabelWidthType10, (float) 2);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str7.equals("TextBlockAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        piePlot0.setLabelLinkPaint(paint16);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot0.setBaseSectionOutlineStroke(stroke27);
        double double29 = piePlot0.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible((int) ' ', (java.lang.Boolean) true);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone(shape14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setAutoRangeStickyZero(true);
        java.awt.Paint paint20 = numberAxis17.getLabelPaint();
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint30 = polarPlot29.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape14, true, paint20, false, paint22, stroke23, true, shape27, stroke28, paint30);
        statisticalLineAndShapeRenderer2.setSeriesFillPaint(0, paint20);
        boolean boolean33 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Paint paint34 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(paint34);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.blue;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = piePlot0.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = java.awt.Color.YELLOW;
        stackedBarRenderer3D0.setWallPaint((java.awt.Paint) color1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D3, categoryPlot4, rectangle2D5, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        numberAxis1.setAutoTickUnitSelection(true);
        java.text.NumberFormat numberFormat23 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNull(numberFormat23);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        textTitle0.setPadding(rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle0.getMargin();
        double double13 = rectangleInsets11.trimHeight((double) (short) -1);
        double double14 = rectangleInsets11.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-53.0d) + "'", double13 == (-53.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalLineAndShapeRenderer3.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer3.setBaseShapesVisible(false);
        java.awt.Color color8 = java.awt.Color.WHITE;
        float[] floatArray15 = new float[] { (-1.0f), (byte) 100, 10L, (byte) -1, 10.0f, ' ' };
        float[] floatArray16 = color8.getColorComponents(floatArray15);
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(0, (java.awt.Paint) color8);
        java.awt.Color color18 = java.awt.Color.getColor("({0}, {1}) = {3} - {4}", color8);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("AreaRendererEndType.LEVEL", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("DateTickUnit[DAY, 1]");
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.toTimelineValue((long) (short) -1);
        segmentedTimeline3.setStartTime(0L);
        java.util.Date date16 = null;
        try {
            segmentedTimeline3.addException(date16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            lineRenderer3D0.drawRangeGridline(graphics2D1, categoryPlot2, valueAxis3, rectangle2D4, (-53.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.removeAll();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete(0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        int int2 = stackedAreaRenderer1.getPassCount();
        int int3 = stackedAreaRenderer1.getRowCount();
        boolean boolean4 = stackedAreaRenderer1.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Paint paint4 = numberAxis1.getLabelPaint();
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis8.getTickMarkPosition();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        dateAxis8.setDownArrow(shape12);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis8.getTickMarkPosition();
        dateAxis8.setLabelURL("TextAnchor.BASELINE_CENTER");
        dateAxis8.setFixedDimension((double) 1.0f);
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        double double21 = polarPlot7.getMaxRadius();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        xYPlot20.setRangeCrosshairValue((double) (byte) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = xYPlot20.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        try {
            xYPlot20.setDataset((int) (short) -1, xYDataset38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(plotOrientation36);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        statisticalLineAndShapeRenderer2.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, 1.0d, (double) 11, 1.0E-8d, 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        statisticalLineAndShapeRenderer2.setBaseItemLabelsVisible(true, true);
        boolean boolean13 = statisticalLineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Font font14 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("({0}, {1}) = {2}", "ThreadContext", "", image3, "({0}, {1}) = {2}", "({0}, {1}) = {2}", "ThreadContext");
        projectInfo7.setCopyright("ThreadContext");
        java.awt.Image image10 = null;
        projectInfo7.setLogo(image10);
        projectInfo7.setVersion("Layer.BACKGROUND");
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem26.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset33);
        java.lang.Number number37 = defaultBoxAndWhiskerCategoryDataset33.getMinRegularValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(attributedString32);
        org.junit.Assert.assertNull(number37);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        polarPlot0.removeChangeListener(plotChangeListener1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        polarPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot0.setRenderer(polarItemRenderer5);
        boolean boolean7 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = groupedStackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        try {
            java.lang.Comparable comparable4 = taskSeriesCollection1.getRowKey(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker2.setStartValue(1.0d);
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker2.setLabelPaint(paint5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) multiplePiePlot7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        try {
            multiplePiePlot7.setPieChart(jFreeChart9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getDomainAxis((-1));
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer32 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke34 = stackedAreaRenderer32.lookupSeriesOutlineStroke(2);
        xYPlot20.setDomainZeroBaselineStroke(stroke34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setAutoRangeStickyZero(true);
        numberAxis37.setTickLabelsVisible(false);
        java.awt.Font font42 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis37.setLabelFont(font42);
        numberAxis37.setVisible(false);
        float float46 = numberAxis37.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.axis.AxisState axisState53 = numberAxis37.draw(graphics2D47, (double) 1, rectangle2D49, rectangle2D50, rectangleEdge51, plotRenderingInfo52);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis37, valueAxis54, xYItemRenderer55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        numberAxis58.setAutoRangeStickyZero(true);
        java.awt.Paint paint61 = numberAxis58.getLabelPaint();
        xYPlot56.setQuadrantPaint(0, paint61);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        xYPlot56.setDataset(xYDataset63);
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        xYPlot56.setRangeAxis((int) '4', valueAxis66, false);
        org.jfree.chart.axis.ValueAxis valueAxis69 = xYPlot56.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot56.setRangeAxisLocation(axisLocation70, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation70, plotOrientation73);
        xYPlot20.setRangeAxisLocation(axisLocation70, false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 2.0f + "'", float46 == 2.0f);
        org.junit.Assert.assertNotNull(axisState53);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(valueAxis69);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int2 = taskSeriesCollection0.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        float float4 = multiplePiePlot3.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot20.setRangeAxisLocation(axisLocation34, false);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis38.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int41 = dateTickUnit40.getCount();
        dateAxis38.setTickUnit(dateTickUnit40, true, false);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = dateAxis38.valueToJava2D((double) (short) 0, rectangle2D46, rectangleEdge47);
        xYPlot20.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis38, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        xYPlot20.zoomRangeAxes(0.2d, plotRenderingInfo52, point2D53);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((-16777216));
        int int3 = shapeList0.size();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        polarPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        int int5 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        java.awt.Paint[] paintArray33 = null;
        java.awt.Paint[] paintArray34 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        xYPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer40 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        numberAxis43.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        groupedStackedBarRenderer40.drawRangeGridline(graphics2D41, categoryPlot42, (org.jfree.chart.axis.ValueAxis) numberAxis43, rectangle2D46, (double) 0);
        groupedStackedBarRenderer40.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font54 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer40.setSeriesItemLabelFont((int) (short) 1, font54, false);
        boolean boolean58 = groupedStackedBarRenderer40.equals((java.lang.Object) '4');
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        numberAxis59.setAutoRangeStickyZero(true);
        numberAxis59.setTickLabelsVisible(false);
        java.awt.Font font64 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis59.setLabelFont(font64);
        groupedStackedBarRenderer40.setBaseItemLabelFont(font64);
        double double67 = groupedStackedBarRenderer40.getUpperClip();
        boolean boolean68 = defaultDrawingSupplier38.equals((java.lang.Object) double67);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Color color2 = java.awt.Color.getColor("TextBlockAnchor.TOP_LEFT", 4);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor2, textAnchor3, (double) (short) 100);
        double double6 = numberTick5.getAngle();
        double double7 = numberTick5.getValue();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("({0}, {1}) = {2}");
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.lookupSeriesOutlinePaint((int) 'a');
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Stroke stroke13 = null;
        try {
            groupedStackedBarRenderer0.setBaseOutlineStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        long long13 = segmentedTimeline3.toTimelineValue((long) (short) -1);
        long long15 = segmentedTimeline3.getTimeFromLong((long) '#');
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getRollUnit();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange7);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer10);
        dateAxis1.setUpperBound((double) (short) 100);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer14 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.clone(shape22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setAutoRangeStickyZero(true);
        java.awt.Paint paint28 = numberAxis25.getLabelPaint();
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint38 = polarPlot37.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape22, true, paint28, false, paint30, stroke31, true, shape35, stroke36, paint38);
        groupedStackedBarRenderer14.setBaseStroke(stroke36);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection41 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection41);
        taskSeriesCollection41.validateObject();
        org.jfree.data.Range range44 = groupedStackedBarRenderer14.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection41);
        dateAxis1.setRange(range44);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLowerBound((double) 100L);
        numberAxis0.setUpperBound(4.0d);
        java.awt.Shape shape5 = numberAxis0.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint7 = numberAxis6.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis6.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit8, false, false);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double15 = numberAxis0.lengthToJava2D(4.0d, rectangle2D13, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        java.lang.String str31 = legendItem26.getDescription();
        java.awt.Shape shape32 = legendItem26.getShape();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "({0}, {1}) = {2}" + "'", str31.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        java.lang.Object obj6 = textTitle0.clone();
        textTitle0.setNotify(false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getDomainAxis((-1));
        int int31 = xYPlot20.getWeight();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Font font29 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis24.setLabelFont(font29);
        numberAxis24.setVisible(false);
        float float33 = numberAxis24.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.axis.AxisState axisState40 = numberAxis24.draw(graphics2D34, (double) 1, rectangle2D36, rectangle2D37, rectangleEdge38, plotRenderingInfo39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeStickyZero(true);
        java.awt.Paint paint48 = numberAxis45.getLabelPaint();
        xYPlot43.setQuadrantPaint(0, paint48);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder50 = xYPlot43.getSeriesRenderingOrder();
        xYPlot20.setSeriesRenderingOrder(seriesRenderingOrder50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = xYPlot20.getRangeAxisEdge(10);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 2.0f + "'", float33 == 2.0f);
        org.junit.Assert.assertNotNull(axisState40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(seriesRenderingOrder50);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.clone(shape8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setAutoRangeStickyZero(true);
        java.awt.Paint paint14 = numberAxis11.getLabelPaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint24 = polarPlot23.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape8, true, paint14, false, paint16, stroke17, true, shape21, stroke22, paint24);
        groupedStackedBarRenderer0.setBaseStroke(stroke22);
        groupedStackedBarRenderer0.setSeriesVisible(31, (java.lang.Boolean) false);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean32 = groupedStackedBarRenderer0.equals((java.lang.Object) "ThreadContext");
        groupedStackedBarRenderer0.setAutoPopulateSeriesPaint(true);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        groupedStackedBarRenderer0.setBaseFillPaint((java.awt.Paint) color35, true);
        java.awt.Font font38 = groupedStackedBarRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        textTitle0.setPadding(rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle0.getMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange18);
        java.lang.String str20 = rectangleConstraint19.toString();
        double double21 = rectangleConstraint19.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D22 = textTitle0.arrange(graphics2D12, rectangleConstraint19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str20.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setAutoPopulateSeriesStroke(false);
        boolean boolean11 = groupedStackedBarRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle((double) 0.0f);
        java.awt.Paint paint3 = null;
        ringPlot0.setLabelBackgroundPaint(paint3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setAutoRangeStickyZero(true);
        numberAxis6.setTickLabelsVisible(false);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis6.setLabelFont(font11);
        numberAxis6.setVisible(false);
        float float15 = numberAxis6.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.axis.AxisState axisState22 = numberAxis6.draw(graphics2D16, (double) 1, rectangle2D18, rectangle2D19, rectangleEdge20, plotRenderingInfo21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis6, valueAxis23, xYItemRenderer24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeStickyZero(true);
        java.awt.Paint paint30 = numberAxis27.getLabelPaint();
        xYPlot25.setQuadrantPaint(0, paint30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot25.setDataset(xYDataset32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        xYPlot25.setRangeAxis((int) '4', valueAxis35, false);
        java.awt.Stroke stroke38 = xYPlot25.getDomainCrosshairStroke();
        ringPlot0.setLabelOutlineStroke(stroke38);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertNotNull(axisState22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getGreen();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray9 = new float[] { (short) -1, 10.0f, '4', 2, 100.0f, 31 };
        try {
            float[] floatArray10 = color0.getComponents(colorSpace2, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 12, 10.0d);
        intervalMarker3.setStartValue(1.0d);
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        intervalMarker3.setLabelPaint(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = intervalMarker3.getLabelOffset();
        double double10 = rectangleInsets8.trimWidth(0.2d);
        java.lang.Class<?> wildcardClass11 = rectangleInsets8.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("ItemLabelAnchor.INSIDE9", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-5.8d) + "'", double10 == (-5.8d));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getBackgroundPaint();
        polarPlot0.setAngleLabelsVisible(true);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState6 = ringPlot0.initialise(graphics2D1, rectangle2D2, (org.jfree.chart.plot.PiePlot) ringPlot3, (java.lang.Integer) (-1), plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor3, textAnchor4, (double) (short) 100);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "", textAnchor3, textAnchor4, (double) (short) 100);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean8 = intervalBarRenderer7.getBaseItemLabelsVisible();
        boolean boolean9 = numberTick6.equals((java.lang.Object) boolean8);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick6.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        polarPlot0.removeChangeListener(plotChangeListener1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        polarPlot0.datasetChanged(datasetChangeEvent3);
        java.awt.Color color7 = java.awt.Color.getColor("ERROR : Relative To String", 255);
        polarPlot0.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.color.ColorSpace colorSpace9 = null;
        float[] floatArray12 = new float[] { 100L, 0.0f };
        try {
            float[] floatArray13 = color7.getColorComponents(colorSpace9, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeStickyZero(true);
        java.awt.Paint paint15 = numberAxis12.getLabelPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint25 = polarPlot24.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape9, true, paint15, false, paint17, stroke18, true, shape22, stroke23, paint25);
        boolean boolean27 = textLine1.equals((java.lang.Object) legendItem26);
        legendItem26.setDatasetIndex((int) '#');
        java.awt.Shape shape30 = legendItem26.getLine();
        int int31 = legendItem26.getSeriesIndex();
        java.text.AttributedString attributedString32 = legendItem26.getAttributedLabel();
        legendItem26.setDatasetIndex((int) (short) 0);
        legendItem26.setDatasetIndex((int) (byte) 100);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(attributedString32);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(false);
        java.awt.Shape shape42 = statisticalLineAndShapeRenderer2.getBaseShape();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity45 = new org.jfree.chart.entity.TickLabelEntity(shape42, "", "DateTickUnit[DAY, 1]");
        java.lang.String str46 = tickLabelEntity45.getToolTipText();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        double double17 = groupedStackedBarRenderer0.getItemMargin();
        boolean boolean20 = groupedStackedBarRenderer0.getItemCreateEntity((-23550), 1900);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.BOTTOM_LEFT", graphics2D1, (float) 8, (float) 2019, (double) 5, (float) 1900, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        dateAxis0.setLabelURL("TextAnchor.BASELINE_CENTER");
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange12, (org.jfree.data.Range) dateRange15);
        dateAxis0.setRange((org.jfree.data.Range) dateRange12);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        numberAxis21.setTickLabelsVisible(false);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis21.setLabelFont(font26);
        numberAxis21.setVisible(false);
        float float30 = numberAxis21.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.axis.AxisState axisState37 = numberAxis21.draw(graphics2D31, (double) 1, rectangle2D33, rectangle2D34, rectangleEdge35, plotRenderingInfo36);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis21, valueAxis38, xYItemRenderer39);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        numberAxis42.setAutoRangeStickyZero(true);
        java.awt.Paint paint45 = numberAxis42.getLabelPaint();
        xYPlot40.setQuadrantPaint(0, paint45);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder47 = xYPlot40.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot40.getRangeAxisEdge((int) '#');
        try {
            double double50 = dateAxis0.valueToJava2D((double) 10L, rectangle2D19, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNotNull(axisState37);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(seriesRenderingOrder47);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((-5.8d), (java.lang.Comparable) 31, (java.lang.Comparable) "UnitType.RELATIVE");
        java.lang.Comparable comparable5 = null;
        try {
            defaultCategoryDataset0.removeValue(comparable5, (java.lang.Comparable) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Paint paint3 = textFragment2.getPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textFragment2, jFreeChart4);
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent5.getChart();
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (int) '4');
        double double7 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset6);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke3 = stackedAreaRenderer1.lookupSeriesOutlineStroke(2);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        org.jfree.data.Range range7 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4);
        try {
            java.lang.Number number10 = taskSeriesCollection4.getEndValue(5, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setLowerBound((double) 100L);
        numberAxis10.setUpperBound(4.0d);
        java.awt.Shape shape15 = numberAxis10.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Paint paint17 = numberAxis16.getLabelPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis16.getTickUnit();
        numberAxis10.setTickUnit(numberTickUnit18, false, false);
        numberAxis0.setTickUnit(numberTickUnit18, false, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(numberTickUnit18);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        boolean boolean27 = xYPlot20.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            xYPlot20.handleClick(0, (-1), plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.get((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setAutoRangeStickyZero(true);
        numberAxis4.setTickLabelsVisible(false);
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis4.setLabelFont(font9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ThreadContext", font9);
        java.awt.Color color12 = java.awt.Color.MAGENTA;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setLowerBound((double) 100L);
        numberAxis13.setInverted(false);
        org.jfree.chart.plot.Plot plot18 = numberAxis13.getPlot();
        numberAxis13.setUpperMargin(0.25d);
        boolean boolean21 = color12.equals((java.lang.Object) 0.25d);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("Layer.BACKGROUND", font9, (java.awt.Paint) color12, (float) (byte) -1);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.BOTTOM_LEFT", font1, (java.awt.Paint) color12, (float) 2, textMeasurer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomOutset(0.0d);
        java.awt.Paint paint3 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        int int1 = boxAndWhiskerRenderer0.getColumnCount();
        java.awt.Paint paint2 = boxAndWhiskerRenderer0.getArtifactPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        java.awt.Image image3 = polarPlot0.getBackgroundImage();
        polarPlot0.setBackgroundAlpha((float) 7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = groupedStackedBarRenderer0.getDrawingSupplier();
        boolean boolean12 = groupedStackedBarRenderer0.getItemCreateEntity((-16777216), 4);
        org.junit.Assert.assertNull(drawingSupplier9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setAutoRangeStickyZero(true);
        java.awt.Paint paint17 = numberAxis14.getLabelPaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint27 = polarPlot26.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape11, true, paint17, false, paint19, stroke20, true, shape24, stroke25, paint27);
        boolean boolean29 = textLine3.equals((java.lang.Object) legendItem28);
        legendItem28.setDatasetIndex((int) '#');
        java.awt.Shape shape32 = legendItem28.getLine();
        int int33 = legendItem28.getSeriesIndex();
        java.text.AttributedString attributedString34 = legendItem28.getAttributedLabel();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset35 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        legendItem28.setDataset((org.jfree.data.general.Dataset) defaultBoxAndWhiskerCategoryDataset35);
        org.jfree.data.Range range37 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset35);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset35, (int) (byte) 100);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(attributedString34);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(pieDataset39);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge((int) '#');
        java.lang.String str30 = rectangleEdge29.toString();
        boolean boolean31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge29);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleEdge.RIGHT" + "'", str30.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.LEVEL" + "'", str1.equals("AreaRendererEndType.LEVEL"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot20.getDomainAxis((-1));
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer32 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Stroke stroke34 = stackedAreaRenderer32.lookupSeriesOutlineStroke(2);
        xYPlot20.setDomainZeroBaselineStroke(stroke34);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot20.getRangeAxisForDataset((-23550));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setRange((double) (short) 10, (double) ' ');
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis0.valueToJava2D((double) 'a', rectangle2D5, rectangleEdge6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = groupedStackedBarRenderer0.getToolTipGenerator(0, 0);
        boolean boolean4 = groupedStackedBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        groupedStackedBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        java.lang.Object obj7 = groupedStackedBarRenderer0.clone();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.axis.AxisState axisState16 = numberAxis0.draw(graphics2D10, (double) 1, rectangle2D12, rectangle2D13, rectangleEdge14, plotRenderingInfo15);
        java.util.List list17 = null;
        axisState16.setTicks(list17);
        java.util.List list19 = null;
        axisState16.setTicks(list19);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(axisState16);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        dateAxis0.setDownArrow(shape4);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        dateAxis0.setLabelURL("TextAnchor.BASELINE_CENTER");
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange12, (org.jfree.data.Range) dateRange15);
        dateAxis0.setRange((org.jfree.data.Range) dateRange12);
        java.text.DateFormat dateFormat18 = null;
        dateAxis0.setDateFormatOverride(dateFormat18);
        org.junit.Assert.assertNotNull(dateTickMarkPosition1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("Pie Plot", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("({0}, {1}) = {2}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeStickyZero(true);
        java.awt.Paint paint24 = numberAxis21.getLabelPaint();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint34 = polarPlot33.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape18, true, paint24, false, paint26, stroke27, true, shape31, stroke32, paint34);
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) ' ', paint26, true);
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(false);
        boolean boolean42 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        groupedStackedBarRenderer0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis3, rectangle2D6, (double) 0);
        groupedStackedBarRenderer0.setSeriesCreateEntities((int) '4', (java.lang.Boolean) false, false);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        groupedStackedBarRenderer0.setSeriesItemLabelFont((int) (short) 1, font14, false);
        double double17 = groupedStackedBarRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalLineAndShapeRenderer20.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer20.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = statisticalLineAndShapeRenderer20.getLegendItemLabelGenerator();
        boolean boolean27 = statisticalLineAndShapeRenderer20.getItemLineVisible((int) (short) 100, 0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.clone(shape36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setAutoRangeStickyZero(true);
        java.awt.Paint paint42 = numberAxis39.getLabelPaint();
        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint52 = polarPlot51.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape36, true, paint42, false, paint44, stroke45, true, shape49, stroke50, paint52);
        statisticalLineAndShapeRenderer20.setSeriesPaint((int) ' ', paint44, true);
        groupedStackedBarRenderer0.setBaseOutlinePaint(paint44, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator59 = groupedStackedBarRenderer0.getSeriesToolTipGenerator((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator60 = groupedStackedBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(categoryToolTipGenerator59);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator60);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color3 = java.awt.Color.getColor("ItemLabelAnchor.INSIDE9", color2);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone(shape15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeStickyZero(true);
        java.awt.Paint paint21 = numberAxis18.getLabelPaint();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint31 = polarPlot30.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape15, true, paint21, false, paint23, stroke24, true, shape28, stroke29, paint31);
        java.awt.Paint paint33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = polarPlot34.getInsets();
        polarPlot34.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint38 = polarPlot34.getRadiusGridlinePaint();
        java.awt.Stroke stroke39 = polarPlot34.getRadiusGridlineStroke();
        java.awt.Color color40 = java.awt.Color.blue;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("", "TextAnchor.BASELINE_CENTER", "", "({0}, {1}) = {2}", shape28, paint33, stroke39, (java.awt.Paint) color40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection43 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number44 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection43);
        int int45 = taskSeriesCollection43.getRowCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot46 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection43);
        java.awt.Paint paint47 = multiplePiePlot46.getAggregatedItemsPaint();
        boolean boolean48 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color42, paint47);
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer49 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        numberAxis52.setLowerBound((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        groupedStackedBarRenderer49.drawRangeGridline(graphics2D50, categoryPlot51, (org.jfree.chart.axis.ValueAxis) numberAxis52, rectangle2D55, (double) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier58 = groupedStackedBarRenderer49.getDrawingSupplier();
        java.awt.Stroke stroke61 = groupedStackedBarRenderer49.getItemStroke(0, 2);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.0f, (java.awt.Paint) color2, stroke39, paint47, stroke61, (float) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0.0d + "'", number44.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(drawingSupplier58);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset(xYDataset27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        xYPlot20.setRangeAxis((int) '4', valueAxis30, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot20.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot20.setRangeAxisLocation(axisLocation34, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation34, plotOrientation37);
        java.lang.String str39 = axisLocation34.toString();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str39.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis1.setLabelFont(font6);
        numberAxis1.setVisible(false);
        float float10 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.axis.AxisState axisState17 = numberAxis1.draw(graphics2D11, (double) 1, rectangle2D13, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeStickyZero(true);
        java.awt.Paint paint25 = numberAxis22.getLabelPaint();
        xYPlot20.setQuadrantPaint(0, paint25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder27 = xYPlot20.getSeriesRenderingOrder();
        java.awt.Paint paint28 = xYPlot20.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot20.getDomainAxisLocation();
        boolean boolean31 = axisLocation29.equals((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(axisState17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = java.awt.Color.YELLOW;
        stackedBarRenderer3D0.setWallPaint((java.awt.Paint) color1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        double double6 = categoryItemRendererState5.getSeriesRunningTotal();
        org.jfree.chart.entity.EntityCollection entityCollection7 = categoryItemRendererState5.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setAutoRangeStickyZero(true);
        numberAxis13.setTickLabelsVisible(false);
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis13.setLabelFont(font18);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(0.0d, (double) (short) 100);
        numberAxis13.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        numberAxis13.setAutoTickUnitSelection(true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection26, 0);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection26, (double) 1.0f);
        try {
            stackedBarRenderer3D0.drawItem(graphics2D3, categoryItemRendererState5, rectangle2D8, categoryPlot9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.data.category.CategoryDataset) taskSeriesCollection26, 0, 11, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(entityCollection7);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.0d + "'", number27.equals(0.0d));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(pieDataset30);
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, 0);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (int) '4');
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D7 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list8 = defaultKeyedValues2D7.getRowKeys();
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 0, 2019, (int) (short) 100, 0, dateFormat13);
        int int15 = defaultKeyedValues2D7.getRowIndex((java.lang.Comparable) dateTickUnit14);
        int int16 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) dateTickUnit14);
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setMargin(0.0d, (double) (short) 0, (double) '4', (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        textTitle0.setPadding(rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle0.getMargin();
        double double13 = rectangleInsets11.calculateBottomOutset((double) 86400000L);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setHeight((double) (short) -1);
        textTitle0.setWidth(0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textTitle0);
        java.awt.Color color6 = java.awt.Color.MAGENTA;
        boolean boolean7 = textTitle0.equals((java.lang.Object) color6);
        java.lang.String str8 = textTitle0.getText();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.lang.Boolean boolean2 = groupedStackedBarRenderer0.getSeriesVisible((int) (short) -1);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        numberAxis0.setVisible(false);
        float float9 = numberAxis0.getTickMarkOutsideLength();
        numberAxis0.centerRange((double) (-1));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("CategoryAnchor.END");
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 10.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot0.getInsets();
        polarPlot0.removeCornerTextItem("RectangleEdge.RIGHT");
        int int5 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("TextAnchor.BASELINE_CENTER");
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 1, 0, (int) (short) 1);
        boolean boolean9 = segmentedTimeline7.equals((java.lang.Object) (byte) 0);
        segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
        long long11 = segmentedTimeline3.getSegmentsGroupSize();
        boolean boolean14 = segmentedTimeline3.containsDomainRange((long) '#', (long) (byte) 100);
        long long15 = segmentedTimeline3.getSegmentsIncludedSize();
        long long16 = segmentedTimeline3.getSegmentsIncludedSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = new org.jfree.chart.axis.SegmentedTimeline(1L, 1, (int) (byte) 10);
        long long21 = segmentedTimeline20.getSegmentsIncludedSize();
        segmentedTimeline3.setBaseTimeline(segmentedTimeline20);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 11L + "'", long11 == 11L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalLineAndShapeRenderer2.getLegendItemLabelGenerator();
        boolean boolean9 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) (short) 100, 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = statisticalLineAndShapeRenderer2.getDrawingSupplier();
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getBaseItemLabelPaint();
        int int12 = statisticalLineAndShapeRenderer2.getRowCount();
        boolean boolean15 = statisticalLineAndShapeRenderer2.getItemCreateEntity((int) '4', 1900);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100L, 1.0d);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeStickyZero(true);
        java.awt.Paint paint18 = numberAxis15.getLabelPaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint28 = polarPlot27.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "({0}, {1}) = {2}", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "hi!", true, shape12, true, paint18, false, paint20, stroke21, true, shape25, stroke26, paint28);
        boolean boolean30 = textLine4.equals((java.lang.Object) legendItem29);
        legendItem29.setDatasetIndex((int) '#');
        java.awt.Shape shape33 = legendItem29.getLine();
        boolean boolean34 = meanAndStandardDeviation2.equals((java.lang.Object) legendItem29);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }
}

