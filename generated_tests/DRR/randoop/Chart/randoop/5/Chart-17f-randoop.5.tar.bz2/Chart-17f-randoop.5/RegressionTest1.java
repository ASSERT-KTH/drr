import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test02");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.getMonth();
//        int int4 = spreadsheetDate2.toSerial();
//        int int5 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int8 = spreadsheetDate7.getMonth();
//        int int9 = spreadsheetDate7.toSerial();
//        int int10 = spreadsheetDate7.toSerial();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(1, serialDate13);
//        java.lang.String str15 = serialDate13.getDescription();
//        java.lang.Class<?> wildcardClass16 = serialDate13.getClass();
//        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate7.getEndOfCurrentMonth(serialDate13);
//        boolean boolean18 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int22 = spreadsheetDate21.getMonth();
//        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate21.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(1, serialDate27);
//        java.lang.String str29 = serialDate27.getDescription();
//        int int30 = spreadsheetDate21.compare(serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean32 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int37 = spreadsheetDate36.getMonth();
//        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate36.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate34.getEndOfCurrentMonth(serialDate39);
//        boolean boolean41 = spreadsheetDate7.isBefore(serialDate39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int44 = spreadsheetDate43.getMonth();
//        int int45 = spreadsheetDate43.toSerial();
//        int int46 = spreadsheetDate43.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int49 = spreadsheetDate48.getMonth();
//        int int50 = spreadsheetDate48.toSerial();
//        int int51 = spreadsheetDate48.toSerial();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(1, serialDate54);
//        java.lang.String str56 = serialDate54.getDescription();
//        java.lang.Class<?> wildcardClass57 = serialDate54.getClass();
//        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate48.getEndOfCurrentMonth(serialDate54);
//        boolean boolean59 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        boolean boolean60 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        try {
//            org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addDays(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-43619) + "'", int30 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNull(str56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("June");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        int int16 = month13.compareTo((java.lang.Object) (-1L));
        java.util.Date date17 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date17, timeZone21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date17);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date17, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date2, timeZone29);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        int int38 = month35.compareTo((java.lang.Object) (-1L));
        java.util.Date date39 = month35.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date39, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date2, timeZone41);
        java.util.Calendar calendar44 = null;
        try {
            year43.peg(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int4 = spreadsheetDate3.getMonth();
//        int int5 = spreadsheetDate3.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int9 = spreadsheetDate8.getMonth();
//        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate8.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(1, serialDate14);
//        java.lang.String str16 = serialDate14.getDescription();
//        int int17 = spreadsheetDate8.compare(serialDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.getMonth();
//        int int21 = spreadsheetDate19.toSerial();
//        boolean boolean22 = spreadsheetDate3.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int26 = spreadsheetDate25.getMonth();
//        int int27 = spreadsheetDate25.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int31 = spreadsheetDate30.getMonth();
//        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate30.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate36 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(1, serialDate36);
//        java.lang.String str38 = serialDate36.getDescription();
//        int int39 = spreadsheetDate30.compare(serialDate36);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int42 = spreadsheetDate41.getMonth();
//        int int43 = spreadsheetDate41.toSerial();
//        boolean boolean44 = spreadsheetDate25.isInRange(serialDate36, (org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean45 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        int int46 = spreadsheetDate41.getDayOfWeek();
//        int int47 = spreadsheetDate41.getDayOfMonth();
//        int int48 = spreadsheetDate41.getYYYY();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-43619) + "'", int17 == (-43619));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-43619) + "'", int39 == (-43619));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1900 + "'", int48 == 1900);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        int int14 = timeSeries7.getMaximumItemCount();
        java.lang.String str15 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 35.0d);
        java.lang.String str12 = timeSeries7.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries7.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) '#');
        long long6 = fixedMillisecond3.getMiddleMillisecond();
        long long7 = fixedMillisecond3.getSerialIndex();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, class8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        long long14 = fixedMillisecond11.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond11.getLastMillisecond(calendar15);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond11.getMiddleMillisecond(calendar17);
        long long19 = fixedMillisecond11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 1);
        boolean boolean22 = spreadsheetDate1.equals((java.lang.Object) timeSeries9);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        int int16 = month13.compareTo((java.lang.Object) (-1L));
        java.util.Date date17 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date17, timeZone21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date17);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date17, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date2, timeZone29);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        int int38 = month35.compareTo((java.lang.Object) (-1L));
        java.util.Date date39 = month35.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date39, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date2, timeZone41);
        int int44 = year43.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1969 + "'", int44 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1969);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, (-1));
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, (java.lang.Class) wildcardClass8);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        int int18 = month16.getMonth();
        boolean boolean20 = month16.equals((java.lang.Object) 10);
        try {
            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 43629L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of java.text.DateFormatSymbols.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(1, serialDate8);
//        java.lang.String str10 = serialDate8.getDescription();
//        int int11 = spreadsheetDate2.compare(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int13 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int18 = spreadsheetDate17.getMonth();
//        int int19 = spreadsheetDate17.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int23 = spreadsheetDate22.getMonth();
//        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(1, serialDate28);
//        java.lang.String str30 = serialDate28.getDescription();
//        int int31 = spreadsheetDate22.compare(serialDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int34 = spreadsheetDate33.getMonth();
//        int int35 = spreadsheetDate33.toSerial();
//        boolean boolean36 = spreadsheetDate17.isInRange(serialDate28, (org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int40 = spreadsheetDate39.getMonth();
//        int int41 = spreadsheetDate39.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int45 = spreadsheetDate44.getMonth();
//        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate44.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate50 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(1, serialDate50);
//        java.lang.String str52 = serialDate50.getDescription();
//        int int53 = spreadsheetDate44.compare(serialDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int56 = spreadsheetDate55.getMonth();
//        int int57 = spreadsheetDate55.toSerial();
//        boolean boolean58 = spreadsheetDate39.isInRange(serialDate50, (org.jfree.data.time.SerialDate) spreadsheetDate55);
//        boolean boolean59 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        org.jfree.data.time.SerialDate serialDate60 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-43619) + "'", int11 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-43619) + "'", int31 == (-43619));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNull(str52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-43619) + "'", int53 == (-43619));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(serialDate60);
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        java.util.Collection collection9 = timeSeries7.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 0);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 100.0f);
        int int15 = fixedMillisecond11.compareTo((java.lang.Object) 10);
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.lang.Comparable comparable17 = timeSeries7.getKey();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener18);
        timeSeries7.setMaximumItemAge((long) 1900);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(comparable17);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        int int13 = timeSeries7.getMaximumItemCount();
        long long14 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) 2958465);
        try {
            timeSeries7.delete(2, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 35.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries7.getNextTimePeriod();
        java.util.List list13 = timeSeries7.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date16 = fixedMillisecond15.getEnd();
        long long17 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        boolean boolean19 = timeSeries7.getNotify();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32L + "'", long17 == 32L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int4 = spreadsheetDate3.getMonth();
//        int int5 = spreadsheetDate3.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int9 = spreadsheetDate8.getMonth();
//        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate8.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(1, serialDate14);
//        java.lang.String str16 = serialDate14.getDescription();
//        int int17 = spreadsheetDate8.compare(serialDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.getMonth();
//        int int21 = spreadsheetDate19.toSerial();
//        boolean boolean22 = spreadsheetDate3.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) '#');
//        long long28 = fixedMillisecond25.getMiddleMillisecond();
//        long long29 = fixedMillisecond25.getSerialIndex();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25, class30);
//        boolean boolean32 = timeSeries31.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
//        int int35 = timeSeries31.getItemCount();
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) spreadsheetDate3, (java.lang.Object) int35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int39 = spreadsheetDate38.getMonth();
//        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate38.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(1, serialDate44);
//        java.lang.String str46 = serialDate44.getDescription();
//        int int47 = spreadsheetDate38.compare(serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int50 = spreadsheetDate49.getMonth();
//        org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate49.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate55 = day54.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays(1, serialDate55);
//        java.lang.String str57 = serialDate55.getDescription();
//        int int58 = spreadsheetDate49.compare(serialDate55);
//        int int59 = spreadsheetDate49.getYYYY();
//        org.jfree.data.time.SerialDate serialDate60 = serialDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int65 = spreadsheetDate64.getMonth();
//        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate64.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate62.getEndOfCurrentMonth(serialDate67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate70 = day69.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int73 = spreadsheetDate72.getMonth();
//        int int74 = spreadsheetDate72.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate72);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int78 = spreadsheetDate77.getMonth();
//        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate77.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate83 = day82.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addDays(1, serialDate83);
//        java.lang.String str85 = serialDate83.getDescription();
//        int int86 = spreadsheetDate77.compare(serialDate83);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int89 = spreadsheetDate88.getMonth();
//        int int90 = spreadsheetDate88.toSerial();
//        boolean boolean91 = spreadsheetDate72.isInRange(serialDate83, (org.jfree.data.time.SerialDate) spreadsheetDate88);
//        org.jfree.data.time.SerialDate serialDate92 = serialDate70.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate72);
//        boolean boolean93 = spreadsheetDate62.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate72);
//        boolean boolean95 = spreadsheetDate3.isInRange(serialDate44, (org.jfree.data.time.SerialDate) spreadsheetDate72, (int) (byte) 1);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-43619) + "'", int17 == (-43619));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-43619) + "'", int47 == (-43619));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-43619) + "'", int58 == (-43619));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1900 + "'", int59 == 1900);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10 + "'", int74 == 10);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNull(str85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-43619) + "'", int86 == (-43619));
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 10 + "'", int90 == 10);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
//        org.junit.Assert.assertNotNull(serialDate92);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        boolean boolean6 = month2.equals((java.lang.Object) 10);
        java.lang.String str7 = month2.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 52" + "'", str7.equals("October 52"));
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
//        java.text.DateFormatSymbols dateFormatSymbols9 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        java.lang.Class<?> wildcardClass10 = dateFormatSymbols9.getClass();
//        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass10);
//        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 1, (java.lang.Object) timeSeries12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) '#');
//        long long18 = fixedMillisecond15.getMiddleMillisecond();
//        long long19 = fixedMillisecond15.getSerialIndex();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond15, class20);
//        java.lang.String str22 = timeSeries21.getDomainDescription();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 35.0d);
//        long long26 = day23.getFirstMillisecond();
//        long long27 = day23.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.previous();
//        int int35 = month32.compareTo((java.lang.Object) (-1L));
//        java.util.Date date36 = month32.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month32.next();
//        java.lang.Number number38 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) month32);
//        java.util.Date date39 = month32.getStart();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(dateFormatSymbols9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNull(inputStream11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43629L + "'", long27 == 43629L);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 35.0d + "'", number38.equals(35.0d));
//        org.junit.Assert.assertNotNull(date39);
//    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        int int14 = month11.compareTo((java.lang.Object) (-1L));
        java.util.Date date15 = month11.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) '#');
        java.util.Calendar calendar21 = null;
        fixedMillisecond18.peg(calendar21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) '#');
        long long28 = fixedMillisecond25.getMiddleMillisecond();
        long long29 = fixedMillisecond25.getSerialIndex();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25, class30);
        java.lang.String str32 = timeSeries31.getDomainDescription();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 35.0d);
        java.lang.String str36 = timeSeries31.getDescription();
        java.util.List list37 = timeSeries31.getItems();
        java.lang.String str38 = timeSeries31.getRangeDescription();
        java.lang.Class<?> wildcardClass39 = timeSeries31.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, (java.lang.Class) wildcardClass39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) '#');
        long long45 = fixedMillisecond42.getMiddleMillisecond();
        long long46 = fixedMillisecond42.getSerialIndex();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond42, class47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
        timeSeries40.setMaximumItemCount(2958465);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Object obj2 = null;
        boolean boolean3 = spreadsheetDate1.equals(obj2);
        boolean boolean5 = spreadsheetDate1.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate6 = null;
        try {
            boolean boolean7 = spreadsheetDate1.isOn(serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1900, 10, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        java.text.DateFormatSymbols dateFormatSymbols4 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass5 = dateFormatSymbols4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "13-June-2019", "ThreadContext", class6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", class6);
        org.junit.Assert.assertNotNull(dateFormatSymbols4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNull(uRL8);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        java.text.DateFormatSymbols dateFormatSymbols1 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass2 = dateFormatSymbols1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass2);
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader4);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader4);
        org.junit.Assert.assertNotNull(dateFormatSymbols1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
        org.junit.Assert.assertNotNull(classLoader4);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("9-January-1900");
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int6 = spreadsheetDate5.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate5.getPreviousDayOfWeek((int) (short) 1);
        boolean boolean9 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int5 = month2.compareTo((java.lang.Object) (-1L));
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        long long9 = fixedMillisecond7.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-60500016000001L) + "'", long8 == (-60500016000001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-60500016000001L) + "'", long9 == (-60500016000001L));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date3 = fixedMillisecond2.getEnd();
        java.text.DateFormatSymbols dateFormatSymbols8 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass9 = dateFormatSymbols8.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        int int17 = month14.compareTo((java.lang.Object) (-1L));
        java.util.Date date18 = month14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone22);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date18);
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date18, timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date3, timeZone30);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.previous();
        int int39 = month36.compareTo((java.lang.Object) (-1L));
        java.util.Date date40 = month36.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date40, timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date3, timeZone42);
        long long45 = year44.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) '#');
        long long50 = fixedMillisecond47.getMiddleMillisecond();
        long long51 = fixedMillisecond47.getSerialIndex();
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond47, class52);
        boolean boolean54 = timeSeries53.getNotify();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.previous();
        int int60 = month57.compareTo((java.lang.Object) (-1L));
        java.util.Date date61 = month57.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) '#');
        java.util.Calendar calendar67 = null;
        fixedMillisecond64.peg(calendar67);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) 12);
        int int72 = year44.compareTo((java.lang.Object) timeSeriesDataItem71);
        try {
            org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(1900, year44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateFormatSymbols8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(inputStream10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-31507200000L) + "'", long45 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = spreadsheetDate2.equals(obj3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int6 = spreadsheetDate2.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        java.lang.Object obj0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) '#');
//        long long5 = fixedMillisecond2.getMiddleMillisecond();
//        long long6 = fixedMillisecond2.getSerialIndex();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, class7);
//        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) timeSeries8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) '#');
//        long long14 = fixedMillisecond11.getMiddleMillisecond();
//        long long15 = fixedMillisecond11.getSerialIndex();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11, class16);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries8.addAndOrUpdate(timeSeries17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) day24);
//        long long26 = day24.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560495599999L + "'", long26 == 1560495599999L);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) '#');
        long long6 = fixedMillisecond3.getMiddleMillisecond();
        long long7 = fixedMillisecond3.getSerialIndex();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, class8);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 35.0d);
        java.lang.String str14 = timeSeries9.getDescription();
        java.util.List list15 = timeSeries9.getItems();
        java.lang.String str16 = timeSeries9.getRangeDescription();
        java.lang.Class<?> wildcardClass17 = timeSeries9.getClass();
        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) '#');
        long long24 = fixedMillisecond21.getMiddleMillisecond();
        long long25 = fixedMillisecond21.getSerialIndex();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21, class26);
        java.lang.String str28 = timeSeries27.getDomainDescription();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 35.0d);
        java.lang.String str32 = timeSeries27.getDescription();
        java.util.List list33 = timeSeries27.getItems();
        java.lang.String str34 = timeSeries27.getRangeDescription();
        java.lang.Class<?> wildcardClass35 = timeSeries27.getClass();
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass35);
        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-January-1900", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass35);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(inputStream18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Value" + "'", str34.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(inputStream36);
        org.junit.Assert.assertNull(obj37);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        java.text.DateFormatSymbols dateFormatSymbols4 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass5 = dateFormatSymbols4.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass5);
        java.lang.String str8 = timeSeries7.getDescription();
        timeSeries7.setNotify(false);
        java.lang.String str11 = timeSeries7.getDomainDescription();
        org.junit.Assert.assertNotNull(dateFormatSymbols4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        java.lang.Object obj0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) '#');
        long long5 = fixedMillisecond2.getMiddleMillisecond();
        long long6 = fixedMillisecond2.getSerialIndex();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, class7);
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) '#');
        long long14 = fixedMillisecond11.getMiddleMillisecond();
        long long15 = fixedMillisecond11.getSerialIndex();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11, class16);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries8.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) day24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries18.removeChangeListener(seriesChangeListener26);
        java.lang.Object obj28 = timeSeries18.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries18.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        int int3 = day0.getYear();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener9);
        timeSeries7.setMaximumItemCount(8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries7.addChangeListener(seriesChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test43");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int5 = spreadsheetDate4.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getPreviousDayOfWeek((int) (short) 1);
//        boolean boolean8 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int12 = spreadsheetDate11.getMonth();
//        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate11.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(1, serialDate17);
//        java.lang.String str19 = serialDate17.getDescription();
//        int int20 = spreadsheetDate11.compare(serialDate17);
//        int int21 = spreadsheetDate11.getYYYY();
//        int int22 = spreadsheetDate11.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int26 = spreadsheetDate25.getMonth();
//        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate25.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(1, serialDate31);
//        java.lang.String str33 = serialDate31.getDescription();
//        int int34 = spreadsheetDate25.compare(serialDate31);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears(2, serialDate31);
//        boolean boolean36 = spreadsheetDate11.isOnOrBefore(serialDate35);
//        int int37 = spreadsheetDate4.compare(serialDate35);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-43619) + "'", int20 == (-43619));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-43619) + "'", int34 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-44350) + "'", int37 == (-44350));
//    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, 4);
        int int3 = month2.getYearValue();
        int int4 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 35.0d);
        boolean boolean12 = timeSeries7.isEmpty();
        timeSeries7.setRangeDescription("9-January-1900");
        java.lang.Object obj15 = timeSeries7.clone();
        java.lang.String str16 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-January-1900" + "'", str16.equals("9-January-1900"));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("13-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        int int16 = month13.compareTo((java.lang.Object) (-1L));
        java.util.Date date17 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date17, timeZone21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date17);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date17, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date2, timeZone29);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        int int38 = month35.compareTo((java.lang.Object) (-1L));
        java.util.Date date39 = month35.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date39, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date2, timeZone41);
        long long44 = year43.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) '#');
        long long49 = fixedMillisecond46.getMiddleMillisecond();
        long long50 = fixedMillisecond46.getSerialIndex();
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond46, class51);
        boolean boolean53 = timeSeries52.getNotify();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month56.previous();
        int int59 = month56.compareTo((java.lang.Object) (-1L));
        java.util.Date date60 = month56.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (double) '#');
        java.util.Calendar calendar66 = null;
        fixedMillisecond63.peg(calendar66);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) 12);
        int int71 = year43.compareTo((java.lang.Object) timeSeriesDataItem70);
        java.util.Date date72 = year43.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-31507200000L) + "'", long44 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(date72);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        java.text.DateFormatSymbols dateFormatSymbols3 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass4 = dateFormatSymbols3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "13-June-2019", "ThreadContext", class5);
        java.lang.Comparable comparable7 = timeSeries6.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 2958465 + "'", comparable7.equals(2958465));
    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test49");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
//        long long4 = fixedMillisecond1.getMiddleMillisecond();
//        long long5 = fixedMillisecond1.getSerialIndex();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 35.0d);
//        long long12 = day9.getFirstMillisecond();
//        long long13 = day9.getSerialIndex();
//        try {
//            java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) day9);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test50");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getMonth();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        int int13 = timeSeries7.getMaximumItemCount();
        long long14 = timeSeries7.getMaximumItemAge();
        long long15 = timeSeries7.getMaximumItemAge();
        java.text.DateFormatSymbols dateFormatSymbols17 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass18 = dateFormatSymbols17.getClass();
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Value", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date27 = fixedMillisecond26.getEnd();
        java.text.DateFormatSymbols dateFormatSymbols32 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass33 = dateFormatSymbols32.getClass();
        java.io.InputStream inputStream34 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass33);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass33);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
        int int41 = month38.compareTo((java.lang.Object) (-1L));
        java.util.Date date42 = month38.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date42, timeZone46);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date42);
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date42, timeZone54);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date27, timeZone54);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month58.previous();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month23, regularTimePeriod59);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries7.getDataItem(regularTimePeriod59);
        java.util.Collection collection62 = timeSeries7.getTimePeriods();
        java.util.Collection collection63 = org.jfree.chart.util.ObjectUtilities.deepClone(collection62);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(dateFormatSymbols17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(dateFormatSymbols32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(inputStream34);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertNotNull(collection62);
        org.junit.Assert.assertNotNull(collection63);
    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test52");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        java.lang.String str4 = day0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 35.0d);
        java.lang.String str12 = timeSeries7.getDescription();
        java.util.List list13 = timeSeries7.getItems();
        java.lang.String str14 = timeSeries7.getRangeDescription();
        java.lang.Class<?> wildcardClass15 = timeSeries7.getClass();
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass15);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(classLoader16);
    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test54");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 32L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int8 = spreadsheetDate7.getMonth();
//        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate7.getPreviousDayOfWeek((int) (short) 1);
//        java.text.DateFormatSymbols dateFormatSymbols15 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
//        java.lang.Class<?> wildcardClass16 = dateFormatSymbols15.getClass();
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass16);
//        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 1, (java.lang.Object) timeSeries18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) '#');
//        long long24 = fixedMillisecond21.getMiddleMillisecond();
//        long long25 = fixedMillisecond21.getSerialIndex();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21, class26);
//        java.lang.String str28 = timeSeries27.getDomainDescription();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 35.0d);
//        long long32 = day29.getFirstMillisecond();
//        long long33 = day29.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) '#');
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
//        int int41 = month38.compareTo((java.lang.Object) (-1L));
//        java.util.Date date42 = month38.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month38.next();
//        java.lang.Number number44 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) month38);
//        int int45 = day0.compareTo((java.lang.Object) number44);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(dateFormatSymbols15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 35.0d + "'", number44.equals(35.0d));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        java.text.DateFormatSymbols dateFormatSymbols2 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass3 = dateFormatSymbols2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-January-1900", class4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class4);
        org.junit.Assert.assertNotNull(dateFormatSymbols2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(inputStream5);
        org.junit.Assert.assertNotNull(inputStream6);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getLastMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols9 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass10 = dateFormatSymbols9.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.previous();
        int int18 = month15.compareTo((java.lang.Object) (-1L));
        java.util.Date date19 = month15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date19, timeZone23);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, (java.lang.Class) wildcardClass10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        try {
            timeSeries26.add(regularTimePeriod27, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60500016000001L) + "'", long4 == (-60500016000001L));
        org.junit.Assert.assertNotNull(dateFormatSymbols9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(regularTimePeriod25);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass1 = dateFormatSymbols0.getClass();
        java.lang.ClassLoader classLoader2 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass1);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader2);
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(classLoader2);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        int int13 = timeSeries7.getMaximumItemCount();
        long long14 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) '#');
        long long21 = fixedMillisecond18.getMiddleMillisecond();
        long long22 = fixedMillisecond18.getSerialIndex();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class23);
        boolean boolean25 = timeSeries24.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener26);
        timeSeries24.setMaximumItemCount(8);
        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries7, (java.lang.Object) timeSeries24);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass1 = dateFormatSymbols0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        int int16 = month13.compareTo((java.lang.Object) (-1L));
        java.util.Date date17 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date17, timeZone21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date17);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date17, timeZone29);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date17, timeZone32);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(4, (-1));
        java.text.DateFormatSymbols dateFormatSymbols41 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass42 = dateFormatSymbols41.getClass();
        java.io.InputStream inputStream43 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass42);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, (java.lang.Class) wildcardClass42);
        java.util.Date date46 = month36.getStart();
        java.text.DateFormatSymbols dateFormatSymbols51 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass52 = dateFormatSymbols51.getClass();
        java.io.InputStream inputStream53 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass52);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass52);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.previous();
        int int60 = month57.compareTo((java.lang.Object) (-1L));
        java.util.Date date61 = month57.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date61);
        java.lang.Class class63 = null;
        java.util.Date date64 = null;
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date64, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date61, timeZone65);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date61);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date61);
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date61);
        java.lang.Class class71 = null;
        java.util.Date date72 = null;
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date72, timeZone73);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date61, timeZone73);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date46, timeZone73);
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date17, timeZone73);
        try {
            org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(dateFormatSymbols41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNull(inputStream43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(dateFormatSymbols51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNull(inputStream53);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod74);
    }

//    @Test
//    public void test60() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test60");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(1, serialDate8);
//        java.lang.String str10 = serialDate8.getDescription();
//        int int11 = spreadsheetDate2.compare(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int15 = spreadsheetDate14.getMonth();
//        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate14.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(1, serialDate20);
//        java.lang.String str22 = serialDate20.getDescription();
//        int int23 = spreadsheetDate14.compare(serialDate20);
//        boolean boolean24 = spreadsheetDate2.isOnOrBefore(serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int27 = spreadsheetDate26.getMonth();
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate26.getPreviousDayOfWeek((int) (short) 1);
//        boolean boolean30 = spreadsheetDate2.isBefore(serialDate29);
//        java.lang.Object obj31 = null;
//        boolean boolean32 = spreadsheetDate2.equals(obj31);
//        int int33 = spreadsheetDate2.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-43619) + "'", int11 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-43619) + "'", int23 == (-43619));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
//    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.lang.Object obj4 = null;
        int int5 = fixedMillisecond1.compareTo(obj4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 0);
        int int4 = day0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        int int14 = month11.compareTo((java.lang.Object) (-1L));
        java.util.Date date15 = month11.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) '#');
        java.util.Calendar calendar21 = null;
        fixedMillisecond18.peg(calendar21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) '#');
        long long28 = fixedMillisecond25.getMiddleMillisecond();
        long long29 = fixedMillisecond25.getSerialIndex();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25, class30);
        java.lang.String str32 = timeSeries31.getDomainDescription();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 35.0d);
        java.lang.String str36 = timeSeries31.getDescription();
        java.util.List list37 = timeSeries31.getItems();
        java.lang.String str38 = timeSeries31.getRangeDescription();
        java.lang.Class<?> wildcardClass39 = timeSeries31.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, (java.lang.Class) wildcardClass39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) '#');
        long long45 = fixedMillisecond42.getMiddleMillisecond();
        long long46 = fixedMillisecond42.getSerialIndex();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond42, class47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
        long long51 = fixedMillisecond42.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 1969L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
        java.text.DateFormatSymbols dateFormatSymbols9 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass10 = dateFormatSymbols9.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass10);
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 1, (java.lang.Object) timeSeries12);
        boolean boolean14 = timeSeries12.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(dateFormatSymbols9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test66() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test66");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.toSerial();
//        int int4 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int7 = spreadsheetDate6.getMonth();
//        int int8 = spreadsheetDate6.toSerial();
//        int int9 = spreadsheetDate6.toSerial();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(1, serialDate12);
//        java.lang.String str14 = serialDate12.getDescription();
//        java.lang.Class<?> wildcardClass15 = serialDate12.getClass();
//        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate6.getEndOfCurrentMonth(serialDate12);
//        boolean boolean17 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int21 = spreadsheetDate20.getMonth();
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate20.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(1, serialDate26);
//        java.lang.String str28 = serialDate26.getDescription();
//        int int29 = spreadsheetDate20.compare(serialDate26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate20);
//        boolean boolean31 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int36 = spreadsheetDate35.getMonth();
//        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate35.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate33.getEndOfCurrentMonth(serialDate38);
//        boolean boolean40 = spreadsheetDate6.isBefore(serialDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int43 = spreadsheetDate42.getMonth();
//        int int44 = spreadsheetDate42.toSerial();
//        int int45 = spreadsheetDate42.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int48 = spreadsheetDate47.getMonth();
//        int int49 = spreadsheetDate47.toSerial();
//        int int50 = spreadsheetDate47.toSerial();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate53 = day52.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays(1, serialDate53);
//        java.lang.String str55 = serialDate53.getDescription();
//        java.lang.Class<?> wildcardClass56 = serialDate53.getClass();
//        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate47.getEndOfCurrentMonth(serialDate53);
//        boolean boolean58 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        boolean boolean59 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate61 = day60.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int64 = spreadsheetDate63.getMonth();
//        int int65 = spreadsheetDate63.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate63);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int69 = spreadsheetDate68.getMonth();
//        org.jfree.data.time.SerialDate serialDate71 = spreadsheetDate68.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate74 = day73.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(1, serialDate74);
//        java.lang.String str76 = serialDate74.getDescription();
//        int int77 = spreadsheetDate68.compare(serialDate74);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int80 = spreadsheetDate79.getMonth();
//        int int81 = spreadsheetDate79.toSerial();
//        boolean boolean82 = spreadsheetDate63.isInRange(serialDate74, (org.jfree.data.time.SerialDate) spreadsheetDate79);
//        org.jfree.data.time.SerialDate serialDate83 = serialDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        boolean boolean84 = spreadsheetDate47.isOnOrBefore(serialDate83);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-43619) + "'", int29 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNull(str55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNull(str76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-43619) + "'", int77 == (-43619));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 10 + "'", int81 == 10);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
//    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-43619));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test68() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test68");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560439441203L + "'", long1 == 1560439441203L);
//    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        int int13 = timeSeries7.getMaximumItemCount();
        long long14 = timeSeries7.getMaximumItemAge();
        timeSeries7.removeAgedItems(false);
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

//    @Test
//    public void test71() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test71");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(1, serialDate8);
//        java.lang.String str10 = serialDate8.getDescription();
//        int int11 = spreadsheetDate2.compare(serialDate8);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int17 = spreadsheetDate16.getMonth();
//        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getPreviousDayOfWeek((int) (short) 1);
//        boolean boolean20 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int23 = spreadsheetDate22.getMonth();
//        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate22.getPreviousDayOfWeek((int) (short) 1);
//        int int26 = spreadsheetDate22.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int30 = spreadsheetDate29.getMonth();
//        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate29.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate35 = day34.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(1, serialDate35);
//        java.lang.String str37 = serialDate35.getDescription();
//        int int38 = spreadsheetDate29.compare(serialDate35);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(2, serialDate35);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays(1, serialDate42);
//        boolean boolean44 = spreadsheetDate22.isInRange(serialDate35, serialDate43);
//        boolean boolean45 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int48 = spreadsheetDate47.getMonth();
//        int int49 = spreadsheetDate47.toSerial();
//        int int50 = spreadsheetDate47.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int53 = spreadsheetDate52.getMonth();
//        int int54 = spreadsheetDate52.toSerial();
//        int int55 = spreadsheetDate52.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int58 = spreadsheetDate57.getMonth();
//        int int59 = spreadsheetDate57.toSerial();
//        int int60 = spreadsheetDate57.toSerial();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate63 = day62.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays(1, serialDate63);
//        java.lang.String str65 = serialDate63.getDescription();
//        java.lang.Class<?> wildcardClass66 = serialDate63.getClass();
//        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate57.getEndOfCurrentMonth(serialDate63);
//        boolean boolean68 = spreadsheetDate52.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int71 = spreadsheetDate70.getMonth();
//        int int72 = spreadsheetDate70.toSerial();
//        int int73 = spreadsheetDate70.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int76 = spreadsheetDate75.getMonth();
//        int int77 = spreadsheetDate75.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate75);
//        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate75.getNearestDayOfWeek(6);
//        int int81 = spreadsheetDate70.compare(serialDate80);
//        boolean boolean82 = spreadsheetDate52.isOnOrBefore(serialDate80);
//        boolean boolean84 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate52, 2147483647);
//        int int85 = spreadsheetDate52.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-43619) + "'", int11 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-43619) + "'", int38 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNull(str65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 10 + "'", int72 == 10);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 10 + "'", int77 == 10);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 3 + "'", int81 == 3);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 3 + "'", int85 == 3);
//    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        int int10 = month8.getMonth();
        boolean boolean11 = fixedMillisecond1.equals((java.lang.Object) month8);
        long long12 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date13 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) '#');
        long long19 = fixedMillisecond16.getMiddleMillisecond();
        long long20 = fixedMillisecond16.getSerialIndex();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16, class21);
        boolean boolean23 = timeSeries22.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond25.previous();
        int int31 = fixedMillisecond25.compareTo((java.lang.Object) 100);
        java.text.DateFormatSymbols dateFormatSymbols32 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass33 = dateFormatSymbols32.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, (java.lang.Class) wildcardClass33);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent37 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class36);
        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date13, (java.lang.Object) seriesChangeEvent37);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateFormatSymbols32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.text.DateFormatSymbols dateFormatSymbols7 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass8 = dateFormatSymbols7.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        int int16 = month13.compareTo((java.lang.Object) (-1L));
        java.util.Date date17 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date17, timeZone21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date17);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date17, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date2, timeZone29);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        int int38 = month35.compareTo((java.lang.Object) (-1L));
        java.util.Date date39 = month35.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date39, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date2, timeZone41);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateFormatSymbols7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        java.text.DateFormatSymbols dateFormatSymbols4 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass5 = dateFormatSymbols4.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        int int13 = month10.compareTo((java.lang.Object) (-1L));
        java.util.Date date14 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone18);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date14);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date14);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date14);
        int int25 = month24.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) '#');
        long long30 = fixedMillisecond27.getMiddleMillisecond();
        long long31 = fixedMillisecond27.getSerialIndex();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond27, class32);
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.previous();
        int int40 = month37.compareTo((java.lang.Object) (-1L));
        java.util.Date date41 = month37.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) '#');
        java.util.Calendar calendar47 = null;
        fixedMillisecond44.peg(calendar47);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (double) '#');
        long long54 = fixedMillisecond51.getMiddleMillisecond();
        long long55 = fixedMillisecond51.getSerialIndex();
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond51, class56);
        boolean boolean58 = timeSeries57.getNotify();
        java.util.Collection collection59 = timeSeries57.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 0);
        boolean boolean63 = fixedMillisecond61.equals((java.lang.Object) 100.0f);
        int int65 = fixedMillisecond61.compareTo((java.lang.Object) 10);
        java.lang.Number number66 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries33.addAndOrUpdate(timeSeries57);
        long long68 = timeSeries57.getMaximumItemAge();
        boolean boolean69 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month24, (java.lang.Object) timeSeries57);
        int int70 = month24.getMonth();
        org.junit.Assert.assertNotNull(dateFormatSymbols4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(collection59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNull(number66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 10 + "'", int70 == 10);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        int int4 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(52, (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(4, (-1));
        java.text.DateFormatSymbols dateFormatSymbols8 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass9 = dateFormatSymbols8.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, (java.lang.Class) wildcardClass9);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        java.lang.Class class14 = timeSeries12.getTimePeriodClass();
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("6-January-1900", class14);
        org.junit.Assert.assertNotNull(dateFormatSymbols8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(inputStream10);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(inputStream15);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
        boolean boolean8 = timeSeries7.getNotify();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        int int14 = month11.compareTo((java.lang.Object) (-1L));
        java.util.Date date15 = month11.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) '#');
        java.util.Calendar calendar21 = null;
        fixedMillisecond18.peg(calendar21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) '#');
        long long28 = fixedMillisecond25.getMiddleMillisecond();
        long long29 = fixedMillisecond25.getSerialIndex();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25, class30);
        boolean boolean32 = timeSeries31.getNotify();
        java.util.Collection collection33 = timeSeries31.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 0);
        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 100.0f);
        int int39 = fixedMillisecond35.compareTo((java.lang.Object) 10);
        java.lang.Number number40 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries31);
        int int42 = timeSeries7.getItemCount();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        int int44 = day43.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) (byte) 0);
        int int47 = day43.getYear();
        int int48 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

//    @Test
//    public void test79() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test79");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) '#');
//        long long4 = fixedMillisecond1.getMiddleMillisecond();
//        long long5 = fixedMillisecond1.getSerialIndex();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class6);
//        boolean boolean8 = timeSeries7.getNotify();
//        java.util.Collection collection9 = timeSeries7.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int12 = spreadsheetDate11.getMonth();
//        int int13 = spreadsheetDate11.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int17 = spreadsheetDate16.getMonth();
//        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(1, serialDate22);
//        java.lang.String str24 = serialDate22.getDescription();
//        int int25 = spreadsheetDate16.compare(serialDate22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int28 = spreadsheetDate27.getMonth();
//        int int29 = spreadsheetDate27.toSerial();
//        boolean boolean30 = spreadsheetDate11.isInRange(serialDate22, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        timeSeries7.setKey((java.lang.Comparable) spreadsheetDate27);
//        timeSeries7.setMaximumItemAge((long) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) '#');
//        long long40 = fixedMillisecond37.getMiddleMillisecond();
//        long long41 = fixedMillisecond37.getSerialIndex();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond37, class42);
//        boolean boolean44 = timeSeries43.getNotify();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.previous();
//        int int50 = month47.compareTo((java.lang.Object) (-1L));
//        java.util.Date date51 = month47.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) '#');
//        java.util.Calendar calendar57 = null;
//        fixedMillisecond54.peg(calendar57);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) '#');
//        long long64 = fixedMillisecond61.getMiddleMillisecond();
//        long long65 = fixedMillisecond61.getSerialIndex();
//        java.lang.Class class66 = null;
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond61, class66);
//        java.lang.String str68 = timeSeries67.getDomainDescription();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries67.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day69, (java.lang.Number) 35.0d);
//        java.lang.String str72 = timeSeries67.getDescription();
//        java.util.List list73 = timeSeries67.getItems();
//        java.lang.String str74 = timeSeries67.getRangeDescription();
//        java.lang.Class<?> wildcardClass75 = timeSeries67.getClass();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond54, (java.lang.Class) wildcardClass75);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond78, (double) '#');
//        long long81 = fixedMillisecond78.getMiddleMillisecond();
//        long long82 = fixedMillisecond78.getSerialIndex();
//        java.lang.Class class83 = null;
//        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond78, class83);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries76.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond78, 0.0d);
//        boolean boolean87 = fixedMillisecond35.equals((java.lang.Object) timeSeriesDataItem86);
//        java.util.Date date88 = fixedMillisecond35.getStart();
//        java.lang.Number number89 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-43619) + "'", int25 == (-43619));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Time" + "'", str68.equals("Time"));
//        org.junit.Assert.assertNull(timeSeriesDataItem71);
//        org.junit.Assert.assertNull(str72);
//        org.junit.Assert.assertNotNull(list73);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Value" + "'", str74.equals("Value"));
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNull(number89);
//    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test80");
        java.text.DateFormatSymbols dateFormatSymbols6 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass7 = dateFormatSymbols6.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, "hi!", "October 52", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        int int15 = month12.compareTo((java.lang.Object) (-1L));
        java.util.Date date16 = month12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date16, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) '#');
        long long27 = fixedMillisecond24.getMiddleMillisecond();
        long long28 = fixedMillisecond24.getSerialIndex();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond24, class29);
        boolean boolean31 = timeSeries30.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond33.previous();
        int int39 = fixedMillisecond33.compareTo((java.lang.Object) 100);
        java.text.DateFormatSymbols dateFormatSymbols40 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        java.lang.Class<?> wildcardClass41 = dateFormatSymbols40.getClass();
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, (java.lang.Class) wildcardClass41);
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        java.lang.Object obj46 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Nearest", (java.lang.Class) wildcardClass7, class45);
        java.lang.Object obj47 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(dateFormatSymbols6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(dateFormatSymbols40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertNull(obj47);
    }

//    @Test
//    public void test81() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test81");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int5 = spreadsheetDate4.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(1, serialDate10);
//        java.lang.String str12 = serialDate10.getDescription();
//        int int13 = spreadsheetDate4.compare(serialDate10);
//        int int14 = spreadsheetDate4.getYYYY();
//        java.lang.String str15 = spreadsheetDate4.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int18 = spreadsheetDate17.getMonth();
//        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate17.getPreviousDayOfWeek((int) (short) 1);
//        int int21 = spreadsheetDate17.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int25 = spreadsheetDate24.getMonth();
//        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate24.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(1, serialDate30);
//        java.lang.String str32 = serialDate30.getDescription();
//        int int33 = spreadsheetDate24.compare(serialDate30);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears(2, serialDate30);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate37 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(1, serialDate37);
//        boolean boolean39 = spreadsheetDate17.isInRange(serialDate30, serialDate38);
//        int int40 = spreadsheetDate4.compare(serialDate38);
//        boolean boolean41 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int45 = spreadsheetDate44.getMonth();
//        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate44.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate50 = day49.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(1, serialDate50);
//        java.lang.String str52 = serialDate50.getDescription();
//        int int53 = spreadsheetDate44.compare(serialDate50);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int59 = spreadsheetDate58.getMonth();
//        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate58.getPreviousDayOfWeek((int) (short) 1);
//        boolean boolean62 = spreadsheetDate56.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int65 = spreadsheetDate64.getMonth();
//        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate64.getPreviousDayOfWeek((int) (short) 1);
//        int int68 = spreadsheetDate64.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int72 = spreadsheetDate71.getMonth();
//        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate71.getPreviousDayOfWeek((int) (short) 1);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate77 = day76.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addDays(1, serialDate77);
//        java.lang.String str79 = serialDate77.getDescription();
//        int int80 = spreadsheetDate71.compare(serialDate77);
//        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addYears(2, serialDate77);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate84 = day83.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addDays(1, serialDate84);
//        boolean boolean86 = spreadsheetDate64.isInRange(serialDate77, serialDate85);
//        boolean boolean87 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, serialDate77);
//        boolean boolean88 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-43619) + "'", int13 == (-43619));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-43619) + "'", int33 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-43620) + "'", int40 == (-43620));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNull(str52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-43619) + "'", int53 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 10 + "'", int68 == 10);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertNull(str79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-43619) + "'", int80 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
//    }
//}

