import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.color.ColorSpace colorSpace6 = null;
        float[] floatArray11 = new float[] { 1.0f, 0, 10.0f, 2.0f };
        try {
            float[] floatArray12 = color4.getColorComponents(colorSpace6, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        try {
            numberAxis1.setRangeAboutValue((double) (byte) -1, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-0.5) <= upper (-1.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            numberAxis1.setTickLabelInsets(rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        try {
            double double8 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 10, (java.lang.Comparable) 8, categoryDataset4, 1.0d, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker3.setStroke(stroke8);
        java.lang.Class class11 = null;
        try {
            java.util.EventListener[] eventListenerArray12 = categoryMarker3.getListeners(class11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getUpperBound();
        org.jfree.data.Range range6 = null;
        try {
            numberAxis1.setRangeWithMargins(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        numberAxis1.addChangeListener(axisChangeListener5);
        java.awt.Paint paint7 = null;
        try {
            numberAxis1.setTickMarkPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        int int4 = color1.getGreen();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = null;
        java.awt.Color color3 = java.awt.Color.CYAN;
        java.awt.Color color5 = java.awt.Color.darkGray;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color5, stroke6);
        categoryMarker7.setLabel("hi!");
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker7.setStroke(stroke10);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke10, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { 64, 10 };
        try {
            float[] floatArray5 = color0.getComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = dateAxis0.draw(graphics2D1, 4.0d, rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 100, 100.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight(10.0d);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = categoryMarker8.getLabelOffsetType();
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color13, stroke14);
        categoryMarker15.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = categoryMarker15.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets0.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType11, lengthAdjustmentType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            dateAxis0.setRange(date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(1, (int) ' ', (int) ' ');
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        try {
            dateAxis0.setMinimumDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        java.awt.Color color4 = color2.darker();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) (byte) 100, (float) (short) 1, (float) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double12 = rectangleInsets10.calculateLeftInset(1.0E-8d);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color14, stroke15);
        categoryMarker16.setLabel("hi!");
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker16.setStroke(stroke19);
        boolean boolean21 = rectangleInsets10.equals((java.lang.Object) stroke19);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1L, (java.awt.Paint) color4, stroke5, (java.awt.Paint) color9, stroke19, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        objectList1.clear();
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = categoryMarker6.getLabelOffsetType();
        java.lang.String str10 = lengthAdjustmentType9.toString();
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = categoryMarker14.getLabelOffsetType();
        java.lang.String str18 = lengthAdjustmentType17.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets0.createAdjustedRectangle(rectangle2D2, lengthAdjustmentType9, lengthAdjustmentType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "EXPAND" + "'", str10.equals("EXPAND"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EXPAND" + "'", str18.equals("EXPAND"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        boolean boolean3 = objectList1.equals((java.lang.Object) (short) -1);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker8.setStroke(stroke11);
        try {
            objectList1.set((int) (byte) -1, (java.lang.Object) categoryMarker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.Size2D size2D0 = null;
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker6.setLabelAnchor(rectangleAnchor11);
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 4.0d, 0.0d, rectangleAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color1 = java.awt.Color.CYAN;
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        categoryMarker5.setLabel("hi!");
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker5.setStroke(stroke8);
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color1, stroke8, paint10, stroke11, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 10);
        java.lang.String str3 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 100.0d, 1.0E-8d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        java.awt.Color color3 = color1.darker();
        java.lang.Object obj4 = null;
        boolean boolean5 = color1.equals(obj4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        dateAxis0.setRangeAboutValue((double) ' ', (double) 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight(10.0d);
        double double5 = rectangleInsets0.calculateBottomOutset((double) (short) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str1.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker3.setStroke(stroke8);
        categoryMarker3.setLabel("EXPAND");
        java.lang.Comparable comparable13 = categoryMarker3.getKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (byte) 0 + "'", comparable13.equals((byte) 0));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            xYPlot0.setRangeAxisLocation((int) (short) -1, axisLocation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent2.getChart();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent2.setChart(jFreeChart5);
        org.junit.Assert.assertNull(jFreeChart3);
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot27.getDomainAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis30.setAutoRangeIncludesZero(false);
        java.awt.Color color33 = java.awt.Color.darkGray;
        numberAxis30.setAxisLinePaint((java.awt.Paint) color33);
        java.lang.Object obj35 = numberAxis30.clone();
        boolean boolean36 = axisLocation28.equals(obj35);
        try {
            categoryPlot25.setRangeAxisLocation((int) (byte) -1, axisLocation28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) tickUnitSource0);
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList((int) '4');
        objectList1.set(6, (java.lang.Object) objectList4);
        objectList4.clear();
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        org.jfree.data.Range range13 = numberAxis1.getDefaultAutoRange();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis1.setLeftArrow(shape14);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        float float6 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, 8.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            boolean boolean32 = categoryPlot25.removeAnnotation(categoryAnnotation30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange(0.0d);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        try {
            categoryPlot25.setBackgroundImageAlpha(2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray9 = new float[] { (byte) 10, 100, (byte) -1, (byte) 100 };
        float[] floatArray10 = java.awt.Color.RGBtoHSB(0, (int) (byte) 1, (int) (byte) 10, floatArray9);
        try {
            float[] floatArray11 = color0.getColorComponents(colorSpace1, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Color color30 = java.awt.Color.darkGray;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color30, stroke31);
        categoryMarker32.setLabel("hi!");
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker32.setStroke(stroke35);
        java.awt.Paint paint37 = categoryMarker32.getLabelPaint();
        boolean boolean38 = categoryMarker32.getDrawAsLine();
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean40 = xYPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker32, layer39);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            categoryPlot25.drawOutline(graphics2D27, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int3 = java.awt.Color.HSBtoRGB((float) 4, (float) (byte) 10, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-123) + "'", int3 == (-123));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            boolean boolean29 = categoryPlot25.removeAnnotation(categoryAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        dateAxis0.setRange((double) 10L, (double) (byte) 100);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = dateAxis0.draw(graphics2D6, 10.0d, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) '#', "");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        numberAxis1.setRangeAboutValue(0.0d, (double) 255);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = categoryMarker3.getLabelOffsetType();
        try {
            categoryMarker3.setAlpha((float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker3);
        java.awt.Image image5 = xYPlot0.getBackgroundImage();
        java.awt.Color color8 = java.awt.Color.darkGray;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color8, stroke9);
        categoryMarker10.setLabel("hi!");
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker10.setStroke(stroke13);
        java.awt.Paint paint15 = categoryMarker10.getLabelPaint();
        org.jfree.chart.util.Layer layer16 = null;
        try {
            xYPlot0.addDomainMarker(10, (org.jfree.chart.plot.Marker) categoryMarker10, layer16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot25.handleClick(0, (int) (byte) 1, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            numberAxis1.setTickLabelInsets(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder2 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Color color0 = java.awt.Color.green;
        int int1 = color0.getRed();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.BLACK;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getRGBColorComponents(floatArray4);
        try {
            float[] floatArray6 = color0.getComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        boolean boolean26 = numberAxis18.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot0.getRenderer();
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis37.getCategoryEnd(0, (int) (short) 0, rectangle2D40, rectangleEdge41);
        categoryAxis37.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double46 = rectangleInsets45.getBottom();
        double double48 = rectangleInsets45.extendHeight((double) (short) 0);
        double double50 = rectangleInsets45.calculateRightInset((double) 8);
        categoryAxis37.setTickLabelInsets(rectangleInsets45);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape54 = numberAxis53.getUpArrow();
        numberAxis53.setTickMarksVisible(false);
        double double57 = numberAxis53.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis53.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer59);
        categoryPlot60.zoom(0.0d);
        categoryPlot60.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint65 = categoryPlot60.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor66 = categoryPlot60.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        categoryPlot60.setFixedDomainAxisSpace(axisSpace67, true);
        java.awt.Color color72 = java.awt.Color.darkGray;
        java.awt.Stroke stroke73 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker74 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color72, stroke73);
        categoryMarker74.setLabel("hi!");
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker74.setStroke(stroke77);
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot60.addDomainMarker((int) '4', categoryMarker74, layer79, true);
        try {
            xYPlot0.addRangeMarker(marker34, layer79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 8.0d + "'", double48 == 8.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 8.0d + "'", double50 == 8.0d);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(categoryAnchor66);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(layer79);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat5 = dateAxis0.getDateFormatOverride();
        java.lang.String str6 = dateAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Stroke stroke3 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        float[] floatArray10 = new float[] { (byte) 10, 100, (byte) -1, (byte) 100 };
        float[] floatArray11 = java.awt.Color.RGBtoHSB(0, (int) (byte) 1, (int) (byte) 10, floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB(255, 255, (int) (short) -1, floatArray10);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.geom.Point2D point2D2 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis1.getStandardTickUnits();
        boolean boolean6 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit7, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource12);
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(tickUnitSource12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        double double11 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setUpperMargin(0.05d);
        boolean boolean14 = xYPlot0.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date20 = dateAxis16.getMinimumDate();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        float float25 = xYPlot24.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot24.getAxisOffset();
        java.lang.Object obj27 = xYPlot24.clone();
        java.awt.Paint paint28 = xYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot24.getDomainAxisEdge((int) '4');
        try {
            double double31 = categoryAxis5.getCategorySeriesMiddle((java.lang.Comparable) "hi!", (java.lang.Comparable) date20, categoryDataset21, 18.0d, rectangle2D23, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        float float7 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        float float14 = xYPlot13.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot13.getAxisOffset();
        java.lang.Object obj16 = xYPlot13.clone();
        java.awt.Paint paint17 = xYPlot13.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot13.getDomainAxisEdge((int) '4');
        try {
            double double20 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) (byte) 1, (java.lang.Comparable) 1.0d, categoryDataset10, (double) (short) 100, rectangle2D12, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        java.awt.Color color37 = java.awt.Color.darkGray;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color37, stroke38);
        categoryMarker39.setLabel("hi!");
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker39.setStroke(stroke42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot25.addDomainMarker((int) '4', categoryMarker39, layer44, true);
        org.jfree.chart.util.UnitType unitType47 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.Object obj48 = null;
        boolean boolean49 = unitType47.equals(obj48);
        boolean boolean50 = categoryPlot25.equals((java.lang.Object) boolean49);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNotNull(unitType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLowerMargin((double) '4');
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date22 = dateAxis18.getMinimumDate();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        float float27 = xYPlot26.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot26.getAxisOffset();
        java.lang.Object obj29 = xYPlot26.clone();
        java.awt.Paint paint30 = xYPlot26.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot26.getDomainAxisEdge((int) '4');
        try {
            double double33 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) (short) -1, (java.lang.Comparable) date22, categoryDataset23, (double) 5, rectangle2D25, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = dateAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        try {
            dateAxis0.setRange((double) 'a', (double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        org.jfree.data.Range range13 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1, jFreeChart14);
        org.jfree.chart.JFreeChart jFreeChart16 = chartChangeEvent15.getChart();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(jFreeChart16);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 100, (float) (short) 1, (float) '4');
        int int4 = color3.getAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 10);
        double double4 = rectangleInsets0.calculateTopOutset((-1.0d));
        double double6 = rectangleInsets0.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-16.0d) + "'", double6 == (-16.0d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        java.awt.geom.Point2D point2D4 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.awt.Paint paint3 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis4.setTickUnit(dateTickUnit5);
        dateAxis0.setTickUnit(dateTickUnit5, false, true);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis12.setTickUnit(dateTickUnit13);
        double double15 = dateAxis12.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date20 = dateAxis16.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis12.dateToJava2D(date20, rectangle2D21, rectangleEdge22);
        try {
            dateAxis0.setRange(date11, date20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke2 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint4 = xYPlot3.getDomainGridlinePaint();
        java.awt.Stroke stroke5 = xYPlot3.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis8.getCategoryEnd(0, (int) (short) 0, rectangle2D11, rectangleEdge12);
        categoryAxis8.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets16.getBottom();
        double double19 = rectangleInsets16.extendHeight((double) (short) 0);
        double double21 = rectangleInsets16.calculateRightInset((double) 8);
        categoryAxis8.setTickLabelInsets(rectangleInsets16);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape25 = numberAxis24.getUpArrow();
        numberAxis24.setTickMarksVisible(false);
        double double28 = numberAxis24.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = numberAxis24.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer30);
        java.awt.Stroke stroke32 = categoryPlot31.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot31.setRangeAxisLocation(axisLocation33, true);
        xYPlot3.setRangeAxisLocation(axisLocation33);
        xYPlot0.setDomainAxisLocation(axisLocation33);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis40.setAutoRangeIncludesZero(false);
        java.lang.Object obj43 = numberAxis40.clone();
        try {
            xYPlot0.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) numberAxis40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        categoryMarker5.setLabel("hi!");
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis10.setAutoRangeIncludesZero(false);
        java.awt.Color color13 = java.awt.Color.darkGray;
        numberAxis10.setAxisLinePaint((java.awt.Paint) color13);
        numberAxis10.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis10.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.awt.Paint paint22 = numberAxis10.getTickMarkPaint();
        xYPlot0.setDomainZeroBaselinePaint(paint22);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color2 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double49 = rectangleInsets47.calculateLeftInset(1.0E-8d);
        java.awt.Color color51 = java.awt.Color.darkGray;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color51, stroke52);
        categoryMarker53.setLabel("hi!");
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker53.setStroke(stroke56);
        boolean boolean58 = rectangleInsets47.equals((java.lang.Object) stroke56);
        categoryPlot25.setInsets(rectangleInsets47, true);
        java.awt.Paint paint61 = categoryPlot25.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getUpperBound();
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray8 = new float[] { (byte) 10, 100, (byte) -1, (byte) 100 };
        float[] floatArray9 = java.awt.Color.RGBtoHSB(0, (int) (byte) 1, (int) (byte) 10, floatArray8);
        float[] floatArray10 = color0.getComponents(floatArray9);
        java.awt.color.ColorSpace colorSpace11 = null;
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Color color14 = java.awt.Color.getColor("", color13);
        java.awt.Color color15 = color13.darker();
        float[] floatArray21 = new float[] { 1L, 0L, 1.0f, (short) 100, (-1L) };
        float[] floatArray22 = color13.getRGBComponents(floatArray21);
        try {
            float[] floatArray23 = color0.getColorComponents(colorSpace11, floatArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            categoryPlot25.setDomainAxisLocation((int) (short) -1, axisLocation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        int int27 = categoryPlot25.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot25.getLegendItems();
        categoryPlot25.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection28);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        double double11 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setUpperMargin(0.05d);
        boolean boolean14 = xYPlot0.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = null;
        try {
            xYPlot0.setRangeAxes(valueAxisArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker3.setStroke(stroke8);
        categoryMarker3.setKey((java.lang.Comparable) 10.0f);
        java.lang.Class class13 = null;
        try {
            java.util.EventListener[] eventListenerArray14 = categoryMarker3.getListeners(class13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getDomainAxisLocation();
        java.awt.Image image7 = null;
        xYPlot5.setBackgroundImage(image7);
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color11, stroke12);
        categoryMarker13.setLabel("hi!");
        categoryMarker13.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker13.setLabelFont(font18);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean22 = xYPlot5.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker13, layer20, true);
        categoryMarker13.setKey((java.lang.Comparable) 1.0d);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation26 = null;
        try {
            boolean boolean28 = xYPlot0.removeAnnotation(xYAnnotation26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        java.lang.String str33 = axisLocation30.toString();
        xYPlot0.setDomainAxisLocation(500, axisLocation30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot0.zoomDomainAxes((double) ' ', plotRenderingInfo36, point2D37, true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str33.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot25.getRangeAxis((int) (byte) 100);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot25.addAnnotation(categoryAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color5 = java.awt.Color.darkGray;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color5, stroke6);
        categoryMarker7.setLabel("hi!");
        categoryMarker7.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color13, stroke14);
        categoryMarker15.setLabel("hi!");
        java.awt.Color color19 = java.awt.Color.darkGray;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color19, stroke20);
        categoryMarker15.setStroke(stroke20);
        categoryMarker7.setStroke(stroke20);
        xYPlot0.setDomainZeroBaselineStroke(stroke20);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot0.getRangeAxis((int) (byte) 100);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets9.getBottom();
        double double12 = rectangleInsets9.extendHeight((double) (short) 0);
        double double14 = rectangleInsets9.calculateRightInset((double) 8);
        categoryAxis1.setTickLabelInsets(rectangleInsets9);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis17.getCategoryEnd(0, (int) (short) 0, rectangle2D20, rectangleEdge21);
        java.lang.String str24 = categoryAxis17.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis17.getCategoryJava2DCoordinate(categoryAnchor25, 64, (int) (byte) 0, rectangle2D28, rectangleEdge29);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        float float35 = xYPlot34.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot34.getAxisOffset();
        java.lang.Object obj37 = xYPlot34.clone();
        java.awt.Paint paint38 = xYPlot34.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot34.getDomainAxisEdge((int) '4');
        try {
            double double41 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor25, 255, (int) (short) -1, rectangle2D33, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.axis.TickUnitSource tickUnitSource59 = numberAxis52.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(tickUnitSource59);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        java.awt.Color color11 = java.awt.Color.red;
        try {
            xYPlot0.setQuadrantPaint((int) '#', (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (35) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean33 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Paint paint34 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = java.awt.Color.BLACK;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        java.lang.String str3 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLowerMargin((double) '4');
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (-1));
        java.awt.Paint paint19 = categoryAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot25.setWeight((int) (byte) -1);
        boolean boolean47 = categoryPlot25.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker8.setStroke(stroke11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        float float14 = xYPlot13.getForegroundAlpha();
        java.awt.Color color17 = java.awt.Color.darkGray;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color17, stroke18);
        categoryMarker19.setLabel("hi!");
        categoryMarker19.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color25 = java.awt.Color.darkGray;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color25, stroke26);
        categoryMarker27.setLabel("hi!");
        java.awt.Color color31 = java.awt.Color.darkGray;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color31, stroke32);
        categoryMarker27.setStroke(stroke32);
        categoryMarker19.setStroke(stroke32);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean38 = xYPlot13.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker19, layer36, true);
        xYPlot0.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) categoryMarker8, layer36, false);
        java.lang.String str41 = categoryMarker8.getLabel();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        boolean boolean3 = objectList1.equals((java.lang.Object) (short) -1);
        java.lang.Object obj4 = objectList1.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot0.zoomDomainAxes((double) 1L, (double) 1, plotRenderingInfo34, point2D35);
        java.lang.Object obj37 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj37);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.geom.Rectangle2D rectangle2D4 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
//        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
//        float float7 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        long long10 = day8.getMiddleMillisecond();
//        java.lang.Object obj11 = null;
//        int int12 = day8.compareTo(obj11);
//        java.lang.String str13 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day8);
//        java.util.Calendar calendar14 = null;
//        try {
//            day8.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNull(str13);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        java.awt.Stroke stroke5 = dateAxis0.getAxisLineStroke();
        try {
            dateAxis0.setRange((double) '#', (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        xYPlot0.clearDomainMarkers();
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.util.Date date9 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit7);
        try {
            dateAxis0.setRange(4.0d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = numberAxis52.valueToJava2D((double) (short) 0, rectangle2D60, rectangleEdge61);
        org.jfree.data.Range range63 = null;
        try {
            numberAxis52.setRange(range63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(0, (int) (short) 0, rectangle2D16, rectangleEdge17);
        categoryAxis13.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getBottom();
        double double24 = rectangleInsets21.extendHeight((double) (short) 0);
        double double26 = rectangleInsets21.calculateRightInset((double) 8);
        categoryAxis13.setTickLabelInsets(rectangleInsets21);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape30 = numberAxis29.getUpArrow();
        numberAxis29.setTickMarksVisible(false);
        double double33 = numberAxis29.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis29.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer35);
        categoryPlot36.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot36.getRendererForDataset(categoryDataset39);
        java.lang.String str41 = categoryPlot36.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(4, axisLocation43);
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation43, false);
        java.awt.Image image47 = xYPlot0.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNull(image47);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D4, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 10);
        double double4 = rectangleInsets0.calculateTopOutset((-1.0d));
        double double6 = rectangleInsets0.calculateRightOutset(0.0d);
        double double8 = rectangleInsets0.calculateTopInset(4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        boolean boolean2 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot3.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot3.setRenderer((int) (short) 1, xYItemRenderer9);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray11 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot3.setRenderers(xYItemRendererArray11);
        xYPlot0.setRenderers(xYItemRendererArray11);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        double double8 = categoryAxis2.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis2.getCategoryEnd(10, 8, rectangle2D11, rectangleEdge12);
        boolean boolean14 = textAnchor0.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setVerticalTickLabels(true);
        java.awt.Paint paint8 = numberAxis1.getLabelPaint();
        java.awt.Font font9 = null;
        try {
            numberAxis1.setLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        int int2 = objectList1.size();
        java.lang.Object obj4 = objectList1.get((int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        boolean boolean3 = seriesRenderingOrder0.equals((java.lang.Object) valueMarker2);
        valueMarker2.setValue((double) (byte) -1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        dateAxis0.setLabel("hi!");
        java.awt.Stroke stroke5 = dateAxis0.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setAutoRangeIncludesZero(false);
        java.awt.Color color10 = java.awt.Color.darkGray;
        numberAxis7.setAxisLinePaint((java.awt.Paint) color10);
        java.lang.Object obj12 = numberAxis7.clone();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis7.setTickMarkPaint(paint13);
        java.text.NumberFormat numberFormat15 = null;
        numberAxis7.setNumberFormatOverride(numberFormat15);
        boolean boolean17 = numberAxis7.isAutoRange();
        java.awt.Shape shape18 = numberAxis7.getLeftArrow();
        org.jfree.data.Range range19 = numberAxis7.getDefaultAutoRange();
        dateAxis0.setRange(range19, false, false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 'a', 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        xYPlot0.drawAnnotations(graphics2D60, rectangle2D61, plotRenderingInfo62);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        float float11 = xYPlot10.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot10.getAxisOffset();
        java.lang.Object obj13 = xYPlot10.clone();
        java.awt.Paint paint14 = xYPlot10.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot10.getDomainAxisEdge((int) '4');
        try {
            double double17 = dateAxis0.java2DToValue((double) 500, rectangle2D9, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 1560452399999L);
        double double4 = rectangleInsets0.extendHeight((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 10.0d, (double) 7, (double) 100);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.calculateLeftInset((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.event.AxisChangeListener axisChangeListener7 = null;
        numberAxis1.addChangeListener(axisChangeListener7);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setVerticalTickLabels(true);
        double double8 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation3 = xYPlot0.getDomainAxisLocation((int) (byte) 100);
        boolean boolean4 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        int int2 = day0.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        categoryMarker3.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker3.setLabelFont(font8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = categoryAxis11.clone();
        double double13 = categoryAxis11.getFixedDimension();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis11.setLabelFont(font14);
        categoryMarker3.setLabelFont(font14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker3.setStroke(stroke8);
        categoryMarker3.setKey((java.lang.Comparable) 10.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        categoryMarker3.notifyListeners(markerChangeEvent13);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        categoryPlot25.configureRangeAxes();
        boolean boolean31 = categoryPlot25.isRangeZoomable();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        try {
            boolean boolean34 = categoryPlot25.removeAnnotation(categoryAnnotation32, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        java.awt.Paint paint8 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis9.setTickUnit(dateTickUnit10);
        dateAxis5.setTickUnit(dateTickUnit10, false, true);
        java.util.Date date15 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit10);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) (short) -1, 0.2d);
        dateAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit23);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        float float28 = xYPlot27.getForegroundAlpha();
        java.awt.Color color31 = java.awt.Color.darkGray;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color31, stroke32);
        categoryMarker33.setLabel("hi!");
        categoryMarker33.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker41.setLabel("hi!");
        java.awt.Color color45 = java.awt.Color.darkGray;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color45, stroke46);
        categoryMarker41.setStroke(stroke46);
        categoryMarker33.setStroke(stroke46);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean52 = xYPlot27.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker33, layer50, true);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis54.setAutoRangeIncludesZero(false);
        java.awt.Color color57 = java.awt.Color.darkGray;
        numberAxis54.setAxisLinePaint((java.awt.Paint) color57);
        boolean boolean59 = numberAxis54.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis61.setAutoRangeIncludesZero(false);
        java.awt.Color color64 = java.awt.Color.darkGray;
        numberAxis61.setAxisLinePaint((java.awt.Paint) color64);
        java.lang.Object obj66 = numberAxis61.clone();
        java.awt.Paint paint67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis61.setTickMarkPaint(paint67);
        java.text.NumberFormat numberFormat69 = null;
        numberAxis61.setNumberFormatOverride(numberFormat69);
        boolean boolean71 = numberAxis61.isAutoRange();
        java.awt.Shape shape72 = numberAxis61.getLeftArrow();
        org.jfree.data.Range range73 = numberAxis61.getDefaultAutoRange();
        java.awt.Shape shape74 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis61.setLeftArrow(shape74);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray76 = new org.jfree.chart.axis.ValueAxis[] { numberAxis54, numberAxis61 };
        xYPlot27.setDomainAxes(valueAxisArray76);
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis79.setAutoRangeIncludesZero(false);
        java.lang.Object obj82 = numberAxis79.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource83 = numberAxis79.getStandardTickUnits();
        boolean boolean84 = numberAxis79.isTickMarksVisible();
        xYPlot27.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis79);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = xYPlot27.getDomainAxisEdge();
        try {
            double double87 = dateAxis0.dateToJava2D(date25, rectangle2D26, rectangleEdge86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(obj66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(valueAxisArray76);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertNotNull(tickUnitSource83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(rectangleEdge86);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (byte) -1);
        java.awt.Font font11 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) 10, font11);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        float float17 = xYPlot16.getForegroundAlpha();
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color20, stroke21);
        categoryMarker22.setLabel("hi!");
        categoryMarker22.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color28 = java.awt.Color.darkGray;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color28, stroke29);
        categoryMarker30.setLabel("hi!");
        java.awt.Color color34 = java.awt.Color.darkGray;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color34, stroke35);
        categoryMarker30.setStroke(stroke35);
        categoryMarker22.setStroke(stroke35);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean41 = xYPlot16.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker22, layer39, true);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis43.setAutoRangeIncludesZero(false);
        java.awt.Color color46 = java.awt.Color.darkGray;
        numberAxis43.setAxisLinePaint((java.awt.Paint) color46);
        boolean boolean48 = numberAxis43.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis50.setAutoRangeIncludesZero(false);
        java.awt.Color color53 = java.awt.Color.darkGray;
        numberAxis50.setAxisLinePaint((java.awt.Paint) color53);
        java.lang.Object obj55 = numberAxis50.clone();
        java.awt.Paint paint56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis50.setTickMarkPaint(paint56);
        java.text.NumberFormat numberFormat58 = null;
        numberAxis50.setNumberFormatOverride(numberFormat58);
        boolean boolean60 = numberAxis50.isAutoRange();
        java.awt.Shape shape61 = numberAxis50.getLeftArrow();
        org.jfree.data.Range range62 = numberAxis50.getDefaultAutoRange();
        java.awt.Shape shape63 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis50.setLeftArrow(shape63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { numberAxis43, numberAxis50 };
        xYPlot16.setDomainAxes(valueAxisArray65);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis68.setAutoRangeIncludesZero(false);
        java.lang.Object obj71 = numberAxis68.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource72 = numberAxis68.getStandardTickUnits();
        boolean boolean73 = numberAxis68.isTickMarksVisible();
        xYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis68);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = xYPlot16.getDomainAxisEdge();
        try {
            double double76 = categoryAxis1.getCategoryEnd(7, 9, rectangle2D15, rectangleEdge75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(tickUnitSource72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(rectangleEdge75);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        java.awt.Color color37 = java.awt.Color.darkGray;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color37, stroke38);
        categoryMarker39.setLabel("hi!");
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker39.setStroke(stroke42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot25.addDomainMarker((int) '4', categoryMarker39, layer44, true);
        float float47 = categoryMarker39.getAlpha();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLowerMargin((double) '4');
        categoryAxis1.setVisible(true);
        double double19 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 10);
        double double4 = rectangleInsets0.calculateTopOutset((-1.0d));
        double double6 = rectangleInsets0.calculateRightOutset(0.0d);
        double double8 = rectangleInsets0.calculateRightInset((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot3.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis8.getCategoryEnd(0, (int) (short) 0, rectangle2D11, rectangleEdge12);
        categoryAxis8.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets16.getBottom();
        double double19 = rectangleInsets16.extendHeight((double) (short) 0);
        double double21 = rectangleInsets16.calculateRightInset((double) 8);
        categoryAxis8.setTickLabelInsets(rectangleInsets16);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape25 = numberAxis24.getUpArrow();
        numberAxis24.setTickMarksVisible(false);
        double double28 = numberAxis24.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = numberAxis24.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer30);
        java.awt.Stroke stroke32 = categoryPlot31.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot31.setRangeAxisLocation(axisLocation33, true);
        java.lang.String str36 = axisLocation33.toString();
        xYPlot3.setDomainAxisLocation(500, axisLocation33);
        java.awt.Paint paint38 = xYPlot3.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        float float40 = xYPlot39.getForegroundAlpha();
        java.awt.Color color43 = java.awt.Color.darkGray;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color43, stroke44);
        categoryMarker45.setLabel("hi!");
        categoryMarker45.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color51 = java.awt.Color.darkGray;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color51, stroke52);
        categoryMarker53.setLabel("hi!");
        java.awt.Color color57 = java.awt.Color.darkGray;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color57, stroke58);
        categoryMarker53.setStroke(stroke58);
        categoryMarker45.setStroke(stroke58);
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot39.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker45, layer62, true);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        xYPlot39.setDataset(xYDataset65);
        java.awt.Graphics2D graphics2D67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        xYPlot39.drawAnnotations(graphics2D67, rectangle2D68, plotRenderingInfo69);
        java.awt.Stroke stroke71 = xYPlot39.getDomainZeroBaselineStroke();
        xYPlot3.setDomainGridlineStroke(stroke71);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot3);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str36.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight((double) (short) 0);
        double double5 = rectangleInsets0.calculateRightInset((double) 8);
        double double7 = rectangleInsets0.calculateTopInset((double) 1560452399999L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = categoryMarker3.getLabelOffsetType();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.lang.Class<?> wildcardClass8 = color7.getClass();
        try {
            java.util.EventListener[] eventListenerArray9 = categoryMarker3.getListeners((java.lang.Class) wildcardClass8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double49 = rectangleInsets47.calculateLeftInset(1.0E-8d);
        java.awt.Color color51 = java.awt.Color.darkGray;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color51, stroke52);
        categoryMarker53.setLabel("hi!");
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker53.setStroke(stroke56);
        boolean boolean58 = rectangleInsets47.equals((java.lang.Object) stroke56);
        categoryPlot25.setInsets(rectangleInsets47, true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot25.addChangeListener(plotChangeListener61);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.data.RangeType rangeType8 = null;
        try {
            numberAxis1.setRangeType(rangeType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (double) 0.5f, 0.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        boolean boolean27 = categoryPlot25.getDrawSharedDomainAxis();
        categoryPlot25.mapDatasetToRangeAxis((int) '4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot3.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis8.getCategoryEnd(0, (int) (short) 0, rectangle2D11, rectangleEdge12);
        categoryAxis8.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets16.getBottom();
        double double19 = rectangleInsets16.extendHeight((double) (short) 0);
        double double21 = rectangleInsets16.calculateRightInset((double) 8);
        categoryAxis8.setTickLabelInsets(rectangleInsets16);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape25 = numberAxis24.getUpArrow();
        numberAxis24.setTickMarksVisible(false);
        double double28 = numberAxis24.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = numberAxis24.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer30);
        java.awt.Stroke stroke32 = categoryPlot31.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot31.setRangeAxisLocation(axisLocation33, true);
        java.lang.String str36 = axisLocation33.toString();
        xYPlot3.setDomainAxisLocation(500, axisLocation33);
        try {
            xYPlot0.setDomainAxisLocation((-123), axisLocation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str36.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot25.getRowRenderingOrder();
        categoryPlot25.setRangeCrosshairLockedOnData(false);
        categoryPlot25.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(sortOrder35);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        xYPlot0.setRangeAxis(valueAxis2);
        java.lang.Object obj4 = null;
        boolean boolean5 = xYPlot0.equals(obj4);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        boolean boolean4 = xYPlot0.isRangeGridlinesVisible();
        xYPlot0.setRangeCrosshairValue((-16.0d), true);
        java.awt.Paint paint8 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        java.awt.Paint paint3 = dateAxis0.getLabelPaint();
        org.jfree.data.Range range4 = null;
        try {
            dateAxis0.setRange(range4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight(10.0d);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D4, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.Plot plot45 = numberAxis31.getPlot();
        java.awt.Shape shape46 = numberAxis31.getDownArrow();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(plot45);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Stroke stroke2 = xYPlot0.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setMaximumCategoryLabelLines(6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color11, stroke12);
        categoryMarker13.setLabel("hi!");
        boolean boolean16 = chartChangeEventType9.equals((java.lang.Object) categoryMarker13);
        boolean boolean17 = categoryAxis1.equals((java.lang.Object) chartChangeEventType9);
        categoryAxis1.setVisible(false);
        categoryAxis1.setUpperMargin((double) (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        xYPlot0.clearRangeMarkers(12);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        java.awt.Stroke stroke32 = xYPlot0.getDomainZeroBaselineStroke();
        java.awt.geom.Point2D point2D33 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot25.setRowRenderingOrder(sortOrder28);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint31 = xYPlot30.getDomainGridlinePaint();
        java.awt.Stroke stroke32 = xYPlot30.getDomainZeroBaselineStroke();
        categoryPlot25.setRangeCrosshairStroke(stroke32);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        float float13 = numberAxis1.getTickMarkOutsideLength();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setAutoRangeIncludesZero(false);
        java.awt.Color color8 = java.awt.Color.darkGray;
        numberAxis5.setAxisLinePaint((java.awt.Paint) color8);
        java.lang.Object obj10 = numberAxis5.clone();
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis5.setTickMarkPaint(paint11);
        java.text.NumberFormat numberFormat13 = null;
        numberAxis5.setNumberFormatOverride(numberFormat13);
        boolean boolean15 = numberAxis5.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis5.setStandardTickUnits(tickUnitSource16);
        boolean boolean18 = dateAxis3.equals((java.lang.Object) tickUnitSource16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.zoomRange((double) (short) -1, 0.2d);
        dateAxis19.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.util.Date date28 = dateAxis19.calculateHighestVisibleTickValue(dateTickUnit26);
        java.util.Date date29 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit26);
        java.util.Date date30 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit26);
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(dateTickUnit31);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.centerRange((double) (byte) 0);
        numberAxis1.setAutoRangeIncludesZero(false);
        boolean boolean8 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color7, dataset8);
        xYPlot0.datasetChanged(datasetChangeEvent9);
        java.awt.Paint paint11 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        xYPlot0.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis9.getCategoryEnd(0, (int) (short) 0, rectangle2D12, rectangleEdge13);
        categoryAxis9.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getBottom();
        double double20 = rectangleInsets17.extendHeight((double) (short) 0);
        double double22 = rectangleInsets17.calculateRightInset((double) 8);
        categoryAxis9.setTickLabelInsets(rectangleInsets17);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape26 = numberAxis25.getUpArrow();
        numberAxis25.setTickMarksVisible(false);
        double double29 = numberAxis25.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis25.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer31);
        categoryPlot32.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot32.getRendererForDataset(categoryDataset35);
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker41.setLabel("hi!");
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker41.setStroke(stroke44);
        java.awt.Paint paint46 = categoryMarker41.getLabelPaint();
        boolean boolean47 = categoryMarker41.getDrawAsLine();
        org.jfree.chart.text.TextAnchor textAnchor48 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        categoryMarker41.setLabelTextAnchor(textAnchor48);
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = categoryAxis52.getCategoryEnd(0, (int) (short) 0, rectangle2D55, rectangleEdge56);
        categoryAxis52.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double61 = rectangleInsets60.getBottom();
        double double63 = rectangleInsets60.extendHeight((double) (short) 0);
        double double65 = rectangleInsets60.calculateRightInset((double) 8);
        categoryAxis52.setTickLabelInsets(rectangleInsets60);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape69 = numberAxis68.getUpArrow();
        numberAxis68.setTickMarksVisible(false);
        double double72 = numberAxis68.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = numberAxis68.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis68, categoryItemRenderer74);
        categoryPlot75.zoom(0.0d);
        categoryPlot75.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint80 = categoryPlot75.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor81 = categoryPlot75.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace82 = null;
        categoryPlot75.setFixedDomainAxisSpace(axisSpace82, true);
        java.awt.Color color87 = java.awt.Color.darkGray;
        java.awt.Stroke stroke88 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker89 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color87, stroke88);
        categoryMarker89.setLabel("hi!");
        java.awt.Stroke stroke92 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker89.setStroke(stroke92);
        org.jfree.chart.util.Layer layer94 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot75.addDomainMarker((int) '4', categoryMarker89, layer94, true);
        categoryPlot32.addDomainMarker((int) '#', categoryMarker41, layer94, false);
        java.util.Collection collection99 = xYPlot0.getRangeMarkers((int) 'a', layer94);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 4.0d + "'", double61 == 4.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 8.0d + "'", double63 == 8.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 8.0d + "'", double65 == 8.0d);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.05d + "'", double72 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(categoryAnchor81);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(stroke92);
        org.junit.Assert.assertNotNull(layer94);
        org.junit.Assert.assertNull(collection99);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str1.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        java.awt.Paint paint5 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke6);
        java.awt.Paint paint8 = categoryMarker3.getLabelPaint();
        boolean boolean9 = categoryMarker3.getDrawAsLine();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        categoryMarker3.setLabelTextAnchor(textAnchor10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis14.getCategoryEnd(0, (int) (short) 0, rectangle2D17, rectangleEdge18);
        categoryAxis14.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double23 = rectangleInsets22.getBottom();
        double double25 = rectangleInsets22.extendHeight((double) (short) 0);
        double double27 = rectangleInsets22.calculateRightInset((double) 8);
        categoryAxis14.setTickLabelInsets(rectangleInsets22);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape31 = numberAxis30.getUpArrow();
        numberAxis30.setTickMarksVisible(false);
        double double34 = numberAxis30.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = numberAxis30.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer36);
        categoryPlot37.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder40 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot37.setRowRenderingOrder(sortOrder40);
        boolean boolean42 = textAnchor10.equals((java.lang.Object) sortOrder40);
        boolean boolean44 = sortOrder40.equals((java.lang.Object) 255);
        boolean boolean46 = sortOrder40.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 8.0d + "'", double27 == 8.0d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(sortOrder40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = categoryPlot25.getDrawingSupplier();
        java.awt.Paint paint35 = categoryPlot25.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.awt.Color color3 = java.awt.Color.lightGray;
        boolean boolean4 = day2.equals((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day2.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        dateAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date11 = dateAxis7.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis14.setAutoRangeIncludesZero(false);
        java.awt.Color color17 = java.awt.Color.darkGray;
        numberAxis14.setAxisLinePaint((java.awt.Paint) color17);
        java.lang.Object obj19 = numberAxis14.clone();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis14.setTickMarkPaint(paint20);
        java.text.NumberFormat numberFormat22 = null;
        numberAxis14.setNumberFormatOverride(numberFormat22);
        boolean boolean24 = numberAxis14.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis14.setStandardTickUnits(tickUnitSource25);
        boolean boolean27 = dateAxis12.equals((java.lang.Object) tickUnitSource25);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.zoomRange((double) (short) -1, 0.2d);
        dateAxis28.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis34.setTickUnit(dateTickUnit35);
        java.util.Date date37 = dateAxis28.calculateHighestVisibleTickValue(dateTickUnit35);
        java.util.Date date38 = dateAxis12.calculateHighestVisibleTickValue(dateTickUnit35);
        try {
            dateAxis0.setRange(date11, date38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot29.setRangeAxisLocation(axisLocation31, true);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setAutoRangeIncludesZero(false);
        java.awt.Color color38 = java.awt.Color.darkGray;
        numberAxis35.setAxisLinePaint((java.awt.Paint) color38);
        numberAxis35.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.AxisState axisState43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        java.util.List list46 = numberAxis35.refreshTicks(graphics2D42, axisState43, rectangle2D44, rectangleEdge45);
        java.awt.Paint paint47 = numberAxis35.getTickMarkPaint();
        categoryPlot29.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        categoryPlot29.setWeight((int) (byte) -1);
        categoryPlot29.clearRangeMarkers(10);
        java.awt.Color color54 = java.awt.Color.darkGray;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color54, stroke55);
        categoryMarker56.setLabel("hi!");
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker56.setStroke(stroke59);
        java.awt.Paint paint61 = categoryMarker56.getLabelPaint();
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean63 = categoryPlot29.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker56, layer62);
        java.util.Collection collection64 = xYPlot0.getRangeMarkers(layer62);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(collection64);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setAutoRangeIncludesZero(false);
        java.awt.Color color5 = java.awt.Color.darkGray;
        numberAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = numberAxis2.clone();
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis2.setTickMarkPaint(paint8);
        java.text.NumberFormat numberFormat10 = null;
        numberAxis2.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis2.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis2.setStandardTickUnits(tickUnitSource13);
        boolean boolean15 = dateAxis0.equals((java.lang.Object) tickUnitSource13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) (short) -1, 0.2d);
        dateAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit23);
        java.util.Date date26 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit23);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double29 = rectangleInsets27.calculateLeftInset(1.0E-8d);
        java.awt.Color color31 = java.awt.Color.darkGray;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color31, stroke32);
        categoryMarker33.setLabel("hi!");
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker33.setStroke(stroke36);
        boolean boolean38 = rectangleInsets27.equals((java.lang.Object) stroke36);
        dateAxis0.setAxisLineStroke(stroke36);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean33 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot0.zoomDomainAxes((double) '4', (double) 100.0f, plotRenderingInfo36, point2D37);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        java.lang.String str8 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 64, (int) (byte) 0, rectangle2D12, rectangleEdge13);
        categoryAxis1.setLabel("RectangleAnchor.TOP_LEFT");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        java.awt.Paint paint20 = dateAxis17.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis21.setTickUnit(dateTickUnit22);
        dateAxis17.setTickUnit(dateTickUnit22, false, true);
        java.lang.String str27 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) false);
        categoryAxis1.setLowerMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis27.getCategoryEnd(0, (int) (short) 0, rectangle2D30, rectangleEdge31);
        double double33 = categoryAxis27.getCategoryMargin();
        categoryAxis27.setMaximumCategoryLabelWidthRatio((float) (byte) -1);
        java.awt.Font font37 = null;
        categoryAxis27.setTickLabelFont((java.lang.Comparable) (byte) 10, font37);
        categoryAxis27.setUpperMargin((double) (byte) 100);
        categoryPlot25.setDomainAxis(categoryAxis27);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline9 = dateAxis5.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Paint paint13 = dateAxis10.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis14.setTickUnit(dateTickUnit15);
        dateAxis10.setTickUnit(dateTickUnit15, false, true);
        java.util.Date date20 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit15);
        java.util.Date date21 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit15);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(timeline9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getRangeAxisEdge();
        boolean boolean60 = xYPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        xYPlot0.setWeight(12);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        intervalMarker2.setStartValue((double) 64);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis36.getCategoryEnd(0, (int) (short) 0, rectangle2D39, rectangleEdge40);
        categoryAxis36.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets44.getBottom();
        double double47 = rectangleInsets44.extendHeight((double) (short) 0);
        double double49 = rectangleInsets44.calculateRightInset((double) 8);
        categoryAxis36.setTickLabelInsets(rectangleInsets44);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape53 = numberAxis52.getUpArrow();
        numberAxis52.setTickMarksVisible(false);
        double double56 = numberAxis52.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis52.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis52, categoryItemRenderer58);
        categoryPlot59.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder62 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot59.setRowRenderingOrder(sortOrder62);
        categoryPlot25.setColumnRenderingOrder(sortOrder62);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        try {
            categoryPlot25.drawBackground(graphics2D65, rectangle2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(sortOrder62);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline5 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeline5);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        int int18 = xYPlot0.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis22.getCategoryEnd(0, (int) (short) 0, rectangle2D25, rectangleEdge26);
        categoryAxis22.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double31 = rectangleInsets30.getBottom();
        double double33 = rectangleInsets30.extendHeight((double) (short) 0);
        double double35 = rectangleInsets30.calculateRightInset((double) 8);
        categoryAxis22.setTickLabelInsets(rectangleInsets30);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape39 = numberAxis38.getUpArrow();
        numberAxis38.setTickMarksVisible(false);
        double double42 = numberAxis38.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis38.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis38, categoryItemRenderer44);
        categoryPlot45.zoom(0.0d);
        categoryPlot45.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint50 = categoryPlot45.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = categoryPlot45.getDomainGridlinePosition();
        java.awt.Color color53 = java.awt.Color.darkGray;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color53, stroke54);
        categoryMarker55.setLabel("hi!");
        java.awt.Color color59 = java.awt.Color.darkGray;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color59, stroke60);
        categoryMarker55.setStroke(stroke60);
        categoryMarker55.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint65 = categoryMarker55.getLabelPaint();
        categoryPlot45.addDomainMarker(categoryMarker55);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot45.getRangeAxis();
        xYPlot0.setDomainAxis((int) (short) 1, valueAxis67);
        boolean boolean69 = xYPlot0.isSubplot();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(categoryAnchor51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxis67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(9, axisLocation38);
        boolean boolean40 = categoryPlot25.isOutlineVisible();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            categoryPlot25.drawBackground(graphics2D41, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getDomainAxisLocation();
        java.awt.Image image7 = null;
        xYPlot5.setBackgroundImage(image7);
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color11, stroke12);
        categoryMarker13.setLabel("hi!");
        categoryMarker13.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker13.setLabelFont(font18);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean22 = xYPlot5.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker13, layer20, true);
        categoryMarker13.setKey((java.lang.Comparable) 1.0d);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener26 = null;
        categoryMarker13.addChangeListener(markerChangeListener26);
        try {
            categoryMarker13.setAlpha((float) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        double double3 = dateAxis0.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date8 = dateAxis4.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis0.dateToJava2D(date8, rectangle2D9, rectangleEdge10);
        org.jfree.chart.ChartColor chartColor15 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 10, (int) '#');
        dateAxis0.setAxisLinePaint((java.awt.Paint) chartColor15);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(0, (int) (short) 0, rectangle2D16, rectangleEdge17);
        categoryAxis13.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getBottom();
        double double24 = rectangleInsets21.extendHeight((double) (short) 0);
        double double26 = rectangleInsets21.calculateRightInset((double) 8);
        categoryAxis13.setTickLabelInsets(rectangleInsets21);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape30 = numberAxis29.getUpArrow();
        numberAxis29.setTickMarksVisible(false);
        double double33 = numberAxis29.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis29.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer35);
        categoryPlot36.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot36.getRendererForDataset(categoryDataset39);
        java.lang.String str41 = categoryPlot36.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(4, axisLocation43);
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation43, false);
        int int47 = xYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        xYPlot0.setRangeCrosshairValue((double) (short) 0, true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        java.awt.Color color13 = color11.darker();
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke15 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Point2D point2D61 = null;
        categoryPlot57.zoomDomainAxes((double) (-1), plotRenderingInfo60, point2D61, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent64 = null;
        categoryPlot57.rendererChanged(rendererChangeEvent64);
        categoryPlot57.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier68 = categoryPlot57.getDrawingSupplier();
        categoryPlot25.setDrawingSupplier(drawingSupplier68);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(drawingSupplier68);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        double double8 = rectangleInsets6.calculateTopOutset((double) 8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double49 = rectangleInsets47.calculateLeftInset(1.0E-8d);
        java.awt.Color color51 = java.awt.Color.darkGray;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color51, stroke52);
        categoryMarker53.setLabel("hi!");
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker53.setStroke(stroke56);
        boolean boolean58 = rectangleInsets47.equals((java.lang.Object) stroke56);
        categoryPlot25.setInsets(rectangleInsets47, true);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets47.createOutsetRectangle(rectangle2D61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        float float5 = xYPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        double double3 = dateAxis0.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date8 = dateAxis4.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis0.dateToJava2D(date8, rectangle2D9, rectangleEdge10);
        boolean boolean12 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setCategoryLabelPositionOffset((int) '4');
        categoryAxis1.setUpperMargin((double) 9);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot25.setRenderer(categoryItemRenderer47);
        float float49 = categoryPlot25.getForegroundAlpha();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation50 = null;
        try {
            categoryPlot25.addAnnotation(categoryAnnotation50, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 1.0f + "'", float49 == 1.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        java.awt.Color color37 = java.awt.Color.darkGray;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color37, stroke38);
        categoryMarker39.setLabel("hi!");
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker39.setStroke(stroke42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot25.addDomainMarker((int) '4', categoryMarker39, layer44, true);
        org.jfree.chart.util.SortOrder sortOrder47 = null;
        try {
            categoryPlot25.setRowRenderingOrder(sortOrder47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(layer44);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        float float8 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Color color0 = java.awt.Color.CYAN;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        try {
            categoryPlot25.zoomRangeAxes((double) (byte) 0, plotRenderingInfo32, point2D33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setAutoRangeIncludesZero(false);
        java.awt.Color color5 = java.awt.Color.darkGray;
        numberAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = numberAxis2.clone();
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis2.setTickMarkPaint(paint8);
        java.text.NumberFormat numberFormat10 = null;
        numberAxis2.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis2.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis2.setStandardTickUnits(tickUnitSource13);
        boolean boolean15 = dateAxis0.equals((java.lang.Object) tickUnitSource13);
        dateAxis0.setLowerBound(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        float float21 = xYPlot20.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = xYPlot20.getAxisOffset();
        java.lang.Object obj23 = xYPlot20.clone();
        java.awt.Paint paint24 = xYPlot20.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot20.getDomainAxisEdge((int) '4');
        try {
            double double27 = dateAxis0.valueToJava2D((double) '4', rectangle2D19, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getRangeAxis();
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 10);
        double double4 = rectangleInsets0.calculateTopOutset((-1.0d));
        double double6 = rectangleInsets0.calculateRightOutset(0.0d);
        double double7 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        java.awt.Stroke stroke5 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        int int47 = categoryPlot25.getDomainAxisCount();
        int int48 = categoryPlot25.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double49 = rectangleInsets47.calculateLeftInset(1.0E-8d);
        java.awt.Color color51 = java.awt.Color.darkGray;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color51, stroke52);
        categoryMarker53.setLabel("hi!");
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker53.setStroke(stroke56);
        boolean boolean58 = rectangleInsets47.equals((java.lang.Object) stroke56);
        categoryPlot25.setInsets(rectangleInsets47, true);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        float float62 = xYPlot61.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = xYPlot61.getAxisOffset();
        java.lang.Object obj64 = xYPlot61.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        xYPlot61.setRenderer((int) ' ', xYItemRenderer66);
        xYPlot61.mapDatasetToRangeAxis(6, (int) (short) 10);
        java.awt.Paint paint71 = xYPlot61.getRangeCrosshairPaint();
        boolean boolean72 = rectangleInsets47.equals((java.lang.Object) xYPlot61);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 1.0f + "'", float62 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = numberAxis52.valueToJava2D((double) (short) 0, rectangle2D60, rectangleEdge61);
        numberAxis52.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNull(paint1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis0.setTimeZone(timeZone8);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot25.getRangeAxis((int) (byte) 100);
        boolean boolean30 = categoryPlot25.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double49 = rectangleInsets47.calculateLeftInset(1.0E-8d);
        java.awt.Color color51 = java.awt.Color.darkGray;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color51, stroke52);
        categoryMarker53.setLabel("hi!");
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker53.setStroke(stroke56);
        boolean boolean58 = rectangleInsets47.equals((java.lang.Object) stroke56);
        categoryPlot25.setInsets(rectangleInsets47, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        categoryPlot25.setRenderer(categoryItemRenderer61, false);
        org.jfree.data.category.CategoryDataset categoryDataset65 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = categoryAxis67.getCategoryEnd(0, (int) (short) 0, rectangle2D70, rectangleEdge71);
        categoryAxis67.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double76 = rectangleInsets75.getBottom();
        double double78 = rectangleInsets75.extendHeight((double) (short) 0);
        double double80 = rectangleInsets75.calculateRightInset((double) 8);
        categoryAxis67.setTickLabelInsets(rectangleInsets75);
        org.jfree.chart.axis.NumberAxis numberAxis83 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape84 = numberAxis83.getUpArrow();
        numberAxis83.setTickMarksVisible(false);
        double double87 = numberAxis83.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets88 = numberAxis83.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer89 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot90 = new org.jfree.chart.plot.CategoryPlot(categoryDataset65, categoryAxis67, (org.jfree.chart.axis.ValueAxis) numberAxis83, categoryItemRenderer89);
        java.awt.Stroke stroke91 = categoryPlot90.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation92 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot90.setRangeAxisLocation(axisLocation92, true);
        java.lang.String str95 = axisLocation92.toString();
        categoryPlot25.setRangeAxisLocation(1, axisLocation92, true);
        boolean boolean98 = categoryPlot25.isSubplot();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 4.0d + "'", double76 == 4.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 8.0d + "'", double78 == 8.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 8.0d + "'", double80 == 8.0d);
        org.junit.Assert.assertNotNull(shape84);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.05d + "'", double87 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets88);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(axisLocation92);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str95.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryPlot25.getFixedRangeAxisSpace();
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker41.setLabel("hi!");
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker41.setStroke(stroke44);
        java.awt.Paint paint46 = categoryMarker41.getPaint();
        categoryPlot25.setRangeGridlinePaint(paint46);
        categoryPlot25.zoom((double) '4');
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis6.setAutoRangeIncludesZero(false);
        java.awt.Color color9 = java.awt.Color.darkGray;
        numberAxis6.setAxisLinePaint((java.awt.Paint) color9);
        java.lang.Object obj11 = numberAxis6.clone();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis6.setTickMarkPaint(paint12);
        java.text.NumberFormat numberFormat14 = null;
        numberAxis6.setNumberFormatOverride(numberFormat14);
        boolean boolean16 = numberAxis6.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis6.setStandardTickUnits(tickUnitSource17);
        boolean boolean19 = dateAxis4.equals((java.lang.Object) tickUnitSource17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline24 = dateAxis20.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Paint paint28 = dateAxis25.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis29.setTickUnit(dateTickUnit30);
        dateAxis25.setTickUnit(dateTickUnit30, false, true);
        java.util.Date date35 = dateAxis20.calculateHighestVisibleTickValue(dateTickUnit30);
        dateAxis4.setTickUnit(dateTickUnit30);
        dateAxis0.setTickUnit(dateTickUnit30, false, false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timeline24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = categoryMarker3.getLabelOffsetType();
        org.jfree.chart.text.TextAnchor textAnchor7 = categoryMarker3.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = categoryAxis64.getCategoryEnd(0, (int) (short) 0, rectangle2D67, rectangleEdge68);
        java.lang.String str71 = categoryAxis64.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = null;
        double double77 = categoryAxis64.getCategoryJava2DCoordinate(categoryAnchor72, 64, (int) (byte) 0, rectangle2D75, rectangleEdge76);
        float float78 = categoryAxis64.getMaximumCategoryLabelWidthRatio();
        categoryPlot57.setDomainAxis(0, categoryAxis64);
        float float80 = categoryPlot57.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        java.awt.geom.Point2D point2D83 = null;
        categoryPlot57.zoomRangeAxes((double) 10.0f, plotRenderingInfo82, point2D83, false);
        org.jfree.chart.axis.ValueAxis valueAxis86 = null;
        try {
            int int87 = categoryPlot57.getRangeAxisIndex(valueAxis86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
        org.junit.Assert.assertTrue("'" + float80 + "' != '" + 1.0f + "'", float80 == 1.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace26, false);
        int int29 = categoryPlot25.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot25.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNull(axisSpace30);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.Plot plot45 = numberAxis31.getPlot();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = categoryAxis48.getCategoryEnd(0, (int) (short) 0, rectangle2D51, rectangleEdge52);
        categoryAxis48.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double57 = rectangleInsets56.getBottom();
        double double59 = rectangleInsets56.extendHeight((double) (short) 0);
        double double61 = rectangleInsets56.calculateRightInset((double) 8);
        categoryAxis48.setTickLabelInsets(rectangleInsets56);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape65 = numberAxis64.getUpArrow();
        numberAxis64.setTickMarksVisible(false);
        double double68 = numberAxis64.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = numberAxis64.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis64, categoryItemRenderer70);
        java.awt.Stroke stroke72 = categoryPlot71.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation73 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot71.setRangeAxisLocation(axisLocation73, true);
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis77.setAutoRangeIncludesZero(false);
        java.awt.Color color80 = java.awt.Color.darkGray;
        numberAxis77.setAxisLinePaint((java.awt.Paint) color80);
        numberAxis77.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D84 = null;
        org.jfree.chart.axis.AxisState axisState85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = null;
        java.util.List list88 = numberAxis77.refreshTicks(graphics2D84, axisState85, rectangle2D86, rectangleEdge87);
        java.awt.Paint paint89 = numberAxis77.getTickMarkPaint();
        categoryPlot71.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis77);
        categoryPlot71.setWeight((int) (byte) -1);
        plot45.setParent((org.jfree.chart.plot.Plot) categoryPlot71);
        categoryPlot71.setRangeCrosshairValue((double) (short) 1, false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(plot45);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 4.0d + "'", double57 == 4.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 8.0d + "'", double59 == 8.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 8.0d + "'", double61 == 8.0d);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.05d + "'", double68 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(axisLocation73);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(list88);
        org.junit.Assert.assertNotNull(paint89);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        java.lang.Object obj4 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        double double11 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setUpperMargin(0.05d);
        boolean boolean14 = xYPlot0.equals((java.lang.Object) categoryAxis5);
        java.awt.Stroke stroke15 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setCategoryLabelPositionOffset((int) '4');
        java.awt.Paint paint9 = categoryAxis1.getTickMarkPaint();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint11 = xYPlot10.getDomainGridlinePaint();
        boolean boolean12 = xYPlot10.isRangeCrosshairVisible();
        boolean boolean13 = categoryAxis1.equals((java.lang.Object) boolean12);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        categoryPlot25.clearDomainMarkers((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color65 = java.awt.Color.RED;
        categoryAxis64.setTickLabelPaint((java.awt.Paint) color65);
        int int67 = categoryPlot25.getDomainAxisIndex(categoryAxis64);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setAutoRangeIncludesZero(false);
        java.awt.Color color5 = java.awt.Color.darkGray;
        numberAxis2.setAxisLinePaint((java.awt.Paint) color5);
        java.lang.Object obj7 = numberAxis2.clone();
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis2.setTickMarkPaint(paint8);
        java.text.NumberFormat numberFormat10 = null;
        numberAxis2.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis2.isAutoRange();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis2.setStandardTickUnits(tickUnitSource13);
        boolean boolean15 = dateAxis0.equals((java.lang.Object) tickUnitSource13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.zoomRange((double) (short) -1, 0.2d);
        dateAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit23);
        java.util.Date date26 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit23);
        dateAxis0.zoomRange(40.0d, (double) 64);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis0.setUpArrow(shape30);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline36 = dateAxis32.getTimeline();
        dateAxis32.setLabelURL("hi!");
        dateAxis32.setAutoRangeMinimumSize((double) 2.0f, true);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        java.awt.Paint paint45 = dateAxis42.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis46.setTickUnit(dateTickUnit47);
        dateAxis42.setTickUnit(dateTickUnit47, false, true);
        java.util.Date date52 = dateAxis32.calculateLowestVisibleTickValue(dateTickUnit47);
        dateAxis0.setMaximumDate(date52);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(dateTickUnit47);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        boolean boolean30 = categoryPlot25.isDomainGridlinesVisible();
        org.jfree.chart.plot.Plot plot31 = categoryPlot25.getRootPlot();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(plot31);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color0 = java.awt.Color.pink;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.String str6 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot25.setWeight((int) (byte) -1);
        categoryPlot25.clearRangeMarkers(10);
        org.jfree.data.general.DatasetGroup datasetGroup49 = categoryPlot25.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(datasetGroup49);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str1.equals("TextAnchor.HALF_ASCENT_CENTER"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setAxisLineVisible(true);
        java.lang.String str10 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Image image4 = null;
        xYPlot0.setBackgroundImage(image4);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer5);
        xYPlot0.mapDatasetToRangeAxis(6, (int) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double12 = rectangleInsets10.calculateLeftInset(1.0E-8d);
        double double13 = rectangleInsets10.getTop();
        xYPlot0.setInsets(rectangleInsets10, false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = xYPlot1.getDomainAxisLocation();
        boolean boolean3 = xYPlot1.isRangeGridlinesVisible();
        boolean boolean4 = xYPlot1.isOutlineVisible();
        boolean boolean5 = categoryAnchor0.equals((java.lang.Object) xYPlot1);
        xYPlot1.clearAnnotations();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange((double) (short) -1, 0.2d);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.util.Date date10 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("", timeZone11);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        categoryMarker3.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker3.setLabelFont(font8);
        java.awt.Paint paint10 = categoryMarker3.getLabelPaint();
        java.awt.Stroke stroke11 = categoryMarker3.getStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        dateAxis0.setRange((double) 10L, (double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis0.valueToJava2D((double) 10L, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis0.setTickUnit(dateTickUnit10);
        java.awt.Font font12 = dateAxis0.getLabelFont();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.jfree.data.general.Dataset dataset4 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertNull(dataset4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = categoryPlot25.getDrawingSupplier();
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        java.lang.Object obj4 = chartChangeEvent2.getSource();
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + ' ' + "'", obj4.equals(' '));
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getDomainGridlineStroke();
        int int31 = categoryPlot29.getWeight();
        java.awt.Stroke stroke32 = categoryPlot29.getDomainGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setUpperMargin((double) 10);
        int int38 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Paint paint39 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot25.getDataset((int) (byte) 0);
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(categoryDataset31);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = categoryAxis64.getCategoryEnd(0, (int) (short) 0, rectangle2D67, rectangleEdge68);
        java.lang.String str71 = categoryAxis64.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = null;
        double double77 = categoryAxis64.getCategoryJava2DCoordinate(categoryAnchor72, 64, (int) (byte) 0, rectangle2D75, rectangleEdge76);
        float float78 = categoryAxis64.getMaximumCategoryLabelWidthRatio();
        categoryPlot57.setDomainAxis(0, categoryAxis64);
        categoryAxis64.setUpperMargin((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(0, (int) (short) 0, rectangle2D16, rectangleEdge17);
        categoryAxis13.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getBottom();
        double double24 = rectangleInsets21.extendHeight((double) (short) 0);
        double double26 = rectangleInsets21.calculateRightInset((double) 8);
        categoryAxis13.setTickLabelInsets(rectangleInsets21);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape30 = numberAxis29.getUpArrow();
        numberAxis29.setTickMarksVisible(false);
        double double33 = numberAxis29.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis29.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer35);
        categoryPlot36.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot36.getRendererForDataset(categoryDataset39);
        java.lang.String str41 = categoryPlot36.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(4, axisLocation43);
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation43, false);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation43);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        java.awt.Paint paint8 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis9.setTickUnit(dateTickUnit10);
        dateAxis5.setTickUnit(dateTickUnit10, false, true);
        java.util.Date date15 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit10);
        dateAxis0.zoomRange((double) 0L, (double) 1);
        try {
            dateAxis0.zoomRange((double) 1L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        double double4 = rectangleInsets2.calculateTopOutset((double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets2.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = java.awt.Color.RED;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        float float4 = xYPlot3.getForegroundAlpha();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker9.setLabel("hi!");
        categoryMarker9.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color15, stroke16);
        categoryMarker17.setLabel("hi!");
        java.awt.Color color21 = java.awt.Color.darkGray;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color21, stroke22);
        categoryMarker17.setStroke(stroke22);
        categoryMarker9.setStroke(stroke22);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean28 = xYPlot3.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker9, layer26, true);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot3.setDataset(xYDataset29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot3.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        boolean boolean35 = xYPlot3.isDomainCrosshairVisible();
        boolean boolean36 = xYPlot3.isDomainZeroBaselineVisible();
        boolean boolean37 = categoryAxis0.equals((java.lang.Object) xYPlot3);
        double double38 = categoryAxis0.getLowerMargin();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis44.getCategoryEnd(0, (int) (short) 0, rectangle2D47, rectangleEdge48);
        categoryAxis44.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double53 = rectangleInsets52.getBottom();
        double double55 = rectangleInsets52.extendHeight((double) (short) 0);
        double double57 = rectangleInsets52.calculateRightInset((double) 8);
        categoryAxis44.setTickLabelInsets(rectangleInsets52);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape61 = numberAxis60.getUpArrow();
        numberAxis60.setTickMarksVisible(false);
        double double64 = numberAxis60.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = numberAxis60.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis60, categoryItemRenderer66);
        categoryPlot67.zoom(0.0d);
        categoryPlot67.clearRangeMarkers((int) (short) 0);
        int int72 = categoryPlot67.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        categoryPlot67.setDataset(categoryDataset73);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = categoryPlot67.getDomainAxisEdge(12);
        try {
            double double77 = categoryAxis0.getCategoryStart((-123), 0, rectangle2D41, rectangleEdge76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 4.0d + "'", double53 == 4.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 8.0d + "'", double55 == 8.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 8.0d + "'", double57 == 8.0d);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.05d + "'", double64 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge76);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(9, axisLocation38);
        boolean boolean40 = categoryPlot25.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot25.setRenderer(categoryItemRenderer41);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer5);
        xYPlot0.mapDatasetToRangeAxis(6, (int) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        java.awt.Color color15 = java.awt.Color.darkGray;
        numberAxis12.setAxisLinePaint((java.awt.Paint) color15);
        org.jfree.data.RangeType rangeType17 = numberAxis12.getRangeType();
        try {
            xYPlot0.setRangeAxis((-123), (org.jfree.chart.axis.ValueAxis) numberAxis12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rangeType17);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        numberAxis18.zoomRange(2.0d, 18.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = categoryAxis64.getCategoryEnd(0, (int) (short) 0, rectangle2D67, rectangleEdge68);
        java.lang.String str71 = categoryAxis64.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = null;
        double double77 = categoryAxis64.getCategoryJava2DCoordinate(categoryAnchor72, 64, (int) (byte) 0, rectangle2D75, rectangleEdge76);
        float float78 = categoryAxis64.getMaximumCategoryLabelWidthRatio();
        categoryPlot57.setDomainAxis(0, categoryAxis64);
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj82 = categoryAxis81.clone();
        java.awt.Stroke stroke83 = categoryAxis81.getTickMarkStroke();
        categoryPlot57.setRangeCrosshairStroke(stroke83);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertNotNull(stroke83);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit7);
        java.util.Date date9 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        boolean boolean14 = day11.equals((java.lang.Object) color13);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        double double10 = numberAxis1.getFixedDimension();
        float float11 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        categoryPlot25.setRenderer(15, categoryItemRenderer27);
        categoryPlot25.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        valueMarker1.setValue(100.0d);
        double double4 = valueMarker1.getValue();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getDomainAxisLocation();
        boolean boolean7 = xYPlot5.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = xYPlot5.getRangeMarkers(layer8);
        java.awt.Paint paint10 = xYPlot5.getDomainZeroBaselinePaint();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot5);
        java.awt.Paint paint12 = xYPlot5.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        categoryPlot25.mapDatasetToRangeAxis((int) 'a', (int) (byte) 10);
        categoryPlot25.setBackgroundImageAlignment((-123));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot25.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot25.getRendererForDataset(categoryDataset41);
        categoryPlot25.setWeight((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNull(categoryItemRenderer42);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        java.awt.Paint paint4 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getDomainAxisEdge((int) '4');
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset(10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Stroke stroke3 = categoryAxis1.getTickMarkStroke();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 4.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, false);
        boolean boolean7 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        valueMarker1.setValue(100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double6 = rectangleInsets4.calculateBottomInset((double) 10);
        double double8 = rectangleInsets4.calculateTopOutset((-1.0d));
        double double10 = rectangleInsets4.calculateRightOutset(0.0d);
        boolean boolean11 = valueMarker1.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        int int13 = xYPlot10.indexOf(xYDataset12);
        boolean boolean14 = xYPlot10.isRangeGridlinesVisible();
        xYPlot10.setRangeCrosshairValue((-16.0d), true);
        boolean boolean18 = numberAxis1.hasListener((java.util.EventListener) xYPlot10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainGridlinePaint();
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        categoryMarker5.setLabel("hi!");
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date13 = dateAxis9.getMinimumDate();
        java.awt.Stroke stroke14 = dateAxis9.getAxisLineStroke();
        categoryMarker5.setOutlineStroke(stroke14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = java.awt.Color.RED;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        float float4 = xYPlot3.getForegroundAlpha();
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker9.setLabel("hi!");
        categoryMarker9.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color15 = java.awt.Color.darkGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color15, stroke16);
        categoryMarker17.setLabel("hi!");
        java.awt.Color color21 = java.awt.Color.darkGray;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color21, stroke22);
        categoryMarker17.setStroke(stroke22);
        categoryMarker9.setStroke(stroke22);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean28 = xYPlot3.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker9, layer26, true);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot3.setDataset(xYDataset29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot3.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        boolean boolean35 = xYPlot3.isDomainCrosshairVisible();
        boolean boolean36 = xYPlot3.isDomainZeroBaselineVisible();
        boolean boolean37 = categoryAxis0.equals((java.lang.Object) xYPlot3);
        org.jfree.chart.plot.Plot plot38 = categoryAxis0.getPlot();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(plot38);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 0L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        int int27 = categoryPlot25.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot25.getRangeAxisEdge();
        java.awt.Image image29 = categoryPlot25.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(image29);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        xYPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(legendItemCollection34);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange((double) (-1));
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis28.getCategoryEnd(0, (int) (short) 0, rectangle2D31, rectangleEdge32);
        categoryAxis28.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double37 = rectangleInsets36.getBottom();
        double double39 = rectangleInsets36.extendHeight((double) (short) 0);
        double double41 = rectangleInsets36.calculateRightInset((double) 8);
        categoryAxis28.setTickLabelInsets(rectangleInsets36);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape45 = numberAxis44.getUpArrow();
        numberAxis44.setTickMarksVisible(false);
        double double48 = numberAxis44.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = numberAxis44.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer50);
        categoryPlot51.zoom(0.0d);
        categoryPlot51.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint56 = categoryPlot51.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor57 = categoryPlot51.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        categoryPlot51.setFixedDomainAxisSpace(axisSpace58, true);
        java.awt.Color color63 = java.awt.Color.darkGray;
        java.awt.Stroke stroke64 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color63, stroke64);
        categoryMarker65.setLabel("hi!");
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker65.setStroke(stroke68);
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot51.addDomainMarker((int) '4', categoryMarker65, layer70, true);
        java.util.Collection collection73 = categoryPlot25.getDomainMarkers(layer70);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 8.0d + "'", double39 == 8.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 8.0d + "'", double41 == 8.0d);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(categoryAnchor57);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertNull(collection73);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.zoomRange((double) (short) -1, 0.2d);
        dateAxis29.setNegativeArrowVisible(true);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis29, true);
        int int37 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.geom.Rectangle2D rectangle2D4 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
//        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
//        float float7 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        long long10 = day8.getMiddleMillisecond();
//        java.lang.Object obj11 = null;
//        int int12 = day8.compareTo(obj11);
//        java.lang.String str13 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day8);
//        int int14 = day8.getMonth();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setRange((double) (short) 1, (double) (short) 100);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = dateAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = null;
        try {
            dateAxis0.setRange(range10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.zoomRange((double) (short) -1, 0.2d);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.util.Date date10 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=175,b=175]", timeZone11);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        boolean boolean2 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) 2.0f, (double) 8, plotRenderingInfo5, point2D6);
        org.junit.Assert.assertNull(valueAxis1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        java.lang.String str33 = axisLocation30.toString();
        xYPlot0.setDomainAxisLocation(500, axisLocation30);
        java.awt.Paint paint35 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        float float37 = xYPlot36.getForegroundAlpha();
        java.awt.Color color40 = java.awt.Color.darkGray;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color40, stroke41);
        categoryMarker42.setLabel("hi!");
        categoryMarker42.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color48 = java.awt.Color.darkGray;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color48, stroke49);
        categoryMarker50.setLabel("hi!");
        java.awt.Color color54 = java.awt.Color.darkGray;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color54, stroke55);
        categoryMarker50.setStroke(stroke55);
        categoryMarker42.setStroke(stroke55);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean61 = xYPlot36.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker42, layer59, true);
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        xYPlot36.setDataset(xYDataset62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        xYPlot36.drawAnnotations(graphics2D64, rectangle2D65, plotRenderingInfo66);
        java.awt.Stroke stroke68 = xYPlot36.getDomainZeroBaselineStroke();
        xYPlot0.setDomainGridlineStroke(stroke68);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str33.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace5);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint9 = xYPlot8.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot8.getDomainAxisLocation((int) (byte) 100);
        xYPlot0.setDomainAxisLocation(255, axisLocation11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis3.setAutoRangeIncludesZero(false);
        java.lang.Object obj6 = numberAxis3.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3.getStandardTickUnits();
        numberAxis3.setTickMarksVisible(false);
        org.jfree.data.Range range10 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis17.getCategoryEnd(0, (int) (short) 0, rectangle2D20, rectangleEdge21);
        categoryAxis17.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets25.getBottom();
        double double28 = rectangleInsets25.extendHeight((double) (short) 0);
        double double30 = rectangleInsets25.calculateRightInset((double) 8);
        categoryAxis17.setTickLabelInsets(rectangleInsets25);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape34 = numberAxis33.getUpArrow();
        numberAxis33.setTickMarksVisible(false);
        double double37 = numberAxis33.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis33.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer39);
        java.awt.Stroke stroke41 = categoryPlot40.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation42, true);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis46.setAutoRangeIncludesZero(false);
        java.awt.Color color49 = java.awt.Color.darkGray;
        numberAxis46.setAxisLinePaint((java.awt.Paint) color49);
        numberAxis46.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.axis.AxisState axisState54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        java.util.List list57 = numberAxis46.refreshTicks(graphics2D53, axisState54, rectangle2D55, rectangleEdge56);
        java.awt.Paint paint58 = numberAxis46.getTickMarkPaint();
        categoryPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis46);
        categoryPlot40.setWeight((int) (byte) -1);
        categoryPlot40.clearRangeMarkers(10);
        java.awt.Color color65 = java.awt.Color.darkGray;
        java.awt.Stroke stroke66 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color65, stroke66);
        categoryMarker67.setLabel("hi!");
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker67.setStroke(stroke70);
        java.awt.Paint paint72 = categoryMarker67.getLabelPaint();
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean74 = categoryPlot40.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker67, layer73);
        boolean boolean75 = xYPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker14, layer73);
        double double76 = intervalMarker14.getStartValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 8.0d + "'", double28 == 8.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 8.0d + "'", double30 == 8.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + (-1.0d) + "'", double76 == (-1.0d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(0, (int) (short) 0, rectangle2D16, rectangleEdge17);
        categoryAxis13.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getBottom();
        double double24 = rectangleInsets21.extendHeight((double) (short) 0);
        double double26 = rectangleInsets21.calculateRightInset((double) 8);
        categoryAxis13.setTickLabelInsets(rectangleInsets21);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape30 = numberAxis29.getUpArrow();
        numberAxis29.setTickMarksVisible(false);
        double double33 = numberAxis29.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis29.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer35);
        categoryPlot36.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot36.getRendererForDataset(categoryDataset39);
        java.lang.String str41 = categoryPlot36.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(4, axisLocation43);
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation43, false);
        boolean boolean47 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(4, axisLocation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryPlot25.getFixedRangeAxisSpace();
        org.jfree.chart.plot.Plot plot38 = categoryPlot25.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        categoryPlot25.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker40);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertNotNull(plot38);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.RIGHT" + "'", str1.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        org.jfree.chart.axis.Timeline timeline4 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        java.awt.Paint paint8 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis9.setTickUnit(dateTickUnit10);
        dateAxis5.setTickUnit(dateTickUnit10, false, true);
        java.util.Date date15 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit10);
        dateAxis0.zoomRange((double) 0L, (double) 1);
        java.awt.Paint paint19 = dateAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        int int30 = categoryPlot25.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot25.setDataset(categoryDataset31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot25.getDomainAxisEdge(12);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis37.getCategoryEnd(0, (int) (short) 0, rectangle2D40, rectangleEdge41);
        categoryAxis37.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double46 = rectangleInsets45.getBottom();
        double double48 = rectangleInsets45.extendHeight((double) (short) 0);
        double double50 = rectangleInsets45.calculateRightInset((double) 8);
        categoryAxis37.setTickLabelInsets(rectangleInsets45);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape54 = numberAxis53.getUpArrow();
        numberAxis53.setTickMarksVisible(false);
        double double57 = numberAxis53.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis53.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer59);
        categoryPlot60.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder63 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot60.setRowRenderingOrder(sortOrder63);
        categoryPlot25.setColumnRenderingOrder(sortOrder63);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 8.0d + "'", double48 == 8.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 8.0d + "'", double50 == 8.0d);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(sortOrder63);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot25.getRangeAxis((int) 'a');
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32);
        categoryPlot25.mapDatasetToRangeAxis((int) '4', (int) (byte) -1);
        boolean boolean37 = categoryPlot25.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot0.getDomainAxisLocation((int) (byte) -1);
        java.lang.String str28 = xYPlot0.getNoDataMessage();
        boolean boolean29 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        java.awt.Color color6 = color4.darker();
        float[] floatArray12 = new float[] { 1L, 0L, 1.0f, (short) 100, (-1L) };
        float[] floatArray13 = color4.getRGBComponents(floatArray12);
        float[] floatArray14 = color2.getComponents(floatArray13);
        try {
            float[] floatArray15 = color0.getColorComponents(colorSpace1, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(7);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        int int3 = objectList1.indexOf((java.lang.Object) textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis4.getCategoryEnd(0, (int) (short) 0, rectangle2D7, rectangleEdge8);
        categoryAxis4.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets12.getBottom();
        double double15 = rectangleInsets12.extendHeight((double) (short) 0);
        double double17 = rectangleInsets12.calculateRightInset((double) 8);
        categoryAxis4.setTickLabelInsets(rectangleInsets12);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape21 = numberAxis20.getUpArrow();
        numberAxis20.setTickMarksVisible(false);
        double double24 = numberAxis20.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis20.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer26);
        java.awt.Stroke stroke28 = categoryPlot27.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot27.zoomDomainAxes((double) (-1), plotRenderingInfo30, point2D31, true);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis36.getCategoryEnd(0, (int) (short) 0, rectangle2D39, rectangleEdge40);
        categoryAxis36.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double45 = rectangleInsets44.getBottom();
        double double47 = rectangleInsets44.extendHeight((double) (short) 0);
        double double49 = rectangleInsets44.calculateRightInset((double) 8);
        categoryAxis36.setTickLabelInsets(rectangleInsets44);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape53 = numberAxis52.getUpArrow();
        numberAxis52.setTickMarksVisible(false);
        double double56 = numberAxis52.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis52.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis52, categoryItemRenderer58);
        java.awt.Stroke stroke60 = categoryPlot59.getDomainGridlineStroke();
        int int61 = categoryPlot59.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection62 = categoryPlot59.getLegendItems();
        boolean boolean63 = categoryPlot27.equals((java.lang.Object) categoryPlot59);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        double double71 = categoryAxis66.getCategoryEnd(0, (int) (short) 0, rectangle2D69, rectangleEdge70);
        java.lang.String str73 = categoryAxis66.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor74 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = null;
        double double79 = categoryAxis66.getCategoryJava2DCoordinate(categoryAnchor74, 64, (int) (byte) 0, rectangle2D77, rectangleEdge78);
        float float80 = categoryAxis66.getMaximumCategoryLabelWidthRatio();
        categoryPlot59.setDomainAxis(0, categoryAxis66);
        boolean boolean82 = datasetRenderingOrder0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 4.0d + "'", double45 == 4.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 8.0d + "'", double49 == 8.0d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(categoryAnchor74);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + float80 + "' != '" + 0.0f + "'", float80 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis3.setAutoRangeIncludesZero(false);
        java.lang.Object obj6 = numberAxis3.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3.getStandardTickUnits();
        numberAxis3.setTickMarksVisible(false);
        org.jfree.data.Range range10 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis17.getCategoryEnd(0, (int) (short) 0, rectangle2D20, rectangleEdge21);
        categoryAxis17.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets25.getBottom();
        double double28 = rectangleInsets25.extendHeight((double) (short) 0);
        double double30 = rectangleInsets25.calculateRightInset((double) 8);
        categoryAxis17.setTickLabelInsets(rectangleInsets25);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape34 = numberAxis33.getUpArrow();
        numberAxis33.setTickMarksVisible(false);
        double double37 = numberAxis33.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = numberAxis33.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer39);
        java.awt.Stroke stroke41 = categoryPlot40.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation42, true);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis46.setAutoRangeIncludesZero(false);
        java.awt.Color color49 = java.awt.Color.darkGray;
        numberAxis46.setAxisLinePaint((java.awt.Paint) color49);
        numberAxis46.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.axis.AxisState axisState54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        java.util.List list57 = numberAxis46.refreshTicks(graphics2D53, axisState54, rectangle2D55, rectangleEdge56);
        java.awt.Paint paint58 = numberAxis46.getTickMarkPaint();
        categoryPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis46);
        categoryPlot40.setWeight((int) (byte) -1);
        categoryPlot40.clearRangeMarkers(10);
        java.awt.Color color65 = java.awt.Color.darkGray;
        java.awt.Stroke stroke66 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color65, stroke66);
        categoryMarker67.setLabel("hi!");
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker67.setStroke(stroke70);
        java.awt.Paint paint72 = categoryMarker67.getLabelPaint();
        org.jfree.chart.util.Layer layer73 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean74 = categoryPlot40.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker67, layer73);
        boolean boolean75 = xYPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker14, layer73);
        org.jfree.chart.plot.XYPlot xYPlot76 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D77 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        xYPlot76.drawAnnotations(graphics2D77, rectangle2D78, plotRenderingInfo79);
        org.jfree.chart.axis.AxisSpace axisSpace81 = null;
        xYPlot76.setFixedDomainAxisSpace(axisSpace81);
        java.awt.Stroke stroke83 = xYPlot76.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke83);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 8.0d + "'", double28 == 8.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 8.0d + "'", double30 == 8.0d);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(layer73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(stroke83);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis13.getCategoryEnd(0, (int) (short) 0, rectangle2D16, rectangleEdge17);
        categoryAxis13.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getBottom();
        double double24 = rectangleInsets21.extendHeight((double) (short) 0);
        double double26 = rectangleInsets21.calculateRightInset((double) 8);
        categoryAxis13.setTickLabelInsets(rectangleInsets21);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape30 = numberAxis29.getUpArrow();
        numberAxis29.setTickMarksVisible(false);
        double double33 = numberAxis29.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis29.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer35);
        categoryPlot36.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot36.getRendererForDataset(categoryDataset39);
        java.lang.String str41 = categoryPlot36.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(4, axisLocation43);
        xYPlot0.setDomainAxisLocation((int) (short) 10, axisLocation43, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot0.zoomRangeAxes((double) 10L, 18.0d, plotRenderingInfo49, point2D50);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation53 = xYPlot52.getDomainAxisLocation();
        boolean boolean54 = xYPlot52.isRangeGridlinesVisible();
        boolean boolean55 = xYPlot52.isOutlineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = xYPlot52.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit58 = null;
        dateAxis57.setTickUnit(dateTickUnit58);
        java.awt.Paint paint60 = dateAxis57.getLabelPaint();
        java.awt.Paint paint61 = dateAxis57.getAxisLinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis63.setAutoRangeIncludesZero(false);
        java.awt.Color color66 = java.awt.Color.darkGray;
        numberAxis63.setAxisLinePaint((java.awt.Paint) color66);
        java.lang.Object obj68 = numberAxis63.clone();
        java.awt.Paint paint69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis63.setTickMarkPaint(paint69);
        java.text.NumberFormat numberFormat71 = null;
        numberAxis63.setNumberFormatOverride(numberFormat71);
        boolean boolean73 = numberAxis63.isAutoRange();
        java.awt.Shape shape74 = numberAxis63.getLeftArrow();
        org.jfree.data.Range range75 = numberAxis63.getDefaultAutoRange();
        org.jfree.chart.JFreeChart jFreeChart76 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent77 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis63, jFreeChart76);
        java.text.NumberFormat numberFormat78 = null;
        numberAxis63.setNumberFormatOverride(numberFormat78);
        org.jfree.chart.axis.NumberAxis numberAxis81 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis81.setUpperMargin((double) 10);
        numberAxis81.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = numberAxis81.getTickLabelInsets();
        numberAxis81.setPositiveArrowVisible(true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray90 = new org.jfree.chart.axis.ValueAxis[] { dateAxis57, numberAxis63, numberAxis81 };
        xYPlot52.setDomainAxes(valueAxisArray90);
        xYPlot0.setDomainAxes(valueAxisArray90);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.0d + "'", double24 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertNotNull(valueAxisArray90);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        double double3 = dateAxis0.getUpperBound();
        double double4 = dateAxis0.getUpperBound();
        dateAxis0.setRange((double) 4, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 1, jFreeChart1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot25.getDomainAxis(4);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot25.getOrientation();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNotNull(plotOrientation49);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) 10);
        numberAxis1.resizeRange((double) '4', (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setAutoRangeIncludesZero(false);
        java.awt.Color color12 = java.awt.Color.darkGray;
        numberAxis9.setAxisLinePaint((java.awt.Paint) color12);
        org.jfree.data.RangeType rangeType14 = numberAxis9.getRangeType();
        numberAxis1.setRangeType(rangeType14);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis1.setLabelFont(font16);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        boolean boolean4 = xYPlot0.isRangeGridlinesVisible();
        xYPlot0.setRangeCrosshairValue((-16.0d), true);
        java.awt.Paint paint8 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot25.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot25.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot25.getRangeAxisLocation((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(valueAxis47);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.lang.Object obj4 = numberAxis1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        double double10 = numberAxis1.getFixedDimension();
        boolean boolean11 = numberAxis1.isInverted();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        java.awt.Paint paint4 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getDomainAxisEdge((int) '4');
        java.awt.Stroke stroke7 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean8 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        float float2 = xYPlot1.getForegroundAlpha();
        java.awt.Color color5 = java.awt.Color.darkGray;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color5, stroke6);
        categoryMarker7.setLabel("hi!");
        categoryMarker7.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color13 = java.awt.Color.darkGray;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color13, stroke14);
        categoryMarker15.setLabel("hi!");
        java.awt.Color color19 = java.awt.Color.darkGray;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color19, stroke20);
        categoryMarker15.setStroke(stroke20);
        categoryMarker7.setStroke(stroke20);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean26 = xYPlot1.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker7, layer24, true);
        boolean boolean27 = rectangleInsets0.equals((java.lang.Object) xYPlot1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        java.awt.Paint paint5 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint8 = xYPlot7.getDomainGridlinePaint();
        java.awt.Color color10 = java.awt.Color.darkGray;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color10, stroke11);
        categoryMarker12.setLabel("hi!");
        boolean boolean15 = xYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker12);
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean18 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker12, layer16, true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        dateAxis0.setNegativeArrowVisible(true);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        double double8 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace5);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setRangeCrosshairValue((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color14, stroke15);
        categoryMarker16.setLabel("hi!");
        categoryMarker16.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color22 = java.awt.Color.darkGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color22, stroke23);
        categoryMarker24.setLabel("hi!");
        java.awt.Color color28 = java.awt.Color.darkGray;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color28, stroke29);
        categoryMarker24.setStroke(stroke29);
        categoryMarker16.setStroke(stroke29);
        numberAxis1.setAxisLineStroke(stroke29);
        numberAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        dateAxis0.setLabel("hi!");
        java.awt.Stroke stroke5 = dateAxis0.getTickMarkStroke();
        boolean boolean7 = dateAxis0.isHiddenValue(0L);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        categoryPlot25.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot25.getRendererForDataset(categoryDataset36);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryItemRenderer37);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis3.setAutoRangeIncludesZero(false);
        java.lang.Object obj6 = numberAxis3.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3.getStandardTickUnits();
        numberAxis3.setTickMarksVisible(false);
        org.jfree.data.Range range10 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3);
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize(class2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP" + "'", str1.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        java.lang.String str33 = axisLocation30.toString();
        xYPlot0.setDomainAxisLocation(500, axisLocation30);
        java.awt.Paint paint35 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        float float37 = xYPlot36.getForegroundAlpha();
        java.awt.Color color40 = java.awt.Color.darkGray;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color40, stroke41);
        categoryMarker42.setLabel("hi!");
        categoryMarker42.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color48 = java.awt.Color.darkGray;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color48, stroke49);
        categoryMarker50.setLabel("hi!");
        java.awt.Color color54 = java.awt.Color.darkGray;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color54, stroke55);
        categoryMarker50.setStroke(stroke55);
        categoryMarker42.setStroke(stroke55);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean61 = xYPlot36.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker42, layer59, true);
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        xYPlot36.setDataset(xYDataset62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        xYPlot36.drawAnnotations(graphics2D64, rectangle2D65, plotRenderingInfo66);
        java.awt.Stroke stroke68 = xYPlot36.getDomainZeroBaselineStroke();
        xYPlot0.setDomainGridlineStroke(stroke68);
        org.jfree.data.xy.XYDataset xYDataset71 = xYPlot0.getDataset(0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str33.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(xYDataset71);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot25.setWeight((int) (byte) -1);
        categoryPlot25.clearRangeMarkers(10);
        java.awt.Color color50 = java.awt.Color.darkGray;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color50, stroke51);
        categoryMarker52.setLabel("hi!");
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker52.setStroke(stroke55);
        java.awt.Paint paint57 = categoryMarker52.getLabelPaint();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean59 = categoryPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer58);
        java.awt.Paint paint60 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
        double double67 = categoryAxis62.getCategoryEnd(0, (int) (short) 0, rectangle2D65, rectangleEdge66);
        double double68 = categoryAxis62.getCategoryMargin();
        double double69 = categoryAxis62.getUpperMargin();
        categoryAxis62.setCategoryLabelPositionOffset(12);
        java.util.List list72 = categoryPlot25.getCategoriesForAxis(categoryAxis62);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier73 = categoryPlot25.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.2d + "'", double68 == 0.2d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.05d + "'", double69 == 0.05d);
        org.junit.Assert.assertNotNull(list72);
        org.junit.Assert.assertNotNull(drawingSupplier73);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = xYPlot0.getDomainAxis();
        xYPlot0.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            boolean boolean6 = xYPlot0.removeAnnotation(xYAnnotation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        float float3 = xYPlot0.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = xYPlot0.getRendererForDataset(xYDataset4);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        float float7 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis1.getCategoryEnd(0, (int) (short) 100, rectangle2D10, rectangleEdge11);
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) 0.5f);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, false);
        boolean boolean7 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset(xYDataset9);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.valueToJava2D(1.0E-8d, rectangle2D5, rectangleEdge6);
        numberAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int2 = day0.getYear();
        int int3 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot25.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29, true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getDomainGridlineStroke();
        int int59 = categoryPlot57.getWeight();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot57.getLegendItems();
        boolean boolean61 = categoryPlot25.equals((java.lang.Object) categoryPlot57);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor62 = categoryPlot25.getDomainGridlinePosition();
        java.lang.Object obj63 = null;
        boolean boolean64 = categoryPlot25.equals(obj63);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(categoryAnchor62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Color color33 = java.awt.Color.darkGray;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color33, stroke34);
        categoryMarker35.setLabel("hi!");
        java.awt.Color color39 = java.awt.Color.darkGray;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color39, stroke40);
        categoryMarker35.setStroke(stroke40);
        categoryMarker35.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint45 = categoryMarker35.getLabelPaint();
        categoryPlot25.addDomainMarker(categoryMarker35);
        int int47 = categoryPlot25.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setDomainAxisLocation(axisLocation48, false);
        org.jfree.chart.axis.AxisLocation axisLocation51 = axisLocation48.getOpposite();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        int int27 = categoryPlot25.getWeight();
        java.awt.Stroke stroke28 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent29);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        double double3 = intervalMarker2.getStartValue();
        double double4 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.Size2D size2D0 = null;
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.LEFT;
        categoryMarker6.setLabelAnchor(rectangleAnchor11);
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 100L, 18.0d, rectangleAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (short) -1, 0.2d);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        dateAxis0.setRange(0.05d, (double) 'a');
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot25.getRendererForDataset(categoryDataset28);
        java.lang.String str30 = categoryPlot25.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis34.getCategoryEnd(0, (int) (short) 0, rectangle2D37, rectangleEdge38);
        categoryAxis34.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double43 = rectangleInsets42.getBottom();
        double double45 = rectangleInsets42.extendHeight((double) (short) 0);
        double double47 = rectangleInsets42.calculateRightInset((double) 8);
        categoryAxis34.setTickLabelInsets(rectangleInsets42);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape51 = numberAxis50.getUpArrow();
        numberAxis50.setTickMarksVisible(false);
        double double54 = numberAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = numberAxis50.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        categoryPlot57.zoom(0.0d);
        categoryPlot57.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint62 = categoryPlot57.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor63 = categoryPlot57.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        categoryPlot57.setFixedDomainAxisSpace(axisSpace64, true);
        java.awt.Color color69 = java.awt.Color.darkGray;
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color69, stroke70);
        categoryMarker71.setLabel("hi!");
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker71.setStroke(stroke74);
        org.jfree.chart.util.Layer layer76 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot57.addDomainMarker((int) '4', categoryMarker71, layer76, true);
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot25.addRangeMarker(4, (org.jfree.chart.plot.Marker) categoryMarker71, layer79);
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        double double87 = categoryAxis82.getCategoryEnd(0, (int) (short) 0, rectangle2D85, rectangleEdge86);
        categoryAxis82.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets90 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double91 = rectangleInsets90.getBottom();
        double double93 = rectangleInsets90.extendHeight((double) (short) 0);
        double double95 = rectangleInsets90.calculateRightInset((double) 8);
        categoryAxis82.setTickLabelInsets(rectangleInsets90);
        categoryPlot25.setDomainAxis(categoryAxis82);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Category Plot" + "'", str30.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 8.0d + "'", double45 == 8.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(categoryAnchor63);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(layer76);
        org.junit.Assert.assertNotNull(layer79);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 4.0d + "'", double91 == 4.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 8.0d + "'", double93 == 8.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 8.0d + "'", double95 == 8.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getDomainGridlineStroke();
        int int31 = categoryPlot29.getWeight();
        java.awt.Stroke stroke32 = categoryPlot29.getDomainGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setUpperMargin((double) 10);
        int int38 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        xYPlot0.setRangeZeroBaselineVisible(false);
        xYPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        valueMarker1.setLabelFont(font51);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomRangeAxes(1.0E-8d, plotRenderingInfo10, point2D11, false);
        java.awt.Stroke stroke14 = null;
        xYPlot0.setOutlineStroke(stroke14);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot0.setDataset(xYDataset26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot0.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot0.getRenderer();
        java.awt.Font font34 = xYPlot0.getNoDataMessageFont();
        java.awt.Color color36 = java.awt.Color.darkGray;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color36, stroke37);
        categoryMarker38.setLabel("hi!");
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker38.setStroke(stroke41);
        java.awt.Paint paint43 = categoryMarker38.getLabelPaint();
        float float44 = categoryMarker38.getAlpha();
        boolean boolean45 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker38);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        categoryPlot25.configureRangeAxes();
        categoryPlot25.clearRangeMarkers(15);
        categoryPlot25.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color3, stroke4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis9.getCategoryEnd(0, (int) (short) 0, rectangle2D12, rectangleEdge13);
        categoryAxis9.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double18 = rectangleInsets17.getBottom();
        double double20 = rectangleInsets17.extendHeight((double) (short) 0);
        double double22 = rectangleInsets17.calculateRightInset((double) 8);
        categoryAxis9.setTickLabelInsets(rectangleInsets17);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape26 = numberAxis25.getUpArrow();
        numberAxis25.setTickMarksVisible(false);
        double double29 = numberAxis25.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis25.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis25, categoryItemRenderer31);
        java.awt.Stroke stroke33 = categoryPlot32.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, paint1, stroke4, (java.awt.Paint) color6, stroke33, 0.0f);
        java.lang.Object obj36 = valueMarker35.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color2, stroke3);
        categoryMarker4.setLabel("hi!");
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) categoryMarker4);
        categoryMarker4.setAlpha(0.0f);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getUpArrow();
        numberAxis1.setTickMarksVisible(false);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        double double7 = rectangleInsets6.getBottom();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot25.setWeight((int) (byte) -1);
        categoryPlot25.clearRangeMarkers(10);
        java.awt.Color color50 = java.awt.Color.darkGray;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color50, stroke51);
        categoryMarker52.setLabel("hi!");
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker52.setStroke(stroke55);
        java.awt.Paint paint57 = categoryMarker52.getLabelPaint();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean59 = categoryPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer58);
        java.awt.Paint paint60 = categoryPlot25.getOutlinePaint();
        categoryPlot25.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot25.setRowRenderingOrder(sortOrder28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.lang.Object obj34 = numberAxis31.clone();
        org.jfree.chart.event.AxisChangeListener axisChangeListener35 = null;
        numberAxis31.addChangeListener(axisChangeListener35);
        boolean boolean37 = sortOrder28.equals((java.lang.Object) numberAxis31);
        numberAxis31.resizeRange(2.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis27.getCategoryEnd(0, (int) (short) 0, rectangle2D30, rectangleEdge31);
        categoryAxis27.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double36 = rectangleInsets35.getBottom();
        double double38 = rectangleInsets35.extendHeight((double) (short) 0);
        double double40 = rectangleInsets35.calculateRightInset((double) 8);
        categoryAxis27.setTickLabelInsets(rectangleInsets35);
        xYPlot0.setAxisOffset(rectangleInsets35);
        java.lang.Object obj43 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 8.0d + "'", double38 == 8.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 8.0d + "'", double40 == 8.0d);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        double double13 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot26.getDomainAxis();
        boolean boolean28 = xYPlot26.isDomainCrosshairVisible();
        boolean boolean29 = xYPlot26.isRangeCrosshairLockedOnData();
        xYPlot26.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint34 = xYPlot33.getDomainGridlinePaint();
        java.awt.Color color36 = java.awt.Color.darkGray;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color36, stroke37);
        categoryMarker38.setLabel("hi!");
        boolean boolean41 = xYPlot33.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker38);
        categoryMarker38.setLabel("DatasetRenderingOrder.FORWARD");
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot26.addDomainMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker38, layer44, true);
        java.util.Collection collection47 = categoryPlot25.getRangeMarkers(layer44);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        xYPlot0.removeChangeListener(plotChangeListener60);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryMarker63.getLabelOffset();
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean66 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer65);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = categoryMarker63.getLabelOffset();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleInsets67);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis6.getCategoryEnd(0, (int) (short) 0, rectangle2D9, rectangleEdge10);
        categoryAxis6.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets14.getBottom();
        double double17 = rectangleInsets14.extendHeight((double) (short) 0);
        double double19 = rectangleInsets14.calculateRightInset((double) 8);
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape23 = numberAxis22.getUpArrow();
        numberAxis22.setTickMarksVisible(false);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = numberAxis22.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        categoryPlot29.zoom(0.0d);
        categoryPlot29.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint34 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace36, true);
        java.awt.Color color41 = java.awt.Color.darkGray;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color41, stroke42);
        categoryMarker43.setLabel("hi!");
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot29.addDomainMarker((int) '4', categoryMarker43, layer48, true);
        java.awt.Font font51 = categoryMarker43.getLabelFont();
        xYPlot0.setNoDataMessageFont(font51);
        java.awt.Paint paint53 = null;
        xYPlot0.setRangeTickBandPaint(paint53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            xYPlot0.handleClick(0, (int) '#', plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = xYPlot0.getAxisOffset();
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer5);
        xYPlot0.mapDatasetToRangeAxis(6, (int) (short) 10);
        java.awt.Paint paint10 = xYPlot0.getRangeCrosshairPaint();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        categoryMarker8.setKey((java.lang.Comparable) 1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis22.getCategoryEnd(0, (int) (short) 0, rectangle2D25, rectangleEdge26);
        categoryAxis22.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double31 = rectangleInsets30.getBottom();
        double double33 = rectangleInsets30.extendHeight((double) (short) 0);
        double double35 = rectangleInsets30.calculateRightInset((double) 8);
        categoryAxis22.setTickLabelInsets(rectangleInsets30);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape39 = numberAxis38.getUpArrow();
        numberAxis38.setTickMarksVisible(false);
        double double42 = numberAxis38.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis38.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis38, categoryItemRenderer44);
        categoryPlot45.zoom(0.0d);
        org.jfree.chart.util.SortOrder sortOrder48 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot45.setRowRenderingOrder(sortOrder48);
        org.jfree.data.category.CategoryDataset categoryDataset51 = categoryPlot45.getDataset((int) (byte) 10);
        categoryMarker8.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot45);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = categoryAxis54.getCategoryEnd(0, (int) (short) 0, rectangle2D57, rectangleEdge58);
        categoryAxis54.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double63 = rectangleInsets62.getBottom();
        double double65 = rectangleInsets62.extendHeight((double) (short) 0);
        double double67 = rectangleInsets62.calculateRightInset((double) 8);
        categoryAxis54.setTickLabelInsets(rectangleInsets62);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double70 = rectangleInsets69.getRight();
        categoryAxis54.setLabelInsets(rectangleInsets69);
        double double72 = categoryAxis54.getFixedDimension();
        java.util.List list73 = categoryPlot45.getCategoriesForAxis(categoryAxis54);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 4.0d + "'", double63 == 4.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 8.0d + "'", double65 == 8.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 8.0d + "'", double67 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 8.0d + "'", double70 == 8.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(list73);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis31.setMarkerBand(markerAxisBand45);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        dateAxis4.setRangeAboutValue((double) 43629L, (double) 255);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryMarker1.getLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryMarker1.notifyListeners(markerChangeEvent3);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis1.getCategoryEnd(0, (int) (short) 0, rectangle2D4, rectangleEdge5);
        categoryAxis1.setMaximumCategoryLabelLines(6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.awt.Color color11 = java.awt.Color.darkGray;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color11, stroke12);
        categoryMarker13.setLabel("hi!");
        boolean boolean16 = chartChangeEventType9.equals((java.lang.Object) categoryMarker13);
        boolean boolean17 = categoryAxis1.equals((java.lang.Object) chartChangeEventType9);
        boolean boolean19 = chartChangeEventType9.equals((java.lang.Object) 4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.awt.Stroke stroke45 = categoryPlot25.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        xYPlot0.setRangeAxis(valueAxis2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(64);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        float float3 = xYPlot0.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        xYPlot0.drawAnnotations(graphics2D4, rectangle2D5, plotRenderingInfo6);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        double double11 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setUpperMargin(0.05d);
        boolean boolean14 = xYPlot0.equals((java.lang.Object) categoryAxis5);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        try {
            java.util.List list19 = categoryAxis5.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setLabel("hi!");
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color7, stroke8);
        categoryMarker9.setLabel("hi!");
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker9.setStroke(stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryMarker9.setLabelOffset(rectangleInsets14);
        categoryMarker3.setLabelOffset(rectangleInsets14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        xYPlot0.setRangeAxis(valueAxis2);
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.brighter();
        java.awt.Color color6 = color5.darker();
        java.awt.Color color7 = color6.darker();
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        double double3 = intervalMarker2.getStartValue();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis5.getCategoryEnd(0, (int) (short) 0, rectangle2D8, rectangleEdge9);
        categoryAxis5.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.extendHeight((double) (short) 0);
        double double18 = rectangleInsets13.calculateRightInset((double) 8);
        categoryAxis5.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getUpArrow();
        numberAxis21.setTickMarksVisible(false);
        double double25 = numberAxis21.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = numberAxis21.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation30, true);
        java.lang.String str33 = axisLocation30.toString();
        xYPlot0.setDomainAxisLocation(500, axisLocation30);
        java.awt.Paint paint35 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        float float37 = xYPlot36.getForegroundAlpha();
        java.awt.Color color40 = java.awt.Color.darkGray;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color40, stroke41);
        categoryMarker42.setLabel("hi!");
        categoryMarker42.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color48 = java.awt.Color.darkGray;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color48, stroke49);
        categoryMarker50.setLabel("hi!");
        java.awt.Color color54 = java.awt.Color.darkGray;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color54, stroke55);
        categoryMarker50.setStroke(stroke55);
        categoryMarker42.setStroke(stroke55);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean61 = xYPlot36.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker42, layer59, true);
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        xYPlot36.setDataset(xYDataset62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        xYPlot36.drawAnnotations(graphics2D64, rectangle2D65, plotRenderingInfo66);
        java.awt.Stroke stroke68 = xYPlot36.getDomainZeroBaselineStroke();
        xYPlot0.setDomainGridlineStroke(stroke68);
        org.jfree.chart.axis.ValueAxis valueAxis71 = xYPlot0.getRangeAxis(0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str33.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(valueAxis71);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        xYPlot0.setDomainCrosshairValue((double) (-1L), false);
        double double29 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        boolean boolean11 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = null;
        dateAxis0.setTickUnit(dateTickUnit1);
        double double3 = dateAxis0.getUpperBound();
        double double4 = dateAxis0.getUpperBound();
        dateAxis0.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setUpperBound((double) 9);
        numberAxis1.setPositiveArrowVisible(true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Paint paint12 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.lang.Object obj9 = numberAxis1.clone();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers(layer3);
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 1.0E-8d);
        boolean boolean8 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker7);
        intervalMarker7.setLabel("TextAnchor.TOP_CENTER");
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        int int3 = xYPlot0.indexOf(xYDataset2);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        xYPlot0.setRangeGridlinePaint(paint4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        java.awt.Paint paint7 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        xYPlot0.removeChangeListener(plotChangeListener60);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryMarker63.getLabelOffset();
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean66 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer65);
        java.awt.Stroke stroke67 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot31.getDomainAxisLocation();
        boolean boolean33 = xYPlot31.isRangeGridlinesVisible();
        boolean boolean34 = xYPlot31.isOutlineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = xYPlot31.getOrientation();
        categoryPlot25.setOrientation(plotOrientation35);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(plotOrientation35);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot0.getDomainAxisLocation((int) (byte) -1);
        java.util.List list28 = xYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Color color1 = java.awt.Color.darkGray;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = categoryMarker3.getStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = categoryAxis1.clone();
        double double3 = categoryAxis1.getFixedDimension();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setLabelFont(font4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis7.getCategoryEnd(0, (int) (short) 0, rectangle2D10, rectangleEdge11);
        java.lang.String str14 = categoryAxis7.getCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis7.getCategoryJava2DCoordinate(categoryAnchor15, 64, (int) (byte) 0, rectangle2D18, rectangleEdge19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        boolean boolean22 = categoryAnchor15.equals((java.lang.Object) color21);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis28.getCategoryEnd(0, (int) (short) 0, rectangle2D31, rectangleEdge32);
        categoryAxis28.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double37 = rectangleInsets36.getBottom();
        double double39 = rectangleInsets36.extendHeight((double) (short) 0);
        double double41 = rectangleInsets36.calculateRightInset((double) 8);
        categoryAxis28.setTickLabelInsets(rectangleInsets36);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape45 = numberAxis44.getUpArrow();
        numberAxis44.setTickMarksVisible(false);
        double double48 = numberAxis44.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = numberAxis44.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer50);
        java.awt.Stroke stroke52 = categoryPlot51.getDomainGridlineStroke();
        int int53 = categoryPlot51.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot51.getRangeAxisEdge();
        try {
            double double55 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor15, (int) (byte) -1, 7, rectangle2D25, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 8.0d + "'", double39 == 8.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 8.0d + "'", double41 == 8.0d);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        int int30 = categoryPlot25.getRangeAxisCount();
        java.util.List list31 = categoryPlot25.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot25.zoomDomainAxes((double) (byte) 1, plotRenderingInfo33, point2D34, true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(15, axisLocation38, true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(list31);
        org.junit.Assert.assertNotNull(axisLocation38);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        java.awt.Image image2 = null;
        xYPlot0.setBackgroundImage(image2);
        java.awt.Color color6 = java.awt.Color.darkGray;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color6, stroke7);
        categoryMarker8.setLabel("hi!");
        categoryMarker8.setKey((java.lang.Comparable) 0.2d);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = xYPlot0.removeDomainMarker((int) '#', (org.jfree.chart.plot.Marker) categoryMarker8, layer15, true);
        int int18 = xYPlot0.getDatasetCount();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis22.getCategoryEnd(0, (int) (short) 0, rectangle2D25, rectangleEdge26);
        categoryAxis22.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double31 = rectangleInsets30.getBottom();
        double double33 = rectangleInsets30.extendHeight((double) (short) 0);
        double double35 = rectangleInsets30.calculateRightInset((double) 8);
        categoryAxis22.setTickLabelInsets(rectangleInsets30);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape39 = numberAxis38.getUpArrow();
        numberAxis38.setTickMarksVisible(false);
        double double42 = numberAxis38.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis38.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis38, categoryItemRenderer44);
        categoryPlot45.zoom(0.0d);
        categoryPlot45.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint50 = categoryPlot45.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = categoryPlot45.getDomainGridlinePosition();
        java.awt.Color color53 = java.awt.Color.darkGray;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color53, stroke54);
        categoryMarker55.setLabel("hi!");
        java.awt.Color color59 = java.awt.Color.darkGray;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color59, stroke60);
        categoryMarker55.setStroke(stroke60);
        categoryMarker55.setKey((java.lang.Comparable) 10.0f);
        java.awt.Paint paint65 = categoryMarker55.getLabelPaint();
        categoryPlot45.addDomainMarker(categoryMarker55);
        org.jfree.chart.axis.ValueAxis valueAxis67 = categoryPlot45.getRangeAxis();
        xYPlot0.setDomainAxis((int) (short) 1, valueAxis67);
        try {
            valueAxis67.zoomRange((double) '4', 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (54.6) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(categoryAnchor51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxis67);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        categoryPlot25.zoom(0.0d);
        categoryPlot25.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace32, true);
        categoryPlot25.mapDatasetToRangeAxis((int) 'a', (int) (byte) 10);
        java.awt.Paint paint38 = categoryPlot25.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Color color4 = java.awt.Color.darkGray;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis1.setTickMarkPaint(paint7);
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis1.isAutoRange();
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        try {
            numberAxis1.zoomRange((double) (byte) 1, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getDomainAxisLocation();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean3 = xYPlot0.isOutlineVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            xYPlot0.drawOutline(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        float float1 = xYPlot0.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color4, stroke5);
        categoryMarker6.setLabel("hi!");
        categoryMarker6.setKey((java.lang.Comparable) 0.2d);
        java.awt.Color color12 = java.awt.Color.darkGray;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setLabel("hi!");
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0, (java.awt.Paint) color18, stroke19);
        categoryMarker14.setStroke(stroke19);
        categoryMarker6.setStroke(stroke19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = xYPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker6, layer23, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setAutoRangeIncludesZero(false);
        java.awt.Color color30 = java.awt.Color.darkGray;
        numberAxis27.setAxisLinePaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis34.setAutoRangeIncludesZero(false);
        java.awt.Color color37 = java.awt.Color.darkGray;
        numberAxis34.setAxisLinePaint((java.awt.Paint) color37);
        java.lang.Object obj39 = numberAxis34.clone();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        numberAxis34.setTickMarkPaint(paint40);
        java.text.NumberFormat numberFormat42 = null;
        numberAxis34.setNumberFormatOverride(numberFormat42);
        boolean boolean44 = numberAxis34.isAutoRange();
        java.awt.Shape shape45 = numberAxis34.getLeftArrow();
        org.jfree.data.Range range46 = numberAxis34.getDefaultAutoRange();
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis34.setLeftArrow(shape47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis34 };
        xYPlot0.setDomainAxes(valueAxisArray49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setAutoRangeIncludesZero(false);
        java.lang.Object obj55 = numberAxis52.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = numberAxis52.getStandardTickUnits();
        boolean boolean57 = numberAxis52.isTickMarksVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        xYPlot0.removeChangeListener(plotChangeListener60);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryMarker63.getLabelOffset();
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean66 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer65);
        categoryMarker63.setLabel("TextAnchor.HALF_ASCENT_CENTER");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        xYPlot0.drawAnnotations(graphics2D1, rectangle2D2, plotRenderingInfo3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis2.getCategoryEnd(0, (int) (short) 0, rectangle2D5, rectangleEdge6);
        categoryAxis2.setMaximumCategoryLabelLines(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.extendHeight((double) (short) 0);
        double double15 = rectangleInsets10.calculateRightInset((double) 8);
        categoryAxis2.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape19 = numberAxis18.getUpArrow();
        numberAxis18.setTickMarksVisible(false);
        double double22 = numberAxis18.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis18.getTickLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis18, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        java.awt.Color color34 = java.awt.Color.darkGray;
        numberAxis31.setAxisLinePaint((java.awt.Paint) color34);
        numberAxis31.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis31.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis31.getTickMarkPaint();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.Plot plot45 = numberAxis31.getPlot();
        java.text.NumberFormat numberFormat46 = null;
        numberAxis31.setNumberFormatOverride(numberFormat46);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(plot45);
    }
}

